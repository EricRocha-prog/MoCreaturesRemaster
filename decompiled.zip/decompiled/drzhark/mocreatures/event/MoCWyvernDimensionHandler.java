/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.Registry
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.Mob
 *  net.minecraft.world.entity.player.Player
 *  net.minecraftforge.event.entity.living.MobSpawnEvent$FinalizeSpawn
 *  net.minecraftforge.event.server.ServerAboutToStartEvent
 *  net.minecraftforge.eventbus.api.Event$Result
 *  net.minecraftforge.eventbus.api.EventPriority
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 */
package drzhark.mocreatures.event;

import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.init.MoCEntities;
import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.living.MobSpawnEvent;
import net.minecraftforge.event.server.ServerAboutToStartEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid="mocreatures")
public class MoCWyvernDimensionHandler {
    private static final Supplier<List<EntityType<?>>> ALLOWED_ENTITIES_SUPPLIER = () -> Arrays.asList((EntityType)MoCEntities.WYVERN.get(), (EntityType)MoCEntities.BUNNY.get(), (EntityType)MoCEntities.SNAKE.get(), (EntityType)MoCEntities.FILCH_LIZARD.get(), (EntityType)MoCEntities.DRAGONFLY.get(), (EntityType)MoCEntities.FIREFLY.get(), (EntityType)MoCEntities.GRASSHOPPER.get());

    private static List<EntityType<?>> getAllowedEntities() {
        return ALLOWED_ENTITIES_SUPPLIER.get();
    }

    @SubscribeEvent(priority=EventPriority.LOW)
    public static void onCheckSpawn(MobSpawnEvent.FinalizeSpawn event) {
        Mob entity = event.getEntity();
        if (entity.m_9236_() != null && entity.m_9236_().m_46472_().m_135782_().toString().equals("mocreatures:wyvernlairworld")) {
            if (MoCreatures.proxy.debug) {
                MoCreatures.LOGGER.info("MoCWyvernDimensionHandler: Checking spawn for {} in Wyvern dimension", (Object)entity.m_6095_().m_20675_());
            }
            if (MoCWyvernDimensionHandler.getAllowedEntities().contains(entity.m_6095_())) {
                if (MoCreatures.proxy.debug) {
                    MoCreatures.LOGGER.info("MoCWyvernDimensionHandler: Allowing {} to spawn in Wyvern dimension", (Object)entity.m_6095_().m_20675_());
                }
                event.setResult(Event.Result.ALLOW);
                return;
            }
            if (entity instanceof Player) {
                event.setResult(Event.Result.DEFAULT);
                return;
            }
            if (MoCreatures.proxy.debug) {
                MoCreatures.LOGGER.info("MoCWyvernDimensionHandler: Non-allowed entity {} attempted to spawn, letting JSON modifiers handle it", (Object)entity.m_6095_().m_20675_());
            }
            event.setResult(Event.Result.DEFAULT);
        }
    }

    @SubscribeEvent
    public static void onServerAboutToStart(ServerAboutToStartEvent event) {
        MoCreatures.LOGGER.info("Adding wyvern island features to biomes directly");
        Registry biomeRegistry = event.getServer().m_206579_().m_175515_(Registries.f_256952_);
        ResourceKey[] biomeKeys = new ResourceKey[]{ResourceKey.m_135785_((ResourceKey)Registries.f_256952_, (ResourceLocation)new ResourceLocation("mocreatures", "wyvernlairlands")), ResourceKey.m_135785_((ResourceKey)Registries.f_256952_, (ResourceLocation)new ResourceLocation("mocreatures", "wyvernlairlandsforest")), ResourceKey.m_135785_((ResourceKey)Registries.f_256952_, (ResourceLocation)new ResourceLocation("mocreatures", "wyvernlair_mountains")), ResourceKey.m_135785_((ResourceKey)Registries.f_256952_, (ResourceLocation)new ResourceLocation("mocreatures", "wyvernlair_desertlands"))};
        for (ResourceKey biomeKey : biomeKeys) {
            MoCreatures.LOGGER.info("Attempting to add wyvern islands to biome: {}", (Object)biomeKey.m_135782_());
            if (biomeRegistry.m_142003_(ResourceKey.m_135785_((ResourceKey)Registries.f_256952_, (ResourceLocation)biomeKey.m_135782_()))) {
                MoCreatures.LOGGER.info("Found biome {} in registry", (Object)biomeKey.m_135782_());
                continue;
            }
            MoCreatures.LOGGER.error("Could not find biome {} in registry", (Object)biomeKey.m_135782_());
        }
        MoCreatures.LOGGER.info("Wyvern island feature registration complete");
        MoCreatures.LOGGER.info("Allowed entities in Wyvern dimension:");
        for (EntityType entityType : MoCWyvernDimensionHandler.getAllowedEntities()) {
            MoCreatures.LOGGER.info("  - {}", (Object)EntityType.m_20613_((EntityType)entityType));
        }
    }
}

