/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.particle.SpriteSet
 *  net.minecraft.core.particles.ParticleType
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.client.event.RegisterParticleProvidersEvent
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber$Bus
 */
package drzhark.mocreatures.event;

import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.client.renderer.fx.MoCParticles;
import drzhark.mocreatures.client.renderer.fx.impl.MoCEntityFXStar;
import drzhark.mocreatures.client.renderer.fx.impl.MoCEntityFXUndead;
import drzhark.mocreatures.client.renderer.fx.impl.MoCEntityFXVacuum;
import drzhark.mocreatures.client.renderer.fx.impl.MoCEntityFXVanish;
import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.core.particles.ParticleType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid="mocreatures", value={Dist.CLIENT}, bus=Mod.EventBusSubscriber.Bus.MOD)
public class MoCClientEvents {
    public static SpriteSet UNDEAD_SPRITE_SET;
    public static SpriteSet VANISH_SPRITE_SET;
    public static SpriteSet STAR_SPRITE_SET;
    public static SpriteSet VACUUM_SPRITE_SET;

    @SubscribeEvent
    public static void onRegisterParticleProviders(RegisterParticleProvidersEvent event) {
        try {
            Minecraft.m_91087_().f_91061_.m_107378_((ParticleType)MoCParticles.UNDEAD_FX.get(), spriteSet -> {
                UNDEAD_SPRITE_SET = spriteSet;
                return new MoCEntityFXUndead.Factory(spriteSet);
            });
            Minecraft.m_91087_().f_91061_.m_107378_((ParticleType)MoCParticles.VANISH_FX.get(), spriteSet -> {
                VANISH_SPRITE_SET = spriteSet;
                return new MoCEntityFXVanish.Provider(spriteSet);
            });
            Minecraft.m_91087_().f_91061_.m_107378_((ParticleType)MoCParticles.STAR_FX.get(), spriteSet -> {
                STAR_SPRITE_SET = spriteSet;
                return new MoCEntityFXStar.Factory(spriteSet);
            });
            Minecraft.m_91087_().f_91061_.m_107378_((ParticleType)MoCParticles.VACUUM_FX.get(), spriteSet -> {
                VACUUM_SPRITE_SET = spriteSet;
                return new MoCEntityFXVacuum.Factory(spriteSet);
            });
            MoCreatures.LOGGER.info("Mo'Creatures particle providers registered successfully");
        }
        catch (Exception e) {
            MoCreatures.LOGGER.error("Error registering Mo'Creatures particle providers: " + e.getMessage(), (Throwable)e);
        }
    }
}

