/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.FriendlyByteBuf
 *  net.minecraft.world.entity.Entity
 *  net.minecraftforge.network.NetworkEvent$Context
 */
package drzhark.mocreatures.network.message;

import drzhark.mocreatures.entity.IMoCEntity;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.network.NetworkEvent;

public class MoCMessageEntityJump {
    public MoCMessageEntityJump() {
    }

    public void encode(FriendlyByteBuf buffer) {
    }

    public MoCMessageEntityJump(FriendlyByteBuf buffer) {
    }

    public static void onMessage(MoCMessageEntityJump message, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            Entity vehicle;
            if (((NetworkEvent.Context)ctx.get()).getSender() != null && (vehicle = ((NetworkEvent.Context)ctx.get()).getSender().m_20202_()) instanceof IMoCEntity) {
                ((IMoCEntity)vehicle).makeEntityJump();
            }
        });
        ctx.get().setPacketHandled(true);
    }

    public String toString() {
        return "MoCMessageEntityJump";
    }
}

