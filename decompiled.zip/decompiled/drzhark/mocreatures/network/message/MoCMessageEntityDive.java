/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.FriendlyByteBuf
 *  net.minecraftforge.network.NetworkEvent$Context
 */
package drzhark.mocreatures.network.message;

import drzhark.mocreatures.entity.IMoCEntity;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

public class MoCMessageEntityDive {
    public MoCMessageEntityDive() {
    }

    public void encode(FriendlyByteBuf buffer) {
    }

    public MoCMessageEntityDive(FriendlyByteBuf buffer) {
    }

    public static void onMessage(MoCMessageEntityDive message, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            if (((NetworkEvent.Context)ctx.get()).getSender() != null && ((NetworkEvent.Context)ctx.get()).getSender().m_20202_() instanceof IMoCEntity) {
                ((IMoCEntity)((NetworkEvent.Context)ctx.get()).getSender().m_20202_()).makeEntityDive();
            }
        });
        ctx.get().setPacketHandled(true);
    }
}

