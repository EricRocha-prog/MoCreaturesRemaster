/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.screens.Screen
 *  net.minecraft.network.FriendlyByteBuf
 *  net.minecraft.world.entity.Entity
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  net.minecraftforge.fml.DistExecutor
 *  net.minecraftforge.network.NetworkEvent$Context
 */
package drzhark.mocreatures.network.message;

import drzhark.mocreatures.client.gui.MoCGUIEntityNamer;
import drzhark.mocreatures.entity.IMoCEntity;
import java.util.function.Supplier;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

public class MoCMessageNameGUI {
    public int entityId;

    public MoCMessageNameGUI() {
    }

    public MoCMessageNameGUI(int entityId) {
        this.entityId = entityId;
    }

    public void encode(FriendlyByteBuf buffer) {
        buffer.writeInt(this.entityId);
    }

    public MoCMessageNameGUI(FriendlyByteBuf buffer) {
        this.entityId = buffer.readInt();
    }

    public static void onMessage(MoCMessageNameGUI message, Supplier<NetworkEvent.Context> ctx) {
        if (((Boolean)DistExecutor.unsafeRunForDist(() -> () -> MoCMessageNameGUI.lambda$onMessage$1((Supplier)ctx, message), () -> () -> false)).booleanValue()) {
            // empty if block
        }
        ctx.get().setPacketHandled(true);
    }

    @OnlyIn(value=Dist.CLIENT)
    private static void handleClient(MoCMessageNameGUI message) {
        Minecraft mc = Minecraft.m_91087_();
        if (mc == null || mc.f_91074_ == null || mc.f_91073_ == null) {
            return;
        }
        Entity ent = mc.f_91073_.m_6815_(message.entityId);
        if (ent instanceof IMoCEntity) {
            IMoCEntity mocEntity = (IMoCEntity)ent;
            mc.m_91152_((Screen)new MoCGUIEntityNamer(mocEntity, mocEntity.getPetName()));
        }
    }

    public String toString() {
        return "MoCMessageNameGUI - entityId: " + this.entityId;
    }

    private static /* synthetic */ Boolean lambda$onMessage$1(Supplier ctx, MoCMessageNameGUI message) {
        ((NetworkEvent.Context)ctx.get()).enqueueWork(() -> MoCMessageNameGUI.handleClient(message));
        return true;
    }
}

