/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.network.FriendlyByteBuf
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.Mob
 *  net.minecraftforge.network.NetworkEvent$Context
 */
package drzhark.mocreatures.network.message;

import java.util.function.Supplier;
import net.minecraft.client.Minecraft;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraftforge.network.NetworkEvent;

public class MoCMessageHealth {
    public int entityId;
    public float health;

    public MoCMessageHealth(int entityId, float health) {
        this.entityId = entityId;
        this.health = health;
    }

    public void encode(FriendlyByteBuf buffer) {
        buffer.writeInt(this.entityId);
        buffer.writeFloat(this.health);
    }

    public MoCMessageHealth(FriendlyByteBuf buffer) {
        this.entityId = buffer.readInt();
        this.health = buffer.readFloat();
    }

    public static void onMessage(MoCMessageHealth message, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            Entity entity;
            Minecraft minecraft = Minecraft.m_91087_();
            if (minecraft.f_91073_ != null && (entity = minecraft.f_91073_.m_6815_(message.entityId)) instanceof Mob) {
                Mob mob = (Mob)entity;
                mob.m_21153_(message.health);
            }
        });
        ctx.get().setPacketHandled(true);
    }

    public String toString() {
        return String.format("MoCMessageHealth - entityId:%s, health:%s", this.entityId, Float.valueOf(this.health));
    }
}

