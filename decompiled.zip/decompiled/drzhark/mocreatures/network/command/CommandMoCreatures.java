/*
 * Decompiled with CFR 0.152.
 */
package drzhark.mocreatures.network.command;

public class CommandMoCreatures {
}

