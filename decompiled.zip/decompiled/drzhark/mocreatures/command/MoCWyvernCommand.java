/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.CommandDispatcher
 *  net.minecraft.commands.CommandSourceStack
 */
package drzhark.mocreatures.command;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;

public class MoCWyvernCommand {
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
    }
}

