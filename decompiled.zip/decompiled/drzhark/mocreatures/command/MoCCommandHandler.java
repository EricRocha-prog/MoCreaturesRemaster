/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.CommandDispatcher
 *  net.minecraft.commands.CommandSourceStack
 *  net.minecraftforge.event.RegisterCommandsEvent
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package drzhark.mocreatures.command;

import com.mojang.brigadier.CommandDispatcher;
import drzhark.mocreatures.command.CommandSpawnMoCHorse;
import drzhark.mocreatures.command.MoCWyvernCommand;
import net.minecraft.commands.CommandSourceStack;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod.EventBusSubscriber(modid="mocreatures")
public class MoCCommandHandler {
    private static final Logger LOGGER = LogManager.getLogger();

    @SubscribeEvent
    public static void registerCommands(RegisterCommandsEvent event) {
        LOGGER.info("MoCreatures registering commands");
        CommandDispatcher dispatcher = event.getDispatcher();
        try {
            LOGGER.info("Registering MoCreatures commands");
            MoCWyvernCommand.register((CommandDispatcher<CommandSourceStack>)dispatcher);
            CommandSpawnMoCHorse.register((CommandDispatcher<CommandSourceStack>)dispatcher);
        }
        catch (Exception e) {
            LOGGER.error("Error registering MoCreatures commands", (Throwable)e);
        }
    }
}

