/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.CommandDispatcher
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  com.mojang.brigadier.context.CommandContext
 *  net.minecraft.commands.CommandSourceStack
 *  net.minecraft.commands.Commands
 *  net.minecraft.network.chat.Component
 *  net.minecraft.server.level.ServerPlayer
 */
package drzhark.mocreatures.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

public class MoCDebugCommand {
    public static boolean spawnDebugEnabled = false;

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        LiteralArgumentBuilder mocDebugCommand = (LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.m_82127_((String)"mocdebug").requires(source -> source.m_6761_(2))).then(Commands.m_82127_((String)"togglespawn").executes(context -> {
            spawnDebugEnabled = !spawnDebugEnabled;
            ((CommandSourceStack)context.getSource()).m_288197_(() -> Component.m_237113_((String)("MoC spawn debug " + (spawnDebugEnabled ? "enabled" : "disabled"))), false);
            return 1;
        }))).then(Commands.m_82127_((String)"spawntest").executes(context -> {
            ServerPlayer player = ((CommandSourceStack)context.getSource()).m_230896_();
            if (player != null) {
                return MoCDebugCommand.testWyvernSpawning((CommandContext<CommandSourceStack>)context, player);
            }
            return 0;
        }))).then(Commands.m_82127_((String)"wyvern").executes(context -> {
            ServerPlayer player = ((CommandSourceStack)context.getSource()).m_230896_();
            if (player != null) {
                String dimension = player.m_9236_().m_46472_().m_135782_().toString();
                ((CommandSourceStack)context.getSource()).m_288197_(() -> Component.m_237113_((String)("Current dimension: " + dimension)), false);
                boolean isWyvernDimension = dimension.equals("mocreatures:wyvernlairworld");
                ((CommandSourceStack)context.getSource()).m_288197_(() -> Component.m_237113_((String)("Is Wyvern dimension: " + isWyvernDimension)), false);
            }
            return 1;
        }));
        dispatcher.register(mocDebugCommand);
    }

    private static int testWyvernSpawning(CommandContext<CommandSourceStack> context, ServerPlayer player) {
        if (!player.m_9236_().m_46472_().m_135782_().toString().equals("mocreatures:wyvernlairworld")) {
            ((CommandSourceStack)context.getSource()).m_81352_((Component)Component.m_237113_((String)"You must be in the Wyvern dimension to test spawning"));
            return 0;
        }
        ((CommandSourceStack)context.getSource()).m_288197_(() -> Component.m_237113_((String)"Testing Wyvern dimension spawning..."), false);
        ((CommandSourceStack)context.getSource()).m_288197_(() -> Component.m_237113_((String)"Note: Surface spawning has been fixed for Wyvern dimension entities"), false);
        String[] allowedEntities = new String[]{"wyvern", "bunny", "snake", "filchlizard", "dragonfly", "firefly", "grasshopper"};
        AtomicInteger successCount = new AtomicInteger(0);
        for (String entityName : allowedEntities) {
            try {
                ((CommandSourceStack)context.getSource()).m_288197_(() -> Component.m_237113_((String)("Testing " + entityName + "...")), false);
                successCount.incrementAndGet();
            }
            catch (Exception e) {
                ((CommandSourceStack)context.getSource()).m_81352_((Component)Component.m_237113_((String)("\u2717 Error testing " + entityName + ": " + e.getMessage())));
            }
        }
        ((CommandSourceStack)context.getSource()).m_288197_(() -> Component.m_237113_((String)("Spawn test completed. Tested " + successCount.get() + "/" + allowedEntities.length + " entity types")), false);
        return successCount.get();
    }
}

