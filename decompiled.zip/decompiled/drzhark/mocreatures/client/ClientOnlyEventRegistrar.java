/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.common.MinecraftForge
 */
package drzhark.mocreatures.client;

import drzhark.mocreatures.client.MoCKeyHandler;
import drzhark.mocreatures.event.MoCEventHooksClient;
import net.minecraftforge.common.MinecraftForge;

public class ClientOnlyEventRegistrar {
    public static void registerClientEvents() {
        MinecraftForge.EVENT_BUS.register((Object)new MoCEventHooksClient());
        MinecraftForge.EVENT_BUS.register((Object)new MoCKeyHandler());
    }
}

