/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.InputConstants$Type
 *  net.minecraft.client.KeyMapping
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  net.minecraftforge.client.event.RegisterKeyMappingsEvent
 *  net.minecraftforge.event.TickEvent$Phase
 *  net.minecraftforge.event.TickEvent$PlayerTickEvent
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 */
package drzhark.mocreatures.client;

import com.mojang.blaze3d.platform.InputConstants;
import drzhark.mocreatures.entity.IMoCEntity;
import drzhark.mocreatures.network.MoCMessageHandler;
import drzhark.mocreatures.network.message.MoCMessageEntityDive;
import drzhark.mocreatures.network.message.MoCMessageEntityJump;
import drzhark.mocreatures.proxy.MoCProxyClient;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@OnlyIn(value=Dist.CLIENT)
@Mod.EventBusSubscriber(modid="mocreatures", value={Dist.CLIENT})
public class MoCKeyHandler {
    public static KeyMapping diveBinding = new KeyMapping("MoCreatures Dive", InputConstants.Type.KEYSYM, 90, "key.categories.movement");

    @SubscribeEvent
    public static void registerKeyMappings(RegisterKeyMappingsEvent event) {
        event.register(diveBinding);
    }

    @SubscribeEvent
    public static void onInput(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) {
            return;
        }
        boolean kbJump = MoCProxyClient.mc.f_91066_.f_92089_.m_90857_();
        boolean kbDive = diveBinding.m_90857_();
        if (kbJump && e.player.m_20202_() != null && e.player.m_20202_() instanceof IMoCEntity) {
            ((IMoCEntity)e.player.m_20202_()).makeEntityJump();
            MoCMessageHandler.INSTANCE.sendToServer((Object)new MoCMessageEntityJump());
        }
        if (kbDive && e.player.m_20202_() != null && e.player.m_20202_() instanceof IMoCEntity) {
            ((IMoCEntity)e.player.m_20202_()).makeEntityDive();
            MoCMessageHandler.INSTANCE.sendToServer((Object)new MoCMessageEntityDive());
        }
    }
}

