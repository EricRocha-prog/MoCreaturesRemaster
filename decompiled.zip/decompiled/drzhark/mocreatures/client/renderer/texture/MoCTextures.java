/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap
 *  net.minecraft.resources.ResourceLocation
 */
package drzhark.mocreatures.client.renderer.texture;

import drzhark.mocreatures.proxy.MoCProxy;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import net.minecraft.resources.ResourceLocation;

public class MoCTextures {
    private static final Object2ObjectOpenHashMap<String, ResourceLocation> RESOURCE_CACHE = new Object2ObjectOpenHashMap();

    public ResourceLocation getArmorTexture(String texture) {
        return this.getTexture(MoCProxy.ARMOR_TEXTURE, texture);
    }

    public ResourceLocation getBlockTexture(String texture) {
        return this.getTexture(MoCProxy.BLOCK_TEXTURE, texture);
    }

    public ResourceLocation getItemTexture(String texture) {
        return this.getTexture(MoCProxy.ITEM_TEXTURE, texture);
    }

    public ResourceLocation getModelTexture(String texture) {
        return this.getTexture(MoCProxy.MODEL_TEXTURE, texture);
    }

    public ResourceLocation getGuiTexture(String texture) {
        return this.getTexture(MoCProxy.GUI_TEXTURE, texture);
    }

    public ResourceLocation getMiscTexture(String texture) {
        return this.getTexture(MoCProxy.MISC_TEXTURE, texture);
    }

    public ResourceLocation getTexture(String category, String texture) {
        ResourceLocation resourceLocation = (ResourceLocation)RESOURCE_CACHE.get((Object)texture);
        if (resourceLocation == null) {
            resourceLocation = new ResourceLocation("mocreatures:" + category + texture);
            RESOURCE_CACHE.put((Object)texture, (Object)resourceLocation);
        }
        return resourceLocation;
    }
}

