/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  net.minecraft.core.particles.ParticleType
 *  net.minecraft.core.particles.SimpleParticleType
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber$Bus
 *  net.minecraftforge.registries.DeferredRegister
 *  net.minecraftforge.registries.ForgeRegistries
 *  net.minecraftforge.registries.IForgeRegistry
 *  net.minecraftforge.registries.RegistryObject
 */
package drzhark.mocreatures.client.renderer.fx;

import com.mojang.serialization.Codec;
import drzhark.mocreatures.client.renderer.fx.data.StarParticleData;
import drzhark.mocreatures.client.renderer.fx.data.VacuumParticleData;
import drzhark.mocreatures.client.renderer.fx.data.VanishParticleData;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.RegistryObject;

@Mod.EventBusSubscriber(modid="mocreatures", bus=Mod.EventBusSubscriber.Bus.MOD)
public class MoCParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES = DeferredRegister.create((IForgeRegistry)ForgeRegistries.PARTICLE_TYPES, (String)"mocreatures");
    public static final RegistryObject<SimpleParticleType> UNDEAD_FX = PARTICLES.register("undead_fx", () -> new SimpleParticleType(false));
    public static final RegistryObject<ParticleType<VanishParticleData>> VANISH_FX = PARTICLES.register("vanish_fx", () -> new ParticleType<VanishParticleData>(false, VanishParticleData.DESERIALIZER){

        public Codec<VanishParticleData> m_7652_() {
            return Codec.unit((Object)new VanishParticleData(1.0f, 1.0f, 1.0f, false));
        }
    });
    public static final RegistryObject<ParticleType<StarParticleData>> STAR_FX = PARTICLES.register("star_fx", () -> new ParticleType<StarParticleData>(false, StarParticleData.DESERIALIZER){

        public Codec<StarParticleData> m_7652_() {
            return Codec.unit((Object)new StarParticleData(1.0f, 1.0f, 1.0f));
        }
    });
    public static final RegistryObject<ParticleType<VacuumParticleData>> VACUUM_FX = PARTICLES.register("vacuum_fx", () -> new ParticleType<VacuumParticleData>(false, VacuumParticleData.DESERIALIZER){

        public Codec<VacuumParticleData> m_7652_() {
            return Codec.unit((Object)new VacuumParticleData(1.0f, 1.0f, 1.0f));
        }
    });
}

