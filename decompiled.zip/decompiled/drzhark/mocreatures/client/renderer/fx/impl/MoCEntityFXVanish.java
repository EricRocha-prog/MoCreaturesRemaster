/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.multiplayer.ClientLevel
 *  net.minecraft.client.particle.Particle
 *  net.minecraft.client.particle.ParticleProvider
 *  net.minecraft.client.particle.ParticleRenderType
 *  net.minecraft.client.particle.SpriteSet
 *  net.minecraft.client.particle.TextureSheetParticle
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.renderer.fx.impl;

import drzhark.mocreatures.client.renderer.fx.data.VanishParticleData;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCEntityFXVanish
extends TextureSheetParticle {
    private final double portalPosX;
    private final double portalPosY;
    private final double portalPosZ;
    private final boolean implode;

    public MoCEntityFXVanish(ClientLevel world, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed, float red, float green, float blue, boolean implode, SpriteSet spriteSet) {
        super(world, x, y, z, 0.0, 0.0, 0.0);
        this.f_107215_ = xSpeed;
        this.f_107216_ = ySpeed * 5.0;
        this.f_107217_ = zSpeed;
        this.portalPosX = this.f_107212_ = x;
        this.portalPosY = this.f_107213_ = y;
        this.portalPosZ = this.f_107214_ = z;
        this.implode = implode;
        this.f_107225_ = (int)(Math.random() * 10.0) + 70;
        this.f_107227_ = red;
        this.f_107228_ = green;
        this.f_107229_ = blue;
        this.f_107230_ = 1.0f;
        this.m_108339_(spriteSet);
    }

    public void m_5989_() {
        float var1;
        this.f_107209_ = this.f_107212_;
        this.f_107210_ = this.f_107213_;
        this.f_107211_ = this.f_107214_;
        int speeder = this.implode ? this.f_107225_ / 2 : 0;
        float sizeExp = this.implode ? 5.0f : 2.0f;
        float var2 = var1 = (float)(this.f_107224_ + speeder) / (float)this.f_107225_;
        var1 = -var1 + var1 * var1 * sizeExp;
        var1 = 1.0f - var1;
        this.f_107212_ = this.portalPosX + this.f_107215_ * (double)var1;
        this.f_107213_ = this.portalPosY + this.f_107216_ * (double)var1 + (double)(1.0f - var2);
        this.f_107214_ = this.portalPosZ + this.f_107217_ * (double)var1;
        if (this.f_107224_++ >= this.f_107225_) {
            this.m_107274_();
        }
    }

    public ParticleRenderType m_7556_() {
        return ParticleRenderType.f_107432_;
    }

    @OnlyIn(value=Dist.CLIENT)
    public static class Provider
    implements ParticleProvider<VanishParticleData> {
        private final SpriteSet spriteSet;

        public Provider(SpriteSet sprite) {
            this.spriteSet = sprite;
        }

        public Particle createParticle(VanishParticleData data, ClientLevel world, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
            return new MoCEntityFXVanish(world, x, y, z, xSpeed, ySpeed, zSpeed, data.red, data.green, data.blue, data.implode, this.spriteSet);
        }
    }
}

