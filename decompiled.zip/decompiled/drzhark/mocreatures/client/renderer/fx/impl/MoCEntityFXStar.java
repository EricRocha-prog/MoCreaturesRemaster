/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.multiplayer.ClientLevel
 *  net.minecraft.client.particle.Particle
 *  net.minecraft.client.particle.ParticleProvider
 *  net.minecraft.client.particle.ParticleRenderType
 *  net.minecraft.client.particle.SpriteSet
 *  net.minecraft.client.particle.TextureSheetParticle
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.renderer.fx.impl;

import drzhark.mocreatures.client.renderer.fx.data.StarParticleData;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCEntityFXStar
extends TextureSheetParticle {
    public MoCEntityFXStar(ClientLevel world, double posX, double posY, double posZ, float red, float green, float blue, SpriteSet spriteSet) {
        super(world, posX, posY, posZ, 0.0, 0.0, 0.0);
        this.f_107215_ *= 0.8;
        this.f_107216_ = this.f_107223_.m_188501_() * 0.4f + 0.05f;
        this.f_107217_ *= 0.8;
        this.f_107227_ = red;
        this.f_107228_ = green;
        this.f_107229_ = blue;
        this.f_107230_ = 1.0f;
        this.m_107250_(0.01f, 0.01f);
        this.f_107226_ = 0.06f;
        this.f_107225_ = (int)(64.0 / (Math.random() * 0.8 + 0.2));
        this.f_107663_ *= 0.6f;
        this.m_108339_(spriteSet);
    }

    public void m_5989_() {
        this.f_107209_ = this.f_107212_;
        this.f_107210_ = this.f_107213_;
        this.f_107211_ = this.f_107214_;
        this.f_107663_ *= 0.995f;
        this.f_107216_ -= 0.03;
        this.m_6257_(this.f_107215_, this.f_107216_, this.f_107217_);
        this.f_107215_ *= 0.9;
        this.f_107216_ *= 0.2;
        this.f_107217_ *= 0.9;
        if (this.f_107218_) {
            this.f_107215_ *= 0.7;
            this.f_107217_ *= 0.7;
        }
        if (this.f_107225_-- <= 0) {
            this.m_107274_();
        }
    }

    public ParticleRenderType m_7556_() {
        return ParticleRenderType.f_107432_;
    }

    public static class Factory
    implements ParticleProvider<StarParticleData> {
        private final SpriteSet spriteSet;

        public Factory(SpriteSet spriteSet) {
            this.spriteSet = spriteSet;
        }

        public Particle createParticle(StarParticleData data, ClientLevel world, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
            return new MoCEntityFXStar(world, x, y, z, data.red, data.green, data.blue, this.spriteSet);
        }
    }
}

