/*
 * Decompiled with CFR 0.152.
 */
package drzhark.mocreatures.client.renderer.fx.data;

public class MoCTextureStitcher {
}

