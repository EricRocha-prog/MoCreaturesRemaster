/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import drzhark.mocreatures.client.model.MoCModelEgg;
import drzhark.mocreatures.entity.item.MoCEntityEgg;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCRenderEgg
extends MobRenderer<MoCEntityEgg, MoCModelEgg<MoCEntityEgg>> {
    public MoCRenderEgg(EntityRendererProvider.Context renderManagerIn, MoCModelEgg modelbase, float f) {
        super(renderManagerIn, (EntityModel)modelbase, f);
    }

    protected void scale(MoCEntityEgg entityegg, PoseStack poseStack, float f) {
        this.stretch(entityegg, poseStack);
        super.m_7546_((LivingEntity)entityegg, poseStack, f);
    }

    protected void stretch(MoCEntityEgg entityegg, PoseStack poseStack) {
        float f = (float)entityegg.getSize() * 0.01f;
        poseStack.m_85841_(f, f, f);
    }

    public ResourceLocation getTextureLocation(MoCEntityEgg entityegg) {
        return entityegg.getTexture();
    }
}

