/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import drzhark.mocreatures.client.model.MoCModelHorse;
import drzhark.mocreatures.client.renderer.entity.MoCRenderMoC;
import drzhark.mocreatures.entity.passive.MoCEntityHorse;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCRenderHorse
extends MoCRenderMoC<MoCEntityHorse, MoCModelHorse<MoCEntityHorse>> {
    public MoCRenderHorse(EntityRendererProvider.Context context, MoCModelHorse<MoCEntityHorse> modelbase) {
        super(context, modelbase, 0.5f);
    }

    public ResourceLocation getTextureLocation(MoCEntityHorse entityhorse) {
        return entityhorse.getTexture();
    }

    protected void adjustHeight(MoCEntityHorse entityhorse, float FHeight, PoseStack poseStack) {
        poseStack.m_252880_(0.0f, FHeight, 0.0f);
    }

    @Override
    protected void scale(MoCEntityHorse entityhorse, PoseStack poseStack, float partialTicks) {
        if (!entityhorse.getIsAdult() || entityhorse.getTypeMoC() > 64) {
            this.stretch(entityhorse, poseStack);
        }
        if (entityhorse.getIsGhost()) {
            this.adjustHeight(entityhorse, -0.3f + entityhorse.tFloat() / 5.0f, poseStack);
        }
        super.scale(entityhorse, poseStack, partialTicks);
    }

    protected void stretch(MoCEntityHorse entityhorse, PoseStack poseStack) {
        float sizeFactor = (float)entityhorse.getMoCAge() * 0.01f;
        if (entityhorse.getIsAdult()) {
            sizeFactor = 1.0f;
        }
        if (entityhorse.getTypeMoC() > 64) {
            sizeFactor *= 0.9f;
        }
        poseStack.m_85841_(sizeFactor, sizeFactor, sizeFactor);
    }
}

