/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.math.Axis
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.renderer.ItemInHandRenderer
 *  net.minecraft.client.renderer.MultiBufferSource
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.client.renderer.entity.RenderLayerParent
 *  net.minecraft.client.renderer.entity.layers.RenderLayer
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.item.ItemDisplayContext
 *  net.minecraft.world.item.ItemStack
 */
package drzhark.mocreatures.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import drzhark.mocreatures.client.model.MoCModelFilchLizard;
import drzhark.mocreatures.entity.passive.MoCEntityFilchLizard;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

public class MoCRenderFilchLizard
extends MobRenderer<MoCEntityFilchLizard, MoCModelFilchLizard<MoCEntityFilchLizard>> {
    public MoCRenderFilchLizard(EntityRendererProvider.Context renderManagerIn, MoCModelFilchLizard modelBase, float f) {
        super(renderManagerIn, (EntityModel)modelBase, f);
        this.m_115326_(new LayerHeldItemCustom(this));
    }

    public ResourceLocation getTextureLocation(MoCEntityFilchLizard entity) {
        return entity.getTexture();
    }

    private class LayerHeldItemCustom
    extends RenderLayer<MoCEntityFilchLizard, MoCModelFilchLizard<MoCEntityFilchLizard>> {
        protected final MoCRenderFilchLizard livingEntityRenderer;

        public LayerHeldItemCustom(MoCRenderFilchLizard livingEntityRendererIn) {
            super((RenderLayerParent)livingEntityRendererIn);
            this.livingEntityRenderer = livingEntityRendererIn;
        }

        public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLightIn, MoCEntityFilchLizard entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
            ItemStack itemStack = entity.m_21205_();
            if (!itemStack.m_41619_()) {
                poseStack.m_85836_();
                if (((MoCModelFilchLizard)this.livingEntityRenderer.m_7200_()).f_102610_) {
                    poseStack.m_252880_(0.0f, 0.625f, 0.0f);
                    poseStack.m_252781_(Axis.f_252495_.m_252977_(-20.0f));
                    poseStack.m_85841_(0.5f, 0.5f, 0.5f);
                }
                if (!entity.m_21205_().m_41619_()) {
                    this.renderHeldItemLizard(poseStack, (LivingEntity)entity, itemStack, ItemDisplayContext.THIRD_PERSON_LEFT_HAND, buffer, packedLightIn);
                }
                poseStack.m_85849_();
            }
        }

        public void renderHeldItemLizard(PoseStack poseStack, LivingEntity entity, ItemStack itemStack, ItemDisplayContext displayContext, MultiBufferSource buffer, int packedLightIn) {
            if (!itemStack.m_41619_()) {
                poseStack.m_85836_();
                if (entity.m_6047_()) {
                    poseStack.m_252880_(0.0f, 0.2f, 0.0f);
                }
                poseStack.m_252781_(Axis.f_252436_.m_252977_(90.0f));
                poseStack.m_252781_(Axis.f_252403_.m_252977_(180.0f));
                poseStack.m_252781_(Axis.f_252403_.m_252977_(20.0f));
                poseStack.m_252880_(-0.55f, -1.0f, -0.05f);
                ItemInHandRenderer renderer = Minecraft.m_91087_().m_91290_().m_234586_();
                renderer.m_269530_(entity, itemStack, displayContext, false, poseStack, buffer, packedLightIn);
                poseStack.m_85849_();
            }
        }

        public boolean shouldCombineTextures() {
            return false;
        }
    }
}

