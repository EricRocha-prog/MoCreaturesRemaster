/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  com.mojang.math.Axis
 *  net.minecraft.client.gui.Font
 *  net.minecraft.client.gui.Font$DisplayMode
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.renderer.MultiBufferSource
 *  net.minecraft.client.renderer.RenderType
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.Mob
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  org.joml.Matrix4f
 */
package drzhark.mocreatures.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.client.model.MoCModelShark;
import drzhark.mocreatures.entity.aquatic.MoCEntityShark;
import net.minecraft.client.gui.Font;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.joml.Matrix4f;

@OnlyIn(value=Dist.CLIENT)
public class MoCRenderShark
extends MobRenderer<MoCEntityShark, MoCModelShark<MoCEntityShark>> {
    public MoCRenderShark(EntityRendererProvider.Context renderManagerIn, MoCModelShark modelbase, float f) {
        super(renderManagerIn, (EntityModel)modelbase, f);
    }

    public void render(MoCEntityShark entityshark, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource buffer, int packedLightIn) {
        super.m_7392_((Mob)entityshark, entityYaw, partialTicks, poseStack, buffer, packedLightIn);
        boolean flag = MoCreatures.proxy.getDisplayPetName() && !entityshark.getPetName().isEmpty();
        boolean flag1 = MoCreatures.proxy.getDisplayPetHealth();
        if (entityshark.getIsTamed()) {
            float f2 = 1.6f;
            float f3 = 0.01666667f * f2;
            float f4 = entityshark.m_20270_(this.f_114476_.f_114358_.m_90592_());
            if (f4 < 16.0f) {
                String s = entityshark.getPetName();
                float f5 = 0.1f;
                Font font = this.m_114481_();
                poseStack.m_85836_();
                poseStack.m_252880_(0.0f, f5, 0.0f);
                poseStack.m_252781_(Axis.f_252436_.m_252977_(-this.f_114476_.f_114358_.m_90590_()));
                poseStack.m_85841_(-f3, -f3, f3);
                int byte0 = -50;
                if (flag1) {
                    if (!flag) {
                        byte0 = (byte)(byte0 + 8);
                    }
                    Matrix4f matrix4f = poseStack.m_85850_().m_252922_();
                    float f6 = entityshark.m_21223_();
                    float f7 = entityshark.m_21233_();
                    float f8 = f6 / f7;
                    float f9 = 40.0f * f8;
                    VertexConsumer vertexconsumer = buffer.m_6299_(RenderType.m_110497_((ResourceLocation)new ResourceLocation("textures/misc/white.png")));
                    vertexconsumer.m_252986_(matrix4f, -20.0f + f9, (float)(-10 + byte0), 0.0f).m_85950_(0.7f, 0.0f, 0.0f, 1.0f).m_7421_(0.0f, 0.0f).m_5752_();
                    vertexconsumer.m_252986_(matrix4f, -20.0f + f9, (float)(-6 + byte0), 0.0f).m_85950_(0.7f, 0.0f, 0.0f, 1.0f).m_7421_(0.0f, 1.0f).m_5752_();
                    vertexconsumer.m_252986_(matrix4f, 20.0f, (float)(-6 + byte0), 0.0f).m_85950_(0.7f, 0.0f, 0.0f, 1.0f).m_7421_(1.0f, 1.0f).m_5752_();
                    vertexconsumer.m_252986_(matrix4f, 20.0f, (float)(-10 + byte0), 0.0f).m_85950_(0.7f, 0.0f, 0.0f, 1.0f).m_7421_(1.0f, 0.0f).m_5752_();
                    vertexconsumer = buffer.m_6299_(RenderType.m_110497_((ResourceLocation)new ResourceLocation("textures/misc/white.png")));
                    vertexconsumer.m_252986_(matrix4f, -20.0f, (float)(-10 + byte0), 0.01f).m_85950_(0.0f, 0.7f, 0.0f, 1.0f).m_7421_(0.0f, 0.0f).m_5752_();
                    vertexconsumer.m_252986_(matrix4f, -20.0f, (float)(-6 + byte0), 0.01f).m_85950_(0.0f, 0.7f, 0.0f, 1.0f).m_7421_(0.0f, 1.0f).m_5752_();
                    vertexconsumer.m_252986_(matrix4f, f9 - 20.0f, (float)(-6 + byte0), 0.01f).m_85950_(0.0f, 0.7f, 0.0f, 1.0f).m_7421_(1.0f, 1.0f).m_5752_();
                    vertexconsumer.m_252986_(matrix4f, f9 - 20.0f, (float)(-10 + byte0), 0.01f).m_85950_(0.0f, 0.7f, 0.0f, 1.0f).m_7421_(1.0f, 0.0f).m_5752_();
                }
                if (flag) {
                    int textWidth = font.m_92895_(s);
                    float textX = (float)(-textWidth) / 2.0f;
                    float textY = byte0;
                    Matrix4f matrix4f = poseStack.m_85850_().m_252922_();
                    VertexConsumer vertexconsumer = buffer.m_6299_(RenderType.m_269058_());
                    vertexconsumer.m_252986_(matrix4f, textX - 1.0f, textY - 1.0f, 0.0f).m_85950_(0.0f, 0.0f, 0.0f, 0.25f).m_5752_();
                    vertexconsumer.m_252986_(matrix4f, textX - 1.0f, textY + 8.0f, 0.0f).m_85950_(0.0f, 0.0f, 0.0f, 0.25f).m_5752_();
                    vertexconsumer.m_252986_(matrix4f, textX + (float)textWidth + 1.0f, textY + 8.0f, 0.0f).m_85950_(0.0f, 0.0f, 0.0f, 0.25f).m_5752_();
                    vertexconsumer.m_252986_(matrix4f, textX + (float)textWidth + 1.0f, textY - 1.0f, 0.0f).m_85950_(0.0f, 0.0f, 0.0f, 0.25f).m_5752_();
                    font.m_271703_(s, textX, textY, 0x20FFFFFF, false, matrix4f, buffer, Font.DisplayMode.SEE_THROUGH, 0, packedLightIn);
                    font.m_271703_(s, textX, textY, -1, false, matrix4f, buffer, Font.DisplayMode.NORMAL, 0, packedLightIn);
                }
                poseStack.m_85849_();
            }
        }
    }

    protected void scale(MoCEntityShark entityshark, PoseStack poseStack, float partialTickTime) {
        this.stretch(entityshark, poseStack);
    }

    protected void stretch(MoCEntityShark entityshark, PoseStack poseStack) {
        poseStack.m_85841_((float)entityshark.getMoCAge() * 0.01f / 2.0f, (float)entityshark.getMoCAge() * 0.01f / 2.0f, (float)entityshark.getMoCAge() * 0.01f / 2.0f);
    }

    public ResourceLocation getTextureLocation(MoCEntityShark entityshark) {
        return entityshark.getTexture();
    }
}

