/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.math.Axis
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import drzhark.mocreatures.client.renderer.entity.MoCRenderMoC;
import drzhark.mocreatures.entity.MoCEntityAmbient;
import drzhark.mocreatures.entity.MoCEntityInsect;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCRenderInsect<T extends MoCEntityInsect, M extends EntityModel<T>>
extends MoCRenderMoC<T, M> {
    public MoCRenderInsect(EntityRendererProvider.Context renderManagerIn, M modelbase) {
        super(renderManagerIn, modelbase, 0.0f);
    }

    @Override
    protected void scale(T entityinsect, PoseStack poseStack, float par2) {
        if (((MoCEntityInsect)entityinsect).climbing()) {
            this.rotateAnimal(entityinsect, poseStack);
        }
        this.stretch(entityinsect, poseStack);
    }

    protected void rotateAnimal(T entityinsect, PoseStack poseStack) {
        poseStack.m_252781_(Axis.f_252495_.m_252977_(90.0f));
    }

    protected void stretch(T entityinsect, PoseStack poseStack) {
        float sizeFactor = ((MoCEntityAmbient)entityinsect).getSizeFactor();
        poseStack.m_85841_(sizeFactor, sizeFactor, sizeFactor);
    }
}

