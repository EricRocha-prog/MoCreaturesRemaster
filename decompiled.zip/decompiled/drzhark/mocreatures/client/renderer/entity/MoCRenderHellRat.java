/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import drzhark.mocreatures.client.model.MoCModelRat;
import drzhark.mocreatures.client.renderer.entity.MoCRenderRat;
import drzhark.mocreatures.entity.hostile.MoCEntityHellRat;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCRenderHellRat
extends MoCRenderRat<MoCEntityHellRat, MoCModelRat<MoCEntityHellRat>> {
    public MoCRenderHellRat(EntityRendererProvider.Context renderManagerIn, MoCModelRat modelbase, float f) {
        super(renderManagerIn, modelbase, f);
    }

    @Override
    protected void stretch(MoCEntityHellRat entityhellrat, PoseStack poseStack) {
        float f = 1.3f;
        poseStack.m_85841_(f, f, f);
    }

    @Override
    public ResourceLocation getTextureLocation(MoCEntityHellRat entityhellrat) {
        return entityhellrat.getTexture();
    }
}

