/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.renderer.MultiBufferSource
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.Mob
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import drzhark.mocreatures.client.model.MoCModelFishy;
import drzhark.mocreatures.entity.aquatic.MoCEntityFishy;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCRenderFishy
extends MobRenderer<MoCEntityFishy, MoCModelFishy<MoCEntityFishy>> {
    public MoCRenderFishy(EntityRendererProvider.Context renderManagerIn, MoCModelFishy modelbase, float f) {
        super(renderManagerIn, (EntityModel)modelbase, f);
    }

    public void render(MoCEntityFishy entityfishy, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource buffer, int packedLightIn) {
        if (entityfishy.getTypeMoC() == 0) {
            entityfishy.selectType();
        }
        super.m_7392_((Mob)entityfishy, entityYaw, partialTicks, poseStack, buffer, packedLightIn);
    }

    protected void scale(MoCEntityFishy entityfishy, PoseStack poseStack, float f) {
        this.stretch(entityfishy, poseStack);
        poseStack.m_252880_(0.0f, 0.3f, 0.0f);
    }

    protected void stretch(MoCEntityFishy entityfishy, PoseStack poseStack) {
        poseStack.m_85841_((float)entityfishy.getMoCAge() * 0.01f, (float)entityfishy.getMoCAge() * 0.01f, (float)entityfishy.getMoCAge() * 0.01f);
    }

    public ResourceLocation getTextureLocation(MoCEntityFishy entityfishy) {
        return entityfishy.getTexture();
    }
}

