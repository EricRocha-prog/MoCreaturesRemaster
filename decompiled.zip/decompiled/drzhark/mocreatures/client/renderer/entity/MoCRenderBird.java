/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import drzhark.mocreatures.client.model.MoCModelBird;
import drzhark.mocreatures.client.renderer.entity.MoCRenderMoC;
import drzhark.mocreatures.entity.passive.MoCEntityBird;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCRenderBird
extends MoCRenderMoC<MoCEntityBird, MoCModelBird<MoCEntityBird>> {
    public MoCRenderBird(EntityRendererProvider.Context renderManagerIn, MoCModelBird modelbase, float f) {
        super(renderManagerIn, modelbase, f);
    }

    public ResourceLocation getTextureLocation(MoCEntityBird par1Entity) {
        return par1Entity.getTexture();
    }

    protected float getBob(MoCEntityBird entitybird, float partialTicks) {
        float f1 = entitybird.winge + (entitybird.wingb - entitybird.winge) * partialTicks;
        float f2 = entitybird.wingd + (entitybird.wingc - entitybird.wingd) * partialTicks;
        return (Mth.m_14031_((float)f1) + 1.0f) * f2;
    }

    @Override
    protected void scale(MoCEntityBird entitybird, PoseStack poseStack, float f) {
        if (!entitybird.m_9236_().m_5776_() && entitybird.m_20202_() != null) {
            poseStack.m_252880_(0.0f, 1.3f, 0.0f);
        }
    }
}

