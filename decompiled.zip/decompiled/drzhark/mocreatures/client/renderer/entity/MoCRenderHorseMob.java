/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import drzhark.mocreatures.client.model.MoCModelHorseMob;
import drzhark.mocreatures.entity.hostile.MoCEntityHorseMob;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCRenderHorseMob
extends MobRenderer<MoCEntityHorseMob, MoCModelHorseMob<MoCEntityHorseMob>> {
    public MoCRenderHorseMob(EntityRendererProvider.Context renderManagerIn, MoCModelHorseMob modelbase) {
        super(renderManagerIn, (EntityModel)modelbase, 0.5f);
    }

    protected void adjustHeight(MoCEntityHorseMob entityhorsemob, float FHeight, PoseStack poseStack) {
        poseStack.m_252880_(0.0f, FHeight, 0.0f);
    }

    public ResourceLocation getTextureLocation(MoCEntityHorseMob entityhorsemob) {
        return entityhorsemob.getTexture();
    }
}

