/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import drzhark.mocreatures.client.model.MoCModelLitterBox;
import drzhark.mocreatures.entity.item.MoCEntityLitterBox;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCRenderLitterBox
extends MobRenderer<MoCEntityLitterBox, MoCModelLitterBox<MoCEntityLitterBox>> {
    public MoCModelLitterBox litterbox;

    public MoCRenderLitterBox(EntityRendererProvider.Context renderManagerIn, MoCModelLitterBox modellitterbox, float f) {
        super(renderManagerIn, (EntityModel)modellitterbox, f);
        this.litterbox = modellitterbox;
    }

    protected void scale(MoCEntityLitterBox entitylitterbox, PoseStack poseStack, float f) {
        this.litterbox.usedlitter = entitylitterbox.getUsedLitter();
    }

    public ResourceLocation getTextureLocation(MoCEntityLitterBox entitylitterbox) {
        return entitylitterbox.getTexture();
    }
}

