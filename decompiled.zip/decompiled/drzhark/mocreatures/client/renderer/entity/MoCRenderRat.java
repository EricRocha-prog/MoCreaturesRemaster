/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.math.Axis
 *  net.minecraft.client.renderer.MultiBufferSource
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import drzhark.mocreatures.client.model.MoCModelRat;
import drzhark.mocreatures.entity.hostile.MoCEntityRat;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCRenderRat<T extends MoCEntityRat, M extends MoCModelRat<T>>
extends MobRenderer<T, M> {
    public MoCRenderRat(EntityRendererProvider.Context renderManagerIn, M modelbase, float f) {
        super(renderManagerIn, modelbase, f);
    }

    public void render(T entityrat, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource buffer, int packedLightIn) {
        super.m_7392_(entityrat, entityYaw, partialTicks, poseStack, buffer, packedLightIn);
    }

    protected void scale(T entityrat, PoseStack poseStack, float f) {
        this.stretch(entityrat, poseStack);
        if (((MoCEntityRat)entityrat).m_6147_()) {
            this.rotateAnimal(entityrat, poseStack);
        }
    }

    protected void rotateAnimal(T entityrat, PoseStack poseStack) {
        poseStack.m_252781_(Axis.f_252495_.m_252977_(90.0f));
        poseStack.m_252880_(0.0f, 0.4f, 0.0f);
    }

    protected void stretch(T entityrat, PoseStack poseStack) {
        float f = 0.8f;
        poseStack.m_85841_(f, f, f);
    }

    public ResourceLocation getTextureLocation(T entityrat) {
        return ((MoCEntityRat)entityrat).getTexture();
    }
}

