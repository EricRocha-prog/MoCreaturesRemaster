/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  com.mojang.math.Axis
 *  net.minecraft.client.renderer.MultiBufferSource
 *  net.minecraft.client.renderer.RenderType
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.RenderLayerParent
 *  net.minecraft.client.renderer.entity.layers.RenderLayer
 *  net.minecraft.client.renderer.texture.OverlayTexture
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.renderer.entity;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.client.model.MoCModelFirefly;
import drzhark.mocreatures.client.renderer.entity.MoCRenderInsect;
import drzhark.mocreatures.entity.ambient.MoCEntityFirefly;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCRenderFirefly
extends MoCRenderInsect<MoCEntityFirefly, MoCModelFirefly<MoCEntityFirefly>> {
    public MoCRenderFirefly(EntityRendererProvider.Context renderManagerIn, MoCModelFirefly modelbase) {
        super(renderManagerIn, modelbase);
        this.m_115326_(new LayerMoCFirefly(this));
    }

    @Override
    protected void scale(MoCEntityFirefly entityfirefly, PoseStack poseStack, float par2) {
        if (entityfirefly.getIsFlying()) {
            this.rotateFirefly(entityfirefly, poseStack);
        } else if (entityfirefly.climbing()) {
            this.rotateAnimal(entityfirefly, poseStack);
        }
    }

    protected void rotateFirefly(MoCEntityFirefly entityfirefly, PoseStack poseStack) {
        poseStack.m_252781_(Axis.f_252495_.m_252977_(40.0f));
    }

    public ResourceLocation getTextureLocation(MoCEntityFirefly entityfirefly) {
        return entityfirefly.getTexture();
    }

    private class LayerMoCFirefly
    extends RenderLayer<MoCEntityFirefly, MoCModelFirefly<MoCEntityFirefly>> {
        private final MoCRenderFirefly mocRenderer;

        public LayerMoCFirefly(MoCRenderFirefly renderer) {
            super((RenderLayerParent)renderer);
            this.mocRenderer = renderer;
        }

        public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLightIn, MoCEntityFirefly entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
            this.setTailBrightness(poseStack, entity, partialTicks);
            VertexConsumer vertexConsumer = buffer.m_6299_(RenderType.m_110458_((ResourceLocation)MoCreatures.proxy.getModelTexture("firefly_glow.png")));
            ((MoCModelFirefly)this.m_117386_()).m_7695_(poseStack, vertexConsumer, packedLightIn, OverlayTexture.f_118083_, 1.0f, 1.0f, 1.0f, 1.0f);
        }

        protected void setTailBrightness(PoseStack poseStack, MoCEntityFirefly entityliving, float partialTicks) {
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.clearColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        }
    }
}

