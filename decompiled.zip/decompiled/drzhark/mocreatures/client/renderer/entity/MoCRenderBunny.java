/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.math.Axis
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.resources.ResourceLocation
 */
package drzhark.mocreatures.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import drzhark.mocreatures.client.model.MoCModelBunny;
import drzhark.mocreatures.client.renderer.entity.MoCRenderMoC;
import drzhark.mocreatures.entity.passive.MoCEntityBunny;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;

public class MoCRenderBunny
extends MoCRenderMoC<MoCEntityBunny, MoCModelBunny<MoCEntityBunny>> {
    public MoCRenderBunny(EntityRendererProvider.Context context, MoCModelBunny modelbase, float f) {
        super(context, modelbase, f);
    }

    public ResourceLocation getTextureLocation(MoCEntityBunny entitybunny) {
        return entitybunny.getTexture();
    }

    @Override
    protected void scale(MoCEntityBunny entitybunny, PoseStack poseStack, float f) {
        if (!entitybunny.getIsAdult()) {
            this.stretch(entitybunny, poseStack);
        }
        this.rotBunny(entitybunny, poseStack);
        this.adjustOffsets(entitybunny.getAdjustedXOffset(), entitybunny.getAdjustedYOffset(), entitybunny.getAdjustedZOffset(), poseStack);
    }

    protected void rotBunny(MoCEntityBunny entitybunny, PoseStack poseStack) {
        if (!entitybunny.m_20096_() && entitybunny.m_20202_() == null) {
            if (entitybunny.m_20184_().f_82480_ > 0.5) {
                poseStack.m_252781_(Axis.f_252495_.m_252977_(35.0f));
            } else if (entitybunny.m_20184_().f_82480_ < -0.5) {
                poseStack.m_252781_(Axis.f_252495_.m_252977_(-35.0f));
            } else {
                poseStack.m_252781_(Axis.f_252495_.m_252977_((float)(entitybunny.m_20184_().f_82480_ * 70.0)));
            }
        }
    }

    protected void stretch(MoCEntityBunny entitybunny, PoseStack poseStack) {
        float f = (float)entitybunny.getMoCAge() * 0.01f;
        poseStack.m_85841_(f, f, f);
    }
}

