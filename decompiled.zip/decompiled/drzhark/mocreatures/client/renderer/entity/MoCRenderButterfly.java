/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import drzhark.mocreatures.client.model.MoCModelButterfly;
import drzhark.mocreatures.client.renderer.entity.MoCRenderInsect;
import drzhark.mocreatures.entity.ambient.MoCEntityButterfly;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCRenderButterfly
extends MoCRenderInsect<MoCEntityButterfly, MoCModelButterfly<MoCEntityButterfly>> {
    public MoCRenderButterfly(EntityRendererProvider.Context renderManagerIn, MoCModelButterfly modelbase) {
        super(renderManagerIn, modelbase);
    }

    @Override
    protected void scale(MoCEntityButterfly entitybutterfly, PoseStack poseStack, float par2) {
        if (entitybutterfly.isOnAir() || !entitybutterfly.m_20096_()) {
            this.adjustHeight(entitybutterfly, entitybutterfly.tFloat(), poseStack);
        }
        if (entitybutterfly.climbing()) {
            this.rotateAnimal(entitybutterfly, poseStack);
        }
        this.stretch(entitybutterfly, poseStack);
    }

    protected void adjustHeight(MoCEntityButterfly entitybutterfly, float FHeight, PoseStack poseStack) {
        poseStack.m_252880_(0.0f, FHeight, 0.0f);
    }

    public ResourceLocation getTextureLocation(MoCEntityButterfly entitybutterfly) {
        return entitybutterfly.getTexture();
    }
}

