/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.math.Axis
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import drzhark.mocreatures.client.model.MoCModelMouse;
import drzhark.mocreatures.client.renderer.entity.MoCRenderMoC;
import drzhark.mocreatures.entity.passive.MoCEntityMouse;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCRenderMouse
extends MoCRenderMoC<MoCEntityMouse, MoCModelMouse<MoCEntityMouse>> {
    public MoCRenderMouse(EntityRendererProvider.Context context, MoCModelMouse<MoCEntityMouse> modelbase, float f) {
        super(context, modelbase, f);
    }

    @Override
    protected void scale(MoCEntityMouse entitymouse, PoseStack poseStack, float partialTickTime) {
        this.stretch(poseStack);
        if (entitymouse.upsideDown()) {
            this.upsideDown(poseStack);
        }
        if (entitymouse.m_6147_()) {
            this.rotateAnimal(poseStack);
        }
    }

    protected void rotateAnimal(PoseStack poseStack) {
        poseStack.m_252781_(Axis.f_252495_.m_252977_(90.0f));
        poseStack.m_252880_(0.0f, 0.4f, 0.0f);
    }

    protected void stretch(PoseStack poseStack) {
        float f = 0.6f;
        poseStack.m_85841_(f, f, f);
    }

    protected void upsideDown(PoseStack poseStack) {
        poseStack.m_252781_(Axis.f_252495_.m_252977_(-90.0f));
        poseStack.m_252880_(-0.55f, 0.0f, 0.0f);
    }

    public ResourceLocation getTextureLocation(MoCEntityMouse entitymouse) {
        return entitymouse.getTexture();
    }
}

