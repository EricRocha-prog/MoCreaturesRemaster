/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.math.Axis
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.tags.FluidTags
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import drzhark.mocreatures.client.model.MoCModelTurtle;
import drzhark.mocreatures.client.renderer.entity.MoCRenderMoC;
import drzhark.mocreatures.entity.passive.MoCEntityTurtle;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.FluidTags;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCRenderTurtle
extends MoCRenderMoC<MoCEntityTurtle, MoCModelTurtle<MoCEntityTurtle>> {
    public MoCModelTurtle turtly;

    public MoCRenderTurtle(EntityRendererProvider.Context renderManagerIn, MoCModelTurtle modelbase, float f) {
        super(renderManagerIn, modelbase, f);
        this.turtly = modelbase;
    }

    @Override
    protected void scale(MoCEntityTurtle entityturtle, PoseStack poseStack, float f) {
        this.turtly.upsidedown = entityturtle.getIsUpsideDown();
        this.turtly.swingProgress = entityturtle.f_20921_;
        this.turtly.isHiding = entityturtle.getIsHiding();
        if (!entityturtle.m_9236_().m_5776_() && entityturtle.m_20202_() != null) {
            poseStack.m_252880_(0.0f, 1.3f, 0.0f);
        }
        if (entityturtle.getIsHiding()) {
            this.adjustHeight(entityturtle, 0.15f * (float)entityturtle.getMoCAge() * 0.01f, poseStack);
        } else if (!(entityturtle.getIsHiding() || entityturtle.getIsUpsideDown() || entityturtle.m_204029_(FluidTags.f_13131_))) {
            this.adjustHeight(entityturtle, 0.05f * (float)entityturtle.getMoCAge() * 0.01f, poseStack);
        }
        if (entityturtle.getIsUpsideDown()) {
            this.rotateAnimal(entityturtle, poseStack);
        }
        this.stretch(entityturtle, poseStack);
    }

    protected void rotateAnimal(MoCEntityTurtle entityturtle, PoseStack poseStack) {
        float f = entityturtle.f_20921_ * 10.0f * (float)entityturtle.getFlipDirection();
        float f2 = entityturtle.f_20921_ / 30.0f * (float)entityturtle.getFlipDirection();
        poseStack.m_252781_(Axis.f_252393_.m_252977_(180.0f + f));
        poseStack.m_252880_(0.0f - f2, 0.5f * (float)entityturtle.getMoCAge() * 0.01f, 0.0f);
    }

    protected void adjustHeight(MoCEntityTurtle entityturtle, float height, PoseStack poseStack) {
        poseStack.m_252880_(0.0f, height, 0.0f);
    }

    protected void stretch(MoCEntityTurtle entityturtle, PoseStack poseStack) {
        float f = (float)entityturtle.getMoCAge() * 0.01f;
        poseStack.m_85841_(f, f, f);
    }

    public ResourceLocation getTextureLocation(MoCEntityTurtle entityturtle) {
        return entityturtle.getTexture();
    }
}

