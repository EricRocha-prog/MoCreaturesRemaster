/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.renderer.MultiBufferSource
 *  net.minecraft.client.renderer.RenderType
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.RenderLayerParent
 *  net.minecraft.client.renderer.entity.layers.RenderLayer
 *  net.minecraft.client.renderer.texture.OverlayTexture
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.client.model.MoCModelGolem;
import drzhark.mocreatures.client.renderer.entity.MoCRenderMoC;
import drzhark.mocreatures.entity.hostile.MoCEntityGolem;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCRenderGolem
extends MoCRenderMoC<MoCEntityGolem, MoCModelGolem<MoCEntityGolem>> {
    public MoCRenderGolem(EntityRendererProvider.Context renderManagerIn, MoCModelGolem modelbase, float f) {
        super(renderManagerIn, modelbase, f);
        this.m_115326_(new LayerMoCGolem(this));
    }

    public ResourceLocation getTextureLocation(MoCEntityGolem par1Entity) {
        return par1Entity.getTexture();
    }

    private class LayerMoCGolem
    extends RenderLayer<MoCEntityGolem, MoCModelGolem<MoCEntityGolem>> {
        public LayerMoCGolem(MoCRenderGolem render) {
            super((RenderLayerParent)render);
        }

        public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLightIn, MoCEntityGolem entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
            ResourceLocation effectTexture = entity.getEffectTexture();
            if (effectTexture != null) {
                float f = (float)entity.f_19797_ + partialTicks;
                ((MoCModelGolem)this.m_117386_()).setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
                VertexConsumer vertexConsumer = buffer.m_6299_(RenderType.m_110436_((ResourceLocation)effectTexture, (float)(f * 0.01f), (float)(f * 0.01f)));
                ((MoCModelGolem)this.m_117386_()).prepareMobModel(entity, netHeadYaw, headPitch, f);
                ((MoCModelGolem)this.m_117386_()).m_7695_(poseStack, vertexConsumer, packedLightIn, OverlayTexture.f_118083_, 0.5f, 0.5f, 0.5f, 1.0f);
            }
        }
    }
}

