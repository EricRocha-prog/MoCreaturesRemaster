/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.math.Axis
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import drzhark.mocreatures.client.model.MoCModelCricket;
import drzhark.mocreatures.client.renderer.entity.MoCRenderMoC;
import drzhark.mocreatures.entity.ambient.MoCEntityCricket;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCRenderCricket
extends MoCRenderMoC<MoCEntityCricket, MoCModelCricket<MoCEntityCricket>> {
    public MoCRenderCricket(EntityRendererProvider.Context renderManagerIn, MoCModelCricket modelbase) {
        super(renderManagerIn, modelbase, 0.0f);
    }

    @Override
    protected void scale(MoCEntityCricket entitycricket, PoseStack poseStack, float par2) {
        this.rotateCricket(entitycricket, poseStack);
    }

    protected void rotateCricket(MoCEntityCricket entitycricket, PoseStack poseStack) {
        if (!entitycricket.m_20096_()) {
            if (entitycricket.m_20184_().f_82480_ > 0.5) {
                poseStack.m_252781_(Axis.f_252495_.m_252977_(35.0f));
            } else if (entitycricket.m_20184_().f_82480_ < -0.5) {
                poseStack.m_252781_(Axis.f_252495_.m_252977_(-35.0f));
            } else {
                poseStack.m_252781_(Axis.f_252495_.m_252977_((float)(entitycricket.m_20184_().f_82480_ * 70.0)));
            }
        }
    }

    public ResourceLocation getTextureLocation(MoCEntityCricket par1Entity) {
        return par1Entity.getTexture();
    }
}

