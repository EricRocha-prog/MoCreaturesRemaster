/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.math.Axis
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import drzhark.mocreatures.client.model.MoCModelGrasshopper;
import drzhark.mocreatures.client.renderer.entity.MoCRenderMoC;
import drzhark.mocreatures.entity.ambient.MoCEntityGrasshopper;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCRenderGrasshopper
extends MoCRenderMoC<MoCEntityGrasshopper, MoCModelGrasshopper<MoCEntityGrasshopper>> {
    public MoCRenderGrasshopper(EntityRendererProvider.Context renderManagerIn, MoCModelGrasshopper modelbase) {
        super(renderManagerIn, modelbase, 0.0f);
    }

    @Override
    protected void scale(MoCEntityGrasshopper entity, PoseStack poseStack, float par2) {
        this.rotateGrasshopper(entity, poseStack);
    }

    protected void rotateGrasshopper(MoCEntityGrasshopper entity, PoseStack poseStack) {
        if (!entity.m_20096_()) {
            if (entity.m_20184_().f_82480_ > 0.5) {
                poseStack.m_252781_(Axis.f_252495_.m_252977_(35.0f));
            } else if (entity.m_20184_().f_82480_ < -0.5) {
                poseStack.m_252781_(Axis.f_252495_.m_252977_(-35.0f));
            } else {
                poseStack.m_252781_(Axis.f_252495_.m_252977_((float)(entity.m_20184_().f_82480_ * 70.0)));
            }
        }
    }

    public ResourceLocation getTextureLocation(MoCEntityGrasshopper par1Entity) {
        return par1Entity.getTexture();
    }
}

