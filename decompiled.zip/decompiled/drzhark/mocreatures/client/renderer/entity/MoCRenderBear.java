/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import drzhark.mocreatures.client.model.MoCModelBear;
import drzhark.mocreatures.client.renderer.entity.MoCRenderMoC;
import drzhark.mocreatures.entity.hunter.MoCEntityBear;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCRenderBear
extends MoCRenderMoC<MoCEntityBear, MoCModelBear<MoCEntityBear>> {
    public MoCRenderBear(EntityRendererProvider.Context renderManagerIn, MoCModelBear modelbase, float f) {
        super(renderManagerIn, modelbase, f);
    }

    @Override
    protected void scale(MoCEntityBear entitybear, PoseStack poseStack, float f) {
        this.stretch(poseStack, entitybear);
        super.scale(entitybear, poseStack, f);
    }

    protected void stretch(PoseStack poseStack, MoCEntityBear entitybear) {
        float sizeFactor = (float)entitybear.getMoCAge() * 0.01f;
        if (entitybear.getIsAdult()) {
            sizeFactor = 1.0f;
        }
        poseStack.m_85841_(sizeFactor *= entitybear.getBearSize(), sizeFactor, sizeFactor);
    }

    public ResourceLocation getTextureLocation(MoCEntityBear entitybear) {
        return entitybear.getTexture();
    }
}

