/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.math.Axis
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import drzhark.mocreatures.client.model.MoCModelPetScorpion;
import drzhark.mocreatures.client.renderer.entity.MoCRenderMoC;
import drzhark.mocreatures.entity.hunter.MoCEntityPetScorpion;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCRenderPetScorpion
extends MoCRenderMoC<MoCEntityPetScorpion, MoCModelPetScorpion<MoCEntityPetScorpion>> {
    public MoCRenderPetScorpion(EntityRendererProvider.Context renderManagerIn, MoCModelPetScorpion modelbase, float f) {
        super(renderManagerIn, modelbase, f);
    }

    protected float getFlipDegrees(MoCEntityPetScorpion entityscorpion) {
        return 180.0f;
    }

    @Override
    protected void scale(MoCEntityPetScorpion entityscorpion, PoseStack poseStack, float f) {
        if (entityscorpion.getIsSitting()) {
            float factorY = 0.4f * ((float)entityscorpion.getMoCAge() / 100.0f);
            poseStack.m_252880_(0.0f, factorY, 0.0f);
        }
        if (!entityscorpion.getIsAdult()) {
            this.stretch(entityscorpion, poseStack);
            if (entityscorpion.m_20202_() != null) {
                this.upsideDown(entityscorpion, poseStack);
            }
        } else {
            this.adjustHeight(entityscorpion, poseStack);
        }
    }

    protected void upsideDown(MoCEntityPetScorpion entityscorpion, PoseStack poseStack) {
        poseStack.m_252781_(Axis.f_252495_.m_252977_(-90.0f));
        poseStack.m_252880_(-1.5f, -0.5f, -2.5f);
    }

    protected void adjustHeight(MoCEntityPetScorpion entityscorpion, PoseStack poseStack) {
        poseStack.m_252880_(0.0f, -0.1f, 0.0f);
    }

    protected void rotateAnimal(MoCEntityPetScorpion entityscorpion, PoseStack poseStack) {
        poseStack.m_252781_(Axis.f_252495_.m_252977_(90.0f));
        poseStack.m_252880_(0.0f, 1.0f, 0.0f);
    }

    protected void stretch(MoCEntityPetScorpion entityscorpion, PoseStack poseStack) {
        float f = 1.1f;
        if (!entityscorpion.getIsAdult()) {
            f = (float)entityscorpion.getMoCAge() * 0.01f;
        }
        poseStack.m_85841_(f, f, f);
    }

    public ResourceLocation getTextureLocation(MoCEntityPetScorpion entityscorpion) {
        return entityscorpion.getTexture();
    }
}

