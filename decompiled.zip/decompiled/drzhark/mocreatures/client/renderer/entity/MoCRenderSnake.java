/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.tags.FluidTags
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import drzhark.mocreatures.client.model.MoCModelSnake;
import drzhark.mocreatures.client.renderer.entity.MoCRenderMoC;
import drzhark.mocreatures.entity.hunter.MoCEntitySnake;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.FluidTags;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCRenderSnake
extends MoCRenderMoC<MoCEntitySnake, MoCModelSnake<MoCEntitySnake>> {
    public MoCRenderSnake(EntityRendererProvider.Context renderManagerIn, MoCModelSnake modelbase, float f) {
        super(renderManagerIn, modelbase, 0.0f);
    }

    public ResourceLocation getTextureLocation(MoCEntitySnake par1Entity) {
        return par1Entity.getTexture();
    }

    protected void adjustHeight(MoCEntitySnake entitysnake, float FHeight, PoseStack poseStack) {
        poseStack.m_252880_(0.0f, FHeight, 0.0f);
    }

    @Override
    protected void scale(MoCEntitySnake entitysnake, PoseStack poseStack, float f) {
        this.stretch(entitysnake, poseStack);
        if (entitysnake.pickedUp()) {
            float xOff = entitysnake.getSizeF() - 1.0f;
            if (xOff > 0.0f) {
                xOff = 0.0f;
            }
            if (entitysnake.m_9236_().m_5776_()) {
                poseStack.m_252880_(xOff, 0.0f, 0.0f);
            } else {
                poseStack.m_252880_(xOff, 0.0f, 0.0f);
            }
        }
        if (entitysnake.m_204029_(FluidTags.f_13131_)) {
            this.adjustHeight(entitysnake, -0.25f, poseStack);
        }
        super.scale(entitysnake, poseStack, f);
    }

    protected void stretch(MoCEntitySnake entitysnake, PoseStack poseStack) {
        float f = entitysnake.getSizeF();
        poseStack.m_85841_(f, f, f);
    }
}

