/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.renderer.MultiBufferSource
 *  net.minecraft.client.renderer.RenderType
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.client.renderer.entity.RenderLayerParent
 *  net.minecraft.client.renderer.entity.layers.RenderLayer
 *  net.minecraft.client.renderer.texture.OverlayTexture
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.item.DyeColor
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import drzhark.mocreatures.client.model.MoCModelKittyBed;
import drzhark.mocreatures.client.model.MoCModelKittyBed2;
import drzhark.mocreatures.entity.item.MoCEntityKittyBed;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.DyeColor;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCRenderKittyBed
extends MobRenderer<MoCEntityKittyBed, MoCModelKittyBed<MoCEntityKittyBed>> {
    public MoCModelKittyBed kittybed;
    private int mycolor;

    public MoCRenderKittyBed(EntityRendererProvider.Context renderManagerIn, MoCModelKittyBed modelkittybed, MoCModelKittyBed2 modelkittybed2, float f) {
        super(renderManagerIn, (EntityModel)modelkittybed, f);
        this.kittybed = modelkittybed;
        this.m_115326_(new LayerMoCKittyBed(this, modelkittybed2));
    }

    protected void scale(MoCEntityKittyBed entitykittybed, PoseStack poseStack, float f) {
        this.mycolor = entitykittybed.getSheetColor();
        this.kittybed.hasMilk = entitykittybed.getHasMilk();
        this.kittybed.hasFood = entitykittybed.getHasFood();
        this.kittybed.pickedUp = entitykittybed.getPickedUp();
        this.kittybed.milklevel = entitykittybed.milkLevel;
    }

    public ResourceLocation getTextureLocation(MoCEntityKittyBed entitykittybed) {
        return entitykittybed.getTexture();
    }

    private static class LayerMoCKittyBed
    extends RenderLayer<MoCEntityKittyBed, MoCModelKittyBed<MoCEntityKittyBed>> {
        private final MoCRenderKittyBed mocRenderer;
        private final MoCModelKittyBed2 mocModel;

        public LayerMoCKittyBed(MoCRenderKittyBed render, MoCModelKittyBed2 model) {
            super((RenderLayerParent)render);
            this.mocRenderer = render;
            this.mocModel = model;
        }

        public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLightIn, MoCEntityKittyBed entitykittybed, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
            int j = this.mocRenderer.mycolor;
            float[] rgb = DyeColor.m_41053_((int)j).m_41068_();
            ((MoCModelKittyBed)this.m_117386_()).m_102624_(this.mocModel);
            this.mocModel.m_7695_(poseStack, buffer.m_6299_(RenderType.m_110458_((ResourceLocation)this.m_117347_((Entity)entitykittybed))), packedLightIn, OverlayTexture.f_118083_, rgb[0], rgb[1], rgb[2], 1.0f);
        }
    }
}

