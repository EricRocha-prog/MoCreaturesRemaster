/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  com.mojang.math.Axis
 *  net.minecraft.client.renderer.MultiBufferSource
 *  net.minecraft.client.renderer.RenderType
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.texture.OverlayTexture
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  org.joml.Matrix4f
 */
package drzhark.mocreatures.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.client.model.MoCModelKitty;
import drzhark.mocreatures.client.renderer.entity.MoCRenderMoC;
import drzhark.mocreatures.entity.neutral.MoCEntityKitty;
import java.lang.reflect.Field;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.joml.Matrix4f;

@OnlyIn(value=Dist.CLIENT)
public class MoCRenderKitty
extends MoCRenderMoC<MoCEntityKitty, MoCModelKitty<MoCEntityKitty>> {
    public MoCModelKitty kitty;
    private Field isSittingField;
    private Field isSwingingField;
    private Field swingProgressField;
    private Field kittystateField;

    public MoCRenderKitty(EntityRendererProvider.Context renderManagerIn, MoCModelKitty modelkitty, float f) {
        super(renderManagerIn, modelkitty, f);
        this.kitty = modelkitty;
        try {
            this.isSittingField = MoCModelKitty.class.getDeclaredField("isSitting");
            this.isSittingField.setAccessible(true);
            this.isSwingingField = MoCModelKitty.class.getDeclaredField("isSwinging");
            this.isSwingingField.setAccessible(true);
            this.swingProgressField = MoCModelKitty.class.getDeclaredField("swingProgress");
            this.swingProgressField.setAccessible(true);
            this.kittystateField = MoCModelKitty.class.getDeclaredField("kittystate");
            this.kittystateField.setAccessible(true);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public ResourceLocation getTextureLocation(MoCEntityKitty entitykitty) {
        return entitykitty.getTexture();
    }

    public void render(MoCEntityKitty entitykitty, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource buffer, int packedLightIn) {
        super.m_7392_(entitykitty, entityYaw, partialTicks, poseStack, buffer, packedLightIn);
        boolean displayPetIcons = MoCreatures.proxy.getDisplayPetIcons();
        if (entitykitty.getIsTamed()) {
            float f2 = 1.6f;
            float f3 = 0.01666667f * f2;
            float f4 = entitykitty.m_20270_(this.f_114476_.f_114358_.m_90592_());
            if (f4 < 12.0f) {
                float f5 = 0.2f;
                if (entitykitty.getIsSitting()) {
                    f5 = 0.4f;
                }
                poseStack.m_85836_();
                poseStack.m_252880_(0.0f, f5, 0.0f);
                poseStack.m_252781_(Axis.f_252436_.m_252977_(-this.f_114476_.f_114358_.m_90590_()));
                poseStack.m_85841_(-f3, -f3, f3);
                if (displayPetIcons && entitykitty.getShowEmoteIcon()) {
                    int i = -90;
                    int k = 32;
                    int l = k / 2 * -1;
                    Matrix4f matrix = poseStack.m_85850_().m_252922_();
                    VertexConsumer vc = buffer.m_6299_(RenderType.m_110497_((ResourceLocation)entitykitty.getEmoteIcon()));
                    int packedLight = 0xF000F0;
                    int packedOverlay = OverlayTexture.f_118083_;
                    vc.m_252986_(matrix, (float)l, (float)(i + k), 0.0f).m_6122_(255, 255, 255, 255).m_7421_(0.0f, 1.0f).m_86008_(packedOverlay).m_85969_(packedLight).m_5752_();
                    vc.m_252986_(matrix, (float)(l + k), (float)(i + k), 0.0f).m_6122_(255, 255, 255, 255).m_7421_(1.0f, 1.0f).m_86008_(packedOverlay).m_85969_(packedLight).m_5752_();
                    vc.m_252986_(matrix, (float)(l + k), (float)i, 0.0f).m_6122_(255, 255, 255, 255).m_7421_(1.0f, 0.0f).m_86008_(packedOverlay).m_85969_(packedLight).m_5752_();
                    vc.m_252986_(matrix, (float)l, (float)i, 0.0f).m_6122_(255, 255, 255, 255).m_7421_(0.0f, 0.0f).m_86008_(packedOverlay).m_85969_(packedLight).m_5752_();
                }
                poseStack.m_85849_();
            }
        }
    }

    protected void onMaBack(MoCEntityKitty entitykitty, PoseStack poseStack) {
        poseStack.m_252781_(Axis.f_252393_.m_252977_(90.0f));
        if (!entitykitty.m_9236_().m_5776_() && entitykitty.m_20202_() != null) {
            poseStack.m_252880_(-1.5f, 1.2f, -0.2f);
        } else {
            poseStack.m_252880_(0.1f, 1.2f, -0.2f);
        }
    }

    protected void onTheSide(MoCEntityKitty entityliving, PoseStack poseStack) {
        poseStack.m_252781_(Axis.f_252393_.m_252977_(90.0f));
        poseStack.m_252880_(1.2f, 1.5f, -0.2f);
    }

    @Override
    protected void scale(MoCEntityKitty entitykitty, PoseStack poseStack, float f) {
        poseStack.m_252880_(0.0f, 1.0f, 0.0f);
        try {
            if (this.isSittingField != null) {
                this.isSittingField.set((Object)this.kitty, entitykitty.getIsSitting());
                this.isSwingingField.set((Object)this.kitty, entitykitty.getIsSwinging());
                this.swingProgressField.set((Object)this.kitty, Float.valueOf(entitykitty.f_20921_));
                this.kittystateField.set((Object)this.kitty, entitykitty.getKittyState());
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        if (!entitykitty.getIsAdult()) {
            this.stretch(entitykitty, poseStack);
        }
        if (entitykitty.getKittyState() == 20) {
            this.onTheSide(entitykitty, poseStack);
        }
        if (entitykitty.climbingTree()) {
            this.rotateAnimal(entitykitty, poseStack);
        }
        if (entitykitty.upsideDown()) {
            this.upsideDown(entitykitty, poseStack);
        }
        if (entitykitty.onMaBack()) {
            this.onMaBack(entitykitty, poseStack);
        }
    }

    protected void rotateAnimal(MoCEntityKitty entitykitty, PoseStack poseStack) {
        poseStack.m_252781_(Axis.f_252495_.m_252977_(90.0f));
        poseStack.m_252880_(0.0f, 1.5f, -1.5f);
    }

    protected void stretch(MoCEntityKitty entitykitty, PoseStack poseStack) {
        poseStack.m_85841_((float)entitykitty.getMoCAge() * 0.01f, (float)entitykitty.getMoCAge() * 0.01f, (float)entitykitty.getMoCAge() * 0.01f);
    }

    protected void upsideDown(MoCEntityKitty entitykitty, PoseStack poseStack) {
        poseStack.m_252781_(Axis.f_252393_.m_252977_(180.0f));
        poseStack.m_252880_(0.0f, 2.75f, 0.0f);
    }
}

