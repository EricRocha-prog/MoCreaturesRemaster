/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.math.Axis
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import drzhark.mocreatures.client.model.MoCModelScorpion;
import drzhark.mocreatures.client.renderer.entity.MoCRenderMoC;
import drzhark.mocreatures.entity.hostile.MoCEntityScorpion;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCRenderScorpion
extends MoCRenderMoC<MoCEntityScorpion, MoCModelScorpion<MoCEntityScorpion>> {
    public MoCRenderScorpion(EntityRendererProvider.Context renderManagerIn, MoCModelScorpion modelbase, float f) {
        super(renderManagerIn, modelbase, f);
    }

    protected float getFlipDegrees(MoCEntityScorpion entityscorpion) {
        return 180.0f;
    }

    @Override
    protected void scale(MoCEntityScorpion entityscorpion, PoseStack poseStack, float f) {
        if (!entityscorpion.getIsAdult()) {
            this.stretch(entityscorpion, poseStack);
        } else {
            this.adjustHeight(entityscorpion, poseStack);
        }
    }

    protected void adjustHeight(MoCEntityScorpion entityscorpion, PoseStack poseStack) {
        poseStack.m_252880_(0.0f, -0.1f, 0.0f);
    }

    protected void rotateAnimal(PoseStack poseStack, MoCEntityScorpion entityscorpion) {
        poseStack.m_252781_(Axis.f_252495_.m_252977_(90.0f));
        poseStack.m_252880_(0.0f, 1.0f, 0.0f);
    }

    protected void stretch(MoCEntityScorpion entityscorpion, PoseStack poseStack) {
        float f = 1.1f;
        if (!entityscorpion.getIsAdult()) {
            f = (float)entityscorpion.getMoCAge() * 0.01f;
        }
        poseStack.m_85841_(f, f, f);
    }

    public ResourceLocation getTextureLocation(MoCEntityScorpion entityscorpion) {
        return entityscorpion.getTexture();
    }
}

