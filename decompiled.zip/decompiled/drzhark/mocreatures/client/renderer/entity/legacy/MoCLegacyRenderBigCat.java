/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  com.mojang.math.Axis
 *  net.minecraft.client.gui.Font
 *  net.minecraft.client.gui.Font$DisplayMode
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.renderer.MultiBufferSource
 *  net.minecraft.client.renderer.RenderType
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.entity.MobRenderer
 *  net.minecraft.client.renderer.entity.RenderLayerParent
 *  net.minecraft.client.renderer.entity.layers.RenderLayer
 *  net.minecraft.client.renderer.texture.OverlayTexture
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.Mob
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  org.joml.Matrix4f
 */
package drzhark.mocreatures.client.renderer.entity.legacy;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.client.model.legacy.MoCLegacyModelBigCat1;
import drzhark.mocreatures.client.model.legacy.MoCLegacyModelBigCat2;
import drzhark.mocreatures.entity.hunter.MoCEntityBigCat;
import drzhark.mocreatures.entity.hunter.MoCEntityLion;
import net.minecraft.client.gui.Font;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.joml.Matrix4f;

@OnlyIn(value=Dist.CLIENT)
public class MoCLegacyRenderBigCat
extends MobRenderer<MoCEntityBigCat, MoCLegacyModelBigCat2<MoCEntityBigCat>> {
    private static final ResourceLocation WHITE_TEXTURE = new ResourceLocation("textures/misc/white.png");
    public MoCLegacyModelBigCat2 bigcat1;

    public MoCLegacyRenderBigCat(EntityRendererProvider.Context renderManagerIn, MoCLegacyModelBigCat2 modelbigcat2, MoCLegacyModelBigCat1 modelbigcat1, float f) {
        super(renderManagerIn, (EntityModel)modelbigcat2, f);
        this.m_115326_(new LayerMoCBigCat(this, renderManagerIn));
        this.bigcat1 = modelbigcat2;
    }

    public ResourceLocation getTextureLocation(MoCEntityBigCat entitybigcat) {
        return entitybigcat.getTexture();
    }

    public void render(MoCEntityBigCat entitybigcat, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource buffer, int packedLightIn) {
        super.m_7392_((Mob)entitybigcat, entityYaw, partialTicks, poseStack, buffer, packedLightIn);
        boolean displayName = MoCreatures.proxy.getDisplayPetName() && !entitybigcat.getPetName().isEmpty();
        boolean displayHealth = MoCreatures.proxy.getDisplayPetHealth();
        if (entitybigcat.getIsTamed()) {
            float f2 = 1.6f;
            float f3 = 0.01666667f * f2;
            float f5 = entitybigcat.m_20270_(this.f_114476_.f_114358_.m_90592_());
            if (f5 < 16.0f) {
                String s = entitybigcat.getPetName();
                float f7 = 0.1f;
                Font font = this.m_114481_();
                poseStack.m_85836_();
                poseStack.m_252880_(0.0f, f7, 0.0f);
                poseStack.m_252781_(Axis.f_252436_.m_252977_(-this.f_114476_.f_114358_.m_90590_()));
                poseStack.m_85841_(-f3, -f3, f3);
                int byte0 = -60;
                if (displayHealth) {
                    if (!displayName) {
                        byte0 = (byte)(byte0 + 8);
                    }
                    Matrix4f matrix4f = poseStack.m_85850_().m_252922_();
                    float f8 = entitybigcat.m_21223_();
                    float f9 = entitybigcat.m_21233_();
                    float f10 = f8 / f9;
                    float f11 = 40.0f * f10;
                    VertexConsumer vertexconsumer = buffer.m_6299_(RenderType.m_110497_((ResourceLocation)WHITE_TEXTURE));
                    vertexconsumer.m_252986_(matrix4f, -20.0f + f11, (float)(-10 + byte0), 0.0f).m_85950_(0.7f, 0.0f, 0.0f, 1.0f).m_7421_(0.0f, 0.0f).m_86008_(0).m_85969_(packedLightIn).m_5601_(0.0f, 1.0f, 0.0f).m_5752_();
                    vertexconsumer.m_252986_(matrix4f, -20.0f + f11, (float)(-6 + byte0), 0.0f).m_85950_(0.7f, 0.0f, 0.0f, 1.0f).m_7421_(0.0f, 1.0f).m_86008_(0).m_85969_(packedLightIn).m_5601_(0.0f, 1.0f, 0.0f).m_5752_();
                    vertexconsumer.m_252986_(matrix4f, 20.0f, (float)(-6 + byte0), 0.0f).m_85950_(0.7f, 0.0f, 0.0f, 1.0f).m_7421_(1.0f, 1.0f).m_86008_(0).m_85969_(packedLightIn).m_5601_(0.0f, 1.0f, 0.0f).m_5752_();
                    vertexconsumer.m_252986_(matrix4f, 20.0f, (float)(-10 + byte0), 0.0f).m_85950_(0.7f, 0.0f, 0.0f, 1.0f).m_7421_(1.0f, 0.0f).m_86008_(0).m_85969_(packedLightIn).m_5601_(0.0f, 1.0f, 0.0f).m_5752_();
                    vertexconsumer = buffer.m_6299_(RenderType.m_110497_((ResourceLocation)WHITE_TEXTURE));
                    vertexconsumer.m_252986_(matrix4f, -20.0f, (float)(-10 + byte0), 0.01f).m_85950_(0.0f, 0.7f, 0.0f, 1.0f).m_7421_(0.0f, 0.0f).m_86008_(0).m_85969_(packedLightIn).m_5601_(0.0f, 1.0f, 0.0f).m_5752_();
                    vertexconsumer.m_252986_(matrix4f, -20.0f, (float)(-6 + byte0), 0.01f).m_85950_(0.0f, 0.7f, 0.0f, 1.0f).m_7421_(0.0f, 1.0f).m_86008_(0).m_85969_(packedLightIn).m_5601_(0.0f, 1.0f, 0.0f).m_5752_();
                    vertexconsumer.m_252986_(matrix4f, f11 - 20.0f, (float)(-6 + byte0), 0.01f).m_85950_(0.0f, 0.7f, 0.0f, 1.0f).m_7421_(1.0f, 1.0f).m_86008_(0).m_85969_(packedLightIn).m_5601_(0.0f, 1.0f, 0.0f).m_5752_();
                    vertexconsumer.m_252986_(matrix4f, f11 - 20.0f, (float)(-10 + byte0), 0.01f).m_85950_(0.0f, 0.7f, 0.0f, 1.0f).m_7421_(1.0f, 0.0f).m_86008_(0).m_85969_(packedLightIn).m_5601_(0.0f, 1.0f, 0.0f).m_5752_();
                }
                if (displayName) {
                    int textWidth = font.m_92895_(s);
                    float textX = (float)(-textWidth) / 2.0f;
                    float textY = byte0;
                    Matrix4f matrix4f = poseStack.m_85850_().m_252922_();
                    VertexConsumer vertexconsumer = buffer.m_6299_(RenderType.m_285907_());
                    int left = (int)(textX - 1.0f);
                    int top = (int)(textY - 1.0f);
                    int right = (int)(textX + (float)textWidth + 1.0f);
                    int bottom = (int)(textY + 8.0f);
                    vertexconsumer.m_252986_(matrix4f, (float)left, (float)top, 0.0f).m_6122_(0, 0, 0, 64).m_5752_();
                    vertexconsumer.m_252986_(matrix4f, (float)left, (float)bottom, 0.0f).m_6122_(0, 0, 0, 64).m_5752_();
                    vertexconsumer.m_252986_(matrix4f, (float)right, (float)bottom, 0.0f).m_6122_(0, 0, 0, 64).m_5752_();
                    vertexconsumer.m_252986_(matrix4f, (float)right, (float)top, 0.0f).m_6122_(0, 0, 0, 64).m_5752_();
                    font.m_271703_(s, textX, textY, 0x20FFFFFF, false, matrix4f, buffer, Font.DisplayMode.SEE_THROUGH, 0, packedLightIn);
                    font.m_271703_(s, textX, textY, -1, false, matrix4f, buffer, Font.DisplayMode.NORMAL, 0, packedLightIn);
                }
                poseStack.m_85849_();
            }
        }
    }

    protected void scale(MoCEntityBigCat entitybigcat, PoseStack poseStack, float f) {
        this.bigcat1.sitting = entitybigcat.getIsSitting();
        this.bigcat1.tamed = entitybigcat.getIsTamed();
        this.stretch(entitybigcat, poseStack);
    }

    protected void stretch(MoCEntityBigCat entitybigcat, PoseStack poseStack) {
        float f = (float)entitybigcat.getMoCAge() * 0.01f;
        if (entitybigcat.getIsAdult()) {
            f = 1.0f;
        }
        poseStack.m_85841_(f, f, f);
    }

    private class LayerMoCBigCat
    extends RenderLayer<MoCEntityBigCat, MoCLegacyModelBigCat2<MoCEntityBigCat>> {
        private final MoCLegacyRenderBigCat mocRenderer;
        private final MoCLegacyModelBigCat1<MoCEntityBigCat> mocModel;

        public LayerMoCBigCat(MoCLegacyRenderBigCat render, EntityRendererProvider.Context context) {
            super((RenderLayerParent)render);
            this.mocRenderer = render;
            this.mocModel = new MoCLegacyModelBigCat1(context.m_174023_(MoCLegacyModelBigCat1.LAYER_LOCATION));
        }

        public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, MoCEntityBigCat entitybigcat, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
            ResourceLocation resourcelocation = entitybigcat instanceof MoCEntityLion && entitybigcat.hasMane() ? (entitybigcat.getTypeMoC() == 7 ? MoCreatures.proxy.getModelTexture("big_cat_white_lion_legacy_layer.png") : MoCreatures.proxy.getModelTexture("big_cat_lion_legacy_layer_male.png")) : MoCreatures.proxy.getModelTexture("big_cat_lion_legacy_layer_female.png");
            this.mocModel.setupAnim(entitybigcat, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
            VertexConsumer vertexconsumer = buffer.m_6299_(RenderType.m_110458_((ResourceLocation)resourcelocation));
            this.mocModel.m_7695_(poseStack, vertexconsumer, packedLight, OverlayTexture.f_118083_, 1.0f, 1.0f, 1.0f, 1.0f);
        }
    }
}

