/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.math.Axis
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.renderer.MultiBufferSource
 *  net.minecraft.client.renderer.entity.EntityRenderer
 *  net.minecraft.client.renderer.entity.EntityRendererProvider$Context
 *  net.minecraft.client.renderer.texture.OverlayTexture
 *  net.minecraft.client.renderer.texture.TextureAtlas
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.renderer.entity;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import drzhark.mocreatures.entity.item.MoCEntityThrowableRock;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCRenderTRock
extends EntityRenderer<MoCEntityThrowableRock> {
    public MoCRenderTRock(EntityRendererProvider.Context renderManagerIn) {
        super(renderManagerIn);
        this.f_114477_ = 0.5f;
    }

    public void render(MoCEntityThrowableRock entitytrock, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource buffer, int packedLightIn) {
        poseStack.m_85836_();
        poseStack.m_252880_(-0.5f, 0.25f, -0.5f);
        poseStack.m_252781_(Axis.f_252392_.m_252977_((float)(100 - entitytrock.acceleration) / 10.0f * 36.0f));
        RenderSystem.clearColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        Minecraft.m_91087_().m_91289_().m_110912_(entitytrock.getState(), poseStack, buffer, packedLightIn, OverlayTexture.f_118083_);
        poseStack.m_85849_();
    }

    public ResourceLocation getTextureLocation(MoCEntityThrowableRock par1Entity) {
        return TextureAtlas.f_118259_;
    }
}

