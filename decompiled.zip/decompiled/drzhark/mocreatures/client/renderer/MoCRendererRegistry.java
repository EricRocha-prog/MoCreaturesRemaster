/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.EntityType
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.client.event.EntityRenderersEvent$RegisterRenderers
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber$Bus
 */
package drzhark.mocreatures.client.renderer;

import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.client.model.MoCModelAnt;
import drzhark.mocreatures.client.model.MoCModelBear;
import drzhark.mocreatures.client.model.MoCModelBee;
import drzhark.mocreatures.client.model.MoCModelBigCat;
import drzhark.mocreatures.client.model.MoCModelBird;
import drzhark.mocreatures.client.model.MoCModelBoar;
import drzhark.mocreatures.client.model.MoCModelBunny;
import drzhark.mocreatures.client.model.MoCModelButterfly;
import drzhark.mocreatures.client.model.MoCModelCrab;
import drzhark.mocreatures.client.model.MoCModelCricket;
import drzhark.mocreatures.client.model.MoCModelCrocodile;
import drzhark.mocreatures.client.model.MoCModelDeer;
import drzhark.mocreatures.client.model.MoCModelDolphin;
import drzhark.mocreatures.client.model.MoCModelDragonfly;
import drzhark.mocreatures.client.model.MoCModelDuck;
import drzhark.mocreatures.client.model.MoCModelEgg;
import drzhark.mocreatures.client.model.MoCModelElephant;
import drzhark.mocreatures.client.model.MoCModelEnt;
import drzhark.mocreatures.client.model.MoCModelFilchLizard;
import drzhark.mocreatures.client.model.MoCModelFirefly;
import drzhark.mocreatures.client.model.MoCModelFishy;
import drzhark.mocreatures.client.model.MoCModelFly;
import drzhark.mocreatures.client.model.MoCModelFox;
import drzhark.mocreatures.client.model.MoCModelGoat;
import drzhark.mocreatures.client.model.MoCModelGolem;
import drzhark.mocreatures.client.model.MoCModelGrasshopper;
import drzhark.mocreatures.client.model.MoCModelHorse;
import drzhark.mocreatures.client.model.MoCModelHorseMob;
import drzhark.mocreatures.client.model.MoCModelJellyFish;
import drzhark.mocreatures.client.model.MoCModelKitty;
import drzhark.mocreatures.client.model.MoCModelKittyBed;
import drzhark.mocreatures.client.model.MoCModelKittyBed2;
import drzhark.mocreatures.client.model.MoCModelKomodo;
import drzhark.mocreatures.client.model.MoCModelLitterBox;
import drzhark.mocreatures.client.model.MoCModelMaggot;
import drzhark.mocreatures.client.model.MoCModelManticore;
import drzhark.mocreatures.client.model.MoCModelManticorePet;
import drzhark.mocreatures.client.model.MoCModelMediumFish;
import drzhark.mocreatures.client.model.MoCModelMiniGolem;
import drzhark.mocreatures.client.model.MoCModelMole;
import drzhark.mocreatures.client.model.MoCModelMouse;
import drzhark.mocreatures.client.model.MoCModelOgre;
import drzhark.mocreatures.client.model.MoCModelOstrich;
import drzhark.mocreatures.client.model.MoCModelPetScorpion;
import drzhark.mocreatures.client.model.MoCModelRaccoon;
import drzhark.mocreatures.client.model.MoCModelRat;
import drzhark.mocreatures.client.model.MoCModelRay;
import drzhark.mocreatures.client.model.MoCModelRegistry;
import drzhark.mocreatures.client.model.MoCModelRoach;
import drzhark.mocreatures.client.model.MoCModelScorpion;
import drzhark.mocreatures.client.model.MoCModelShark;
import drzhark.mocreatures.client.model.MoCModelSilverSkeleton;
import drzhark.mocreatures.client.model.MoCModelSmallFish;
import drzhark.mocreatures.client.model.MoCModelSnail;
import drzhark.mocreatures.client.model.MoCModelSnake;
import drzhark.mocreatures.client.model.MoCModelTurkey;
import drzhark.mocreatures.client.model.MoCModelTurtle;
import drzhark.mocreatures.client.model.MoCModelWerehuman;
import drzhark.mocreatures.client.model.MoCModelWerewolf;
import drzhark.mocreatures.client.model.MoCModelWolf;
import drzhark.mocreatures.client.model.MoCModelWraith;
import drzhark.mocreatures.client.model.MoCModelWyvern;
import drzhark.mocreatures.client.model.legacy.MoCLegacyModelBigCat1;
import drzhark.mocreatures.client.model.legacy.MoCLegacyModelBigCat2;
import drzhark.mocreatures.client.renderer.entity.MoCRenderBird;
import drzhark.mocreatures.client.renderer.entity.MoCRenderBunny;
import drzhark.mocreatures.client.renderer.entity.MoCRenderButterfly;
import drzhark.mocreatures.client.renderer.entity.MoCRenderCricket;
import drzhark.mocreatures.client.renderer.entity.MoCRenderCrocodile;
import drzhark.mocreatures.client.renderer.entity.MoCRenderDolphin;
import drzhark.mocreatures.client.renderer.entity.MoCRenderEgg;
import drzhark.mocreatures.client.renderer.entity.MoCRenderFilchLizard;
import drzhark.mocreatures.client.renderer.entity.MoCRenderFirefly;
import drzhark.mocreatures.client.renderer.entity.MoCRenderGoat;
import drzhark.mocreatures.client.renderer.entity.MoCRenderGolem;
import drzhark.mocreatures.client.renderer.entity.MoCRenderGrasshopper;
import drzhark.mocreatures.client.renderer.entity.MoCRenderHellRat;
import drzhark.mocreatures.client.renderer.entity.MoCRenderHorse;
import drzhark.mocreatures.client.renderer.entity.MoCRenderHorseMob;
import drzhark.mocreatures.client.renderer.entity.MoCRenderInsect;
import drzhark.mocreatures.client.renderer.entity.MoCRenderKitty;
import drzhark.mocreatures.client.renderer.entity.MoCRenderKittyBed;
import drzhark.mocreatures.client.renderer.entity.MoCRenderLitterBox;
import drzhark.mocreatures.client.renderer.entity.MoCRenderMoC;
import drzhark.mocreatures.client.renderer.entity.MoCRenderMouse;
import drzhark.mocreatures.client.renderer.entity.MoCRenderOstrich;
import drzhark.mocreatures.client.renderer.entity.MoCRenderPetScorpion;
import drzhark.mocreatures.client.renderer.entity.MoCRenderRat;
import drzhark.mocreatures.client.renderer.entity.MoCRenderScorpion;
import drzhark.mocreatures.client.renderer.entity.MoCRenderShark;
import drzhark.mocreatures.client.renderer.entity.MoCRenderSnake;
import drzhark.mocreatures.client.renderer.entity.MoCRenderTRock;
import drzhark.mocreatures.client.renderer.entity.MoCRenderTurtle;
import drzhark.mocreatures.client.renderer.entity.MoCRenderWWolf;
import drzhark.mocreatures.client.renderer.entity.MoCRenderWerewolf;
import drzhark.mocreatures.client.renderer.entity.MoCRenderWraith;
import drzhark.mocreatures.client.renderer.entity.legacy.MoCLegacyRenderBigCat;
import drzhark.mocreatures.entity.hostile.MoCEntityWerewolf;
import drzhark.mocreatures.entity.passive.MoCEntityHorse;
import drzhark.mocreatures.entity.passive.MoCEntityMouse;
import drzhark.mocreatures.init.MoCEntities;
import net.minecraft.world.entity.EntityType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid="mocreatures", value={Dist.CLIENT}, bus=Mod.EventBusSubscriber.Bus.MOD)
public class MoCRendererRegistry {
    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer((EntityType)MoCEntities.BUNNY.get(), ctx -> new MoCRenderBunny(ctx, new MoCModelBunny(ctx.m_174023_(MoCModelRegistry.BUNNY)), 0.3f));
        event.registerEntityRenderer((EntityType)MoCEntities.BIRD.get(), ctx -> new MoCRenderBird(ctx, new MoCModelBird(ctx.m_174023_(MoCModelRegistry.BIRD)), 0.3f));
        event.registerEntityRenderer((EntityType)MoCEntities.TURTLE.get(), ctx -> new MoCRenderTurtle(ctx, new MoCModelTurtle(ctx.m_174023_(MoCModelRegistry.TURTLE)), 0.4f));
        event.registerEntityRenderer((EntityType)MoCEntities.MOUSE.get(), ctx -> new MoCRenderMouse(ctx, new MoCModelMouse<MoCEntityMouse>(ctx.m_174023_(MoCModelRegistry.MOUSE)), 0.1f));
        event.registerEntityRenderer((EntityType)MoCEntities.SNAKE.get(), ctx -> new MoCRenderSnake(ctx, new MoCModelSnake(ctx.m_174023_(MoCModelRegistry.SNAKE)), 0.0f));
        event.registerEntityRenderer((EntityType)MoCEntities.TURKEY.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelTurkey(ctx.m_174023_(MoCModelRegistry.TURKEY)), 0.4f));
        event.registerEntityRenderer((EntityType)MoCEntities.BUTTERFLY.get(), ctx -> new MoCRenderButterfly(ctx, new MoCModelButterfly(ctx.m_174023_(MoCModelRegistry.BUTTERFLY))));
        event.registerEntityRenderer((EntityType)MoCEntities.WILDHORSE.get(), ctx -> new MoCRenderHorse(ctx, new MoCModelHorse<MoCEntityHorse>(ctx.m_174023_(MoCModelRegistry.HORSE))));
        event.registerEntityRenderer((EntityType)MoCEntities.HORSE_MOB.get(), ctx -> new MoCRenderHorseMob(ctx, new MoCModelHorseMob(ctx.m_174023_(MoCModelRegistry.HORSE_MOB))));
        event.registerEntityRenderer((EntityType)MoCEntities.BOAR.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelBoar(ctx.m_174023_(MoCModelRegistry.BOAR)), 0.5f));
        event.registerEntityRenderer((EntityType)MoCEntities.BLACK_BEAR.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelBear(ctx.m_174023_(MoCModelRegistry.BEAR)), 0.7f));
        event.registerEntityRenderer((EntityType)MoCEntities.GRIZZLY_BEAR.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelBear(ctx.m_174023_(MoCModelRegistry.BEAR)), 0.7f));
        event.registerEntityRenderer((EntityType)MoCEntities.PANDA_BEAR.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelBear(ctx.m_174023_(MoCModelRegistry.BEAR)), 0.7f));
        event.registerEntityRenderer((EntityType)MoCEntities.POLAR_BEAR.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelBear(ctx.m_174023_(MoCModelRegistry.BEAR)), 0.7f));
        event.registerEntityRenderer((EntityType)MoCEntities.DUCK.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelDuck(ctx.m_174023_(MoCModelRegistry.DUCK)), 0.3f));
        event.registerEntityRenderer((EntityType)MoCEntities.DEER.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelDeer(ctx.m_174023_(MoCModelRegistry.DEER)), 0.5f));
        event.registerEntityRenderer((EntityType)MoCEntities.WWOLF.get(), ctx -> new MoCRenderWWolf(ctx, new MoCModelWolf(ctx.m_174023_(MoCModelRegistry.WOLF)), 0.7f));
        event.registerEntityRenderer((EntityType)MoCEntities.WRAITH.get(), ctx -> new MoCRenderWraith(ctx, new MoCModelWraith(ctx.m_174023_(MoCModelRegistry.WRAITH)), 0.5f));
        event.registerEntityRenderer((EntityType)MoCEntities.FLAME_WRAITH.get(), ctx -> new MoCRenderWraith(ctx, new MoCModelWraith(ctx.m_174023_(MoCModelRegistry.WRAITH)), 0.5f));
        event.registerEntityRenderer((EntityType)MoCEntities.WEREWOLF.get(), ctx -> new MoCRenderWerewolf(ctx, new MoCModelWerehuman<MoCEntityWerewolf>(ctx.m_174023_(MoCModelRegistry.WEREHUMAN)), new MoCModelWerewolf(ctx.m_174023_(MoCModelRegistry.WEREWOLF)), 0.7f));
        event.registerEntityRenderer((EntityType)MoCEntities.FILCH_LIZARD.get(), ctx -> new MoCRenderFilchLizard(ctx, new MoCModelFilchLizard(ctx.m_174023_(MoCModelRegistry.FILCH_LIZARD)), 0.5f));
        event.registerEntityRenderer((EntityType)MoCEntities.FOX.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelFox(ctx.m_174023_(MoCModelRegistry.FOX)), 0.5f));
        event.registerEntityRenderer((EntityType)MoCEntities.SHARK.get(), ctx -> new MoCRenderShark(ctx, new MoCModelShark(ctx.m_174023_(MoCModelRegistry.SHARK)), 0.6f));
        event.registerEntityRenderer((EntityType)MoCEntities.DOLPHIN.get(), ctx -> new MoCRenderDolphin(ctx, new MoCModelDolphin(ctx.m_174023_(MoCModelRegistry.DOLPHIN)), 0.6f));
        event.registerEntityRenderer((EntityType)MoCEntities.FISHY.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelFishy(ctx.m_174023_(MoCModelRegistry.FISHY)), 0.1f));
        event.registerEntityRenderer((EntityType)MoCEntities.EGG.get(), ctx -> new MoCRenderEgg(ctx, new MoCModelEgg(ctx.m_174023_(MoCModelRegistry.EGG)), 0.0f));
        event.registerEntityRenderer((EntityType)MoCEntities.KITTY.get(), ctx -> new MoCRenderKitty(ctx, new MoCModelKitty(ctx.m_174023_(MoCModelRegistry.KITTY), 0.0f, 15.0f), 0.4f));
        event.registerEntityRenderer((EntityType)MoCEntities.KITTY_BED.get(), ctx -> new MoCRenderKittyBed(ctx, new MoCModelKittyBed(ctx.m_174023_(MoCModelRegistry.KITTY_BED)), new MoCModelKittyBed2(ctx.m_174023_(MoCModelRegistry.KITTY_BED2)), 0.3f));
        event.registerEntityRenderer((EntityType)MoCEntities.LITTERBOX.get(), ctx -> new MoCRenderLitterBox(ctx, new MoCModelLitterBox(ctx.m_174023_(MoCModelRegistry.LITTER_BOX)), 0.3f));
        event.registerEntityRenderer((EntityType)MoCEntities.RAT.get(), ctx -> new MoCRenderRat(ctx, new MoCModelRat(ctx.m_174023_(MoCModelRegistry.RAT)), 0.2f));
        event.registerEntityRenderer((EntityType)MoCEntities.HELL_RAT.get(), ctx -> new MoCRenderHellRat(ctx, new MoCModelRat(ctx.m_174023_(MoCModelRegistry.RAT)), 0.4f));
        event.registerEntityRenderer((EntityType)MoCEntities.CAVE_SCORPION.get(), ctx -> new MoCRenderScorpion(ctx, new MoCModelScorpion(ctx.m_174023_(MoCModelRegistry.SCORPION)), 0.4f));
        event.registerEntityRenderer((EntityType)MoCEntities.DIRT_SCORPION.get(), ctx -> new MoCRenderScorpion(ctx, new MoCModelScorpion(ctx.m_174023_(MoCModelRegistry.SCORPION)), 0.4f));
        event.registerEntityRenderer((EntityType)MoCEntities.FIRE_SCORPION.get(), ctx -> new MoCRenderScorpion(ctx, new MoCModelScorpion(ctx.m_174023_(MoCModelRegistry.SCORPION)), 0.4f));
        event.registerEntityRenderer((EntityType)MoCEntities.FROST_SCORPION.get(), ctx -> new MoCRenderScorpion(ctx, new MoCModelScorpion(ctx.m_174023_(MoCModelRegistry.SCORPION)), 0.4f));
        event.registerEntityRenderer((EntityType)MoCEntities.UNDEAD_SCORPION.get(), ctx -> new MoCRenderScorpion(ctx, new MoCModelScorpion(ctx.m_174023_(MoCModelRegistry.SCORPION)), 0.4f));
        event.registerEntityRenderer((EntityType)MoCEntities.CROCODILE.get(), ctx -> new MoCRenderCrocodile(ctx, new MoCModelCrocodile(ctx.m_174023_(MoCModelRegistry.CROCODILE)), 0.5f));
        if (MoCreatures.proxy.legacyBigCatModels) {
            event.registerEntityRenderer((EntityType)MoCEntities.LION.get(), ctx -> new MoCLegacyRenderBigCat(ctx, new MoCLegacyModelBigCat2(ctx.m_174023_(MoCModelRegistry.LEGACY_BIG_CAT2)), new MoCLegacyModelBigCat1(ctx.m_174023_(MoCModelRegistry.LEGACY_BIG_CAT1)), 0.5f));
            event.registerEntityRenderer((EntityType)MoCEntities.TIGER.get(), ctx -> new MoCLegacyRenderBigCat(ctx, new MoCLegacyModelBigCat2(ctx.m_174023_(MoCModelRegistry.LEGACY_BIG_CAT2)), new MoCLegacyModelBigCat1(ctx.m_174023_(MoCModelRegistry.LEGACY_BIG_CAT1)), 0.5f));
            event.registerEntityRenderer((EntityType)MoCEntities.LEOPARD.get(), ctx -> new MoCLegacyRenderBigCat(ctx, new MoCLegacyModelBigCat2(ctx.m_174023_(MoCModelRegistry.LEGACY_BIG_CAT2)), new MoCLegacyModelBigCat1(ctx.m_174023_(MoCModelRegistry.LEGACY_BIG_CAT1)), 0.5f));
            event.registerEntityRenderer((EntityType)MoCEntities.PANTHER.get(), ctx -> new MoCLegacyRenderBigCat(ctx, new MoCLegacyModelBigCat2(ctx.m_174023_(MoCModelRegistry.LEGACY_BIG_CAT2)), new MoCLegacyModelBigCat1(ctx.m_174023_(MoCModelRegistry.LEGACY_BIG_CAT1)), 0.5f));
            event.registerEntityRenderer((EntityType)MoCEntities.LEOGER.get(), ctx -> new MoCLegacyRenderBigCat(ctx, new MoCLegacyModelBigCat2(ctx.m_174023_(MoCModelRegistry.LEGACY_BIG_CAT2)), new MoCLegacyModelBigCat1(ctx.m_174023_(MoCModelRegistry.LEGACY_BIG_CAT1)), 0.5f));
            event.registerEntityRenderer((EntityType)MoCEntities.LIARD.get(), ctx -> new MoCLegacyRenderBigCat(ctx, new MoCLegacyModelBigCat2(ctx.m_174023_(MoCModelRegistry.LEGACY_BIG_CAT2)), new MoCLegacyModelBigCat1(ctx.m_174023_(MoCModelRegistry.LEGACY_BIG_CAT1)), 0.5f));
            event.registerEntityRenderer((EntityType)MoCEntities.LIGER.get(), ctx -> new MoCLegacyRenderBigCat(ctx, new MoCLegacyModelBigCat2(ctx.m_174023_(MoCModelRegistry.LEGACY_BIG_CAT2)), new MoCLegacyModelBigCat1(ctx.m_174023_(MoCModelRegistry.LEGACY_BIG_CAT1)), 0.5f));
            event.registerEntityRenderer((EntityType)MoCEntities.LITHER.get(), ctx -> new MoCLegacyRenderBigCat(ctx, new MoCLegacyModelBigCat2(ctx.m_174023_(MoCModelRegistry.LEGACY_BIG_CAT2)), new MoCLegacyModelBigCat1(ctx.m_174023_(MoCModelRegistry.LEGACY_BIG_CAT1)), 0.5f));
            event.registerEntityRenderer((EntityType)MoCEntities.PANTHARD.get(), ctx -> new MoCLegacyRenderBigCat(ctx, new MoCLegacyModelBigCat2(ctx.m_174023_(MoCModelRegistry.LEGACY_BIG_CAT2)), new MoCLegacyModelBigCat1(ctx.m_174023_(MoCModelRegistry.LEGACY_BIG_CAT1)), 0.5f));
            event.registerEntityRenderer((EntityType)MoCEntities.PANTHGER.get(), ctx -> new MoCLegacyRenderBigCat(ctx, new MoCLegacyModelBigCat2(ctx.m_174023_(MoCModelRegistry.LEGACY_BIG_CAT2)), new MoCLegacyModelBigCat1(ctx.m_174023_(MoCModelRegistry.LEGACY_BIG_CAT1)), 0.5f));
        } else {
            event.registerEntityRenderer((EntityType)MoCEntities.LION.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelBigCat(ctx.m_174023_(MoCModelRegistry.BIG_CAT)), 0.5f));
            event.registerEntityRenderer((EntityType)MoCEntities.TIGER.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelBigCat(ctx.m_174023_(MoCModelRegistry.BIG_CAT)), 0.5f));
            event.registerEntityRenderer((EntityType)MoCEntities.LEOPARD.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelBigCat(ctx.m_174023_(MoCModelRegistry.BIG_CAT)), 0.5f));
            event.registerEntityRenderer((EntityType)MoCEntities.PANTHER.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelBigCat(ctx.m_174023_(MoCModelRegistry.BIG_CAT)), 0.5f));
            event.registerEntityRenderer((EntityType)MoCEntities.LEOGER.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelBigCat(ctx.m_174023_(MoCModelRegistry.BIG_CAT)), 0.5f));
            event.registerEntityRenderer((EntityType)MoCEntities.LIARD.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelBigCat(ctx.m_174023_(MoCModelRegistry.BIG_CAT)), 0.5f));
            event.registerEntityRenderer((EntityType)MoCEntities.LIGER.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelBigCat(ctx.m_174023_(MoCModelRegistry.BIG_CAT)), 0.5f));
            event.registerEntityRenderer((EntityType)MoCEntities.LITHER.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelBigCat(ctx.m_174023_(MoCModelRegistry.BIG_CAT)), 0.5f));
            event.registerEntityRenderer((EntityType)MoCEntities.PANTHARD.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelBigCat(ctx.m_174023_(MoCModelRegistry.BIG_CAT)), 0.5f));
            event.registerEntityRenderer((EntityType)MoCEntities.PANTHGER.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelBigCat(ctx.m_174023_(MoCModelRegistry.BIG_CAT)), 0.5f));
        }
        event.registerEntityRenderer((EntityType)MoCEntities.COD.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelMediumFish(ctx.m_174023_(MoCModelRegistry.MEDIUM_FISH)), 0.2f));
        event.registerEntityRenderer((EntityType)MoCEntities.SALMON.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelMediumFish(ctx.m_174023_(MoCModelRegistry.MEDIUM_FISH)), 0.2f));
        event.registerEntityRenderer((EntityType)MoCEntities.BASS.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelMediumFish(ctx.m_174023_(MoCModelRegistry.MEDIUM_FISH)), 0.2f));
        event.registerEntityRenderer((EntityType)MoCEntities.ANCHOVY.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelSmallFish(ctx.m_174023_(MoCModelRegistry.SMALL_FISH)), 0.1f));
        event.registerEntityRenderer((EntityType)MoCEntities.ANGELFISH.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelSmallFish(ctx.m_174023_(MoCModelRegistry.SMALL_FISH)), 0.1f));
        event.registerEntityRenderer((EntityType)MoCEntities.ANGLER.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelSmallFish(ctx.m_174023_(MoCModelRegistry.SMALL_FISH)), 0.1f));
        event.registerEntityRenderer((EntityType)MoCEntities.CLOWNFISH.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelSmallFish(ctx.m_174023_(MoCModelRegistry.SMALL_FISH)), 0.1f));
        event.registerEntityRenderer((EntityType)MoCEntities.GOLDFISH.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelSmallFish(ctx.m_174023_(MoCModelRegistry.SMALL_FISH)), 0.1f));
        event.registerEntityRenderer((EntityType)MoCEntities.HIPPOTANG.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelSmallFish(ctx.m_174023_(MoCModelRegistry.SMALL_FISH)), 0.1f));
        event.registerEntityRenderer((EntityType)MoCEntities.MANDERIN.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelSmallFish(ctx.m_174023_(MoCModelRegistry.SMALL_FISH)), 0.1f));
        event.registerEntityRenderer((EntityType)MoCEntities.PIRANHA.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelSmallFish(ctx.m_174023_(MoCModelRegistry.SMALL_FISH)), 0.1f));
        event.registerEntityRenderer((EntityType)MoCEntities.MANTA_RAY.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelRay(ctx.m_174023_(MoCModelRegistry.RAY)), 0.4f));
        event.registerEntityRenderer((EntityType)MoCEntities.STING_RAY.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelRay(ctx.m_174023_(MoCModelRegistry.RAY)), 0.4f));
        event.registerEntityRenderer((EntityType)MoCEntities.JELLYFISH.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelJellyFish(ctx.m_174023_(MoCModelRegistry.JELLYFISH)), 0.1f));
        event.registerEntityRenderer((EntityType)MoCEntities.GOAT.get(), ctx -> new MoCRenderGoat(ctx, new MoCModelGoat(ctx.m_174023_(MoCModelRegistry.GOAT)), 0.3f));
        event.registerEntityRenderer((EntityType)MoCEntities.OSTRICH.get(), ctx -> new MoCRenderOstrich(ctx, new MoCModelOstrich(ctx.m_174023_(MoCModelRegistry.OSTRICH)), 0.5f));
        event.registerEntityRenderer((EntityType)MoCEntities.BEE.get(), ctx -> new MoCRenderInsect(ctx, new MoCModelBee(ctx.m_174023_(MoCModelRegistry.BEE))));
        event.registerEntityRenderer((EntityType)MoCEntities.FLY.get(), ctx -> new MoCRenderInsect(ctx, new MoCModelFly(ctx.m_174023_(MoCModelRegistry.FLY))));
        event.registerEntityRenderer((EntityType)MoCEntities.DRAGONFLY.get(), ctx -> new MoCRenderInsect(ctx, new MoCModelDragonfly(ctx.m_174023_(MoCModelRegistry.DRAGONFLY))));
        event.registerEntityRenderer((EntityType)MoCEntities.FIREFLY.get(), ctx -> new MoCRenderFirefly(ctx, new MoCModelFirefly(ctx.m_174023_(MoCModelRegistry.FIREFLY))));
        event.registerEntityRenderer((EntityType)MoCEntities.CRICKET.get(), ctx -> new MoCRenderCricket(ctx, new MoCModelCricket(ctx.m_174023_(MoCModelRegistry.CRICKET))));
        event.registerEntityRenderer((EntityType)MoCEntities.GRASSHOPPER.get(), ctx -> new MoCRenderGrasshopper(ctx, new MoCModelGrasshopper(ctx.m_174023_(MoCModelRegistry.GRASSHOPPER))));
        event.registerEntityRenderer((EntityType)MoCEntities.SNAIL.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelSnail(ctx.m_174023_(MoCModelRegistry.SNAIL)), 0.0f));
        event.registerEntityRenderer((EntityType)MoCEntities.ROACH.get(), ctx -> new MoCRenderInsect(ctx, new MoCModelRoach(ctx.m_174023_(MoCModelRegistry.ROACH))));
        event.registerEntityRenderer((EntityType)MoCEntities.BIG_GOLEM.get(), ctx -> new MoCRenderGolem(ctx, new MoCModelGolem(ctx.m_174023_(MoCModelRegistry.BIG_GOLEM)), 0.5f));
        event.registerEntityRenderer((EntityType)MoCEntities.TROCK.get(), ctx -> new MoCRenderTRock(ctx));
        event.registerEntityRenderer((EntityType)MoCEntities.PET_SCORPION.get(), ctx -> new MoCRenderPetScorpion(ctx, new MoCModelPetScorpion(ctx.m_174023_(MoCModelRegistry.PET_SCORPION)), 0.4f));
        event.registerEntityRenderer((EntityType)MoCEntities.ELEPHANT.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelElephant(ctx.m_174023_(MoCModelRegistry.ELEPHANT)), 0.7f));
        event.registerEntityRenderer((EntityType)MoCEntities.KOMODO_DRAGON.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelKomodo(ctx.m_174023_(MoCModelRegistry.KOMODO)), 0.3f));
        event.registerEntityRenderer((EntityType)MoCEntities.WYVERN.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelWyvern(ctx.m_174023_(MoCModelRegistry.WYVERN)), 0.5f));
        event.registerEntityRenderer((EntityType)MoCEntities.GREEN_OGRE.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelOgre(ctx.m_174023_(MoCModelRegistry.OGRE)), 0.6f));
        event.registerEntityRenderer((EntityType)MoCEntities.CAVE_OGRE.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelOgre(ctx.m_174023_(MoCModelRegistry.OGRE)), 0.6f));
        event.registerEntityRenderer((EntityType)MoCEntities.FIRE_OGRE.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelOgre(ctx.m_174023_(MoCModelRegistry.OGRE)), 0.6f));
        event.registerEntityRenderer((EntityType)MoCEntities.MAGGOT.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelMaggot(ctx.m_174023_(MoCModelRegistry.MAGGOT)), 0.0f));
        event.registerEntityRenderer((EntityType)MoCEntities.CRAB.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelCrab(ctx.m_174023_(MoCModelRegistry.CRAB)), 0.2f));
        event.registerEntityRenderer((EntityType)MoCEntities.RACCOON.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelRaccoon(ctx.m_174023_(MoCModelRegistry.RACCOON)), 0.4f));
        event.registerEntityRenderer((EntityType)MoCEntities.MINI_GOLEM.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelMiniGolem(ctx.m_174023_(MoCModelRegistry.MINI_GOLEM)), 0.5f));
        event.registerEntityRenderer((EntityType)MoCEntities.SILVER_SKELETON.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelSilverSkeleton(ctx.m_174023_(MoCModelRegistry.SILVER_SKELETON)), 0.6f));
        event.registerEntityRenderer((EntityType)MoCEntities.ANT.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelAnt(ctx.m_174023_(MoCModelRegistry.ANT)), 0.0f));
        event.registerEntityRenderer((EntityType)MoCEntities.ENT.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelEnt(ctx.m_174023_(MoCModelRegistry.ENT)), 0.5f));
        event.registerEntityRenderer((EntityType)MoCEntities.MOLE.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelMole(ctx.m_174023_(MoCModelRegistry.MOLE)), 0.0f));
        event.registerEntityRenderer((EntityType)MoCEntities.DARK_MANTICORE.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelManticore(ctx.m_174023_(MoCModelRegistry.MANTICORE)), 0.7f));
        event.registerEntityRenderer((EntityType)MoCEntities.FIRE_MANTICORE.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelManticore(ctx.m_174023_(MoCModelRegistry.MANTICORE)), 0.7f));
        event.registerEntityRenderer((EntityType)MoCEntities.FROST_MANTICORE.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelManticore(ctx.m_174023_(MoCModelRegistry.MANTICORE)), 0.7f));
        event.registerEntityRenderer((EntityType)MoCEntities.PLAIN_MANTICORE.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelManticore(ctx.m_174023_(MoCModelRegistry.MANTICORE)), 0.7f));
        event.registerEntityRenderer((EntityType)MoCEntities.TOXIC_MANTICORE.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelManticore(ctx.m_174023_(MoCModelRegistry.MANTICORE)), 0.7f));
        event.registerEntityRenderer((EntityType)MoCEntities.MANTICORE_PET.get(), ctx -> new MoCRenderMoC(ctx, new MoCModelManticorePet(ctx.m_174023_(MoCModelRegistry.MANTICORE_PET)), 0.7f));
    }
}

