/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeDeformation
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.MoCEntityAnimal;
import drzhark.mocreatures.entity.neutral.MoCEntityOstrich;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelOstrich<T extends MoCEntityOstrich>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "ostrich"), "main");
    private static final float RADIAN_CONV = 57.29578f;
    private final ModelPart UBeak;
    private final ModelPart UBeak2;
    private final ModelPart UBeakb;
    private final ModelPart UBeak2b;
    private final ModelPart LBeak;
    private final ModelPart LBeakb;
    private final ModelPart LBeak2;
    private final ModelPart LBeak2b;
    private final ModelPart Body;
    private final ModelPart Tail;
    private final ModelPart LLegA;
    private final ModelPart LLegB;
    private final ModelPart LLegC;
    private final ModelPart LFoot;
    private final ModelPart RLegA;
    private final ModelPart RLegB;
    private final ModelPart RLegC;
    private final ModelPart RFoot;
    private final ModelPart Tail1;
    private final ModelPart Tail2;
    private final ModelPart Tail3;
    private final ModelPart LWingB;
    private final ModelPart LWingC;
    private final ModelPart LWingD;
    private final ModelPart LWingE;
    private final ModelPart RWingB;
    private final ModelPart RWingC;
    private final ModelPart RWingD;
    private final ModelPart RWingE;
    private final ModelPart SaddleA;
    private final ModelPart SaddleB;
    private final ModelPart SaddleL;
    private final ModelPart SaddleR;
    private final ModelPart SaddleL2;
    private final ModelPart SaddleR2;
    private final ModelPart SaddleC;
    private final ModelPart NeckLFeather;
    private final ModelPart NeckUFeather;
    private final ModelPart NeckD;
    private final ModelPart Saddlebag;
    private final ModelPart Flagpole;
    private final ModelPart FlagBlack;
    private final ModelPart FlagDarkGrey;
    private final ModelPart FlagYellow;
    private final ModelPart FlagBrown;
    private final ModelPart FlagGreen;
    private final ModelPart FlagCyan;
    private final ModelPart FlagLightBlue;
    private final ModelPart FlagDarkBlue;
    private final ModelPart FlagPurple;
    private final ModelPart FlagDarkPurple;
    private final ModelPart FlagDarkGreen;
    private final ModelPart FlagLightRed;
    private final ModelPart FlagRed;
    private final ModelPart FlagWhite;
    private final ModelPart FlagGrey;
    private final ModelPart FlagOrange;
    private final ModelPart NeckU;
    private final ModelPart NeckL;
    private final ModelPart NeckHarness;
    private final ModelPart NeckHarness2;
    private final ModelPart NeckHarnessRight;
    private final ModelPart NeckHarnessLeft;
    private final ModelPart Head;
    private final ModelPart UniHorn;
    private final ModelPart HelmetLeather;
    private final ModelPart HelmetIron;
    private final ModelPart HelmetGold;
    private final ModelPart HelmetDiamond;
    private final ModelPart HelmetHide;
    private final ModelPart HelmetNeckHide;
    private final ModelPart HelmetHideEar1;
    private final ModelPart HelmetHideEar2;
    private final ModelPart HelmetFur;
    private final ModelPart HelmetNeckFur;
    private final ModelPart HelmetFurEar1;
    private final ModelPart HelmetFurEar2;
    private final ModelPart HelmetReptile;
    private final ModelPart HelmetReptileEar1;
    private final ModelPart HelmetReptileEar2;
    private final ModelPart HelmetGreenChitin;
    private final ModelPart HelmetYellowChitin;
    private final ModelPart HelmetBlueChitin;
    private final ModelPart HelmetBlackChitin;
    private final ModelPart HelmetRedChitin;
    private final ModelPart Tailpart1;
    private final ModelPart Tailpart2;
    private final ModelPart Tailpart3;
    private final ModelPart Tailpart4;
    private final ModelPart Tailpart5;
    private byte typeI;
    private boolean openMouth;
    private boolean isSaddled;
    private boolean bagged;
    private boolean rider;
    private int helmet;
    private int flagColor;

    public MoCModelOstrich(ModelPart root) {
        this.UBeak = root.m_171324_("UBeak");
        this.UBeak2 = root.m_171324_("UBeak2");
        this.UBeakb = root.m_171324_("UBeakb");
        this.UBeak2b = root.m_171324_("UBeak2b");
        this.LBeak = root.m_171324_("LBeak");
        this.LBeakb = root.m_171324_("LBeakb");
        this.LBeak2 = root.m_171324_("LBeak2");
        this.LBeak2b = root.m_171324_("LBeak2b");
        this.Body = root.m_171324_("Body");
        this.Tail = root.m_171324_("Tail");
        this.LLegA = root.m_171324_("LLegA");
        this.LLegB = root.m_171324_("LLegB");
        this.LLegC = root.m_171324_("LLegC");
        this.LFoot = root.m_171324_("LFoot");
        this.RLegA = root.m_171324_("RLegA");
        this.RLegB = root.m_171324_("RLegB");
        this.RLegC = root.m_171324_("RLegC");
        this.RFoot = root.m_171324_("RFoot");
        this.Tail1 = root.m_171324_("Tail1");
        this.Tail2 = root.m_171324_("Tail2");
        this.Tail3 = root.m_171324_("Tail3");
        this.LWingB = root.m_171324_("LWingB");
        this.LWingC = root.m_171324_("LWingC");
        this.LWingD = root.m_171324_("LWingD");
        this.LWingE = root.m_171324_("LWingE");
        this.RWingB = root.m_171324_("RWingB");
        this.RWingC = root.m_171324_("RWingC");
        this.RWingD = root.m_171324_("RWingD");
        this.RWingE = root.m_171324_("RWingE");
        this.SaddleA = root.m_171324_("SaddleA");
        this.SaddleB = root.m_171324_("SaddleB");
        this.SaddleL = root.m_171324_("SaddleL");
        this.SaddleR = root.m_171324_("SaddleR");
        this.SaddleL2 = root.m_171324_("SaddleL2");
        this.SaddleR2 = root.m_171324_("SaddleR2");
        this.SaddleC = root.m_171324_("SaddleC");
        this.NeckLFeather = root.m_171324_("NeckLFeather");
        this.NeckUFeather = root.m_171324_("NeckUFeather");
        this.NeckD = root.m_171324_("NeckD");
        this.Saddlebag = root.m_171324_("Saddlebag");
        this.Flagpole = root.m_171324_("Flagpole");
        this.FlagBlack = root.m_171324_("FlagBlack");
        this.FlagDarkGrey = root.m_171324_("FlagDarkGrey");
        this.FlagYellow = root.m_171324_("FlagYellow");
        this.FlagBrown = root.m_171324_("FlagBrown");
        this.FlagGreen = root.m_171324_("FlagGreen");
        this.FlagCyan = root.m_171324_("FlagCyan");
        this.FlagLightBlue = root.m_171324_("FlagLightBlue");
        this.FlagDarkBlue = root.m_171324_("FlagDarkBlue");
        this.FlagPurple = root.m_171324_("FlagPurple");
        this.FlagDarkPurple = root.m_171324_("FlagDarkPurple");
        this.FlagDarkGreen = root.m_171324_("FlagDarkGreen");
        this.FlagLightRed = root.m_171324_("FlagLightRed");
        this.FlagRed = root.m_171324_("FlagRed");
        this.FlagWhite = root.m_171324_("FlagWhite");
        this.FlagGrey = root.m_171324_("FlagGrey");
        this.FlagOrange = root.m_171324_("FlagOrange");
        this.NeckU = root.m_171324_("NeckU");
        this.NeckL = root.m_171324_("NeckL");
        this.NeckHarness = root.m_171324_("NeckHarness");
        this.NeckHarness2 = root.m_171324_("NeckHarness2");
        this.NeckHarnessRight = root.m_171324_("NeckHarnessRight");
        this.NeckHarnessLeft = root.m_171324_("NeckHarnessLeft");
        this.Head = root.m_171324_("Head");
        this.UniHorn = root.m_171324_("UniHorn");
        this.HelmetLeather = root.m_171324_("HelmetLeather");
        this.HelmetIron = root.m_171324_("HelmetIron");
        this.HelmetGold = root.m_171324_("HelmetGold");
        this.HelmetDiamond = root.m_171324_("HelmetDiamond");
        this.HelmetHide = root.m_171324_("HelmetHide");
        this.HelmetNeckHide = root.m_171324_("HelmetNeckHide");
        this.HelmetHideEar1 = root.m_171324_("HelmetHideEar1");
        this.HelmetHideEar2 = root.m_171324_("HelmetHideEar2");
        this.HelmetFur = root.m_171324_("HelmetFur");
        this.HelmetNeckFur = root.m_171324_("HelmetNeckFur");
        this.HelmetFurEar1 = root.m_171324_("HelmetFurEar1");
        this.HelmetFurEar2 = root.m_171324_("HelmetFurEar2");
        this.HelmetReptile = root.m_171324_("HelmetReptile");
        this.HelmetReptileEar1 = root.m_171324_("HelmetReptileEar1");
        this.HelmetReptileEar2 = root.m_171324_("HelmetReptileEar2");
        this.HelmetGreenChitin = root.m_171324_("HelmetGreenChitin");
        this.HelmetYellowChitin = root.m_171324_("HelmetYellowChitin");
        this.HelmetBlueChitin = root.m_171324_("HelmetBlueChitin");
        this.HelmetBlackChitin = root.m_171324_("HelmetBlackChitin");
        this.HelmetRedChitin = root.m_171324_("HelmetRedChitin");
        this.Tailpart1 = root.m_171324_("Tailpart1");
        this.Tailpart2 = root.m_171324_("Tailpart2");
        this.Tailpart3 = root.m_171324_("Tailpart3");
        this.Tailpart4 = root.m_171324_("Tailpart4");
        this.Tailpart5 = root.m_171324_("Tailpart5");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        root.m_171599_("UBeak", CubeListBuilder.m_171558_().m_171514_(12, 16).m_171488_(-1.5f, -15.0f, -5.5f, 3.0f, 1.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-6.0f));
        root.m_171599_("UBeak2", CubeListBuilder.m_171558_().m_171514_(20, 16).m_171488_(-1.0f, -15.0f, -7.5f, 2.0f, 1.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-6.0f));
        root.m_171599_("UBeakb", CubeListBuilder.m_171558_().m_171514_(12, 16).m_171488_(-1.5f, -15.0f, -6.5f, 3.0f, 1.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)3.0f, (float)-6.0f, (float)-0.0698132f, (float)0.0f, (float)0.0f));
        root.m_171599_("UBeak2b", CubeListBuilder.m_171558_().m_171514_(20, 16).m_171488_(-1.0f, -15.0f, -8.5f, 2.0f, 1.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)3.0f, (float)-6.0f, (float)-0.0698132f, (float)0.0f, (float)0.0f));
        root.m_171599_("LBeak", CubeListBuilder.m_171558_().m_171514_(12, 22).m_171488_(-1.5f, -14.0f, -5.5f, 3.0f, 1.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-6.0f));
        root.m_171599_("LBeakb", CubeListBuilder.m_171558_().m_171514_(12, 22).m_171488_(-1.5f, -14.0f, -3.9f, 3.0f, 1.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)3.0f, (float)-6.0f, (float)0.122173f, (float)0.0f, (float)0.0f));
        root.m_171599_("LBeak2", CubeListBuilder.m_171558_().m_171514_(20, 22).m_171488_(-1.0f, -14.0f, -7.5f, 2.0f, 1.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-6.0f));
        root.m_171599_("LBeak2b", CubeListBuilder.m_171558_().m_171514_(20, 22).m_171488_(-1.0f, -14.0f, -5.9f, 2.0f, 1.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)3.0f, (float)-6.0f, (float)0.122173f, (float)0.0f, (float)0.0f));
        root.m_171599_("Body", CubeListBuilder.m_171558_().m_171514_(0, 38).m_171488_(-4.0f, 1.0f, 0.0f, 8.0f, 10.0f, 16.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)-6.0f));
        root.m_171599_("LLegA", CubeListBuilder.m_171558_().m_171514_(50, 28).m_171488_(-2.0f, -1.0f, -2.5f, 4.0f, 6.0f, 5.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)4.0f, (float)5.0f, (float)4.0f, (float)0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("LLegB", CubeListBuilder.m_171558_().m_171514_(50, 39).m_171488_(-1.5f, 5.0f, -1.5f, 3.0f, 4.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)4.0f, (float)5.0f, (float)4.0f, (float)0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("LLegC", CubeListBuilder.m_171558_().m_171514_(8, 38).m_171488_(-1.0f, 8.0f, 2.5f, 2.0f, 10.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)4.0f, (float)5.0f, (float)4.0f, (float)-0.2617994f, (float)0.0f, (float)0.0f));
        root.m_171599_("LFoot", CubeListBuilder.m_171558_().m_171514_(32, 42).m_171488_(-1.0f, 17.0f, -9.0f, 2.0f, 1.0f, 5.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)4.0f, (float)5.0f, (float)4.0f, (float)0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("RLegA", CubeListBuilder.m_171558_().m_171514_(0, 27).m_171488_(-2.0f, -1.0f, -2.5f, 4.0f, 6.0f, 5.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-4.0f, (float)5.0f, (float)4.0f, (float)0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("RLegB", CubeListBuilder.m_171558_().m_171514_(18, 27).m_171488_(-1.5f, 5.0f, -1.5f, 3.0f, 4.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-4.0f, (float)5.0f, (float)4.0f, (float)0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("RLegC", CubeListBuilder.m_171558_().m_171514_(0, 38).m_171488_(-1.0f, 8.0f, 2.5f, 2.0f, 10.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-4.0f, (float)5.0f, (float)4.0f, (float)-0.2617994f, (float)0.0f, (float)0.0f));
        root.m_171599_("RFoot", CubeListBuilder.m_171558_().m_171514_(32, 48).m_171488_(-1.0f, 17.0f, -9.0f, 2.0f, 1.0f, 5.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-4.0f, (float)5.0f, (float)4.0f, (float)0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("Tail1", CubeListBuilder.m_171558_().m_171514_(44, 18).m_171488_(-0.5f, -2.0f, -2.0f, 1.0f, 4.0f, 6.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)4.0f, (float)15.0f, (float)0.3490659f, (float)0.0f, (float)0.0f));
        root.m_171599_("Tail2", CubeListBuilder.m_171558_().m_171514_(58, 18).m_171488_(-2.6f, -2.0f, -2.0f, 1.0f, 4.0f, 6.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)4.0f, (float)15.0f, (float)0.3490659f, (float)-0.2617994f, (float)0.0f));
        root.m_171599_("Tail3", CubeListBuilder.m_171558_().m_171514_(30, 18).m_171488_(1.6f, -2.0f, -2.0f, 1.0f, 4.0f, 6.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)4.0f, (float)15.0f, (float)0.3490659f, (float)0.2617994f, (float)0.0f));
        root.m_171599_("LWingB", CubeListBuilder.m_171558_().m_171514_(68, 46).m_171488_(-0.5f, -3.0f, 0.0f, 1.0f, 4.0f, 14.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)4.0f, (float)4.0f, (float)-3.0f, (float)0.0872665f, (float)0.0872665f, (float)0.0f));
        root.m_171599_("LWingC", CubeListBuilder.m_171558_().m_171514_(98, 46).m_171488_(-1.0f, 0.0f, 0.0f, 1.0f, 4.0f, 14.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)4.0f, (float)4.0f, (float)-3.0f, (float)0.0f, (float)0.0872665f, (float)0.0f));
        root.m_171599_("LWingD", CubeListBuilder.m_171558_().m_171514_(26, 84).m_171488_(0.0f, -1.0f, -1.0f, 15.0f, 2.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)4.0f, (float)3.0f, (float)-3.0f, (float)0.0f, (float)0.0f, (float)-0.3490659f));
        root.m_171599_("LWingE", CubeListBuilder.m_171558_().m_171514_(0, 103).m_171488_(0.0f, 0.0f, 1.0f, 15.0f, 0.0f, 15.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)4.0f, (float)3.0f, (float)-3.0f, (float)0.0f, (float)0.0f, (float)-0.3490659f));
        root.m_171599_("RWingB", CubeListBuilder.m_171558_().m_171514_(68, 0).m_171488_(-0.5f, -3.0f, 0.0f, 1.0f, 4.0f, 14.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-4.0f, (float)4.0f, (float)-3.0f, (float)0.0872665f, (float)-0.0872665f, (float)0.0f));
        root.m_171599_("RWingC", CubeListBuilder.m_171558_().m_171514_(98, 0).m_171488_(0.0f, 0.0f, 0.0f, 1.0f, 4.0f, 14.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-4.0f, (float)4.0f, (float)-3.0f, (float)0.0f, (float)-0.0872665f, (float)0.0f));
        root.m_171599_("RWingD", CubeListBuilder.m_171558_().m_171514_(26, 80).m_171488_(-15.0f, -1.0f, -1.0f, 15.0f, 2.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-4.0f, (float)3.0f, (float)-3.0f, (float)0.0f, (float)0.0f, (float)0.3490659f));
        root.m_171599_("RWingE", CubeListBuilder.m_171558_().m_171514_(0, 88).m_171488_(-15.0f, 0.0f, 1.0f, 15.0f, 0.0f, 15.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-4.0f, (float)3.0f, (float)-3.0f, (float)0.0f, (float)0.0f, (float)0.3490659f));
        root.m_171599_("SaddleA", CubeListBuilder.m_171558_().m_171514_(72, 18).m_171488_(-4.0f, 0.5f, -3.0f, 8.0f, 1.0f, 8.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        root.m_171599_("SaddleB", CubeListBuilder.m_171558_().m_171514_(72, 27).m_171488_(-1.5f, 0.0f, -3.0f, 3.0f, 1.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        root.m_171599_("SaddleL", CubeListBuilder.m_171558_().m_171514_(72, 30).m_171488_(-0.5f, 0.0f, -0.5f, 1.0f, 6.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)4.0f, (float)1.0f, (float)0.0f));
        root.m_171599_("SaddleR", CubeListBuilder.m_171558_().m_171514_(84, 30).m_171488_(-0.5f, 0.0f, -0.5f, 1.0f, 6.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-4.0f, (float)1.0f, (float)0.0f));
        root.m_171599_("SaddleL2", CubeListBuilder.m_171558_().m_171514_(76, 30).m_171488_(-0.5f, 6.0f, -1.0f, 1.0f, 2.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)4.0f, (float)1.0f, (float)0.0f));
        root.m_171599_("SaddleR2", CubeListBuilder.m_171558_().m_171514_(88, 30).m_171488_(-0.5f, 6.0f, -1.0f, 1.0f, 2.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-4.0f, (float)1.0f, (float)0.0f));
        root.m_171599_("SaddleC", CubeListBuilder.m_171558_().m_171514_(84, 27).m_171488_(-4.0f, 0.0f, 3.0f, 8.0f, 1.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        root.m_171599_("NeckLFeather", CubeListBuilder.m_171558_().m_171514_(8, 73).m_171488_(0.0f, -8.0f, -0.5f, 0.0f, 7.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)3.0f, (float)-6.0f, (float)0.2007129f, (float)0.0f, (float)0.0f));
        root.m_171599_("NeckUFeather", CubeListBuilder.m_171558_().m_171514_(0, 73).m_171488_(0.0f, -16.0f, -2.0f, 0.0f, 9.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-6.0f));
        root.m_171599_("NeckD", CubeListBuilder.m_171558_().m_171514_(0, 16).m_171488_(-1.5f, -4.0f, -2.0f, 3.0f, 8.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)3.0f, (float)-6.0f, (float)0.4363323f, (float)0.0f, (float)0.0f));
        root.m_171599_("Saddlebag", CubeListBuilder.m_171558_().m_171514_(32, 7).m_171488_(-4.5f, -3.0f, 5.0f, 9.0f, 4.0f, 7.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)-0.2602503f, (float)0.0f, (float)0.0f));
        root.m_171599_("Flagpole", CubeListBuilder.m_171558_().m_171514_(28, 0).m_171488_(-0.5f, -15.0f, -0.5f, 1.0f, 17.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)5.0f, (float)-0.2602503f, (float)0.0f, (float)0.0f));
        root.m_171599_("FlagBlack", CubeListBuilder.m_171558_().m_171514_(108, 8).m_171488_(0.0f, -2.1f, 0.0f, 0.0f, 4.0f, 10.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-12.0f, (float)8.0f, (float)-0.2602503f, (float)0.0f, (float)0.0f));
        root.m_171599_("FlagDarkGrey", CubeListBuilder.m_171558_().m_171514_(108, 12).m_171488_(0.0f, -2.1f, 0.0f, 0.0f, 4.0f, 10.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-12.0f, (float)8.0f, (float)-0.2602503f, (float)0.0f, (float)0.0f));
        root.m_171599_("FlagYellow", CubeListBuilder.m_171558_().m_171514_(48, 46).m_171488_(0.0f, -2.1f, 0.0f, 0.0f, 4.0f, 10.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-12.0f, (float)8.0f, (float)-0.2602503f, (float)0.0f, (float)0.0f));
        root.m_171599_("FlagBrown", CubeListBuilder.m_171558_().m_171514_(48, 42).m_171488_(0.0f, -2.1f, 0.0f, 0.0f, 4.0f, 10.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-12.0f, (float)8.0f, (float)-0.2602503f, (float)0.0f, (float)0.0f));
        root.m_171599_("FlagGreen", CubeListBuilder.m_171558_().m_171514_(48, 38).m_171488_(0.0f, -2.1f, 0.0f, 0.0f, 4.0f, 10.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-12.0f, (float)8.0f, (float)-0.2602503f, (float)0.0f, (float)0.0f));
        root.m_171599_("FlagCyan", CubeListBuilder.m_171558_().m_171514_(48, 50).m_171488_(0.0f, -2.1f, 0.0f, 0.0f, 4.0f, 10.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-12.0f, (float)8.0f, (float)-0.2602503f, (float)0.0f, (float)0.0f));
        root.m_171599_("FlagLightBlue", CubeListBuilder.m_171558_().m_171514_(68, 32).m_171488_(0.0f, -2.1f, 0.0f, 0.0f, 4.0f, 10.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-12.0f, (float)8.0f, (float)-0.2602503f, (float)0.0f, (float)0.0f));
        root.m_171599_("FlagDarkBlue", CubeListBuilder.m_171558_().m_171514_(68, 28).m_171488_(0.0f, -2.1f, 0.0f, 0.0f, 4.0f, 10.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-12.0f, (float)8.0f, (float)-0.2602503f, (float)0.0f, (float)0.0f));
        root.m_171599_("FlagPurple", CubeListBuilder.m_171558_().m_171514_(88, 32).m_171488_(0.0f, -2.1f, 0.0f, 0.0f, 4.0f, 10.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-12.0f, (float)8.0f, (float)-0.2602503f, (float)0.0f, (float)0.0f));
        root.m_171599_("FlagDarkPurple", CubeListBuilder.m_171558_().m_171514_(88, 28).m_171488_(0.0f, -2.1f, 0.0f, 0.0f, 4.0f, 10.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-12.0f, (float)8.0f, (float)-0.2602503f, (float)0.0f, (float)0.0f));
        root.m_171599_("FlagDarkGreen", CubeListBuilder.m_171558_().m_171514_(108, 32).m_171488_(0.0f, -2.1f, 0.0f, 0.0f, 4.0f, 10.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-12.0f, (float)8.0f, (float)-0.2602503f, (float)0.0f, (float)0.0f));
        root.m_171599_("FlagLightRed", CubeListBuilder.m_171558_().m_171514_(108, 28).m_171488_(0.0f, -2.1f, 0.0f, 0.0f, 4.0f, 10.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-12.0f, (float)8.0f, (float)-0.2602503f, (float)0.0f, (float)0.0f));
        root.m_171599_("FlagRed", CubeListBuilder.m_171558_().m_171514_(108, 24).m_171488_(0.0f, -2.1f, 0.0f, 0.0f, 4.0f, 10.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-12.0f, (float)8.0f, (float)-0.2602503f, (float)0.0f, (float)0.0f));
        root.m_171599_("FlagWhite", CubeListBuilder.m_171558_().m_171514_(108, 20).m_171488_(0.0f, -2.1f, 0.0f, 0.0f, 4.0f, 10.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-12.0f, (float)8.0f, (float)-0.2602503f, (float)0.0f, (float)0.0f));
        root.m_171599_("FlagGrey", CubeListBuilder.m_171558_().m_171514_(108, 16).m_171488_(0.0f, -2.1f, 0.0f, 0.0f, 4.0f, 10.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-12.0f, (float)8.0f, (float)-0.2602503f, (float)0.0f, (float)0.0f));
        root.m_171599_("FlagOrange", CubeListBuilder.m_171558_().m_171514_(88, 24).m_171488_(0.0f, -2.1f, 0.0f, 0.0f, 4.0f, 10.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-12.0f, (float)8.0f, (float)-0.2602503f, (float)0.0f, (float)0.0f));
        root.m_171599_("NeckU", CubeListBuilder.m_171558_().m_171514_(20, 0).m_171488_(-1.0f, -12.0f, -4.0f, 2.0f, 5.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-6.0f));
        root.m_171599_("NeckL", CubeListBuilder.m_171558_().m_171514_(20, 7).m_171488_(-1.0f, -8.0f, -2.5f, 2.0f, 5.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)3.0f, (float)-6.0f, (float)0.2007129f, (float)0.0f, (float)0.0f));
        root.m_171599_("NeckHarness", CubeListBuilder.m_171558_().m_171514_(0, 11).m_171488_(-2.0f, -3.0f, -2.5f, 4.0f, 1.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)3.0f, (float)-6.0f, (float)0.4363323f, (float)0.0f, (float)0.0f));
        root.m_171599_("NeckHarness2", CubeListBuilder.m_171558_().m_171514_(84, 55).m_171488_(-3.0f, -2.5f, -2.0f, 6.0f, 1.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-6.0f));
        root.m_171599_("NeckHarnessRight", CubeListBuilder.m_171558_().m_171514_(84, 45).m_171488_(-2.3f, -3.5f, -0.5f, 0.0f, 3.0f, 12.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)3.0f, (float)-6.0f, (float)0.8983798f, (float)0.0f, (float)0.0f));
        root.m_171599_("NeckHarnessLeft", CubeListBuilder.m_171558_().m_171514_(84, 45).m_171488_(2.3f, -3.5f, -0.5f, 0.0f, 3.0f, 12.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)3.0f, (float)-6.0f, (float)0.8983798f, (float)0.0f, (float)0.0f));
        root.m_171599_("Head", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-1.5f, -16.0f, -4.5f, 3.0f, 4.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-6.0f));
        root.m_171599_("UniHorn", CubeListBuilder.m_171558_().m_171514_(0, 8).m_171488_(-0.5f, -21.0f, 0.5f, 1.0f, 6.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)3.0f, (float)-6.0f, (float)0.3171542f, (float)0.0f, (float)0.0f));
        root.m_171599_("HelmetLeather", CubeListBuilder.m_171558_().m_171514_(66, 0).m_171488_(-2.0f, -16.5f, -5.0f, 4.0f, 5.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-6.0f));
        root.m_171599_("HelmetIron", CubeListBuilder.m_171558_().m_171514_(84, 46).m_171488_(-2.0f, -16.5f, -5.0f, 4.0f, 5.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-6.0f));
        root.m_171599_("HelmetGold", CubeListBuilder.m_171558_().m_171514_(112, 64).m_171488_(-2.0f, -16.5f, -5.0f, 4.0f, 5.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-6.0f));
        root.m_171599_("HelmetDiamond", CubeListBuilder.m_171558_().m_171514_(96, 64).m_171488_(-2.0f, -16.5f, -5.0f, 4.0f, 5.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-6.0f));
        root.m_171599_("HelmetHide", CubeListBuilder.m_171558_().m_171514_(96, 5).m_171488_(-2.0f, -16.5f, -5.0f, 4.0f, 5.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-6.0f));
        root.m_171599_("HelmetNeckHide", CubeListBuilder.m_171558_().m_171514_(58, 0).m_171488_(-1.5f, -12.0f, -4.5f, 3.0f, 1.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-6.0f));
        root.m_171599_("HelmetHideEar1", CubeListBuilder.m_171558_().m_171514_(84, 9).m_171488_(-2.5f, -18.0f, -3.0f, 2.0f, 2.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-6.0f));
        root.m_171599_("HelmetHideEar2", CubeListBuilder.m_171558_().m_171514_(90, 9).m_171488_(0.5f, -18.0f, -3.0f, 2.0f, 2.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-6.0f));
        root.m_171599_("HelmetFur", CubeListBuilder.m_171558_().m_171514_(84, 0).m_171488_(-2.0f, -16.5f, -5.0f, 4.0f, 5.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-6.0f));
        root.m_171599_("HelmetNeckFur", CubeListBuilder.m_171558_().m_171514_(96, 0).m_171488_(-1.5f, -12.0f, -4.5f, 3.0f, 1.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-6.0f));
        root.m_171599_("HelmetFurEar1", CubeListBuilder.m_171558_().m_171514_(66, 9).m_171488_(-2.5f, -18.0f, -3.0f, 2.0f, 2.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-6.0f));
        root.m_171599_("HelmetFurEar2", CubeListBuilder.m_171558_().m_171514_(76, 9).m_171488_(0.5f, -17.0f, -3.0f, 2.0f, 2.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-6.0f));
        root.m_171599_("HelmetReptile", CubeListBuilder.m_171558_().m_171514_(64, 64).m_171488_(-2.0f, -16.5f, -5.0f, 4.0f, 5.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-6.0f));
        root.m_171599_("HelmetReptileEar2", CubeListBuilder.m_171558_().m_171514_(114, 45).m_171488_(2.5f, -16.5f, -2.0f, 0.0f, 5.0f, 5.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)3.0f, (float)-6.0f, (float)0.0f, (float)0.6108652f, (float)0.0f));
        root.m_171599_("HelmetReptileEar1", CubeListBuilder.m_171558_().m_171514_(114, 50).m_171488_(-2.5f, -16.5f, -2.0f, 0.0f, 5.0f, 5.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)3.0f, (float)-6.0f, (float)0.0f, (float)-0.6108652f, (float)0.0f));
        root.m_171599_("HelmetGreenChitin", CubeListBuilder.m_171558_().m_171514_(80, 64).m_171488_(-2.0f, -16.5f, -5.0f, 4.0f, 5.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-6.0f));
        root.m_171599_("HelmetYellowChitin", CubeListBuilder.m_171558_().m_171514_(0, 64).m_171488_(-2.0f, -16.5f, -5.0f, 4.0f, 5.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-6.0f));
        root.m_171599_("HelmetBlueChitin", CubeListBuilder.m_171558_().m_171514_(16, 64).m_171488_(-2.0f, -16.5f, -5.0f, 4.0f, 5.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-6.0f));
        root.m_171599_("HelmetBlackChitin", CubeListBuilder.m_171558_().m_171514_(32, 64).m_171488_(-2.0f, -16.5f, -5.0f, 4.0f, 5.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-6.0f));
        root.m_171599_("HelmetRedChitin", CubeListBuilder.m_171558_().m_171514_(48, 64).m_171488_(-2.0f, -16.5f, -5.0f, 4.0f, 5.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-6.0f));
        root.m_171599_("Tail", CubeListBuilder.m_171558_().m_171514_(30, 28).m_171488_(-2.5f, -1.0f, 0.0f, 5.0f, 5.0f, 5.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)4.0f, (float)10.0f));
        root.m_171599_("Tailpart1", CubeListBuilder.m_171558_().m_171514_(30, 28).m_171488_(-2.5f, -2.2f, 5.0f, 5.0f, 5.0f, 5.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)4.0f, (float)10.0f, (float)-0.2974289f, (float)0.0f, (float)0.0f));
        root.m_171599_("Tailpart2", CubeListBuilder.m_171558_().m_171514_(60, 73).m_171488_(-2.5f, -4.3f, 9.0f, 5.0f, 5.0f, 8.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)4.0f, (float)10.0f, (float)-0.5205006f, (float)0.0f, (float)0.0f));
        root.m_171599_("Tailpart3", CubeListBuilder.m_171558_().m_171514_(60, 86).m_171488_(-2.0f, 1.0f, 16.0f, 4.0f, 4.0f, 7.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)4.0f, (float)10.0f, (float)-0.2230717f, (float)0.0f, (float)0.0f));
        root.m_171599_("Tailpart4", CubeListBuilder.m_171558_().m_171514_(60, 97).m_171488_(-1.5f, 8.0f, 20.6f, 3.0f, 3.0f, 7.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)4.0f, (float)10.0f, (float)0.0743572f, (float)0.0f, (float)0.0f));
        root.m_171599_("Tailpart5", CubeListBuilder.m_171558_().m_171514_(60, 107).m_171488_(-1.0f, 16.5f, 22.9f, 2.0f, 2.0f, 5.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)4.0f, (float)10.0f, (float)0.4089647f, (float)0.0f, (float)0.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)128, (int)128);
    }

    public void prepareMobModel(T entity, float limbSwing, float limbSwingAmount, float partialTick) {
        this.typeI = (byte)((MoCEntityAnimal)entity).getTypeMoC();
        this.openMouth = ((MoCEntityOstrich)entity).mouthCounter != 0;
        this.isSaddled = ((MoCEntityOstrich)entity).getIsRideable();
        this.bagged = ((MoCEntityOstrich)entity).getIsChested();
        this.rider = entity.m_20159_();
        this.helmet = ((MoCEntityOstrich)entity).getHelmet();
        this.flagColor = ((MoCEntityOstrich)entity).getFlagColorRaw();
    }

    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        boolean isHiding = ((MoCEntityOstrich)entity).getHiding();
        boolean wingFlap = ((MoCEntityOstrich)entity).wingCounter != 0;
        int jumpCounter = ((MoCEntityOstrich)entity).jumpCounter;
        boolean floating = ((MoCEntityOstrich)entity).isFlyer() && ((MoCEntityAnimal)entity).isOnAir();
        float LLegXRot = Mth.m_14089_((float)(limbSwing * 0.4f)) * 1.1f * limbSwingAmount;
        float RLegXRot = Mth.m_14089_((float)(limbSwing * 0.4f + (float)Math.PI)) * 1.1f * limbSwingAmount;
        if (isHiding) {
            this.Head.f_104201_ = 9.0f;
            this.Head.f_104203_ = 2.61799f;
            this.Head.f_104204_ = 0.0f;
        } else {
            this.Head.f_104201_ = 3.0f;
            this.Head.f_104203_ = RLegXRot / 20.0f + -headPitch / 57.295776f;
            this.Head.f_104204_ = netHeadYaw / 57.295776f;
        }
        if (this.rider) {
            this.Head.f_104203_ = floating ? 0.0f : RLegXRot / 20.0f;
        }
        this.UBeak.f_104201_ = this.Head.f_104201_;
        this.UBeakb.f_104201_ = this.Head.f_104201_;
        this.UBeak2.f_104201_ = this.Head.f_104201_;
        this.UBeak2b.f_104201_ = this.Head.f_104201_;
        this.LBeak.f_104201_ = this.Head.f_104201_;
        this.LBeakb.f_104201_ = this.Head.f_104201_;
        this.LBeak2.f_104201_ = this.Head.f_104201_;
        this.LBeak2b.f_104201_ = this.Head.f_104201_;
        this.NeckU.f_104201_ = this.Head.f_104201_;
        this.NeckD.f_104201_ = this.Head.f_104201_;
        this.NeckL.f_104201_ = this.Head.f_104201_;
        this.UniHorn.f_104201_ = this.Head.f_104201_;
        this.UBeak.f_104203_ = this.Head.f_104203_;
        this.UBeak.f_104204_ = this.Head.f_104204_;
        this.UBeak2.f_104203_ = this.Head.f_104203_;
        this.UBeak2.f_104204_ = this.Head.f_104204_;
        this.LBeak.f_104203_ = this.Head.f_104203_;
        this.LBeak.f_104204_ = this.Head.f_104204_;
        this.LBeak2.f_104203_ = this.Head.f_104203_;
        this.LBeak2.f_104204_ = this.Head.f_104204_;
        this.NeckU.f_104203_ = this.Head.f_104203_;
        this.NeckU.f_104204_ = this.Head.f_104204_;
        this.NeckD.f_104203_ = 0.4363323f + this.Head.f_104203_;
        this.NeckD.f_104204_ = this.Head.f_104204_;
        this.NeckL.f_104203_ = 0.20071286f + this.Head.f_104203_;
        this.NeckL.f_104204_ = this.Head.f_104204_;
        this.UBeakb.f_104203_ = -0.0698132f + this.Head.f_104203_;
        this.UBeakb.f_104204_ = this.Head.f_104204_;
        this.UBeak2b.f_104203_ = -0.0698132f + this.Head.f_104203_;
        this.UBeak2b.f_104204_ = this.Head.f_104204_;
        this.LBeakb.f_104203_ = 0.12217305f + this.Head.f_104203_;
        this.LBeakb.f_104204_ = this.Head.f_104204_;
        this.LBeak2b.f_104203_ = 0.12217305f + this.Head.f_104203_;
        this.LBeak2b.f_104204_ = this.Head.f_104204_;
        this.NeckUFeather.f_104201_ = this.Head.f_104201_;
        this.NeckLFeather.f_104201_ = this.Head.f_104201_;
        this.UniHorn.f_104201_ = this.Head.f_104201_;
        this.NeckUFeather.f_104203_ = this.Head.f_104203_;
        this.NeckUFeather.f_104204_ = this.Head.f_104204_;
        this.NeckLFeather.f_104203_ = 0.20071286f + this.Head.f_104203_;
        this.NeckLFeather.f_104204_ = this.Head.f_104204_;
        this.UniHorn.f_104203_ = 0.31415927f + this.Head.f_104203_;
        this.UniHorn.f_104204_ = this.Head.f_104204_;
        this.NeckHarness.f_104201_ = this.Head.f_104201_;
        this.NeckHarness2.f_104201_ = this.Head.f_104201_;
        this.NeckHarnessLeft.f_104201_ = this.Head.f_104201_;
        this.NeckHarnessRight.f_104201_ = this.Head.f_104201_;
        this.NeckHarness.f_104203_ = 0.43633232f + this.Head.f_104203_;
        this.NeckHarness.f_104204_ = this.Head.f_104204_;
        this.NeckHarness2.f_104203_ = this.Head.f_104203_;
        this.NeckHarness2.f_104204_ = this.Head.f_104204_;
        this.NeckHarnessLeft.f_104203_ = 0.87266463f + this.Head.f_104203_;
        this.NeckHarnessLeft.f_104204_ = this.Head.f_104204_;
        this.NeckHarnessRight.f_104203_ = 0.87266463f + this.Head.f_104203_;
        this.NeckHarnessRight.f_104204_ = this.Head.f_104204_;
        switch (this.helmet) {
            case 1: {
                this.HelmetLeather.f_104201_ = this.Head.f_104201_;
                this.HelmetLeather.f_104203_ = this.Head.f_104203_;
                this.HelmetLeather.f_104204_ = this.Head.f_104204_;
                break;
            }
            case 2: {
                this.HelmetIron.f_104201_ = this.Head.f_104201_;
                this.HelmetIron.f_104203_ = this.Head.f_104203_;
                this.HelmetIron.f_104204_ = this.Head.f_104204_;
                break;
            }
            case 3: {
                this.HelmetGold.f_104201_ = this.Head.f_104201_;
                this.HelmetGold.f_104203_ = this.Head.f_104203_;
                this.HelmetGold.f_104204_ = this.Head.f_104204_;
                break;
            }
            case 4: {
                this.HelmetDiamond.f_104201_ = this.Head.f_104201_;
                this.HelmetDiamond.f_104203_ = this.Head.f_104203_;
                this.HelmetDiamond.f_104204_ = this.Head.f_104204_;
                break;
            }
            case 5: {
                this.HelmetHide.f_104201_ = this.Head.f_104201_;
                this.HelmetHide.f_104203_ = this.Head.f_104203_;
                this.HelmetHide.f_104204_ = this.Head.f_104204_;
                this.HelmetNeckHide.f_104201_ = this.Head.f_104201_;
                this.HelmetNeckHide.f_104203_ = this.Head.f_104203_;
                this.HelmetNeckHide.f_104204_ = this.Head.f_104204_;
                this.HelmetHideEar1.f_104201_ = this.Head.f_104201_;
                this.HelmetHideEar1.f_104203_ = this.Head.f_104203_;
                this.HelmetHideEar1.f_104204_ = this.Head.f_104204_;
                this.HelmetHideEar2.f_104201_ = this.Head.f_104201_;
                this.HelmetHideEar2.f_104203_ = this.Head.f_104203_;
                this.HelmetHideEar2.f_104204_ = this.Head.f_104204_;
                break;
            }
            case 6: {
                this.HelmetFur.f_104201_ = this.Head.f_104201_;
                this.HelmetFur.f_104203_ = this.Head.f_104203_;
                this.HelmetFur.f_104204_ = this.Head.f_104204_;
                this.HelmetNeckFur.f_104201_ = this.Head.f_104201_;
                this.HelmetNeckFur.f_104203_ = this.Head.f_104203_;
                this.HelmetNeckFur.f_104204_ = this.Head.f_104204_;
                this.HelmetFurEar1.f_104201_ = this.Head.f_104201_;
                this.HelmetFurEar1.f_104203_ = this.Head.f_104203_;
                this.HelmetFurEar1.f_104204_ = this.Head.f_104204_;
                this.HelmetFurEar2.f_104201_ = this.Head.f_104201_;
                this.HelmetFurEar2.f_104203_ = this.Head.f_104203_;
                this.HelmetFurEar2.f_104204_ = this.Head.f_104204_;
                break;
            }
            case 7: {
                this.HelmetReptile.f_104201_ = this.Head.f_104201_;
                this.HelmetReptile.f_104203_ = this.Head.f_104203_;
                this.HelmetReptile.f_104204_ = this.Head.f_104204_;
                this.HelmetReptileEar1.f_104201_ = this.Head.f_104201_;
                this.HelmetReptileEar1.f_104203_ = this.Head.f_104203_;
                this.HelmetReptileEar1.f_104204_ = -0.61086524f + this.Head.f_104204_;
                this.HelmetReptileEar2.f_104201_ = this.Head.f_104201_;
                this.HelmetReptileEar2.f_104203_ = this.Head.f_104203_;
                this.HelmetReptileEar2.f_104204_ = 0.61086524f + this.Head.f_104204_;
                break;
            }
            case 8: {
                this.HelmetGreenChitin.f_104201_ = this.Head.f_104201_;
                this.HelmetGreenChitin.f_104203_ = this.Head.f_104203_;
                this.HelmetGreenChitin.f_104204_ = this.Head.f_104204_;
                break;
            }
            case 9: {
                this.HelmetYellowChitin.f_104201_ = this.Head.f_104201_;
                this.HelmetYellowChitin.f_104203_ = this.Head.f_104203_;
                this.HelmetYellowChitin.f_104204_ = this.Head.f_104204_;
                break;
            }
            case 10: {
                this.HelmetBlueChitin.f_104201_ = this.Head.f_104201_;
                this.HelmetBlueChitin.f_104203_ = this.Head.f_104203_;
                this.HelmetBlueChitin.f_104204_ = this.Head.f_104204_;
                break;
            }
            case 11: {
                this.HelmetBlackChitin.f_104201_ = this.Head.f_104201_;
                this.HelmetBlackChitin.f_104203_ = this.Head.f_104203_;
                this.HelmetBlackChitin.f_104204_ = this.Head.f_104204_;
                break;
            }
            case 12: {
                this.HelmetRedChitin.f_104201_ = this.Head.f_104201_;
                this.HelmetRedChitin.f_104203_ = this.Head.f_104203_;
                this.HelmetRedChitin.f_104204_ = this.Head.f_104204_;
            }
        }
        float flagF = Mth.m_14089_((float)(limbSwing * 0.8f)) * 0.1f * limbSwingAmount;
        switch (this.flagColor) {
            case 0: {
                this.FlagWhite.f_104204_ = flagF;
                break;
            }
            case 1: {
                this.FlagOrange.f_104204_ = flagF;
                break;
            }
            case 2: {
                this.FlagPurple.f_104204_ = flagF;
                break;
            }
            case 3: {
                this.FlagLightBlue.f_104204_ = flagF;
                break;
            }
            case 4: {
                this.FlagYellow.f_104204_ = flagF;
                break;
            }
            case 5: {
                this.FlagGreen.f_104204_ = flagF;
                break;
            }
            case 6: {
                this.FlagLightRed.f_104204_ = flagF;
                break;
            }
            case 7: {
                this.FlagDarkGrey.f_104204_ = flagF;
                break;
            }
            case 8: {
                this.FlagGrey.f_104204_ = flagF;
                break;
            }
            case 9: {
                this.FlagCyan.f_104204_ = flagF;
                break;
            }
            case 10: {
                this.FlagDarkPurple.f_104204_ = flagF;
                break;
            }
            case 11: {
                this.FlagDarkBlue.f_104204_ = flagF;
                break;
            }
            case 12: {
                this.FlagBrown.f_104204_ = flagF;
                break;
            }
            case 13: {
                this.FlagDarkGreen.f_104204_ = flagF;
                break;
            }
            case 14: {
                this.FlagRed.f_104204_ = flagF;
                break;
            }
            case 15: {
                this.FlagBlack.f_104204_ = flagF;
            }
        }
        if ((this.typeI == 5 || this.typeI == 6) && floating) {
            this.LLegC.f_104201_ = 8.0f;
            this.LLegC.f_104202_ = 17.0f;
            this.RLegC.f_104201_ = 8.0f;
            this.RLegC.f_104202_ = 17.0f;
            this.LFoot.f_104201_ = -5.0f;
            this.LFoot.f_104202_ = -3.0f;
            this.RFoot.f_104201_ = -5.0f;
            this.RFoot.f_104202_ = -3.0f;
            this.LLegB.f_104203_ = this.LLegA.f_104203_ = 0.6981317f;
            this.LLegC.f_104203_ = -1.4835298f;
            this.LFoot.f_104203_ = 0.43633232f;
            this.RLegB.f_104203_ = this.RLegA.f_104203_ = 0.6981317f;
            this.RLegC.f_104203_ = -1.4835298f;
            this.RFoot.f_104203_ = 0.43633232f;
        } else {
            this.LLegC.f_104201_ = 5.0f;
            this.LLegC.f_104202_ = 4.0f;
            this.RLegC.f_104201_ = 5.0f;
            this.RLegC.f_104202_ = 4.0f;
            this.LFoot.f_104201_ = 5.0f;
            this.LFoot.f_104202_ = 4.0f;
            this.RFoot.f_104201_ = 5.0f;
            this.RFoot.f_104202_ = 4.0f;
            this.LLegB.f_104203_ = this.LLegA.f_104203_ = 0.1745329f + LLegXRot;
            this.LLegC.f_104203_ = -0.2617994f + LLegXRot;
            this.LFoot.f_104203_ = this.LLegA.f_104203_;
            this.RLegB.f_104203_ = this.RLegA.f_104203_ = 0.1745329f + RLegXRot;
            this.RLegC.f_104203_ = -0.2617994f + RLegXRot;
            this.RFoot.f_104203_ = this.RLegA.f_104203_;
        }
        if (this.typeI == 5 || this.typeI == 6) {
            float wingF = jumpCounter != 0 ? -0.6981317f + Mth.m_14089_((float)((float)jumpCounter * 0.3f)) * 1.3f : (this.rider && floating ? Mth.m_14089_((float)(ageInTicks * 0.8f)) * 0.2f : Mth.m_14089_((float)(limbSwing * 0.3f)) * limbSwingAmount);
            this.LWingD.f_104205_ = -0.34906584f - wingF;
            this.LWingE.f_104205_ = -0.34906584f - wingF;
            this.RWingD.f_104205_ = 0.34906584f + wingF;
            this.RWingE.f_104205_ = 0.34906584f + wingF;
        } else {
            float wingF = 0.17453292f + Mth.m_14089_((float)(limbSwing * 0.6f)) * 0.2f * limbSwingAmount;
            if (wingFlap) {
                wingF += 0.87266463f;
            }
            this.LWingB.f_104204_ = 0.0872665f + wingF;
            this.LWingC.f_104204_ = 0.0872665f + wingF;
            this.RWingB.f_104204_ = -0.0872665f - wingF;
            this.RWingC.f_104204_ = -0.0872665f - wingF;
            this.LWingB.f_104203_ = 0.0872665f + RLegXRot / 10.0f;
            this.LWingC.f_104203_ = RLegXRot / 10.0f;
            this.RWingB.f_104203_ = 0.0872665f + RLegXRot / 10.0f;
            this.RWingC.f_104203_ = RLegXRot / 10.0f;
        }
        if (this.rider) {
            this.SaddleL2.f_104203_ = this.SaddleL.f_104203_ = -1.0471976f;
            this.SaddleR2.f_104203_ = this.SaddleR.f_104203_ = -1.0471976f;
            this.SaddleL2.f_104205_ = this.SaddleL.f_104205_ = -0.6981317f;
            this.SaddleR2.f_104205_ = this.SaddleR.f_104205_ = 0.6981317f;
        } else {
            this.SaddleL.f_104203_ = RLegXRot / 3.0f;
            this.SaddleL2.f_104203_ = RLegXRot / 3.0f;
            this.SaddleR.f_104203_ = RLegXRot / 3.0f;
            this.SaddleR2.f_104203_ = RLegXRot / 3.0f;
            this.SaddleL.f_104205_ = RLegXRot / 5.0f;
            this.SaddleL2.f_104205_ = RLegXRot / 5.0f;
            this.SaddleR.f_104205_ = -RLegXRot / 5.0f;
            this.SaddleR2.f_104205_ = -RLegXRot / 5.0f;
        }
        if (this.typeI == 6) {
            float rotF;
            float f6 = 15.0f;
            this.Tail.f_104204_ = rotF = Mth.m_14089_((float)(limbSwing * 0.5f)) * 0.3f * limbSwingAmount;
            rotF += rotF / f6;
            this.Tailpart1.f_104204_ = rotF;
            rotF += rotF / f6;
            this.Tailpart2.f_104204_ = rotF;
            rotF += rotF / f6;
            this.Tailpart3.f_104204_ = rotF;
            rotF += rotF / f6;
            this.Tailpart4.f_104204_ = rotF;
            rotF += rotF / f6;
            this.Tailpart5.f_104204_ = rotF;
        }
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.Head.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.NeckU.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.NeckD.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.NeckL.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Body.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Tail.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LLegA.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LLegB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LLegC.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LFoot.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RLegA.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RLegB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RLegC.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RFoot.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        if (this.typeI == 8) {
            this.UniHorn.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        }
        if (this.typeI == 5 || this.typeI == 6) {
            this.LWingD.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.LWingE.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.RWingD.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.RWingE.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.NeckUFeather.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.NeckLFeather.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        } else {
            this.LWingB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.LWingC.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.RWingB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.RWingC.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        }
        if (this.typeI == 6) {
            this.Tailpart1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Tailpart2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Tailpart3.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Tailpart4.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Tailpart5.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        } else {
            this.Tail1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Tail2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Tail3.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        }
        if (this.openMouth) {
            this.UBeakb.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.UBeak2b.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.LBeakb.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.LBeak2b.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        } else {
            this.UBeak.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.UBeak2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.LBeak.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.LBeak2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        }
        if (this.isSaddled) {
            this.SaddleA.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.SaddleB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.SaddleC.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.SaddleL.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.SaddleR.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.SaddleL2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.SaddleR2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.NeckHarness.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.NeckHarness2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            if (this.rider) {
                this.NeckHarnessLeft.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.NeckHarnessRight.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            }
        }
        if (this.bagged) {
            this.Saddlebag.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Flagpole.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            switch (this.flagColor) {
                case 0: {
                    this.FlagWhite.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                    break;
                }
                case 1: {
                    this.FlagOrange.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                    break;
                }
                case 2: {
                    this.FlagPurple.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                    break;
                }
                case 3: {
                    this.FlagLightBlue.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                    break;
                }
                case 4: {
                    this.FlagYellow.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                    break;
                }
                case 5: {
                    this.FlagGreen.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                    break;
                }
                case 6: {
                    this.FlagLightRed.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                    break;
                }
                case 7: {
                    this.FlagDarkGrey.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                    break;
                }
                case 8: {
                    this.FlagGrey.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                    break;
                }
                case 9: {
                    this.FlagCyan.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                    break;
                }
                case 10: {
                    this.FlagDarkPurple.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                    break;
                }
                case 11: {
                    this.FlagDarkBlue.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                    break;
                }
                case 12: {
                    this.FlagBrown.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                    break;
                }
                case 13: {
                    this.FlagDarkGreen.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                    break;
                }
                case 14: {
                    this.FlagRed.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                    break;
                }
                case 15: {
                    this.FlagBlack.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                }
            }
        }
        switch (this.helmet) {
            case 1: {
                this.HelmetLeather.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                break;
            }
            case 2: {
                this.HelmetIron.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                break;
            }
            case 3: {
                this.HelmetGold.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                break;
            }
            case 4: {
                this.HelmetDiamond.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                break;
            }
            case 5: {
                this.HelmetHide.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.HelmetNeckHide.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.HelmetHideEar1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.HelmetHideEar2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                break;
            }
            case 6: {
                this.HelmetFur.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.HelmetNeckFur.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.HelmetFurEar1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.HelmetFurEar2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                break;
            }
            case 7: {
                this.HelmetReptile.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.HelmetReptileEar1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.HelmetReptileEar2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                break;
            }
            case 8: {
                this.HelmetGreenChitin.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                break;
            }
            case 9: {
                this.HelmetYellowChitin.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                break;
            }
            case 10: {
                this.HelmetBlueChitin.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                break;
            }
            case 11: {
                this.HelmetBlackChitin.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                break;
            }
            case 12: {
                this.HelmetRedChitin.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            }
        }
    }
}

