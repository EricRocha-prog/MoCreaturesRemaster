/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.MoCEntityAnimal;
import drzhark.mocreatures.entity.passive.MoCEntityBird;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelBird<T extends MoCEntityBird>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "bird"), "main");
    private final ModelPart head;
    private final ModelPart beak;
    private final ModelPart body;
    private final ModelPart leftLeg;
    private final ModelPart rightLeg;
    private final ModelPart rWing;
    private final ModelPart lWing;
    private final ModelPart tail;

    public MoCModelBird(ModelPart root) {
        this.head = root.m_171324_("head");
        this.beak = root.m_171324_("beak");
        this.body = root.m_171324_("body");
        this.leftLeg = root.m_171324_("leftleg");
        this.rightLeg = root.m_171324_("rightleg");
        this.rWing = root.m_171324_("rwing");
        this.lWing = root.m_171324_("lwing");
        this.tail = root.m_171324_("tail");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        root.m_171599_("head", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-1.5f, -3.0f, -2.0f, 3.0f, 3.0f, 3.0f), PartPose.m_171419_((float)0.0f, (float)15.0f, (float)-4.0f));
        root.m_171599_("beak", CubeListBuilder.m_171558_().m_171514_(14, 0).m_171481_(-0.5f, -1.5f, -3.0f, 1.0f, 1.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)15.0f, (float)-4.0f));
        root.m_171599_("body", CubeListBuilder.m_171558_().m_171514_(0, 9).m_171481_(-2.0f, -4.0f, -3.0f, 4.0f, 8.0f, 4.0f), PartPose.m_171423_((float)0.0f, (float)16.0f, (float)0.0f, (float)1.047198f, (float)0.0f, (float)0.0f));
        root.m_171599_("leftleg", CubeListBuilder.m_171558_().m_171514_(26, 0).m_171481_(-1.0f, 0.0f, -4.0f, 3.0f, 4.0f, 3.0f), PartPose.m_171419_((float)-2.0f, (float)19.0f, (float)1.0f));
        root.m_171599_("rightleg", CubeListBuilder.m_171558_().m_171514_(26, 0).m_171481_(-1.0f, 0.0f, -4.0f, 3.0f, 4.0f, 3.0f), PartPose.m_171419_((float)1.0f, (float)19.0f, (float)1.0f));
        root.m_171599_("rwing", CubeListBuilder.m_171558_().m_171514_(24, 13).m_171481_(-1.0f, 0.0f, -3.0f, 1.0f, 5.0f, 5.0f), PartPose.m_171419_((float)-2.0f, (float)14.0f, (float)0.0f));
        root.m_171599_("lwing", CubeListBuilder.m_171558_().m_171514_(24, 13).m_171481_(0.0f, 0.0f, -3.0f, 1.0f, 5.0f, 5.0f), PartPose.m_171419_((float)2.0f, (float)14.0f, (float)0.0f));
        root.m_171599_("tail", CubeListBuilder.m_171558_().m_171514_(0, 23).m_171481_(-6.0f, 5.0f, 2.0f, 4.0f, 1.0f, 4.0f), PartPose.m_171423_((float)4.0f, (float)13.0f, (float)0.0f, (float)0.261799f, (float)0.0f, (float)0.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)64, (int)32);
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.head.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.beak.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.body.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leftLeg.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.rightLeg.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.rWing.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.lWing.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.tail.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }

    public void setupAnim(T entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float wingRot;
        this.head.f_104203_ = -(headPitch * 0.5f) * ((float)Math.PI / 180);
        this.beak.f_104204_ = this.head.f_104204_ = netHeadYaw * ((float)Math.PI / 180);
        if (((MoCEntityAnimal)entityIn).isOnAir() && entityIn.m_20202_() == null) {
            this.leftLeg.f_104203_ = 1.4f;
            this.rightLeg.f_104203_ = 1.4f;
        } else {
            this.leftLeg.f_104203_ = Mth.m_14089_((float)(limbSwing * 0.6662f)) * limbSwingAmount;
            this.rightLeg.f_104203_ = Mth.m_14089_((float)(limbSwing * 0.6662f + (float)Math.PI)) * limbSwingAmount;
        }
        this.rWing.f_104205_ = wingRot = ageInTicks;
        this.lWing.f_104205_ = -wingRot;
    }
}

