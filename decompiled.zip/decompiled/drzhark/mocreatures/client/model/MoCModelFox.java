/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeDeformation
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.hunter.MoCEntityFox;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelFox<T extends MoCEntityFox>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "fox"), "main");
    private final ModelPart body;
    private final ModelPart leg1;
    private final ModelPart leg2;
    private final ModelPart leg3;
    private final ModelPart leg4;
    private final ModelPart head;
    private final ModelPart snout;
    private final ModelPart ears;
    private final ModelPart tail;

    public MoCModelFox(ModelPart root) {
        this.body = root.m_171324_("body");
        this.leg1 = root.m_171324_("leg1");
        this.leg2 = root.m_171324_("leg2");
        this.leg3 = root.m_171324_("leg3");
        this.leg4 = root.m_171324_("leg4");
        this.head = root.m_171324_("head");
        this.snout = root.m_171324_("snout");
        this.ears = root.m_171324_("ears");
        this.tail = root.m_171324_("tail");
    }

    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.head.f_104204_ = netHeadYaw * ((float)Math.PI / 180);
        this.head.f_104203_ = headPitch * ((float)Math.PI / 180);
        this.snout.f_104204_ = this.head.f_104204_;
        this.snout.f_104203_ = this.head.f_104203_;
        this.ears.f_104204_ = this.head.f_104204_;
        this.ears.f_104203_ = this.head.f_104203_;
        this.leg1.f_104203_ = Mth.m_14089_((float)(limbSwing * 0.6662f)) * 1.4f * limbSwingAmount;
        this.leg2.f_104203_ = Mth.m_14089_((float)(limbSwing * 0.6662f + (float)Math.PI)) * 1.4f * limbSwingAmount;
        this.leg3.f_104203_ = Mth.m_14089_((float)(limbSwing * 0.6662f + (float)Math.PI)) * 1.4f * limbSwingAmount;
        this.leg4.f_104203_ = Mth.m_14089_((float)(limbSwing * 0.6662f)) * 1.4f * limbSwingAmount;
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.body.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg1.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg2.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg3.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg4.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.head.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.snout.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.tail.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.ears.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        int legHeight = 8;
        root.m_171599_("body", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(1.0f, 0.0f, 0.0f, 6.0f, 6.0f, 12.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-4.0f, (float)10.0f, (float)-6.0f));
        root.m_171599_("head", CubeListBuilder.m_171558_().m_171514_(0, 20).m_171488_(-2.0f, -3.0f, -4.0f, 6.0f, 6.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-1.0f, (float)11.0f, (float)-6.0f));
        root.m_171599_("snout", CubeListBuilder.m_171558_().m_171514_(20, 20).m_171488_(0.0f, 1.0f, -7.0f, 2.0f, 2.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-1.0f, (float)11.0f, (float)-6.0f));
        root.m_171599_("ears", CubeListBuilder.m_171558_().m_171514_(50, 20).m_171488_(-2.0f, -6.0f, -2.0f, 6.0f, 4.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-1.0f, (float)11.0f, (float)-6.0f));
        root.m_171599_("tail", CubeListBuilder.m_171558_().m_171514_(32, 20).m_171488_(-4.0f, -5.0f, -2.0f, 3.0f, 3.0f, 8.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)2.5f, (float)15.0f, (float)5.0f, (float)-0.5235988f, (float)0.0f, (float)0.0f));
        root.m_171599_("leg1", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-1.0f, 0.0f, -2.0f, 3.0f, (float)legHeight, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-2.0f, (float)(24 - legHeight), (float)5.0f));
        root.m_171599_("leg2", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-1.0f, 0.0f, -2.0f, 3.0f, (float)legHeight, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)1.0f, (float)(24 - legHeight), (float)5.0f));
        root.m_171599_("leg3", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-1.0f, 0.0f, -2.0f, 3.0f, (float)legHeight, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-2.0f, (float)(24 - legHeight), (float)-4.0f));
        root.m_171599_("leg4", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-1.0f, 0.0f, -2.0f, 3.0f, (float)legHeight, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)1.0f, (float)(24 - legHeight), (float)-4.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)64, (int)32);
    }
}

