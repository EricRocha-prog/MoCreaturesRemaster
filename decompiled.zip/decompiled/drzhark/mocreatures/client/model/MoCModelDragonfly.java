/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.MoCEntityInsect;
import drzhark.mocreatures.entity.ambient.MoCEntityDragonfly;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelDragonfly<T extends MoCEntityDragonfly>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "dragonfly"), "main");
    private final ModelPart Head;
    private final ModelPart RAntenna;
    private final ModelPart LAntenna;
    private final ModelPart Mouth;
    private final ModelPart Thorax;
    private final ModelPart Abdomen;
    private final ModelPart FrontLegs;
    private final ModelPart MidLegs;
    private final ModelPart RearLegs;
    private final ModelPart WingFrontRight;
    private final ModelPart WingFrontLeft;
    private final ModelPart WingRearRight;
    private final ModelPart WingRearLeft;

    public MoCModelDragonfly(ModelPart root) {
        this.Head = root.m_171324_("Head");
        this.RAntenna = root.m_171324_("RAntenna");
        this.LAntenna = root.m_171324_("LAntenna");
        this.Mouth = root.m_171324_("Mouth");
        this.Thorax = root.m_171324_("Thorax");
        this.Abdomen = root.m_171324_("Abdomen");
        this.FrontLegs = root.m_171324_("FrontLegs");
        this.MidLegs = root.m_171324_("MidLegs");
        this.RearLegs = root.m_171324_("RearLegs");
        this.WingFrontRight = root.m_171324_("WingFrontRight");
        this.WingFrontLeft = root.m_171324_("WingFrontLeft");
        this.WingRearRight = root.m_171324_("WingRearRight");
        this.WingRearLeft = root.m_171324_("WingRearLeft");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        root.m_171599_("Head", CubeListBuilder.m_171558_().m_171514_(0, 4).m_171481_(-1.0f, 0.0f, -1.0f, 2.0f, 1.0f, 2.0f), PartPose.m_171423_((float)0.0f, (float)21.0f, (float)-2.0f, (float)-2.171231f, (float)0.0f, (float)0.0f));
        root.m_171599_("RAntenna", CubeListBuilder.m_171558_().m_171514_(0, 7).m_171481_(-0.5f, 0.0f, -1.0f, 1.0f, 0.0f, 1.0f), PartPose.m_171423_((float)-0.5f, (float)19.7f, (float)-2.3f, (float)-1.041001f, (float)0.7853982f, (float)0.0f));
        root.m_171599_("LAntenna", CubeListBuilder.m_171558_().m_171514_(4, 7).m_171481_(-0.5f, 0.0f, -1.0f, 1.0f, 0.0f, 1.0f), PartPose.m_171423_((float)0.5f, (float)19.7f, (float)-2.3f, (float)-1.041001f, (float)-0.7853982f, (float)0.0f));
        root.m_171599_("Mouth", CubeListBuilder.m_171558_().m_171514_(0, 11).m_171481_(-0.5f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)21.1f, (float)-2.3f, (float)-2.171231f, (float)0.0f, (float)0.0f));
        root.m_171599_("Thorax", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-1.0f, 0.0f, -1.0f, 2.0f, 2.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)20.0f, (float)-1.0f));
        root.m_171599_("Abdomen", CubeListBuilder.m_171558_().m_171514_(8, 0).m_171481_(-0.5f, 0.0f, -1.0f, 1.0f, 7.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)20.5f, (float)0.0f, (float)1.427659f, (float)0.0f, (float)0.0f));
        root.m_171599_("FrontLegs", CubeListBuilder.m_171558_().m_171514_(0, 8).m_171481_(-1.0f, 0.0f, 0.0f, 2.0f, 3.0f, 0.0f), PartPose.m_171423_((float)0.0f, (float)21.5f, (float)-1.8f, (float)0.1487144f, (float)0.0f, (float)0.0f));
        root.m_171599_("MidLegs", CubeListBuilder.m_171558_().m_171514_(4, 8).m_171481_(-1.0f, 0.0f, 0.0f, 2.0f, 3.0f, 0.0f), PartPose.m_171423_((float)0.0f, (float)22.0f, (float)-1.2f, (float)0.5948578f, (float)0.0f, (float)0.0f));
        root.m_171599_("RearLegs", CubeListBuilder.m_171558_().m_171514_(8, 8).m_171481_(-1.0f, 0.0f, 0.0f, 2.0f, 3.0f, 0.0f), PartPose.m_171423_((float)0.0f, (float)22.0f, (float)-0.4f, (float)1.070744f, (float)0.0f, (float)0.0f));
        root.m_171599_("WingFrontRight", CubeListBuilder.m_171558_().m_171514_(0, 28).m_171481_(-7.0f, 0.0f, -1.0f, 7.0f, 0.0f, 2.0f), PartPose.m_171423_((float)-1.0f, (float)20.0f, (float)-1.0f, (float)0.0f, (float)-0.1396263f, (float)0.0872665f));
        root.m_171599_("WingFrontLeft", CubeListBuilder.m_171558_().m_171514_(0, 30).m_171481_(0.0f, 0.0f, -1.0f, 7.0f, 0.0f, 2.0f), PartPose.m_171423_((float)1.0f, (float)20.0f, (float)-1.0f, (float)0.0f, (float)0.1396263f, (float)-0.0872665f));
        root.m_171599_("WingRearRight", CubeListBuilder.m_171558_().m_171514_(0, 24).m_171481_(-7.0f, 0.0f, -1.0f, 7.0f, 0.0f, 2.0f), PartPose.m_171423_((float)-1.0f, (float)20.0f, (float)-1.0f, (float)0.0f, (float)0.3490659f, (float)-0.0872665f));
        root.m_171599_("WingRearLeft", CubeListBuilder.m_171558_().m_171514_(0, 26).m_171481_(0.0f, 0.0f, -1.0f, 7.0f, 0.0f, 2.0f), PartPose.m_171423_((float)1.0f, (float)20.0f, (float)-1.0f, (float)0.0f, (float)-0.3490659f, (float)0.0872665f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)32, (int)32);
    }

    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float legMovB;
        float legMov;
        float WingRot = 0.0f;
        if (((MoCEntityInsect)entity).getIsFlying() || entity.m_20184_().f_82480_ < -0.1) {
            WingRot = Mth.m_14089_((float)(ageInTicks * 2.0f)) * 0.5f;
            legMovB = legMov = limbSwingAmount * 1.5f;
        } else {
            legMov = Mth.m_14089_((float)(limbSwing * 1.5f + (float)Math.PI)) * 2.0f * limbSwingAmount;
            legMovB = Mth.m_14089_((float)(limbSwing * 1.5f)) * 2.0f * limbSwingAmount;
        }
        this.WingFrontRight.f_104205_ = WingRot;
        this.WingRearLeft.f_104205_ = WingRot;
        this.WingFrontLeft.f_104205_ = -WingRot;
        this.WingRearRight.f_104205_ = -WingRot;
        this.FrontLegs.f_104203_ = 0.1487144f + legMov;
        this.MidLegs.f_104203_ = 0.5948578f + legMovB;
        this.RearLegs.f_104203_ = 1.070744f + legMov;
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.Head.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Abdomen.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.FrontLegs.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RAntenna.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LAntenna.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RearLegs.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.MidLegs.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Mouth.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Thorax.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        poseStack.m_85836_();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.clearColor((float)0.8f, (float)0.8f, (float)0.8f, (float)0.6f);
        this.WingRearRight.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.WingFrontRight.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.WingFrontLeft.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.WingRearLeft.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        RenderSystem.disableBlend();
        poseStack.m_85849_();
    }
}

