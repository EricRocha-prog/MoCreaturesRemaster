/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeDeformation
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.item.MoCEntityLitterBox;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelLitterBox<T extends MoCEntityLitterBox>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "litter_box"), "main");
    public boolean usedlitter;
    private final ModelPart Table1;
    private final ModelPart Table2;
    private final ModelPart Table3;
    private final ModelPart Table4;
    private final ModelPart Bottom;
    private final ModelPart Litter;
    private final ModelPart LitterUsed;

    public MoCModelLitterBox(ModelPart root) {
        this.Table1 = root.m_171324_("Table1");
        this.Table3 = root.m_171324_("Table3");
        this.Table2 = root.m_171324_("Table2");
        this.Table4 = root.m_171324_("Table4");
        this.Bottom = root.m_171324_("Bottom");
        this.Litter = root.m_171324_("Litter");
        this.LitterUsed = root.m_171324_("LitterUsed");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition part = mesh.m_171576_();
        part.m_171599_("Table1", CubeListBuilder.m_171558_().m_171514_(30, 0).m_171488_(-8.0f, 0.0f, 7.0f, 16.0f, 6.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)18.0f, (float)0.0f));
        part.m_171599_("Table3", CubeListBuilder.m_171558_().m_171514_(30, 0).m_171488_(-8.0f, 18.0f, -8.0f, 16.0f, 6.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        part.m_171599_("Table2", CubeListBuilder.m_171558_().m_171514_(30, 0).m_171488_(-8.0f, -3.0f, 0.0f, 16.0f, 6.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)8.0f, (float)21.0f, (float)0.0f, (float)0.0f, (float)1.5707964f, (float)0.0f));
        part.m_171599_("Table4", CubeListBuilder.m_171558_().m_171514_(30, 0).m_171488_(-8.0f, -3.0f, 0.0f, 16.0f, 6.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-9.0f, (float)21.0f, (float)0.0f, (float)0.0f, (float)1.5707964f, (float)0.0f));
        part.m_171599_("Litter", CubeListBuilder.m_171558_().m_171514_(0, 15).m_171488_(0.0f, 0.0f, 0.0f, 16.0f, 2.0f, 14.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-8.0f, (float)21.0f, (float)-7.0f));
        part.m_171599_("LitterUsed", CubeListBuilder.m_171558_().m_171514_(16, 15).m_171488_(0.0f, 0.0f, 0.0f, 16.0f, 2.0f, 14.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-8.0f, (float)21.0f, (float)-7.0f));
        part.m_171599_("Bottom", CubeListBuilder.m_171558_().m_171514_(16, 15).m_171488_(-10.0f, 0.0f, -7.0f, 16.0f, 1.0f, 14.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)2.0f, (float)23.0f, (float)0.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)64, (int)32);
    }

    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.Table1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Table3.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Table2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Table4.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Bottom.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        if (this.usedlitter) {
            this.LitterUsed.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        } else {
            this.Litter.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        }
    }
}

