/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.client.model.MoCModelAbstractHorse;
import drzhark.mocreatures.entity.MoCEntityAnimal;
import drzhark.mocreatures.entity.passive.MoCEntityHorse;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelHorse<T extends MoCEntityHorse>
extends MoCModelAbstractHorse<T> {
    protected ModelPart headSaddle;
    protected ModelPart saddle;
    protected ModelPart saddleB;
    protected ModelPart saddleC;
    protected ModelPart saddleL;
    protected ModelPart saddleL2;
    protected ModelPart saddleR;
    protected ModelPart saddleR2;
    protected ModelPart saddleMouthL;
    protected ModelPart saddleMouthR;
    protected ModelPart saddleMouthLine;
    protected ModelPart saddleMouthLineR;
    protected ModelPart muleEarL;
    protected ModelPart muleEarR;
    protected ModelPart ear1;
    protected ModelPart ear2;
    protected ModelPart neck;
    protected ModelPart head;
    protected ModelPart uMouth;
    protected ModelPart lMouth;
    protected ModelPart uMouth2;
    protected ModelPart lMouth2;
    protected ModelPart mane;
    protected ModelPart body;
    protected ModelPart tailA;
    protected ModelPart tailB;
    protected ModelPart tailC;
    protected ModelPart leg1A;
    protected ModelPart leg1B;
    protected ModelPart leg1C;
    protected ModelPart leg2A;
    protected ModelPart leg2B;
    protected ModelPart leg2C;
    protected ModelPart leg3A;
    protected ModelPart leg3B;
    protected ModelPart leg3C;
    protected ModelPart leg4A;
    protected ModelPart leg4B;
    protected ModelPart leg4C;
    protected ModelPart unicorn;
    protected ModelPart bag1;
    protected ModelPart bag2;
    protected ModelPart midWing;
    protected ModelPart innerWing;
    protected ModelPart outerWing;
    protected ModelPart innerWingR;
    protected ModelPart midWingR;
    protected ModelPart outerWingR;
    protected ModelPart butterflyL;
    protected ModelPart butterflyR;
    private boolean chested;
    private boolean flyer;
    private boolean isGhost;
    private boolean isUnicorned;
    private float transparency;
    private int vanishingInt;
    private int wingflapInt;
    private boolean openMouth;

    public MoCModelHorse(ModelPart root) {
        super(root);
        this.headSaddle = root.m_171324_("headSaddle");
        this.saddle = root.m_171324_("saddle");
        this.saddleB = root.m_171324_("saddleB");
        this.saddleC = root.m_171324_("saddleC");
        this.saddleL = root.m_171324_("saddleL");
        this.saddleL2 = root.m_171324_("saddleL2");
        this.saddleR = root.m_171324_("saddleR");
        this.saddleR2 = root.m_171324_("saddleR2");
        this.saddleMouthL = root.m_171324_("saddleMouthL");
        this.saddleMouthR = root.m_171324_("saddleMouthR");
        this.saddleMouthLine = root.m_171324_("saddleMouthLine");
        this.saddleMouthLineR = root.m_171324_("saddleMouthLineR");
        this.muleEarL = root.m_171324_("muleEarL");
        this.muleEarR = root.m_171324_("muleEarR");
        this.ear1 = root.m_171324_("ear1");
        this.ear2 = root.m_171324_("ear2");
        this.neck = root.m_171324_("neck");
        this.head = root.m_171324_("head");
        this.uMouth = root.m_171324_("uMouth");
        this.lMouth = root.m_171324_("lMouth");
        this.uMouth2 = root.m_171324_("uMouth2");
        this.lMouth2 = root.m_171324_("lMouth2");
        this.mane = root.m_171324_("mane");
        this.body = root.m_171324_("body");
        this.tailA = root.m_171324_("tailA");
        this.tailB = root.m_171324_("tailB");
        this.tailC = root.m_171324_("tailC");
        this.leg1A = root.m_171324_("leg1A");
        this.leg1B = root.m_171324_("leg1B");
        this.leg1C = root.m_171324_("leg1C");
        this.leg2A = root.m_171324_("leg2A");
        this.leg2B = root.m_171324_("leg2B");
        this.leg2C = root.m_171324_("leg2C");
        this.leg3A = root.m_171324_("leg3A");
        this.leg3B = root.m_171324_("leg3B");
        this.leg3C = root.m_171324_("leg3C");
        this.leg4A = root.m_171324_("leg4A");
        this.leg4B = root.m_171324_("leg4B");
        this.leg4C = root.m_171324_("leg4C");
        this.unicorn = root.m_171324_("unicorn");
        this.bag1 = root.m_171324_("bag1");
        this.bag2 = root.m_171324_("bag2");
        this.midWing = root.m_171324_("midWing");
        this.innerWing = root.m_171324_("innerWing");
        this.outerWing = root.m_171324_("outerWing");
        this.innerWingR = root.m_171324_("innerWingR");
        this.midWingR = root.m_171324_("midWingR");
        this.outerWingR = root.m_171324_("outerWingR");
        this.butterflyL = root.m_171324_("butterflyL");
        this.butterflyR = root.m_171324_("butterflyR");
    }

    public void prepareMobModel(T entityIn, float limbSwing, float limbSwingAmount, float partialTick) {
        super.m_6839_(entityIn, limbSwing, limbSwingAmount, partialTick);
    }

    public void setupAnim(T entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        super.m_6973_(entityIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        this.type = ((MoCEntityAnimal)entityIn).getTypeMoC();
        this.vanishingInt = ((MoCEntityHorse)entityIn).getVanishC();
        this.wingflapInt = ((MoCEntityHorse)entityIn).wingFlapCounter;
        this.saddled = ((MoCEntityHorse)entityIn).getIsRideable();
        this.openMouth = ((MoCEntityHorse)entityIn).mouthCounter != 0;
        this.rider = entityIn.m_20160_();
        this.chested = ((MoCEntityHorse)entityIn).getIsChested();
        this.flyer = ((MoCEntityHorse)entityIn).isFlyer();
        this.isGhost = ((MoCEntityHorse)entityIn).getIsGhost();
        this.isUnicorned = ((MoCEntityHorse)entityIn).isUnicorned();
        this.transparency = this.vanishingInt != 0 ? 1.0f - (float)this.vanishingInt / 100.0f : ((MoCEntityHorse)entityIn).tFloat();
        this.flapwings = ((MoCEntityHorse)entityIn).wingFlapCounter != 0;
        this.shuffling = ((MoCEntityHorse)entityIn).shuffleCounter != 0;
        this.wings = ((MoCEntityHorse)entityIn).isFlyer() && !((MoCEntityHorse)entityIn).getIsGhost() && this.type < 45;
        this.eating = ((MoCEntityHorse)entityIn).getIsSitting();
        this.standing = ((MoCEntityHorse)entityIn).standCounter != 0 && entityIn.m_20202_() == null;
        boolean bl = this.moveTail = ((MoCEntityHorse)entityIn).tailCounter != 0;
        this.floating = ((MoCEntityHorse)entityIn).getIsGhost() ? true : (((MoCEntityHorse)entityIn).isFlyer() ? (entityIn.m_20160_() ? !entityIn.m_20096_() : !entityIn.m_20096_() && (Math.abs(entityIn.m_20184_().f_82480_) > 0.03 || ((MoCEntityHorse)entityIn).f_19789_ > 0.5f)) : false);
        if (entityIn.m_20096_() && !((MoCEntityHorse)entityIn).getIsGhost()) {
            this.floating = false;
        }
    }

    @Override
    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        if (!this.isGhost && this.vanishingInt == 0) {
            if (this.saddled) {
                this.headSaddle.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.saddle.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.saddleB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.saddleC.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.saddleL.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.saddleL2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.saddleR.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.saddleR2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.saddleMouthL.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.saddleMouthR.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                if (this.rider) {
                    this.saddleMouthLine.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                    this.saddleMouthLineR.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                }
            }
            if (this.type == 65 || this.type == 66 || this.type == 67) {
                this.muleEarL.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.muleEarR.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            } else {
                this.ear1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.ear2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            }
            this.neck.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.head.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            if (this.openMouth) {
                this.uMouth2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.lMouth2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            } else {
                this.uMouth.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.lMouth.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            }
            this.mane.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.body.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tailA.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tailB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tailC.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.leg1A.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.leg1B.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.leg1C.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.leg2A.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.leg2B.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.leg2C.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.leg3A.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.leg3B.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.leg3C.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.leg4A.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.leg4B.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.leg4C.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            if (this.isUnicorned) {
                this.unicorn.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            }
            if (this.chested) {
                this.bag1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.bag2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            }
            if (this.flyer && this.type < 45) {
                this.midWing.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.innerWing.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.outerWing.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.innerWingR.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.midWingR.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.outerWingR.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            } else if (this.type > 44 && this.type < 60) {
                poseStack.m_85836_();
                RenderSystem.enableBlend();
                float transparencyVal = 0.7f;
                RenderSystem.defaultBlendFunc();
                RenderSystem.clearColor((float)1.2f, (float)1.2f, (float)1.2f, (float)transparencyVal);
                poseStack.m_85841_(1.3f, 1.0f, 1.3f);
                this.butterflyL.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.butterflyR.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                RenderSystem.disableBlend();
                poseStack.m_85849_();
            }
        } else {
            poseStack.m_85836_();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.clearColor((float)0.8f, (float)0.8f, (float)0.8f, (float)this.transparency);
            poseStack.m_85841_(1.3f, 1.0f, 1.3f);
            this.ear1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.ear2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.neck.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.head.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            if (this.openMouth) {
                this.uMouth2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.lMouth2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            } else {
                this.uMouth.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.lMouth.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            }
            this.mane.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.body.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tailA.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tailB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tailC.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.leg1A.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.leg1B.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.leg1C.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.leg2A.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.leg2B.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.leg2C.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.leg3A.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.leg3B.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.leg3C.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.leg4A.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.leg4B.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.leg4C.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            if (this.type == 39 || this.type == 40 || this.type == 28) {
                this.midWing.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.innerWing.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.outerWing.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.innerWingR.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.midWingR.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.outerWingR.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            }
            if (this.type >= 50 && this.type < 60) {
                this.butterflyL.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.butterflyR.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            }
            if (this.saddled) {
                this.headSaddle.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.saddle.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.saddleB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.saddleC.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.saddleL.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.saddleL2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.saddleR.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.saddleR2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.saddleMouthL.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.saddleMouthR.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                if (this.rider) {
                    this.saddleMouthLine.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                    this.saddleMouthLineR.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                }
            }
            RenderSystem.disableBlend();
            poseStack.m_85849_();
            if (this.type == 21 || this.type == 22) {
                float wingTransparency = 0.0f;
                if (this.wingflapInt != 0) {
                    wingTransparency = 1.0f - (float)this.wingflapInt / 25.0f;
                }
                if (wingTransparency > this.transparency) {
                    wingTransparency = this.transparency;
                }
                poseStack.m_85836_();
                RenderSystem.enableBlend();
                RenderSystem.defaultBlendFunc();
                RenderSystem.clearColor((float)0.8f, (float)0.8f, (float)0.8f, (float)wingTransparency);
                poseStack.m_85841_(1.3f, 1.0f, 1.3f);
                this.butterflyL.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.butterflyR.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                RenderSystem.disableBlend();
                poseStack.m_85849_();
            }
        }
    }

    public static LayerDefinition createBodyLayer() {
        return MoCModelAbstractHorse.createBodyLayer();
    }
}

