/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  org.jetbrains.annotations.NotNull
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.ambient.MoCEntityAnt;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.jetbrains.annotations.NotNull;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelAnt<T extends MoCEntityAnt>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "ant"), "main");
    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart mouth;
    private final ModelPart rightAntenna;
    private final ModelPart leftAntenna;
    private final ModelPart thorax;
    private final ModelPart abdomen;
    private final ModelPart midLegs;
    private final ModelPart frontLegs;
    private final ModelPart rearLegs;

    public MoCModelAnt(ModelPart root) {
        this.root = root;
        this.head = root.m_171324_("head");
        this.mouth = root.m_171324_("mouth");
        this.rightAntenna = root.m_171324_("right_antenna");
        this.leftAntenna = root.m_171324_("left_antenna");
        this.thorax = root.m_171324_("thorax");
        this.abdomen = root.m_171324_("abdomen");
        this.midLegs = root.m_171324_("mid_legs");
        this.frontLegs = root.m_171324_("front_legs");
        this.rearLegs = root.m_171324_("rear_legs");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        root.m_171599_("head", CubeListBuilder.m_171558_().m_171514_(0, 11).m_171481_(-0.5f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)21.9f, (float)-1.3f, (float)-2.171231f, (float)0.0f, (float)0.0f));
        root.m_171599_("mouth", CubeListBuilder.m_171558_().m_171514_(8, 10).m_171481_(0.0f, 0.0f, 0.0f, 2.0f, 1.0f, 0.0f), PartPose.m_171423_((float)-1.0f, (float)22.3f, (float)-1.9f, (float)-0.8286699f, (float)0.0f, (float)0.0f));
        root.m_171599_("right_antenna", CubeListBuilder.m_171558_().m_171514_(0, 6).m_171481_(-0.5f, 0.0f, -1.0f, 1.0f, 0.0f, 1.0f), PartPose.m_171423_((float)-0.5f, (float)21.7f, (float)-2.3f, (float)-1.041001f, (float)0.7853982f, (float)0.0f));
        root.m_171599_("left_antenna", CubeListBuilder.m_171558_().m_171514_(4, 6).m_171481_(-0.5f, 0.0f, -1.0f, 1.0f, 0.0f, 1.0f), PartPose.m_171423_((float)0.5f, (float)21.7f, (float)-2.3f, (float)-1.041001f, (float)-0.7853982f, (float)0.0f));
        root.m_171599_("thorax", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-0.5f, 1.5f, -1.0f, 1.0f, 1.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)20.0f, (float)-0.5f));
        root.m_171599_("abdomen", CubeListBuilder.m_171558_().m_171514_(8, 1).m_171481_(-0.5f, -0.2f, -1.0f, 1.0f, 2.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)21.5f, (float)0.3f, (float)1.706911f, (float)0.0f, (float)0.0f));
        root.m_171599_("mid_legs", CubeListBuilder.m_171558_().m_171514_(4, 8).m_171481_(-1.0f, 0.0f, 0.0f, 2.0f, 3.0f, 0.0f), PartPose.m_171423_((float)0.0f, (float)22.0f, (float)-0.7f, (float)0.5948578f, (float)0.0f, (float)0.0f));
        root.m_171599_("front_legs", CubeListBuilder.m_171558_().m_171514_(0, 8).m_171481_(-1.0f, 0.0f, 0.0f, 2.0f, 3.0f, 0.0f), PartPose.m_171423_((float)0.0f, (float)22.0f, (float)-0.8f, (float)-0.6192304f, (float)0.0f, (float)0.0f));
        root.m_171599_("rear_legs", CubeListBuilder.m_171558_().m_171514_(0, 8).m_171481_(-1.0f, 0.0f, 0.0f, 2.0f, 3.0f, 0.0f), PartPose.m_171423_((float)0.0f, (float)22.0f, (float)0.0f, (float)0.9136644f, (float)0.0f, (float)0.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)32, (int)32);
    }

    public void setupAnim(@NotNull T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float legMov = Mth.m_14089_((float)(limbSwing + (float)Math.PI)) * limbSwingAmount;
        float legMovB = Mth.m_14089_((float)limbSwing) * limbSwingAmount;
        this.frontLegs.f_104203_ = -0.6192304f + legMov;
        this.midLegs.f_104203_ = 0.5948578f + legMovB;
        this.rearLegs.f_104203_ = 0.9136644f + legMov;
    }

    public void m_7695_(@NotNull PoseStack poseStack, @NotNull VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.root.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}

