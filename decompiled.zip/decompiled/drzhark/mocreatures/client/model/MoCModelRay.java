/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.aquatic.MoCEntityRay;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelRay<T extends MoCEntityRay>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "ray"), "main");
    private final ModelPart tail;
    private final ModelPart body;
    private final ModelPart right;
    private final ModelPart left;
    private final ModelPart bodyU;
    private final ModelPart rWingA;
    private final ModelPart rWingB;
    private final ModelPart rWingC;
    private final ModelPart rWingD;
    private final ModelPart rWingE;
    private final ModelPart rWingF;
    private final ModelPart rWingG;
    private final ModelPart lWingA;
    private final ModelPart lWingB;
    private final ModelPart lWingC;
    private final ModelPart lWingD;
    private final ModelPart lWingE;
    private final ModelPart lWingF;
    private final ModelPart lWingG;
    private final ModelPart bodyTail;
    private final ModelPart lEye;
    private final ModelPart rEye;
    private boolean isMantaRay;
    private boolean attacking;

    public MoCModelRay(ModelPart root) {
        this.tail = root.m_171324_("tail");
        this.body = root.m_171324_("body");
        this.right = root.m_171324_("right");
        this.left = root.m_171324_("left");
        this.bodyU = root.m_171324_("body_u");
        this.bodyTail = root.m_171324_("body_tail");
        this.rWingA = root.m_171324_("r_wing_a");
        this.rWingB = root.m_171324_("r_wing_b");
        this.rWingC = root.m_171324_("r_wing_c");
        this.rWingD = root.m_171324_("r_wing_d");
        this.rWingE = root.m_171324_("r_wing_e");
        this.rWingF = root.m_171324_("r_wing_f");
        this.rWingG = root.m_171324_("r_wing_g");
        this.lWingA = root.m_171324_("l_wing_a");
        this.lWingB = root.m_171324_("l_wing_b");
        this.lWingC = root.m_171324_("l_wing_c");
        this.lWingD = root.m_171324_("l_wing_d");
        this.lWingE = root.m_171324_("l_wing_e");
        this.lWingF = root.m_171324_("l_wing_f");
        this.lWingG = root.m_171324_("l_wing_g");
        this.lEye = root.m_171324_("l_eye");
        this.rEye = root.m_171324_("r_eye");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        root.m_171599_("body", CubeListBuilder.m_171558_().m_171514_(26, 0).m_171481_(-4.0f, -1.0f, 0.0f, 8.0f, 2.0f, 11.0f), PartPose.m_171419_((float)0.0f, (float)22.0f, (float)-5.0f));
        root.m_171599_("right", CubeListBuilder.m_171558_().m_171514_(10, 26).m_171481_(-0.5f, -1.0f, -4.0f, 1.0f, 2.0f, 4.0f), PartPose.m_171419_((float)-3.0f, (float)22.0f, (float)-4.8f));
        root.m_171599_("left", CubeListBuilder.m_171558_().m_171514_(0, 26).m_171481_(-0.5f, -1.0f, -4.0f, 1.0f, 2.0f, 4.0f), PartPose.m_171419_((float)3.0f, (float)22.0f, (float)-4.8f));
        root.m_171599_("body_u", CubeListBuilder.m_171558_().m_171514_(0, 11).m_171481_(-3.0f, -1.0f, 0.0f, 6.0f, 1.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)21.0f, (float)-4.0f));
        root.m_171599_("tail", CubeListBuilder.m_171558_().m_171514_(30, 15).m_171481_(-0.5f, -0.5f, 1.0f, 1.0f, 1.0f, 16.0f), PartPose.m_171419_((float)0.0f, (float)22.0f, (float)8.0f));
        root.m_171599_("body_tail", CubeListBuilder.m_171558_().m_171514_(0, 20).m_171481_(-1.8f, -0.5f, -3.2f, 5.0f, 1.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)22.0f, (float)7.0f, (float)0.0f, (float)1.0f, (float)0.0f));
        root.m_171599_("r_wing_a", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-3.0f, -0.5f, -5.0f, 3.0f, 1.0f, 10.0f), PartPose.m_171419_((float)-4.0f, (float)22.0f, (float)1.0f));
        root.m_171599_("r_wing_b", CubeListBuilder.m_171558_().m_171514_(2, 2).m_171481_(-6.0f, -0.5f, -4.0f, 3.0f, 1.0f, 8.0f), PartPose.m_171419_((float)-4.0f, (float)22.0f, (float)1.0f));
        root.m_171599_("r_wing_c", CubeListBuilder.m_171558_().m_171514_(5, 4).m_171481_(-8.0f, -0.5f, -3.0f, 2.0f, 1.0f, 6.0f), PartPose.m_171419_((float)-4.0f, (float)22.0f, (float)1.0f));
        root.m_171599_("r_wing_d", CubeListBuilder.m_171558_().m_171514_(6, 5).m_171481_(-10.0f, -0.5f, -2.5f, 2.0f, 1.0f, 5.0f), PartPose.m_171419_((float)-4.0f, (float)22.0f, (float)1.0f));
        root.m_171599_("r_wing_e", CubeListBuilder.m_171558_().m_171514_(7, 6).m_171481_(-12.0f, -0.5f, -2.0f, 2.0f, 1.0f, 4.0f), PartPose.m_171419_((float)-4.0f, (float)22.0f, (float)1.0f));
        root.m_171599_("r_wing_f", CubeListBuilder.m_171558_().m_171514_(8, 7).m_171481_(-14.0f, -0.5f, -1.5f, 2.0f, 1.0f, 3.0f), PartPose.m_171419_((float)-4.0f, (float)22.0f, (float)1.0f));
        root.m_171599_("r_wing_g", CubeListBuilder.m_171558_().m_171514_(9, 8).m_171481_(-16.0f, -0.5f, -1.0f, 2.0f, 1.0f, 2.0f), PartPose.m_171419_((float)-4.0f, (float)22.0f, (float)1.0f));
        root.m_171599_("l_wing_a", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171480_().m_171481_(0.0f, -0.5f, -5.0f, 3.0f, 1.0f, 10.0f), PartPose.m_171419_((float)4.0f, (float)22.0f, (float)1.0f));
        root.m_171599_("l_wing_b", CubeListBuilder.m_171558_().m_171514_(2, 2).m_171480_().m_171481_(3.0f, -0.5f, -4.0f, 3.0f, 1.0f, 8.0f), PartPose.m_171419_((float)4.0f, (float)22.0f, (float)1.0f));
        root.m_171599_("l_wing_c", CubeListBuilder.m_171558_().m_171514_(5, 4).m_171480_().m_171481_(6.0f, -0.5f, -3.0f, 2.0f, 1.0f, 6.0f), PartPose.m_171419_((float)4.0f, (float)22.0f, (float)1.0f));
        root.m_171599_("l_wing_d", CubeListBuilder.m_171558_().m_171514_(6, 5).m_171480_().m_171481_(8.0f, -0.5f, -2.5f, 2.0f, 1.0f, 5.0f), PartPose.m_171419_((float)4.0f, (float)22.0f, (float)1.0f));
        root.m_171599_("l_wing_e", CubeListBuilder.m_171558_().m_171514_(7, 6).m_171480_().m_171481_(10.0f, -0.5f, -2.0f, 2.0f, 1.0f, 4.0f), PartPose.m_171419_((float)4.0f, (float)22.0f, (float)1.0f));
        root.m_171599_("l_wing_f", CubeListBuilder.m_171558_().m_171514_(8, 7).m_171480_().m_171481_(12.0f, -0.5f, -1.5f, 2.0f, 1.0f, 3.0f), PartPose.m_171419_((float)4.0f, (float)22.0f, (float)1.0f));
        root.m_171599_("l_wing_g", CubeListBuilder.m_171558_().m_171514_(9, 8).m_171480_().m_171481_(14.0f, -0.5f, -1.0f, 2.0f, 1.0f, 2.0f), PartPose.m_171419_((float)4.0f, (float)22.0f, (float)1.0f));
        root.m_171599_("l_eye", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-3.0f, -2.0f, 1.0f, 1.0f, 1.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)21.0f, (float)-4.0f));
        root.m_171599_("r_eye", CubeListBuilder.m_171558_().m_171514_(0, 3).m_171481_(2.0f, -2.0f, 1.0f, 1.0f, 1.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)21.0f, (float)-4.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)64, (int)32);
    }

    public void m_7695_(PoseStack stack, VertexConsumer builder, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.tail.m_104306_(stack, builder, packedLight, packedOverlay, red, green, blue, alpha);
        this.body.m_104306_(stack, builder, packedLight, packedOverlay, red, green, blue, alpha);
        this.bodyU.m_104306_(stack, builder, packedLight, packedOverlay, red, green, blue, alpha);
        this.bodyTail.m_104306_(stack, builder, packedLight, packedOverlay, red, green, blue, alpha);
        this.rWingA.m_104306_(stack, builder, packedLight, packedOverlay, red, green, blue, alpha);
        this.rWingB.m_104306_(stack, builder, packedLight, packedOverlay, red, green, blue, alpha);
        this.lWingA.m_104306_(stack, builder, packedLight, packedOverlay, red, green, blue, alpha);
        this.lWingB.m_104306_(stack, builder, packedLight, packedOverlay, red, green, blue, alpha);
        if (this.isMantaRay) {
            this.right.m_104306_(stack, builder, packedLight, packedOverlay, red, green, blue, alpha);
            this.left.m_104306_(stack, builder, packedLight, packedOverlay, red, green, blue, alpha);
            this.rWingC.m_104306_(stack, builder, packedLight, packedOverlay, red, green, blue, alpha);
            this.rWingD.m_104306_(stack, builder, packedLight, packedOverlay, red, green, blue, alpha);
            this.rWingE.m_104306_(stack, builder, packedLight, packedOverlay, red, green, blue, alpha);
            this.rWingF.m_104306_(stack, builder, packedLight, packedOverlay, red, green, blue, alpha);
            this.rWingG.m_104306_(stack, builder, packedLight, packedOverlay, red, green, blue, alpha);
            this.lWingC.m_104306_(stack, builder, packedLight, packedOverlay, red, green, blue, alpha);
            this.lWingD.m_104306_(stack, builder, packedLight, packedOverlay, red, green, blue, alpha);
            this.lWingE.m_104306_(stack, builder, packedLight, packedOverlay, red, green, blue, alpha);
            this.lWingF.m_104306_(stack, builder, packedLight, packedOverlay, red, green, blue, alpha);
            this.lWingG.m_104306_(stack, builder, packedLight, packedOverlay, red, green, blue, alpha);
        } else {
            this.rEye.m_104306_(stack, builder, packedLight, packedOverlay, red, green, blue, alpha);
            this.lEye.m_104306_(stack, builder, packedLight, packedOverlay, red, green, blue, alpha);
        }
    }

    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float wag;
        this.attacking = ((MoCEntityRay)entity).isPoisoning();
        this.isMantaRay = ((MoCEntityRay)entity).isMantaRay();
        this.tail.f_104204_ = wag = Mth.m_14089_((float)(limbSwing * 0.6662f)) * 0.7f * limbSwingAmount;
        this.tail.f_104203_ = this.attacking ? 0.5f : 0.0f;
        float rotF = Mth.m_14089_((float)(limbSwing * 0.6662f)) * 1.5f * limbSwingAmount;
        float f6 = 20.0f;
        this.rWingA.f_104205_ = rotF;
        this.lWingA.f_104205_ = -rotF;
        rotF += rotF / f6;
        this.rWingB.f_104205_ = rotF;
        this.lWingB.f_104205_ = -rotF;
        rotF += rotF / f6;
        this.rWingC.f_104205_ = rotF;
        this.lWingC.f_104205_ = -rotF;
        rotF += rotF / f6;
        this.rWingD.f_104205_ = rotF;
        this.lWingD.f_104205_ = -rotF;
        rotF += rotF / f6;
        this.rWingE.f_104205_ = rotF;
        this.lWingE.f_104205_ = -rotF;
        rotF += rotF / f6;
        this.rWingF.f_104205_ = rotF;
        this.lWingF.f_104205_ = -rotF;
        rotF += rotF / f6;
        this.rWingG.f_104205_ = rotF;
        this.lWingG.f_104205_ = -rotF;
    }
}

