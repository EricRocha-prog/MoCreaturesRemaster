/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.hunter.MoCEntityRaccoon;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelRaccoon<T extends MoCEntityRaccoon>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "raccoon"), "main");
    private final ModelPart head;
    private final ModelPart snout;
    private final ModelPart rightEar;
    private final ModelPart leftEar;
    private final ModelPart leftSideburn;
    private final ModelPart rightSideburn;
    private final ModelPart neck;
    private final ModelPart body;
    private final ModelPart tailA;
    private final ModelPart tailB;
    private final ModelPart rightFrontLegA;
    private final ModelPart rightFrontLegB;
    private final ModelPart rightFrontFoot;
    private final ModelPart leftFrontLegA;
    private final ModelPart leftFrontLegB;
    private final ModelPart leftFrontFoot;
    private final ModelPart rightRearLegA;
    private final ModelPart rightRearLegB;
    private final ModelPart rightRearFoot;
    private final ModelPart leftRearLegA;
    private final ModelPart leftRearLegB;
    private final ModelPart leftRearFoot;
    private final float radianF = 57.29578f;

    public MoCModelRaccoon(ModelPart root) {
        this.head = root.m_171324_("head");
        this.snout = root.m_171324_("snout");
        this.rightEar = root.m_171324_("right_ear");
        this.leftEar = root.m_171324_("left_ear");
        this.leftSideburn = this.head.m_171324_("left_sideburn");
        this.rightSideburn = this.head.m_171324_("right_sideburn");
        this.neck = root.m_171324_("neck");
        this.body = root.m_171324_("body");
        this.tailA = root.m_171324_("tail_a");
        this.tailB = root.m_171324_("tail_b");
        this.rightFrontLegA = root.m_171324_("right_front_leg_a");
        this.rightFrontLegB = root.m_171324_("right_front_leg_b");
        this.rightFrontFoot = root.m_171324_("right_front_foot");
        this.leftFrontLegA = root.m_171324_("left_front_leg_a");
        this.leftFrontLegB = root.m_171324_("left_front_leg_b");
        this.leftFrontFoot = root.m_171324_("left_front_foot");
        this.rightRearLegA = root.m_171324_("right_rear_leg_a");
        this.rightRearLegB = root.m_171324_("right_rear_leg_b");
        this.rightRearFoot = root.m_171324_("right_rear_foot");
        this.leftRearLegA = root.m_171324_("left_rear_leg_a");
        this.leftRearLegB = root.m_171324_("left_rear_leg_b");
        this.leftRearFoot = root.m_171324_("left_rear_foot");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        PartDefinition head = root.m_171599_("head", CubeListBuilder.m_171558_().m_171514_(38, 21).m_171481_(-4.0f, -3.5f, -6.5f, 8.0f, 6.0f, 5.0f), PartPose.m_171419_((float)0.0f, (float)17.0f, (float)-4.0f));
        head.m_171599_("right_sideburn", CubeListBuilder.m_171558_().m_171514_(0, 32).m_171481_(-3.0f, -2.0f, -2.0f, 3.0f, 4.0f, 4.0f), PartPose.m_171423_((float)-2.5f, (float)0.5f, (float)-3.2f, (float)0.0f, (float)-0.5235988f, (float)0.0f));
        head.m_171599_("left_sideburn", CubeListBuilder.m_171558_().m_171514_(0, 40).m_171481_(0.0f, -2.0f, -2.0f, 3.0f, 4.0f, 4.0f), PartPose.m_171423_((float)2.5f, (float)0.5f, (float)-3.2f, (float)0.0f, (float)0.5235988f, (float)0.0f));
        root.m_171599_("snout", CubeListBuilder.m_171558_().m_171514_(24, 25).m_171481_(-1.5f, -0.5f, -10.5f, 3.0f, 3.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)17.0f, (float)-4.0f));
        root.m_171599_("right_ear", CubeListBuilder.m_171558_().m_171514_(24, 22).m_171481_(-4.0f, -5.5f, -3.5f, 3.0f, 2.0f, 1.0f), PartPose.m_171419_((float)0.0f, (float)17.0f, (float)-4.0f));
        root.m_171599_("left_ear", CubeListBuilder.m_171558_().m_171514_(24, 18).m_171481_(1.0f, -5.5f, -3.5f, 3.0f, 2.0f, 1.0f), PartPose.m_171419_((float)0.0f, (float)17.0f, (float)-4.0f));
        root.m_171599_("neck", CubeListBuilder.m_171558_().m_171514_(46, 4).m_171481_(-2.5f, -2.0f, -3.0f, 5.0f, 4.0f, 3.0f), PartPose.m_171423_((float)0.0f, (float)17.0f, (float)-4.0f, (float)-0.4461433f, (float)0.0f, (float)0.0f));
        root.m_171599_("body", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-3.0f, 0.0f, -3.0f, 6.0f, 6.0f, 12.0f), PartPose.m_171419_((float)0.0f, (float)15.0f, (float)-2.0f));
        root.m_171599_("tail_a", CubeListBuilder.m_171558_().m_171514_(0, 3).m_171481_(-1.5f, -6.0f, -1.5f, 3.0f, 6.0f, 3.0f), PartPose.m_171423_((float)0.0f, (float)16.5f, (float)6.5f, (float)-2.024582f, (float)0.0f, (float)0.0f));
        root.m_171599_("tail_b", CubeListBuilder.m_171558_().m_171514_(24, 3).m_171481_(-1.5f, -11.0f, 0.3f, 3.0f, 6.0f, 3.0f), PartPose.m_171423_((float)0.0f, (float)16.5f, (float)6.5f, (float)-1.689974f, (float)0.0f, (float)0.0f));
        root.m_171599_("right_front_leg_a", CubeListBuilder.m_171558_().m_171514_(36, 0).m_171481_(-4.0f, -1.0f, -1.0f, 2.0f, 5.0f, 3.0f), PartPose.m_171423_((float)0.0f, (float)18.0f, (float)-4.0f, (float)0.5205006f, (float)0.0f, (float)0.0f));
        root.m_171599_("right_front_leg_b", CubeListBuilder.m_171558_().m_171514_(46, 11).m_171481_(-3.5f, 1.0f, 2.0f, 2.0f, 4.0f, 2.0f), PartPose.m_171423_((float)0.0f, (float)18.0f, (float)-4.0f, (float)-0.3717861f, (float)0.0f, (float)0.0f));
        root.m_171599_("right_front_foot", CubeListBuilder.m_171558_().m_171514_(46, 0).m_171481_(-4.0f, 5.0f, -1.0f, 3.0f, 1.0f, 3.0f), PartPose.m_171419_((float)0.0f, (float)18.0f, (float)-4.0f));
        root.m_171599_("left_front_leg_a", CubeListBuilder.m_171558_().m_171514_(36, 8).m_171481_(2.0f, -1.0f, -1.0f, 2.0f, 5.0f, 3.0f), PartPose.m_171423_((float)0.0f, (float)18.0f, (float)-4.0f, (float)0.5205006f, (float)0.0f, (float)0.0f));
        root.m_171599_("left_front_leg_b", CubeListBuilder.m_171558_().m_171514_(54, 11).m_171481_(1.5f, 1.0f, 2.0f, 2.0f, 4.0f, 2.0f), PartPose.m_171423_((float)0.0f, (float)18.0f, (float)-4.0f, (float)-0.3717861f, (float)0.0f, (float)0.0f));
        root.m_171599_("left_front_foot", CubeListBuilder.m_171558_().m_171514_(46, 0).m_171481_(1.0f, 5.0f, -1.0f, 3.0f, 1.0f, 3.0f), PartPose.m_171419_((float)0.0f, (float)18.0f, (float)-4.0f));
        root.m_171599_("right_rear_leg_a", CubeListBuilder.m_171558_().m_171514_(12, 18).m_171481_(-5.0f, -2.0f, -3.0f, 2.0f, 5.0f, 4.0f), PartPose.m_171423_((float)0.0f, (float)18.0f, (float)4.0f, (float)0.9294653f, (float)0.0f, (float)0.0f));
        root.m_171599_("right_rear_leg_b", CubeListBuilder.m_171558_().m_171514_(0, 27).m_171481_(-4.5f, 2.0f, -5.0f, 2.0f, 2.0f, 3.0f), PartPose.m_171423_((float)0.0f, (float)18.0f, (float)4.0f, (float)0.9294653f, (float)0.0f, (float)0.0f));
        root.m_171599_("right_rear_foot", CubeListBuilder.m_171558_().m_171514_(46, 0).m_171481_(-5.0f, 5.0f, -2.0f, 3.0f, 1.0f, 3.0f), PartPose.m_171419_((float)0.0f, (float)18.0f, (float)4.0f));
        root.m_171599_("left_rear_leg_a", CubeListBuilder.m_171558_().m_171514_(0, 18).m_171481_(3.0f, -2.0f, -3.0f, 2.0f, 5.0f, 4.0f), PartPose.m_171423_((float)0.0f, (float)18.0f, (float)4.0f, (float)0.9294653f, (float)0.0f, (float)0.0f));
        root.m_171599_("left_rear_leg_b", CubeListBuilder.m_171558_().m_171514_(10, 27).m_171481_(2.5f, 2.0f, -5.0f, 2.0f, 2.0f, 3.0f), PartPose.m_171423_((float)0.0f, (float)18.0f, (float)4.0f, (float)0.9294653f, (float)0.0f, (float)0.0f));
        root.m_171599_("left_rear_foot", CubeListBuilder.m_171558_().m_171514_(46, 0).m_171481_(2.0f, 5.0f, -2.0f, 3.0f, 1.0f, 3.0f), PartPose.m_171419_((float)0.0f, (float)18.0f, (float)4.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)64, (int)64);
    }

    public void m_7695_(PoseStack matrixStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.head.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.snout.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.rightEar.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leftEar.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.neck.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.body.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.tailA.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.tailB.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.rightFrontLegA.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.rightFrontLegB.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.rightFrontFoot.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leftFrontLegA.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leftFrontLegB.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leftFrontFoot.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.rightRearLegA.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.rightRearLegB.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.rightRearFoot.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leftRearLegA.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leftRearLegB.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leftRearFoot.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }

    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.head.f_104204_ = netHeadYaw * ((float)Math.PI / 180);
        this.head.f_104203_ = headPitch * ((float)Math.PI / 180);
        this.snout.f_104204_ = this.head.f_104204_;
        this.snout.f_104203_ = this.head.f_104203_;
        this.rightEar.f_104203_ = this.head.f_104203_;
        this.rightEar.f_104204_ = this.head.f_104204_;
        this.leftEar.f_104203_ = this.head.f_104203_;
        this.leftEar.f_104204_ = this.head.f_104204_;
        float RLegXRot = Mth.m_14089_((float)(limbSwing + (float)Math.PI)) * 0.8f * limbSwingAmount;
        float LLegXRot = Mth.m_14089_((float)limbSwing) * 0.8f * limbSwingAmount;
        this.rightFrontLegA.f_104203_ = 0.5235988f + RLegXRot;
        this.leftFrontLegA.f_104203_ = 0.5235988f + LLegXRot;
        this.rightRearLegA.f_104203_ = 0.9250245f + LLegXRot;
        this.leftRearLegA.f_104203_ = 0.9250245f + RLegXRot;
        this.rightFrontLegB.f_104203_ = -0.36651915f + RLegXRot;
        this.rightFrontFoot.f_104203_ = RLegXRot;
        this.leftFrontLegB.f_104203_ = -0.36651915f + LLegXRot;
        this.leftFrontFoot.f_104203_ = LLegXRot;
        this.rightRearLegB.f_104203_ = 0.9250245f + LLegXRot;
        this.rightRearFoot.f_104203_ = LLegXRot;
        this.leftRearLegB.f_104203_ = 0.9250245f + RLegXRot;
        this.leftRearFoot.f_104203_ = RLegXRot;
        this.tailB.f_104204_ = this.tailA.f_104204_ = Mth.m_14089_((float)(limbSwing * 0.6662f)) * 0.7f * limbSwingAmount;
    }
}

