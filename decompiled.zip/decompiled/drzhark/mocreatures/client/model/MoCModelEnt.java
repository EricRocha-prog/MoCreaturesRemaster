/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.neutral.MoCEntityEnt;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelEnt<T extends MoCEntityEnt>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "ent"), "main");
    private final ModelPart Body;
    private final ModelPart LShoulder;
    private final ModelPart LArm;
    private final ModelPart LWrist;
    private final ModelPart LHand;
    private final ModelPart LFingers;
    private final ModelPart RShoulder;
    private final ModelPart RArm;
    private final ModelPart RWrist;
    private final ModelPart RHand;
    private final ModelPart RFingers;
    private final ModelPart LLeg;
    private final ModelPart LThigh;
    private final ModelPart LKnee;
    private final ModelPart LAnkle;
    private final ModelPart LFoot;
    private final ModelPart RLeg;
    private final ModelPart RThigh;
    private final ModelPart RKnee;
    private final ModelPart RAnkle;
    private final ModelPart RFoot;
    private final ModelPart Neck;
    private final ModelPart Face;
    private final ModelPart Head;
    private final ModelPart Nose;
    private final ModelPart Mouth;
    private final ModelPart TreeBase;
    private final ModelPart Leave1;
    private final ModelPart Leave2;
    private final ModelPart Leave3;
    private final ModelPart Leave4;
    private final ModelPart Leave5;
    private final ModelPart Leave6;
    private final ModelPart Leave7;
    private final ModelPart Leave8;
    private final ModelPart Leave9;
    private final ModelPart Leave10;
    private final ModelPart Leave11;
    private final ModelPart Leave12;
    private final ModelPart Leave13;
    private final ModelPart Leave14;
    private final ModelPart Leave15;
    private final ModelPart Leave16;

    public MoCModelEnt(ModelPart root) {
        this.Body = root.m_171324_("Body");
        this.LShoulder = root.m_171324_("LShoulder");
        this.LArm = root.m_171324_("LArm");
        this.LWrist = root.m_171324_("LWrist");
        this.LHand = root.m_171324_("LHand");
        this.LFingers = root.m_171324_("LFingers");
        this.RShoulder = root.m_171324_("RShoulder");
        this.RArm = root.m_171324_("RArm");
        this.RWrist = root.m_171324_("RWrist");
        this.RHand = root.m_171324_("RHand");
        this.RFingers = root.m_171324_("RFingers");
        this.LLeg = root.m_171324_("LLeg");
        this.LThigh = root.m_171324_("LThigh");
        this.LKnee = root.m_171324_("LKnee");
        this.LAnkle = root.m_171324_("LAnkle");
        this.LFoot = root.m_171324_("LFoot");
        this.RLeg = root.m_171324_("RLeg");
        this.RThigh = root.m_171324_("RThigh");
        this.RKnee = root.m_171324_("RKnee");
        this.RAnkle = root.m_171324_("RAnkle");
        this.RFoot = root.m_171324_("RFoot");
        this.Neck = root.m_171324_("Neck");
        this.Face = root.m_171324_("Face");
        this.Head = root.m_171324_("Head");
        this.Nose = root.m_171324_("Nose");
        this.Mouth = root.m_171324_("Mouth");
        this.TreeBase = root.m_171324_("TreeBase");
        this.Leave1 = root.m_171324_("Leave1");
        this.Leave2 = root.m_171324_("Leave2");
        this.Leave3 = root.m_171324_("Leave3");
        this.Leave4 = root.m_171324_("Leave4");
        this.Leave5 = root.m_171324_("Leave5");
        this.Leave6 = root.m_171324_("Leave6");
        this.Leave7 = root.m_171324_("Leave7");
        this.Leave8 = root.m_171324_("Leave8");
        this.Leave9 = root.m_171324_("Leave9");
        this.Leave10 = root.m_171324_("Leave10");
        this.Leave11 = root.m_171324_("Leave11");
        this.Leave12 = root.m_171324_("Leave12");
        this.Leave13 = root.m_171324_("Leave13");
        this.Leave14 = root.m_171324_("Leave14");
        this.Leave15 = root.m_171324_("Leave15");
        this.Leave16 = root.m_171324_("Leave16");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition parts = mesh.m_171576_();
        parts.m_171599_("Body", CubeListBuilder.m_171558_().m_171514_(68, 36).m_171481_(-7.5f, -12.5f, -4.5f, 15.0f, 25.0f, 9.0f), PartPose.m_171419_((float)0.0f, (float)-31.0f, (float)0.0f));
        parts.m_171599_("LShoulder", CubeListBuilder.m_171558_().m_171514_(48, 108).m_171481_(6.0f, -14.0f, -4.8f, 9.0f, 7.0f, 7.0f), PartPose.m_171423_((float)0.0f, (float)-31.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-0.1745329f));
        parts.m_171599_("LArm", CubeListBuilder.m_171558_().m_171514_(80, 108).m_171481_(0.0f, -4.0f, -5.0f, 6.0f, 24.0f, 6.0f), PartPose.m_171423_((float)10.0f, (float)-42.0f, (float)1.0f, (float)0.0f, (float)0.0f, (float)-0.1745329f));
        parts.m_171599_("LWrist", CubeListBuilder.m_171558_().m_171514_(0, 169).m_171481_(2.0f, 17.0f, -6.0f, 8.0f, 15.0f, 8.0f), PartPose.m_171419_((float)10.0f, (float)-42.0f, (float)1.0f));
        parts.m_171599_("LHand", CubeListBuilder.m_171558_().m_171514_(88, 241).m_171481_(1.0f, 28.0f, -7.0f, 10.0f, 5.0f, 10.0f), PartPose.m_171419_((float)10.0f, (float)-42.0f, (float)1.0f));
        parts.m_171599_("LFingers", CubeListBuilder.m_171558_().m_171514_(88, 176).m_171481_(1.0f, 33.0f, -7.0f, 10.0f, 15.0f, 10.0f), PartPose.m_171419_((float)10.0f, (float)-42.0f, (float)1.0f));
        parts.m_171599_("RShoulder", CubeListBuilder.m_171558_().m_171514_(48, 122).m_171481_(-15.0f, -14.0f, -4.8f, 9.0f, 7.0f, 7.0f), PartPose.m_171423_((float)0.0f, (float)-31.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.1745329f));
        parts.m_171599_("RArm", CubeListBuilder.m_171558_().m_171514_(104, 108).m_171481_(-6.0f, -4.0f, -5.0f, 6.0f, 24.0f, 6.0f), PartPose.m_171423_((float)-10.0f, (float)-42.0f, (float)1.0f, (float)0.0f, (float)0.0f, (float)0.1745329f));
        parts.m_171599_("RWrist", CubeListBuilder.m_171558_().m_171514_(32, 169).m_171481_(-10.0f, 17.0f, -6.0f, 8.0f, 15.0f, 8.0f), PartPose.m_171419_((float)-10.0f, (float)-42.0f, (float)1.0f));
        parts.m_171599_("RHand", CubeListBuilder.m_171558_().m_171514_(88, 226).m_171481_(-11.0f, 28.0f, -7.0f, 10.0f, 5.0f, 10.0f), PartPose.m_171419_((float)-10.0f, (float)-42.0f, (float)1.0f));
        parts.m_171599_("RFingers", CubeListBuilder.m_171558_().m_171514_(88, 201).m_171481_(-11.0f, 33.0f, -7.0f, 10.0f, 15.0f, 10.0f), PartPose.m_171419_((float)-10.0f, (float)-42.0f, (float)1.0f));
        parts.m_171599_("LLeg", CubeListBuilder.m_171558_().m_171514_(0, 90).m_171481_(3.0f, 0.0f, -3.0f, 6.0f, 20.0f, 6.0f), PartPose.m_171419_((float)0.0f, (float)-21.0f, (float)0.0f));
        parts.m_171599_("LThigh", CubeListBuilder.m_171558_().m_171514_(24, 64).m_171481_(2.5f, 4.0f, -3.5f, 7.0f, 12.0f, 7.0f), PartPose.m_171419_((float)0.0f, (float)-21.0f, (float)0.0f));
        parts.m_171599_("LKnee", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(2.0f, 20.0f, -4.0f, 8.0f, 24.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)-21.0f, (float)0.0f));
        parts.m_171599_("LAnkle", CubeListBuilder.m_171558_().m_171514_(32, 29).m_171481_(1.5f, 25.0f, -4.5f, 9.0f, 20.0f, 9.0f), PartPose.m_171419_((float)0.0f, (float)-21.0f, (float)0.0f));
        parts.m_171599_("LFoot", CubeListBuilder.m_171558_().m_171514_(0, 206).m_171481_(1.5f, 38.0f, -23.5f, 9.0f, 5.0f, 9.0f), PartPose.m_171423_((float)0.0f, (float)-21.0f, (float)0.0f, (float)0.2617994f, (float)0.0f, (float)0.0f));
        parts.m_171599_("RLeg", CubeListBuilder.m_171558_().m_171514_(0, 64).m_171481_(-9.0f, 0.0f, -3.0f, 6.0f, 20.0f, 6.0f), PartPose.m_171419_((float)0.0f, (float)-21.0f, (float)0.0f));
        parts.m_171599_("RThigh", CubeListBuilder.m_171558_().m_171514_(24, 83).m_171481_(-9.5f, 4.0f, -3.5f, 7.0f, 12.0f, 7.0f), PartPose.m_171419_((float)0.0f, (float)-21.0f, (float)0.0f));
        parts.m_171599_("RKnee", CubeListBuilder.m_171558_().m_171514_(0, 32).m_171481_(-10.0f, 20.0f, -4.0f, 8.0f, 24.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)-21.0f, (float)0.0f));
        parts.m_171599_("RAnkle", CubeListBuilder.m_171558_().m_171514_(32, 0).m_171481_(-10.5f, 25.0f, -4.5f, 9.0f, 20.0f, 9.0f), PartPose.m_171419_((float)0.0f, (float)-21.0f, (float)0.0f));
        parts.m_171599_("RFoot", CubeListBuilder.m_171558_().m_171514_(0, 192).m_171481_(-10.5f, 38.0f, -23.5f, 9.0f, 5.0f, 9.0f), PartPose.m_171423_((float)0.0f, (float)-21.0f, (float)0.0f, (float)0.2617994f, (float)0.0f, (float)0.0f));
        parts.m_171599_("Neck", CubeListBuilder.m_171558_().m_171514_(52, 90).m_171481_(-4.0f, -8.0f, -5.8f, 8.0f, 10.0f, 8.0f), PartPose.m_171423_((float)0.0f, (float)-44.0f, (float)0.0f, (float)0.5235988f, (float)0.0f, (float)0.0f));
        parts.m_171599_("Face", CubeListBuilder.m_171558_().m_171514_(52, 70).m_171481_(-4.5f, -11.0f, -9.0f, 9.0f, 7.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)-44.0f, (float)0.0f));
        parts.m_171599_("Head", CubeListBuilder.m_171558_().m_171514_(84, 88).m_171481_(-6.0f, -20.5f, -9.5f, 12.0f, 10.0f, 10.0f), PartPose.m_171419_((float)0.0f, (float)-44.0f, (float)0.0f));
        parts.m_171599_("Nose", CubeListBuilder.m_171558_().m_171514_(82, 88).m_171481_(-1.5f, -12.0f, -12.0f, 3.0f, 7.0f, 3.0f), PartPose.m_171423_((float)0.0f, (float)-44.0f, (float)0.0f, (float)-0.122173f, (float)0.0f, (float)0.0f));
        parts.m_171599_("Mouth", CubeListBuilder.m_171558_().m_171514_(77, 36).m_171481_(-3.0f, -8.0f, -6.8f, 6.0f, 2.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)-44.0f, (float)0.0f, (float)0.5235988f, (float)0.0f, (float)0.0f));
        parts.m_171599_("TreeBase", CubeListBuilder.m_171558_().m_171514_(0, 136).m_171481_(-10.0f, -31.5f, -11.5f, 20.0f, 13.0f, 20.0f), PartPose.m_171419_((float)0.0f, (float)-44.0f, (float)0.0f));
        parts.m_171599_("Leave1", CubeListBuilder.m_171558_().m_171514_(0, 224).m_171481_(-16.0f, -45.0f, -17.0f, 16.0f, 16.0f, 16.0f), PartPose.m_171419_((float)0.0f, (float)-44.0f, (float)0.0f));
        parts.m_171599_("Leave2", CubeListBuilder.m_171558_().m_171514_(0, 224).m_171481_(0.0f, -45.0f, -17.0f, 16.0f, 16.0f, 16.0f), PartPose.m_171419_((float)0.0f, (float)-44.0f, (float)0.0f));
        parts.m_171599_("Leave3", CubeListBuilder.m_171558_().m_171514_(0, 224).m_171481_(0.0f, -45.0f, -1.0f, 16.0f, 16.0f, 16.0f), PartPose.m_171419_((float)0.0f, (float)-44.0f, (float)0.0f));
        parts.m_171599_("Leave4", CubeListBuilder.m_171558_().m_171514_(0, 224).m_171481_(-16.0f, -45.0f, -1.0f, 16.0f, 16.0f, 16.0f), PartPose.m_171419_((float)0.0f, (float)-44.0f, (float)0.0f));
        parts.m_171599_("Leave5", CubeListBuilder.m_171558_().m_171514_(0, 224).m_171481_(-16.0f, -45.0f, -33.0f, 16.0f, 16.0f, 16.0f), PartPose.m_171419_((float)0.0f, (float)-44.0f, (float)0.0f));
        parts.m_171599_("Leave6", CubeListBuilder.m_171558_().m_171514_(0, 224).m_171481_(0.0f, -45.0f, -33.0f, 16.0f, 16.0f, 16.0f), PartPose.m_171419_((float)0.0f, (float)-44.0f, (float)0.0f));
        parts.m_171599_("Leave7", CubeListBuilder.m_171558_().m_171514_(0, 224).m_171481_(16.0f, -45.0f, -17.0f, 16.0f, 16.0f, 16.0f), PartPose.m_171419_((float)0.0f, (float)-44.0f, (float)0.0f));
        parts.m_171599_("Leave8", CubeListBuilder.m_171558_().m_171514_(0, 224).m_171481_(16.0f, -45.0f, -1.0f, 16.0f, 16.0f, 16.0f), PartPose.m_171419_((float)0.0f, (float)-44.0f, (float)0.0f));
        parts.m_171599_("Leave9", CubeListBuilder.m_171558_().m_171514_(0, 224).m_171481_(0.0f, -45.0f, 15.0f, 16.0f, 16.0f, 16.0f), PartPose.m_171419_((float)0.0f, (float)-44.0f, (float)0.0f));
        parts.m_171599_("Leave10", CubeListBuilder.m_171558_().m_171514_(0, 224).m_171481_(-16.0f, -45.0f, 15.0f, 16.0f, 16.0f, 16.0f), PartPose.m_171419_((float)0.0f, (float)-44.0f, (float)0.0f));
        parts.m_171599_("Leave11", CubeListBuilder.m_171558_().m_171514_(0, 224).m_171481_(-32.0f, -45.0f, -1.0f, 16.0f, 16.0f, 16.0f), PartPose.m_171419_((float)0.0f, (float)-44.0f, (float)0.0f));
        parts.m_171599_("Leave12", CubeListBuilder.m_171558_().m_171514_(0, 224).m_171481_(-32.0f, -45.0f, -17.0f, 16.0f, 16.0f, 16.0f), PartPose.m_171419_((float)0.0f, (float)-44.0f, (float)0.0f));
        parts.m_171599_("Leave13", CubeListBuilder.m_171558_().m_171514_(0, 224).m_171481_(-16.0f, -61.0f, -17.0f, 16.0f, 16.0f, 16.0f), PartPose.m_171419_((float)0.0f, (float)-44.0f, (float)0.0f));
        parts.m_171599_("Leave14", CubeListBuilder.m_171558_().m_171514_(0, 224).m_171481_(0.0f, -61.0f, -17.0f, 16.0f, 16.0f, 16.0f), PartPose.m_171419_((float)0.0f, (float)-44.0f, (float)0.0f));
        parts.m_171599_("Leave15", CubeListBuilder.m_171558_().m_171514_(0, 224).m_171481_(0.0f, -61.0f, -1.0f, 16.0f, 16.0f, 16.0f), PartPose.m_171419_((float)0.0f, (float)-44.0f, (float)0.0f));
        parts.m_171599_("Leave16", CubeListBuilder.m_171558_().m_171514_(0, 224).m_171481_(-16.0f, -61.0f, -1.0f, 16.0f, 16.0f, 16.0f), PartPose.m_171419_((float)0.0f, (float)-44.0f, (float)0.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)128, (int)256);
    }

    public void m_7695_(PoseStack pose, VertexConsumer buffer, int packedLight, int packedOverlay, float r, float g, float b, float a) {
        this.Body.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.LShoulder.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.LArm.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.LWrist.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.LHand.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.LFingers.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.RShoulder.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.RArm.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.RWrist.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.RHand.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.RFingers.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.LLeg.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.LThigh.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.LKnee.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.LAnkle.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.LFoot.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.RLeg.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.RThigh.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.RKnee.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.RAnkle.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.RFoot.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.Neck.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.Face.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.Head.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.Nose.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.Mouth.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.TreeBase.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.Leave1.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.Leave2.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.Leave3.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.Leave4.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.Leave5.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.Leave6.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.Leave7.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.Leave8.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.Leave9.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.Leave10.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.Leave11.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.Leave12.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.Leave13.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.Leave14.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.Leave15.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
        this.Leave16.m_104306_(pose, buffer, packedLight, packedOverlay, r, g, b, a);
    }

    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float headYRot;
        float rad = 57.29578f;
        float RArmXRot = Mth.m_14089_((float)(limbSwing * 0.6662f + (float)Math.PI)) * 2.0f * limbSwingAmount * 0.5f;
        float LArmXRot = Mth.m_14089_((float)(limbSwing * 0.6662f)) * 2.0f * limbSwingAmount * 0.5f;
        float RLegXRot = Mth.m_14089_((float)(limbSwing * 0.6662f)) * 1.0f * limbSwingAmount;
        float LLegXRot = Mth.m_14089_((float)(limbSwing * 0.6662f + (float)Math.PI)) * 1.0f * limbSwingAmount;
        this.LWrist.f_104203_ = LArmXRot;
        this.LWrist.f_104205_ = Mth.m_14089_((float)(ageInTicks * 0.09f)) * 0.05f - 0.05f;
        this.RWrist.f_104203_ = RArmXRot;
        this.RWrist.f_104205_ = -(Mth.m_14089_((float)(ageInTicks * 0.09f)) * 0.05f) + 0.05f;
        this.LArm.f_104203_ = this.LWrist.f_104203_;
        this.LHand.f_104203_ = this.LWrist.f_104203_;
        this.LFingers.f_104203_ = this.LWrist.f_104203_;
        this.LArm.f_104205_ = -10.0f / rad + this.LWrist.f_104205_;
        this.LHand.f_104205_ = this.LWrist.f_104205_;
        this.LFingers.f_104205_ = this.LWrist.f_104205_;
        this.RArm.f_104203_ = this.RWrist.f_104203_;
        this.RHand.f_104203_ = this.RWrist.f_104203_;
        this.RFingers.f_104203_ = this.RWrist.f_104203_;
        this.RArm.f_104205_ = 10.0f / rad + this.RWrist.f_104205_;
        this.RHand.f_104205_ = this.RWrist.f_104205_;
        this.RFingers.f_104205_ = this.RWrist.f_104205_;
        this.RLeg.f_104203_ = RLegXRot;
        this.LKnee.f_104203_ = this.LAnkle.f_104203_ = (this.LLeg.f_104203_ = LLegXRot);
        this.LThigh.f_104203_ = this.LAnkle.f_104203_;
        this.RKnee.f_104203_ = this.RAnkle.f_104203_ = this.RLeg.f_104203_;
        this.RThigh.f_104203_ = this.RAnkle.f_104203_;
        this.LFoot.f_104203_ = 15.0f / rad + this.LLeg.f_104203_;
        this.RFoot.f_104203_ = 15.0f / rad + this.RLeg.f_104203_;
        this.Neck.f_104204_ = headYRot = netHeadYaw / rad;
        this.Face.f_104204_ = headYRot;
        this.Head.f_104204_ = headYRot;
        this.Nose.f_104204_ = headYRot;
        this.Mouth.f_104204_ = headYRot;
        this.TreeBase.f_104204_ = headYRot;
        this.Leave1.f_104204_ = headYRot;
        this.Leave2.f_104204_ = headYRot;
        this.Leave3.f_104204_ = headYRot;
        this.Leave4.f_104204_ = headYRot;
        this.Leave5.f_104204_ = headYRot;
        this.Leave6.f_104204_ = headYRot;
        this.Leave7.f_104204_ = headYRot;
        this.Leave8.f_104204_ = headYRot;
        this.Leave9.f_104204_ = headYRot;
        this.Leave10.f_104204_ = headYRot;
        this.Leave11.f_104204_ = headYRot;
        this.Leave12.f_104204_ = headYRot;
        this.Leave13.f_104204_ = headYRot;
        this.Leave14.f_104204_ = headYRot;
        this.Leave15.f_104204_ = headYRot;
        this.Leave16.f_104204_ = headYRot;
    }
}

