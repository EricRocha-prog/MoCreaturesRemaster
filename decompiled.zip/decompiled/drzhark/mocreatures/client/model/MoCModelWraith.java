/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.HumanoidModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.builders.CubeDeformation
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.hostile.MoCEntityWraith;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelWraith<T extends MoCEntityWraith>
extends HumanoidModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "wraith"), "main");
    private int attackCounter;
    private boolean isSneaking;

    public MoCModelWraith(ModelPart root) {
        super(root);
    }

    public static LayerDefinition createBodyLayer() {
        return LayerDefinition.m_171565_((MeshDefinition)HumanoidModel.m_170681_((CubeDeformation)CubeDeformation.f_171458_, (float)0.0f), (int)64, (int)40);
    }

    public void prepareMobModel(T entity, float limbSwing, float limbSwingAmount, float partialTick) {
        this.isSneaking = entity.m_6047_();
        this.attackCounter = ((MoCEntityWraith)entity).attackCounter;
    }

    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        super.m_6973_(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        float f6 = Mth.m_14031_((float)(this.attackCounter > 0 ? (float)this.attackCounter * 0.12f : (float)this.attackCounter * 0.12f));
        float f7 = Mth.m_14031_((float)((1.0f - (1.0f - (this.attackCounter > 0 ? 1.0f : 1.0f)) * (1.0f - (this.attackCounter > 0 ? 1.0f : 1.0f))) * (float)Math.PI));
        this.f_102811_.f_104205_ = 0.0f;
        this.f_102812_.f_104205_ = 0.0f;
        float swingProg = this.f_102608_;
        float sinSwing = Mth.m_14031_((float)(swingProg * (float)Math.PI));
        this.f_102811_.f_104204_ = -(0.1f - sinSwing * 0.6f);
        this.f_102812_.f_104204_ = 0.1f - sinSwing * 0.6f;
        if (this.attackCounter != 0) {
            float armMov = Mth.m_14089_((float)((float)this.attackCounter * 0.12f)) * 4.0f;
            this.f_102811_.f_104203_ = -armMov;
            this.f_102812_.f_104203_ = -armMov;
        } else {
            this.f_102811_.f_104203_ = -1.5707964f;
            this.f_102812_.f_104203_ = -1.5707964f;
            float fSwing = sinSwing * 1.2f - f7 * 0.4f;
            this.f_102811_.f_104203_ -= fSwing;
            this.f_102812_.f_104203_ -= fSwing;
            this.f_102811_.f_104203_ += Mth.m_14031_((float)(ageInTicks * 0.067f)) * 0.05f;
            this.f_102812_.f_104203_ -= Mth.m_14031_((float)(ageInTicks * 0.067f)) * 0.05f;
        }
        this.f_102811_.f_104205_ += Mth.m_14089_((float)(ageInTicks * 0.09f)) * 0.05f + 0.05f;
        this.f_102812_.f_104205_ -= Mth.m_14089_((float)(ageInTicks * 0.09f)) * 0.05f + 0.05f;
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        poseStack.m_85836_();
        if (this.f_102610_) {
            poseStack.m_85841_(0.75f, 0.75f, 0.75f);
            poseStack.m_252880_(0.0f, 0.5f, 0.0f);
        } else if (this.isSneaking) {
            poseStack.m_252880_(0.0f, 0.2f, 0.0f);
        }
        this.f_102808_.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.f_102810_.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.f_102811_.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.f_102812_.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.f_102813_.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.f_102814_.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        poseStack.m_85849_();
    }
}

