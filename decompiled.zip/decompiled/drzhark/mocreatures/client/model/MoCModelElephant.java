/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.neutral.MoCEntityElephant;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelElephant<T extends MoCEntityElephant>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "elephant"), "main");
    private final ModelPart head;
    private final ModelPart neck;
    private final ModelPart headBump;
    private final ModelPart chin;
    private final ModelPart lowerLip;
    private final ModelPart back;
    private final ModelPart leftSmallEar;
    private final ModelPart leftBigEar;
    private final ModelPart rightSmallEar;
    private final ModelPart rightBigEar;
    private final ModelPart hump;
    private final ModelPart body;
    private final ModelPart skirt;
    private final ModelPart rightTuskA;
    private final ModelPart rightTuskB;
    private final ModelPart rightTuskC;
    private final ModelPart rightTuskD;
    private final ModelPart leftTuskA;
    private final ModelPart leftTuskB;
    private final ModelPart leftTuskC;
    private final ModelPart leftTuskD;
    private final ModelPart trunkA;
    private final ModelPart trunkB;
    private final ModelPart trunkC;
    private final ModelPart trunkD;
    private final ModelPart trunkE;
    private final ModelPart frontRightUpperLeg;
    private final ModelPart frontRightLowerLeg;
    private final ModelPart frontLeftUpperLeg;
    private final ModelPart frontLeftLowerLeg;
    private final ModelPart backRightUpperLeg;
    private final ModelPart backRightLowerLeg;
    private final ModelPart backLeftUpperLeg;
    private final ModelPart backLeftLowerLeg;
    private final ModelPart tailRoot;
    private final ModelPart tail;
    private final ModelPart tailPlush;
    private final ModelPart storageRightBedroll;
    private final ModelPart storageLeftBedroll;
    private final ModelPart storageFrontRightChest;
    private final ModelPart storageBackRightChest;
    private final ModelPart storageFrontLeftChest;
    private final ModelPart storageBackLeftChest;
    private final ModelPart storageRightBlankets;
    private final ModelPart storageLeftBlankets;
    private final ModelPart harnessBlanket;
    private final ModelPart harnessUpperBelt;
    private final ModelPart harnessLowerBelt;
    private final ModelPart cabinPillow;
    private final ModelPart cabinLeftRail;
    private final ModelPart cabin;
    private final ModelPart cabinRightRail;
    private final ModelPart cabinBackRail;
    private final ModelPart cabinRoof;
    private final ModelPart fortNeckBeam;
    private final ModelPart fortBackBeam;
    private final ModelPart tuskLD1;
    private final ModelPart tuskLD2;
    private final ModelPart tuskLD3;
    private final ModelPart tuskLD4;
    private final ModelPart tuskLD5;
    private final ModelPart tuskRD1;
    private final ModelPart tuskRD2;
    private final ModelPart tuskRD3;
    private final ModelPart tuskRD4;
    private final ModelPart tuskRD5;
    private final ModelPart tuskLI1;
    private final ModelPart tuskLI2;
    private final ModelPart tuskLI3;
    private final ModelPart tuskLI4;
    private final ModelPart tuskLI5;
    private final ModelPart tuskRI1;
    private final ModelPart tuskRI2;
    private final ModelPart tuskRI3;
    private final ModelPart tuskRI4;
    private final ModelPart tuskRI5;
    private final ModelPart tuskLW1;
    private final ModelPart tuskLW2;
    private final ModelPart tuskLW3;
    private final ModelPart tuskLW4;
    private final ModelPart tuskLW5;
    private final ModelPart tuskRW1;
    private final ModelPart tuskRW2;
    private final ModelPart tuskRW3;
    private final ModelPart tuskRW4;
    private final ModelPart tuskRW5;
    private final ModelPart fortFloor1;
    private final ModelPart fortFloor2;
    private final ModelPart fortFloor3;
    private final ModelPart fortBackWall;
    private final ModelPart fortBackLeftWall;
    private final ModelPart fortBackRightWall;
    private final ModelPart storageUpLeft;
    private final ModelPart storageUpRight;
    private MoCEntityElephant elephant;
    private float radianF = 57.29578f;
    private int tusks;
    private boolean isSitting;
    private int tailCounter;
    private int earCounter;
    private int trunkCounter;

    public MoCModelElephant(ModelPart root) {
        this.head = root.m_171324_("head");
        this.neck = root.m_171324_("neck");
        this.headBump = root.m_171324_("headBump");
        this.chin = root.m_171324_("chin");
        this.lowerLip = root.m_171324_("lowerLip");
        this.back = root.m_171324_("back");
        this.leftSmallEar = root.m_171324_("leftSmallEar");
        this.leftBigEar = root.m_171324_("leftBigEar");
        this.rightSmallEar = root.m_171324_("rightSmallEar");
        this.rightBigEar = root.m_171324_("rightBigEar");
        this.hump = root.m_171324_("hump");
        this.body = root.m_171324_("body");
        this.skirt = root.m_171324_("skirt");
        this.rightTuskA = root.m_171324_("rightTuskA");
        this.rightTuskB = root.m_171324_("rightTuskB");
        this.rightTuskC = root.m_171324_("rightTuskC");
        this.rightTuskD = root.m_171324_("rightTuskD");
        this.leftTuskA = root.m_171324_("leftTuskA");
        this.leftTuskB = root.m_171324_("leftTuskB");
        this.leftTuskC = root.m_171324_("leftTuskC");
        this.leftTuskD = root.m_171324_("leftTuskD");
        this.trunkA = root.m_171324_("trunkA");
        this.trunkB = root.m_171324_("trunkB");
        this.trunkC = root.m_171324_("trunkC");
        this.trunkD = root.m_171324_("trunkD");
        this.trunkE = root.m_171324_("trunkE");
        this.frontRightUpperLeg = root.m_171324_("frontRightUpperLeg");
        this.frontRightLowerLeg = root.m_171324_("frontRightLowerLeg");
        this.frontLeftUpperLeg = root.m_171324_("frontLeftUpperLeg");
        this.frontLeftLowerLeg = root.m_171324_("frontLeftLowerLeg");
        this.backRightUpperLeg = root.m_171324_("backRightUpperLeg");
        this.backRightLowerLeg = root.m_171324_("backRightLowerLeg");
        this.backLeftUpperLeg = root.m_171324_("backLeftUpperLeg");
        this.backLeftLowerLeg = root.m_171324_("backLeftLowerLeg");
        this.tailRoot = root.m_171324_("tailRoot");
        this.tail = root.m_171324_("tail");
        this.tailPlush = root.m_171324_("tailPlush");
        this.storageRightBedroll = root.m_171324_("storageRightBedroll");
        this.storageLeftBedroll = root.m_171324_("storageLeftBedroll");
        this.storageFrontRightChest = root.m_171324_("storageFrontRightChest");
        this.storageBackRightChest = root.m_171324_("storageBackRightChest");
        this.storageFrontLeftChest = root.m_171324_("storageFrontLeftChest");
        this.storageBackLeftChest = root.m_171324_("storageBackLeftChest");
        this.storageRightBlankets = root.m_171324_("storageRightBlankets");
        this.storageLeftBlankets = root.m_171324_("storageLeftBlankets");
        this.harnessBlanket = root.m_171324_("harnessBlanket");
        this.harnessUpperBelt = root.m_171324_("harnessUpperBelt");
        this.harnessLowerBelt = root.m_171324_("harnessLowerBelt");
        this.cabinPillow = root.m_171324_("cabinPillow");
        this.cabinLeftRail = root.m_171324_("cabinLeftRail");
        this.cabin = root.m_171324_("cabin");
        this.cabinRightRail = root.m_171324_("cabinRightRail");
        this.cabinBackRail = root.m_171324_("cabinBackRail");
        this.cabinRoof = root.m_171324_("cabinRoof");
        this.fortNeckBeam = root.m_171324_("fortNeckBeam");
        this.fortBackBeam = root.m_171324_("fortBackBeam");
        this.tuskLD1 = root.m_171324_("tuskLD1");
        this.tuskLD2 = root.m_171324_("tuskLD2");
        this.tuskLD3 = root.m_171324_("tuskLD3");
        this.tuskLD4 = root.m_171324_("tuskLD4");
        this.tuskLD5 = root.m_171324_("tuskLD5");
        this.tuskRD1 = root.m_171324_("tuskRD1");
        this.tuskRD2 = root.m_171324_("tuskRD2");
        this.tuskRD3 = root.m_171324_("tuskRD3");
        this.tuskRD4 = root.m_171324_("tuskRD4");
        this.tuskRD5 = root.m_171324_("tuskRD5");
        this.tuskLI1 = root.m_171324_("tuskLI1");
        this.tuskLI2 = root.m_171324_("tuskLI2");
        this.tuskLI3 = root.m_171324_("tuskLI3");
        this.tuskLI4 = root.m_171324_("tuskLI4");
        this.tuskLI5 = root.m_171324_("tuskLI5");
        this.tuskRI1 = root.m_171324_("tuskRI1");
        this.tuskRI2 = root.m_171324_("tuskRI2");
        this.tuskRI3 = root.m_171324_("tuskRI3");
        this.tuskRI4 = root.m_171324_("tuskRI4");
        this.tuskRI5 = root.m_171324_("tuskRI5");
        this.tuskLW1 = root.m_171324_("tuskLW1");
        this.tuskLW2 = root.m_171324_("tuskLW2");
        this.tuskLW3 = root.m_171324_("tuskLW3");
        this.tuskLW4 = root.m_171324_("tuskLW4");
        this.tuskLW5 = root.m_171324_("tuskLW5");
        this.tuskRW1 = root.m_171324_("tuskRW1");
        this.tuskRW2 = root.m_171324_("tuskRW2");
        this.tuskRW3 = root.m_171324_("tuskRW3");
        this.tuskRW4 = root.m_171324_("tuskRW4");
        this.tuskRW5 = root.m_171324_("tuskRW5");
        this.fortFloor1 = root.m_171324_("fortFloor1");
        this.fortFloor2 = root.m_171324_("fortFloor2");
        this.fortFloor3 = root.m_171324_("fortFloor3");
        this.fortBackWall = root.m_171324_("fortBackWall");
        this.fortBackLeftWall = root.m_171324_("fortBackLeftWall");
        this.fortBackRightWall = root.m_171324_("fortBackRightWall");
        this.storageUpLeft = root.m_171324_("storageUpLeft");
        this.storageUpRight = root.m_171324_("storageUpRight");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        root.m_171599_("head", CubeListBuilder.m_171558_().m_171514_(60, 0).m_171481_(-5.5f, -6.0f, -8.0f, 11.0f, 15.0f, 10.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)-0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("neck", CubeListBuilder.m_171558_().m_171514_(46, 48).m_171481_(-4.95f, -6.0f, -8.0f, 10.0f, 14.0f, 8.0f), PartPose.m_171423_((float)0.0f, (float)-8.0f, (float)-10.0f, (float)-0.2617994f, (float)0.0f, (float)0.0f));
        root.m_171599_("headBump", CubeListBuilder.m_171558_().m_171514_(104, 41).m_171481_(-3.0f, -9.0f, -6.0f, 6.0f, 3.0f, 6.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)-0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("chin", CubeListBuilder.m_171558_().m_171514_(86, 56).m_171481_(-1.5f, -6.0f, -10.7f, 3.0f, 5.0f, 4.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)2.054118f, (float)0.0f, (float)0.0f));
        root.m_171599_("lowerLip", CubeListBuilder.m_171558_().m_171514_(80, 65).m_171481_(-2.0f, -2.0f, -14.0f, 4.0f, 2.0f, 6.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)1.570796f, (float)0.0f, (float)0.0f));
        root.m_171599_("back", CubeListBuilder.m_171558_().m_171514_(0, 48).m_171481_(-5.0f, -10.0f, -10.0f, 10.0f, 2.0f, 26.0f), PartPose.m_171419_((float)0.0f, (float)-4.0f, (float)-3.0f));
        root.m_171599_("leftSmallEar", CubeListBuilder.m_171558_().m_171514_(102, 0).m_171481_(2.0f, -8.0f, -5.0f, 8.0f, 10.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)-0.1745329f, (float)-0.5235988f, (float)0.5235988f));
        root.m_171599_("leftBigEar", CubeListBuilder.m_171558_().m_171514_(102, 0).m_171481_(2.0f, -8.0f, -5.0f, 12.0f, 14.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)-0.1745329f, (float)-0.5235988f, (float)0.5235988f));
        root.m_171599_("rightSmallEar", CubeListBuilder.m_171558_().m_171514_(106, 15).m_171481_(-10.0f, -8.0f, -5.0f, 8.0f, 10.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)-0.1745329f, (float)0.5235988f, (float)-0.5235988f));
        root.m_171599_("rightBigEar", CubeListBuilder.m_171558_().m_171514_(102, 15).m_171481_(-14.0f, -8.0f, -5.0f, 12.0f, 14.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)-0.1745329f, (float)0.5235988f, (float)-0.5235988f));
        root.m_171599_("hump", CubeListBuilder.m_171558_().m_171514_(88, 30).m_171481_(-6.0f, -2.0f, -3.0f, 12.0f, 3.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)-13.0f, (float)-5.5f));
        root.m_171599_("body", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-8.0f, -10.0f, -10.0f, 16.0f, 20.0f, 28.0f), PartPose.m_171419_((float)0.0f, (float)-2.0f, (float)-3.0f));
        root.m_171599_("skirt", CubeListBuilder.m_171558_().m_171514_(28, 94).m_171481_(-8.0f, -10.0f, -6.0f, 16.0f, 28.0f, 6.0f), PartPose.m_171423_((float)0.0f, (float)8.0f, (float)-3.0f, (float)1.570796f, (float)0.0f, (float)0.0f));
        root.m_171599_("rightTuskA", CubeListBuilder.m_171558_().m_171514_(2, 60).m_171481_(-3.8f, -3.5f, -19.0f, 2.0f, 2.0f, 10.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)1.22173f, (float)0.0f, (float)0.1745329f));
        root.m_171599_("rightTuskB", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-3.8f, 6.2f, -24.2f, 2.0f, 2.0f, 7.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)0.6981317f, (float)0.0f, (float)0.1745329f));
        root.m_171599_("rightTuskC", CubeListBuilder.m_171558_().m_171514_(0, 18).m_171481_(-3.8f, 17.1f, -21.9f, 2.0f, 2.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)0.1745329f, (float)0.0f, (float)0.1745329f));
        root.m_171599_("rightTuskD", CubeListBuilder.m_171558_().m_171514_(14, 18).m_171481_(-3.8f, 25.5f, -14.5f, 2.0f, 2.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)-0.3490659f, (float)0.0f, (float)0.1745329f));
        root.m_171599_("leftTuskA", CubeListBuilder.m_171558_().m_171514_(2, 48).m_171481_(1.8f, -3.5f, -19.0f, 2.0f, 2.0f, 10.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)1.22173f, (float)0.0f, (float)-0.1745329f));
        root.m_171599_("leftTuskB", CubeListBuilder.m_171558_().m_171514_(0, 9).m_171481_(1.8f, 6.2f, -24.2f, 2.0f, 2.0f, 7.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)0.6981317f, (float)0.0f, (float)-0.1745329f));
        root.m_171599_("leftTuskC", CubeListBuilder.m_171558_().m_171514_(0, 18).m_171481_(1.8f, 17.1f, -21.9f, 2.0f, 2.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)0.1745329f, (float)0.0f, (float)-0.1745329f));
        root.m_171599_("leftTuskD", CubeListBuilder.m_171558_().m_171514_(14, 18).m_171481_(1.8f, 25.5f, -14.5f, 2.0f, 2.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)-0.3490659f, (float)0.0f, (float)-0.1745329f));
        root.m_171599_("trunkA", CubeListBuilder.m_171558_().m_171514_(0, 76).m_171481_(-4.0f, -2.5f, -18.0f, 8.0f, 7.0f, 10.0f), PartPose.m_171423_((float)0.0f, (float)-3.0f, (float)-22.46667f, (float)1.570796f, (float)0.0f, (float)0.0f));
        root.m_171599_("trunkB", CubeListBuilder.m_171558_().m_171514_(0, 93).m_171481_(-3.0f, -2.5f, -7.0f, 6.0f, 5.0f, 7.0f), PartPose.m_171423_((float)0.0f, (float)6.5f, (float)-22.5f, (float)1.658063f, (float)0.0f, (float)0.0f));
        root.m_171599_("trunkC", CubeListBuilder.m_171558_().m_171514_(0, 105).m_171481_(-2.5f, -2.0f, -4.0f, 5.0f, 4.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)13.0f, (float)-22.0f, (float)1.919862f, (float)0.0f, (float)0.0f));
        root.m_171599_("trunkD", CubeListBuilder.m_171558_().m_171514_(0, 114).m_171481_(-2.0f, -1.5f, -5.0f, 4.0f, 3.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)16.0f, (float)-21.5f, (float)2.216568f, (float)0.0f, (float)0.0f));
        root.m_171599_("trunkE", CubeListBuilder.m_171558_().m_171514_(0, 122).m_171481_(-1.5f, -1.0f, -4.0f, 3.0f, 2.0f, 4.0f), PartPose.m_171423_((float)0.0f, (float)19.5f, (float)-19.0f, (float)2.530727f, (float)0.0f, (float)0.0f));
        root.m_171599_("frontRightUpperLeg", CubeListBuilder.m_171558_().m_171514_(100, 109).m_171481_(-3.5f, 0.0f, -3.5f, 7.0f, 12.0f, 7.0f), PartPose.m_171419_((float)-4.6f, (float)4.0f, (float)-9.6f));
        root.m_171599_("frontRightLowerLeg", CubeListBuilder.m_171558_().m_171514_(100, 73).m_171481_(-3.5f, 0.0f, -3.5f, 7.0f, 10.0f, 7.0f), PartPose.m_171419_((float)-4.6f, (float)14.0f, (float)-9.6f));
        root.m_171599_("frontLeftUpperLeg", CubeListBuilder.m_171558_().m_171514_(100, 90).m_171481_(-3.5f, 0.0f, -3.5f, 7.0f, 12.0f, 7.0f), PartPose.m_171419_((float)4.6f, (float)4.0f, (float)-9.6f));
        root.m_171599_("frontLeftLowerLeg", CubeListBuilder.m_171558_().m_171514_(72, 73).m_171481_(-3.5f, 0.0f, -3.5f, 7.0f, 10.0f, 7.0f), PartPose.m_171419_((float)4.6f, (float)14.0f, (float)-9.6f));
        root.m_171599_("backRightUpperLeg", CubeListBuilder.m_171558_().m_171514_(72, 109).m_171481_(-3.5f, 0.0f, -3.5f, 7.0f, 12.0f, 7.0f), PartPose.m_171419_((float)-4.6f, (float)4.0f, (float)11.6f));
        root.m_171599_("backRightLowerLeg", CubeListBuilder.m_171558_().m_171514_(100, 56).m_171481_(-3.5f, 0.0f, -3.5f, 7.0f, 10.0f, 7.0f), PartPose.m_171419_((float)-4.6f, (float)14.0f, (float)11.6f));
        root.m_171599_("backLeftUpperLeg", CubeListBuilder.m_171558_().m_171514_(72, 90).m_171481_(-3.5f, 0.0f, -3.5f, 7.0f, 12.0f, 7.0f), PartPose.m_171419_((float)4.6f, (float)4.0f, (float)11.6f));
        root.m_171599_("backLeftLowerLeg", CubeListBuilder.m_171558_().m_171514_(44, 77).m_171481_(-3.5f, 0.0f, -3.5f, 7.0f, 10.0f, 7.0f), PartPose.m_171419_((float)4.6f, (float)14.0f, (float)11.6f));
        root.m_171599_("tailRoot", CubeListBuilder.m_171558_().m_171514_(20, 105).m_171481_(-1.0f, 0.0f, -2.0f, 2.0f, 10.0f, 2.0f), PartPose.m_171423_((float)0.0f, (float)-8.0f, (float)15.0f, (float)0.296706f, (float)0.0f, (float)0.0f));
        root.m_171599_("tail", CubeListBuilder.m_171558_().m_171514_(20, 117).m_171481_(-1.0f, 9.7f, -0.2f, 2.0f, 6.0f, 2.0f), PartPose.m_171423_((float)0.0f, (float)-8.0f, (float)15.0f, (float)0.1134464f, (float)0.0f, (float)0.0f));
        root.m_171599_("tailPlush", CubeListBuilder.m_171558_().m_171514_(26, 76).m_171481_(-1.5f, 15.5f, -0.7f, 3.0f, 6.0f, 3.0f), PartPose.m_171423_((float)0.0f, (float)-8.0f, (float)15.0f, (float)0.1134464f, (float)0.0f, (float)0.0f));
        root.m_171599_("storageRightBedroll", CubeListBuilder.m_171558_().m_171514_(90, 231).m_171481_(-2.5f, 8.0f, -8.0f, 3.0f, 3.0f, 16.0f), PartPose.m_171423_((float)-9.0f, (float)-10.2f, (float)1.0f, (float)0.0f, (float)0.0f, (float)0.418879f));
        root.m_171599_("storageLeftBedroll", CubeListBuilder.m_171558_().m_171514_(90, 231).m_171481_(-0.5f, 8.0f, -8.0f, 3.0f, 3.0f, 16.0f), PartPose.m_171423_((float)9.0f, (float)-10.2f, (float)1.0f, (float)0.0f, (float)0.0f, (float)-0.418879f));
        root.m_171599_("storageFrontRightChest", CubeListBuilder.m_171558_().m_171514_(76, 208).m_171481_(-3.5f, 0.0f, -5.0f, 5.0f, 8.0f, 10.0f), PartPose.m_171423_((float)-11.0f, (float)-1.2f, (float)-4.5f, (float)0.0f, (float)0.0f, (float)-0.2617994f));
        root.m_171599_("storageBackRightChest", CubeListBuilder.m_171558_().m_171514_(76, 208).m_171481_(-3.5f, 0.0f, -5.0f, 5.0f, 8.0f, 10.0f), PartPose.m_171423_((float)-11.0f, (float)-1.2f, (float)6.5f, (float)0.0f, (float)0.0f, (float)-0.2617994f));
        root.m_171599_("storageFrontLeftChest", CubeListBuilder.m_171558_().m_171514_(76, 226).m_171481_(-1.5f, 0.0f, -5.0f, 5.0f, 8.0f, 10.0f), PartPose.m_171423_((float)11.0f, (float)-1.2f, (float)-4.5f, (float)0.0f, (float)0.0f, (float)0.2617994f));
        root.m_171599_("storageBackLeftChest", CubeListBuilder.m_171558_().m_171514_(76, 226).m_171481_(-1.5f, 0.0f, -5.0f, 5.0f, 8.0f, 10.0f), PartPose.m_171423_((float)11.0f, (float)-1.2f, (float)6.5f, (float)0.0f, (float)0.0f, (float)0.2617994f));
        root.m_171599_("storageRightBlankets", CubeListBuilder.m_171558_().m_171514_(0, 228).m_171481_(-4.5f, -1.0f, -7.0f, 5.0f, 10.0f, 14.0f), PartPose.m_171419_((float)-9.0f, (float)-10.2f, (float)1.0f));
        root.m_171599_("storageLeftBlankets", CubeListBuilder.m_171558_().m_171514_(38, 228).m_171481_(-0.5f, -1.0f, -7.0f, 5.0f, 10.0f, 14.0f), PartPose.m_171419_((float)9.0f, (float)-10.2f, (float)1.0f));
        root.m_171599_("harnessBlanket", CubeListBuilder.m_171558_().m_171514_(0, 196).m_171481_(-8.5f, -2.0f, -3.0f, 17.0f, 14.0f, 18.0f), PartPose.m_171419_((float)0.0f, (float)-13.2f, (float)-3.5f));
        root.m_171599_("harnessUpperBelt", CubeListBuilder.m_171558_().m_171514_(70, 196).m_171481_(-8.5f, 0.5f, -2.0f, 17.0f, 10.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)-2.0f, (float)-2.5f));
        root.m_171599_("harnessLowerBelt", CubeListBuilder.m_171558_().m_171514_(70, 196).m_171481_(-8.5f, 0.5f, -2.5f, 17.0f, 10.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)-2.0f, (float)7.0f));
        root.m_171599_("cabinPillow", CubeListBuilder.m_171558_().m_171514_(76, 146).m_171481_(-6.5f, 0.0f, -6.5f, 13.0f, 4.0f, 13.0f), PartPose.m_171419_((float)0.0f, (float)-16.0f, (float)2.0f));
        root.m_171599_("cabinLeftRail", CubeListBuilder.m_171558_().m_171514_(56, 147).m_171481_(-7.0f, 0.0f, 7.0f, 14.0f, 1.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)-23.0f, (float)1.5f, (float)0.0f, (float)1.570796f, (float)0.0f));
        root.m_171599_("cabin", CubeListBuilder.m_171558_().m_171514_(0, 128).m_171481_(-7.0f, 0.0f, -7.0f, 14.0f, 20.0f, 14.0f), PartPose.m_171419_((float)0.0f, (float)-35.0f, (float)2.0f));
        root.m_171599_("cabinRightRail", CubeListBuilder.m_171558_().m_171514_(56, 147).m_171481_(-7.0f, 0.0f, 7.0f, 14.0f, 1.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)-23.0f, (float)1.5f, (float)0.0f, (float)-1.570796f, (float)0.0f));
        root.m_171599_("cabinBackRail", CubeListBuilder.m_171558_().m_171514_(56, 147).m_171481_(-7.0f, 0.0f, 7.0f, 14.0f, 1.0f, 1.0f), PartPose.m_171419_((float)0.0f, (float)-23.0f, (float)1.5f));
        root.m_171599_("cabinRoof", CubeListBuilder.m_171558_().m_171514_(56, 128).m_171481_(-7.5f, 0.0f, -7.5f, 15.0f, 4.0f, 15.0f), PartPose.m_171419_((float)0.0f, (float)-34.0f, (float)2.0f));
        root.m_171599_("fortNeckBeam", CubeListBuilder.m_171558_().m_171514_(26, 180).m_171481_(-12.0f, 0.0f, -20.5f, 24.0f, 4.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)-16.0f, (float)10.0f));
        root.m_171599_("fortBackBeam", CubeListBuilder.m_171558_().m_171514_(26, 180).m_171481_(-12.0f, 0.0f, 0.0f, 24.0f, 4.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)-16.0f, (float)10.0f));
        root.m_171599_("tuskLD1", CubeListBuilder.m_171558_().m_171514_(108, 207).m_171481_(1.3f, 5.5f, -24.2f, 3.0f, 3.0f, 7.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)0.6981317f, (float)0.0f, (float)-0.1745329f));
        root.m_171599_("tuskLD2", CubeListBuilder.m_171558_().m_171514_(112, 199).m_171481_(1.29f, 16.5f, -21.9f, 3.0f, 3.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)0.1745329f, (float)0.0f, (float)-0.1745329f));
        root.m_171599_("tuskLD3", CubeListBuilder.m_171558_().m_171514_(110, 190).m_171481_(1.3f, 24.9f, -15.5f, 3.0f, 3.0f, 6.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)-0.3490659f, (float)0.0f, (float)-0.1745329f));
        root.m_171599_("tuskLD4", CubeListBuilder.m_171558_().m_171514_(86, 175).m_171481_(2.7f, 14.5f, -21.9f, 0.0f, 7.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)0.1745329f, (float)0.0f, (float)-0.1745329f));
        root.m_171599_("tuskLD5", CubeListBuilder.m_171558_().m_171514_(112, 225).m_171481_(2.7f, 22.9f, -17.5f, 0.0f, 7.0f, 8.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)-0.3490659f, (float)0.0f, (float)-0.1745329f));
        root.m_171599_("tuskRD1", CubeListBuilder.m_171558_().m_171514_(108, 207).m_171481_(-4.3f, 5.5f, -24.2f, 3.0f, 3.0f, 7.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)0.6981317f, (float)0.0f, (float)0.1745329f));
        root.m_171599_("tuskRD2", CubeListBuilder.m_171558_().m_171514_(112, 199).m_171481_(-4.29f, 16.5f, -21.9f, 3.0f, 3.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)0.1745329f, (float)0.0f, (float)0.1745329f));
        root.m_171599_("tuskRD3", CubeListBuilder.m_171558_().m_171514_(110, 190).m_171481_(-4.3f, 24.9f, -15.5f, 3.0f, 3.0f, 6.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)-0.3490659f, (float)0.0f, (float)0.1745329f));
        root.m_171599_("tuskRD4", CubeListBuilder.m_171558_().m_171514_(86, 163).m_171481_(-2.8f, 14.5f, -21.9f, 0.0f, 7.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)0.1745329f, (float)0.0f, (float)0.1745329f));
        root.m_171599_("tuskRD5", CubeListBuilder.m_171558_().m_171514_(112, 232).m_171481_(-2.8f, 22.9f, -17.5f, 0.0f, 7.0f, 8.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)-0.3490659f, (float)0.0f, (float)0.1745329f));
        root.m_171599_("tuskLI1", CubeListBuilder.m_171558_().m_171514_(108, 180).m_171481_(1.3f, 5.5f, -24.2f, 3.0f, 3.0f, 7.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)0.6981317f, (float)0.0f, (float)-0.1745329f));
        root.m_171599_("tuskLI2", CubeListBuilder.m_171558_().m_171514_(112, 172).m_171481_(1.29f, 16.5f, -21.9f, 3.0f, 3.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)0.1745329f, (float)0.0f, (float)-0.1745329f));
        root.m_171599_("tuskLI3", CubeListBuilder.m_171558_().m_171514_(110, 163).m_171481_(1.3f, 24.9f, -15.5f, 3.0f, 3.0f, 6.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)-0.3490659f, (float)0.0f, (float)-0.1745329f));
        root.m_171599_("tuskLI4", CubeListBuilder.m_171558_().m_171514_(96, 175).m_171481_(2.7f, 14.5f, -21.9f, 0.0f, 7.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)0.1745329f, (float)0.0f, (float)-0.1745329f));
        root.m_171599_("tuskLI5", CubeListBuilder.m_171558_().m_171514_(112, 209).m_171481_(2.7f, 22.9f, -17.5f, 0.0f, 7.0f, 8.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)-0.3490659f, (float)0.0f, (float)-0.1745329f));
        root.m_171599_("tuskRI1", CubeListBuilder.m_171558_().m_171514_(108, 180).m_171481_(-4.3f, 5.5f, -24.2f, 3.0f, 3.0f, 7.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)0.6981317f, (float)0.0f, (float)0.1745329f));
        root.m_171599_("tuskRI2", CubeListBuilder.m_171558_().m_171514_(112, 172).m_171481_(-4.29f, 16.5f, -21.9f, 3.0f, 3.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)0.1745329f, (float)0.0f, (float)0.1745329f));
        root.m_171599_("tuskRI3", CubeListBuilder.m_171558_().m_171514_(110, 163).m_171481_(-4.3f, 24.9f, -15.5f, 3.0f, 3.0f, 6.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)-0.3490659f, (float)0.0f, (float)0.1745329f));
        root.m_171599_("tuskRI4", CubeListBuilder.m_171558_().m_171514_(96, 163).m_171481_(-2.8f, 14.5f, -21.9f, 0.0f, 7.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)0.1745329f, (float)0.0f, (float)0.1745329f));
        root.m_171599_("tuskRI5", CubeListBuilder.m_171558_().m_171514_(112, 216).m_171481_(-2.8f, 22.9f, -17.5f, 0.0f, 7.0f, 8.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)-0.3490659f, (float)0.0f, (float)0.1745329f));
        root.m_171599_("tuskLW1", CubeListBuilder.m_171558_().m_171514_(56, 166).m_171481_(1.3f, 5.5f, -24.2f, 3.0f, 3.0f, 7.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)0.6981317f, (float)0.0f, (float)-0.1745329f));
        root.m_171599_("tuskLW2", CubeListBuilder.m_171558_().m_171514_(60, 158).m_171481_(1.29f, 16.5f, -21.9f, 3.0f, 3.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)0.1745329f, (float)0.0f, (float)-0.1745329f));
        root.m_171599_("tuskLW3", CubeListBuilder.m_171558_().m_171514_(58, 149).m_171481_(1.3f, 24.9f, -15.5f, 3.0f, 3.0f, 6.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)-0.3490659f, (float)0.0f, (float)-0.1745329f));
        root.m_171599_("tuskLW4", CubeListBuilder.m_171558_().m_171514_(46, 164).m_171481_(2.7f, 14.5f, -21.9f, 0.0f, 7.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)0.1745329f, (float)0.0f, (float)-0.1745329f));
        root.m_171599_("tuskLW5", CubeListBuilder.m_171558_().m_171514_(52, 192).m_171481_(2.7f, 22.9f, -17.5f, 0.0f, 7.0f, 8.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)-0.3490659f, (float)0.0f, (float)-0.1745329f));
        root.m_171599_("tuskRW1", CubeListBuilder.m_171558_().m_171514_(56, 166).m_171481_(-4.3f, 5.5f, -24.2f, 3.0f, 3.0f, 7.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)0.6981317f, (float)0.0f, (float)0.1745329f));
        root.m_171599_("tuskRW2", CubeListBuilder.m_171558_().m_171514_(60, 158).m_171481_(-4.29f, 16.5f, -21.9f, 3.0f, 3.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)0.1745329f, (float)0.0f, (float)0.1745329f));
        root.m_171599_("tuskRW3", CubeListBuilder.m_171558_().m_171514_(58, 149).m_171481_(-4.3f, 24.9f, -15.5f, 3.0f, 3.0f, 6.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)-0.3490659f, (float)0.0f, (float)0.1745329f));
        root.m_171599_("tuskRW4", CubeListBuilder.m_171558_().m_171514_(46, 157).m_171481_(-2.8f, 14.5f, -21.9f, 0.0f, 7.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)0.1745329f, (float)0.0f, (float)0.1745329f));
        root.m_171599_("tuskRW5", CubeListBuilder.m_171558_().m_171514_(52, 199).m_171481_(-2.8f, 22.9f, -17.5f, 0.0f, 7.0f, 8.0f), PartPose.m_171423_((float)0.0f, (float)-10.0f, (float)-16.5f, (float)-0.3490659f, (float)0.0f, (float)0.1745329f));
        root.m_171599_("fortFloor1", CubeListBuilder.m_171558_().m_171514_(0, 176).m_171481_(-0.5f, -20.0f, -6.0f, 1.0f, 8.0f, 12.0f), PartPose.m_171423_((float)0.0f, (float)-16.0f, (float)10.0f, (float)1.570796f, (float)0.0f, (float)1.570796f));
        root.m_171599_("fortFloor2", CubeListBuilder.m_171558_().m_171514_(0, 176).m_171481_(-0.5f, -12.0f, -6.0f, 1.0f, 8.0f, 12.0f), PartPose.m_171423_((float)0.0f, (float)-16.0f, (float)10.0f, (float)1.570796f, (float)0.0f, (float)1.570796f));
        root.m_171599_("fortFloor3", CubeListBuilder.m_171558_().m_171514_(0, 176).m_171481_(-0.5f, -4.0f, -6.0f, 1.0f, 8.0f, 12.0f), PartPose.m_171423_((float)0.0f, (float)-16.0f, (float)10.0f, (float)1.570796f, (float)0.0f, (float)1.570796f));
        root.m_171599_("fortBackWall", CubeListBuilder.m_171558_().m_171514_(0, 176).m_171481_(-5.0f, -6.2f, -6.0f, 1.0f, 8.0f, 12.0f), PartPose.m_171423_((float)0.0f, (float)-16.0f, (float)10.0f, (float)0.0f, (float)1.570796f, (float)0.0f));
        root.m_171599_("fortBackLeftWall", CubeListBuilder.m_171558_().m_171514_(0, 176).m_171481_(6.0f, -6.0f, -7.0f, 1.0f, 8.0f, 12.0f), PartPose.m_171419_((float)0.0f, (float)-16.0f, (float)10.0f));
        root.m_171599_("fortBackRightWall", CubeListBuilder.m_171558_().m_171514_(0, 176).m_171481_(-7.0f, -6.0f, -7.0f, 1.0f, 8.0f, 12.0f), PartPose.m_171419_((float)0.0f, (float)-16.0f, (float)10.0f));
        root.m_171599_("storageUpLeft", CubeListBuilder.m_171558_().m_171514_(76, 226).m_171481_(6.5f, 1.0f, -14.0f, 5.0f, 8.0f, 10.0f), PartPose.m_171423_((float)0.0f, (float)-16.0f, (float)10.0f, (float)0.0f, (float)0.0f, (float)-0.3839724f));
        root.m_171599_("storageUpRight", CubeListBuilder.m_171558_().m_171514_(76, 208).m_171481_(-11.5f, 1.0f, -14.0f, 5.0f, 8.0f, 10.0f), PartPose.m_171423_((float)0.0f, (float)-16.0f, (float)10.0f, (float)0.0f, (float)0.0f, (float)0.3839724f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)128, (int)256);
    }

    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.elephant = entity;
        this.tusks = this.elephant.getTusks();
        this.tailCounter = this.elephant.tailCounter;
        this.earCounter = this.elephant.earCounter;
        this.trunkCounter = this.elephant.trunkCounter;
        this.isSitting = this.elephant.sitCounter != 0;
        this.setRotationAngles(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
    }

    public void m_7695_(PoseStack matrixStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        int type = this.elephant.getTypeMoC();
        int harness = this.elephant.getArmorType();
        int storage = this.elephant.getStorage();
        if (this.tusks == 0) {
            this.leftTuskB.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.rightTuskB.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            if (this.elephant.getIsAdult() || this.elephant.getMoCAge() > 70) {
                this.leftTuskC.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.rightTuskC.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            }
            if (this.elephant.getIsAdult() || this.elephant.getMoCAge() > 90) {
                this.leftTuskD.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.rightTuskD.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            }
        } else if (this.tusks == 1) {
            this.tuskLW1.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskLW2.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskLW3.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskLW4.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskLW5.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskRW1.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskRW2.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskRW3.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskRW4.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskRW5.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        } else if (this.tusks == 2) {
            this.tuskLI1.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskLI2.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskLI3.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskLI4.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskLI5.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskRI1.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskRI2.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskRI3.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskRI4.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskRI5.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        } else if (this.tusks == 3) {
            this.tuskLD1.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskLD2.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskLD3.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskLD4.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskLD5.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskRD1.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskRD2.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskRD3.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskRD4.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.tuskRD5.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        }
        if (type == 1) {
            this.leftBigEar.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.rightBigEar.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        } else {
            this.leftSmallEar.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.rightSmallEar.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        }
        if (type == 3 || type == 4) {
            this.headBump.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.skirt.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        }
        if (harness >= 1) {
            this.harnessBlanket.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.harnessUpperBelt.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.harnessLowerBelt.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            if (type == 5) {
                this.skirt.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            }
        }
        if (harness == 3) {
            if (type == 5) {
                this.cabinPillow.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.cabinLeftRail.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.cabin.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.cabinRightRail.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.cabinBackRail.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.cabinRoof.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            }
            if (type == 4) {
                this.fortBackRightWall.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.fortBackLeftWall.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.fortBackWall.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.fortFloor1.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.fortFloor2.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.fortFloor3.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.fortNeckBeam.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.fortBackBeam.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            }
        }
        if (storage >= 1) {
            this.storageRightBedroll.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.storageFrontRightChest.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.storageBackRightChest.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.storageRightBlankets.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        }
        if (storage >= 2) {
            this.storageLeftBlankets.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.storageLeftBedroll.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.storageFrontLeftChest.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.storageBackLeftChest.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        }
        if (storage >= 3) {
            this.storageUpLeft.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        }
        if (storage >= 4) {
            this.storageUpRight.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        }
        this.head.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.neck.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.chin.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.lowerLip.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.back.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.hump.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.body.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.rightTuskA.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leftTuskA.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.trunkA.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.trunkB.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.trunkC.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.trunkD.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.trunkE.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.frontRightUpperLeg.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.frontRightLowerLeg.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.frontLeftUpperLeg.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.frontLeftLowerLeg.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.backRightUpperLeg.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.backRightLowerLeg.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.backLeftUpperLeg.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.backLeftLowerLeg.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.tailRoot.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.tail.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.tailPlush.m_104306_(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }

    public void setRotationAngles(T entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        if (headPitch < 0.0f) {
            headPitch = 0.0f;
        }
        float headXRadians = headPitch / this.radianF;
        float headY = Mth.m_14036_((float)netHeadYaw, (float)-20.0f, (float)20.0f) / this.radianF;
        float rLegX = Mth.m_14089_((float)(limbSwing * 0.6662f + (float)Math.PI)) * 0.8f * limbSwingAmount;
        float lLegX = Mth.m_14089_((float)(limbSwing * 0.6662f)) * 0.8f * limbSwingAmount;
        float yOffset = this.isSitting ? 8.0f : 0.0f;
        this.adjustY(yOffset);
        float trunkOsc = 0.0f;
        if (this.trunkCounter != 0) {
            headXRadians = 0.0f;
            trunkOsc = Mth.m_14089_((float)((float)this.trunkCounter * 0.2f)) * 12.0f;
        }
        if (this.isSitting) {
            headXRadians = 0.0f;
            trunkOsc = 25.0f;
        }
        this.head.f_104203_ = -10.0f / this.radianF + headXRadians;
        this.head.f_104204_ = headY;
        this.headBump.f_104203_ = this.head.f_104203_;
        this.headBump.f_104204_ = headY;
        this.chin.f_104204_ = headY;
        this.chin.f_104203_ = 113.0f / this.radianF + headXRadians;
        this.lowerLip.f_104204_ = headY;
        this.lowerLip.f_104203_ = 85.0f / this.radianF + headXRadians;
        this.rightTuskA.f_104204_ = headY;
        this.rightTuskA.f_104203_ = 70.0f / this.radianF + headXRadians;
        this.leftTuskA.f_104204_ = headY;
        this.leftTuskA.f_104203_ = 70.0f / this.radianF + headXRadians;
        float earFlap = 0.0f;
        if (this.earCounter != 0) {
            earFlap = Mth.m_14089_((float)((float)this.earCounter * 0.5f)) * 0.35f;
        }
        this.rightBigEar.f_104204_ = 30.0f / this.radianF + headY + earFlap;
        this.rightSmallEar.f_104204_ = 30.0f / this.radianF + headY + earFlap;
        this.leftBigEar.f_104204_ = -30.0f / this.radianF + headY - earFlap;
        this.leftSmallEar.f_104204_ = -30.0f / this.radianF + headY - earFlap;
        this.rightBigEar.f_104203_ = -10.0f / this.radianF + headXRadians;
        this.rightSmallEar.f_104203_ = -10.0f / this.radianF + headXRadians;
        this.leftBigEar.f_104203_ = -10.0f / this.radianF + headXRadians;
        this.leftSmallEar.f_104203_ = -10.0f / this.radianF + headXRadians;
        this.trunkA.f_104204_ = headY;
        float trunkARot = 90.0f - trunkOsc;
        if (trunkARot < 85.0f) {
            trunkARot = 85.0f;
        }
        this.trunkA.f_104203_ = trunkARot / this.radianF + headXRadians;
        this.repositionChildFromParent(this.trunkA, this.head);
        this.repositionChildFromParent(this.trunkB, this.trunkA);
        this.trunkB.f_104204_ = headY;
        this.trunkB.f_104203_ = (95.0f - trunkOsc * 1.5f) / this.radianF + headXRadians;
        this.repositionChildFromParent(this.trunkC, this.trunkB);
        this.trunkC.f_104204_ = headY;
        this.trunkC.f_104203_ = (110.0f - trunkOsc * 3.0f) / this.radianF + headXRadians;
        this.repositionChildFromParent(this.trunkD, this.trunkC);
        this.trunkD.f_104204_ = headY;
        this.trunkD.f_104203_ = (127.0f - trunkOsc * 4.5f) / this.radianF + headXRadians;
        this.repositionChildFromParent(this.trunkE, this.trunkD);
        this.trunkE.f_104204_ = headY;
        this.trunkE.f_104203_ = (145.0f - trunkOsc * 6.0f) / this.radianF + headXRadians;
        if (this.isSitting) {
            this.frontRightUpperLeg.f_104203_ = -30.0f / this.radianF;
            this.frontLeftUpperLeg.f_104203_ = -30.0f / this.radianF;
            this.backRightUpperLeg.f_104203_ = -30.0f / this.radianF;
            this.backLeftUpperLeg.f_104203_ = -30.0f / this.radianF;
            this.frontRightLowerLeg.f_104203_ = 90.0f / this.radianF;
            this.frontLeftLowerLeg.f_104203_ = 90.0f / this.radianF;
            this.backRightLowerLeg.f_104203_ = 90.0f / this.radianF;
            this.backLeftLowerLeg.f_104203_ = 90.0f / this.radianF;
        } else {
            this.frontRightUpperLeg.f_104203_ = rLegX;
            this.frontLeftUpperLeg.f_104203_ = lLegX;
            this.backRightUpperLeg.f_104203_ = lLegX;
            this.backLeftUpperLeg.f_104203_ = rLegX;
            float lDeg = lLegX * 57.295776f;
            float rDeg = rLegX * 57.295776f;
            if (lDeg > 0.0f) {
                lDeg *= 2.0f;
            }
            if (rDeg > 0.0f) {
                rDeg *= 2.0f;
            }
            this.frontLeftLowerLeg.f_104203_ = lDeg / this.radianF;
            this.frontRightLowerLeg.f_104203_ = rDeg / this.radianF;
            this.backLeftLowerLeg.f_104203_ = rDeg / this.radianF;
            this.backRightLowerLeg.f_104203_ = lDeg / this.radianF;
        }
        this.repositionLegChild(this.frontRightLowerLeg, this.frontRightUpperLeg);
        this.repositionLegChild(this.frontLeftLowerLeg, this.frontLeftUpperLeg);
        this.repositionLegChild(this.backRightLowerLeg, this.backRightUpperLeg);
        this.repositionLegChild(this.backLeftLowerLeg, this.backLeftUpperLeg);
        switch (this.tusks) {
            case 0: {
                this.leftTuskB.f_104204_ = headY;
                this.leftTuskC.f_104204_ = headY;
                this.leftTuskD.f_104204_ = headY;
                this.rightTuskB.f_104204_ = headY;
                this.rightTuskC.f_104204_ = headY;
                this.rightTuskD.f_104204_ = headY;
                this.leftTuskB.f_104203_ = 40.0f / this.radianF + headXRadians;
                this.leftTuskC.f_104203_ = 10.0f / this.radianF + headXRadians;
                this.leftTuskD.f_104203_ = -20.0f / this.radianF + headXRadians;
                this.rightTuskB.f_104203_ = 40.0f / this.radianF + headXRadians;
                this.rightTuskC.f_104203_ = 10.0f / this.radianF + headXRadians;
                this.rightTuskD.f_104203_ = -20.0f / this.radianF + headXRadians;
                break;
            }
            case 1: {
                for (ModelPart m : new ModelPart[]{this.tuskLW1, this.tuskLW2, this.tuskLW3, this.tuskLW4, this.tuskLW5, this.tuskRW1, this.tuskRW2, this.tuskRW3, this.tuskRW4, this.tuskRW5}) {
                    m.f_104204_ = headY;
                    m.f_104203_ = 40.0f / this.radianF + headXRadians;
                }
                for (ModelPart m : new ModelPart[]{this.tuskLW2, this.tuskLW4, this.tuskRW2, this.tuskRW4}) {
                    m.f_104203_ = 10.0f / this.radianF + headXRadians;
                }
                for (ModelPart m : new ModelPart[]{this.tuskLW3, this.tuskRW3}) {
                    m.f_104203_ = -20.0f / this.radianF + headXRadians;
                }
                break;
            }
            case 2: {
                for (ModelPart m : new ModelPart[]{this.tuskLI1, this.tuskLI2, this.tuskLI3, this.tuskLI4, this.tuskLI5, this.tuskRI1, this.tuskRI2, this.tuskRI3, this.tuskRI4, this.tuskRI5}) {
                    m.f_104204_ = headY;
                    m.f_104203_ = 40.0f / this.radianF + headXRadians;
                }
                for (ModelPart m : new ModelPart[]{this.tuskLI2, this.tuskLI4, this.tuskRI2, this.tuskRI4}) {
                    m.f_104203_ = 10.0f / this.radianF + headXRadians;
                }
                for (ModelPart m : new ModelPart[]{this.tuskLI3, this.tuskRI3}) {
                    m.f_104203_ = -20.0f / this.radianF + headXRadians;
                }
                break;
            }
            case 3: {
                for (ModelPart m : new ModelPart[]{this.tuskLD1, this.tuskLD2, this.tuskLD3, this.tuskLD4, this.tuskLD5, this.tuskRD1, this.tuskRD2, this.tuskRD3, this.tuskRD4, this.tuskRD5}) {
                    m.f_104204_ = headY;
                    m.f_104203_ = 40.0f / this.radianF + headXRadians;
                }
                for (ModelPart m : new ModelPart[]{this.tuskLD2, this.tuskLD4, this.tuskRD2, this.tuskRD4}) {
                    m.f_104203_ = 10.0f / this.radianF + headXRadians;
                }
                for (ModelPart m : new ModelPart[]{this.tuskLD3, this.tuskRD3}) {
                    m.f_104203_ = -20.0f / this.radianF + headXRadians;
                }
                break;
            }
        }
        this.storageLeftBedroll.f_104203_ = lLegX / 10.0f;
        this.storageFrontLeftChest.f_104203_ = lLegX / 5.0f;
        this.storageBackLeftChest.f_104203_ = lLegX / 5.0f;
        this.storageRightBedroll.f_104203_ = rLegX / 10.0f;
        this.storageFrontRightChest.f_104203_ = rLegX / 5.0f;
        this.storageBackRightChest.f_104203_ = rLegX / 5.0f;
        this.fortNeckBeam.f_104205_ = lLegX / 50.0f;
        this.fortBackBeam.f_104205_ = lLegX / 50.0f;
        this.fortBackRightWall.f_104205_ = lLegX / 50.0f;
        this.fortBackLeftWall.f_104205_ = lLegX / 50.0f;
        this.fortBackWall.f_104203_ = -lLegX / 50.0f;
        float tailSwing = limbSwingAmount * 0.9f;
        if (tailSwing < 0.0f) {
            tailSwing = 0.0f;
        }
        if (this.tailCounter != 0) {
            this.tailRoot.f_104204_ = Mth.m_14089_((float)(ageInTicks * 0.4f)) * 1.3f;
            tailSwing = 30.0f / this.radianF;
        } else {
            this.tailRoot.f_104204_ = 0.0f;
        }
        this.tailRoot.f_104203_ = 17.0f / this.radianF + tailSwing;
        this.tailPlush.f_104203_ = this.tail.f_104203_ = 6.5f / this.radianF + tailSwing;
        this.tail.f_104204_ = this.tailPlush.f_104204_ = this.tailRoot.f_104204_;
    }

    private void adjustY(float offsetY) {
        this.head.f_104201_ = -10.0f + offsetY;
        this.neck.f_104201_ = -8.0f + offsetY;
        this.headBump.f_104201_ = -10.0f + offsetY;
        this.chin.f_104201_ = -10.0f + offsetY;
        this.lowerLip.f_104201_ = -10.0f + offsetY;
        this.back.f_104201_ = -4.0f + offsetY;
        this.leftSmallEar.f_104201_ = -10.0f + offsetY;
        this.leftBigEar.f_104201_ = -10.0f + offsetY;
        this.rightSmallEar.f_104201_ = -10.0f + offsetY;
        this.rightBigEar.f_104201_ = -10.0f + offsetY;
        this.hump.f_104201_ = -13.0f + offsetY;
        this.body.f_104201_ = -2.0f + offsetY;
        this.skirt.f_104201_ = 8.0f + offsetY;
        this.rightTuskA.f_104201_ = -10.0f + offsetY;
        this.rightTuskB.f_104201_ = -10.0f + offsetY;
        this.rightTuskC.f_104201_ = -10.0f + offsetY;
        this.rightTuskD.f_104201_ = -10.0f + offsetY;
        this.leftTuskA.f_104201_ = -10.0f + offsetY;
        this.leftTuskB.f_104201_ = -10.0f + offsetY;
        this.leftTuskC.f_104201_ = -10.0f + offsetY;
        this.leftTuskD.f_104201_ = -10.0f + offsetY;
        this.trunkA.f_104201_ = -3.0f + offsetY;
        this.trunkB.f_104201_ = 6.5f + offsetY;
        this.trunkC.f_104201_ = 13.0f + offsetY;
        this.trunkD.f_104201_ = 16.0f + offsetY;
        this.trunkE.f_104201_ = 19.5f + offsetY;
        this.frontRightUpperLeg.f_104201_ = 4.0f + offsetY;
        this.frontRightLowerLeg.f_104201_ = 14.0f + offsetY;
        this.frontLeftUpperLeg.f_104201_ = 4.0f + offsetY;
        this.frontLeftLowerLeg.f_104201_ = 14.0f + offsetY;
        this.backRightUpperLeg.f_104201_ = 4.0f + offsetY;
        this.backRightLowerLeg.f_104201_ = 14.0f + offsetY;
        this.backLeftUpperLeg.f_104201_ = 4.0f + offsetY;
        this.backLeftLowerLeg.f_104201_ = 14.0f + offsetY;
        this.tailRoot.f_104201_ = -8.0f + offsetY;
        this.tail.f_104201_ = -8.0f + offsetY;
        this.tailPlush.f_104201_ = -8.0f + offsetY;
        this.storageRightBedroll.f_104201_ = -10.2f + offsetY;
        this.storageLeftBedroll.f_104201_ = -10.2f + offsetY;
        this.storageFrontRightChest.f_104201_ = -1.2f + offsetY;
        this.storageBackRightChest.f_104201_ = -1.2f + offsetY;
        this.storageFrontLeftChest.f_104201_ = -1.2f + offsetY;
        this.storageBackLeftChest.f_104201_ = -1.2f + offsetY;
        this.storageRightBlankets.f_104201_ = -10.2f + offsetY;
        this.storageLeftBlankets.f_104201_ = -10.2f + offsetY;
        this.harnessBlanket.f_104201_ = -13.2f + offsetY;
        this.harnessUpperBelt.f_104201_ = -2.0f + offsetY;
        this.harnessLowerBelt.f_104201_ = -2.0f + offsetY;
        this.cabinPillow.f_104201_ = -16.0f + offsetY;
        this.cabinLeftRail.f_104201_ = -23.0f + offsetY;
        this.cabin.f_104201_ = -35.0f + offsetY;
        this.cabinRightRail.f_104201_ = -23.0f + offsetY;
        this.cabinBackRail.f_104201_ = -23.0f + offsetY;
        this.cabinRoof.f_104201_ = -34.0f + offsetY;
        this.fortNeckBeam.f_104201_ = -16.0f + offsetY;
        this.fortBackBeam.f_104201_ = -16.0f + offsetY;
        this.fortFloor1.f_104201_ = -16.0f + offsetY;
        this.fortFloor2.f_104201_ = -16.0f + offsetY;
        this.fortFloor3.f_104201_ = -16.0f + offsetY;
        this.fortBackWall.f_104201_ = -16.0f + offsetY;
        this.fortBackLeftWall.f_104201_ = -16.0f + offsetY;
        this.fortBackRightWall.f_104201_ = -16.0f + offsetY;
        this.storageUpLeft.f_104201_ = -16.0f + offsetY;
        this.storageUpRight.f_104201_ = -16.0f + offsetY;
        this.tuskLD1.f_104201_ = -10.0f + offsetY;
        this.tuskLD2.f_104201_ = -10.0f + offsetY;
        this.tuskLD3.f_104201_ = -10.0f + offsetY;
        this.tuskLD4.f_104201_ = -10.0f + offsetY;
        this.tuskLD5.f_104201_ = -10.0f + offsetY;
        this.tuskRD1.f_104201_ = -10.0f + offsetY;
        this.tuskRD2.f_104201_ = -10.0f + offsetY;
        this.tuskRD3.f_104201_ = -10.0f + offsetY;
        this.tuskRD4.f_104201_ = -10.0f + offsetY;
        this.tuskRD5.f_104201_ = -10.0f + offsetY;
        this.tuskLI1.f_104201_ = -10.0f + offsetY;
        this.tuskLI2.f_104201_ = -10.0f + offsetY;
        this.tuskLI3.f_104201_ = -10.0f + offsetY;
        this.tuskLI4.f_104201_ = -10.0f + offsetY;
        this.tuskLI5.f_104201_ = -10.0f + offsetY;
        this.tuskRI1.f_104201_ = -10.0f + offsetY;
        this.tuskRI2.f_104201_ = -10.0f + offsetY;
        this.tuskRI3.f_104201_ = -10.0f + offsetY;
        this.tuskRI4.f_104201_ = -10.0f + offsetY;
        this.tuskRI5.f_104201_ = -10.0f + offsetY;
        this.tuskLW1.f_104201_ = -10.0f + offsetY;
        this.tuskLW2.f_104201_ = -10.0f + offsetY;
        this.tuskLW3.f_104201_ = -10.0f + offsetY;
        this.tuskLW4.f_104201_ = -10.0f + offsetY;
        this.tuskLW5.f_104201_ = -10.0f + offsetY;
        this.tuskRW1.f_104201_ = -10.0f + offsetY;
        this.tuskRW2.f_104201_ = -10.0f + offsetY;
        this.tuskRW3.f_104201_ = -10.0f + offsetY;
        this.tuskRW4.f_104201_ = -10.0f + offsetY;
        this.tuskRW5.f_104201_ = -10.0f + offsetY;
    }

    private void repositionChildFromParent(ModelPart child, ModelPart parent) {
        float dy = child.f_104201_ - parent.f_104201_;
        float dz = child.f_104202_ - parent.f_104202_;
        child.f_104201_ = parent.f_104201_ + Mth.m_14031_((float)parent.f_104203_) * dy;
        child.f_104202_ = parent.f_104202_ - Mth.m_14089_((float)parent.f_104204_) * (Mth.m_14089_((float)parent.f_104203_) * dy);
    }

    private void repositionLegChild(ModelPart lower, ModelPart upper) {
        float dY = Math.abs(lower.f_104201_ - upper.f_104201_);
        lower.f_104202_ = upper.f_104202_ + Mth.m_14031_((float)upper.f_104203_) * dY;
        lower.f_104201_ = upper.f_104201_ + Mth.m_14089_((float)upper.f_104203_) * dY;
    }
}

