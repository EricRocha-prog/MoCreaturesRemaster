/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeDeformation
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.item.MoCEntityKittyBed;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelKittyBed<T extends MoCEntityKittyBed>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "kitty_bed"), "main");
    public boolean hasMilk;
    public boolean hasFood;
    public boolean pickedUp;
    public float milklevel;
    private final ModelPart TableL;
    private final ModelPart TableR;
    private final ModelPart Table_B;
    private final ModelPart FoodT;
    private final ModelPart FoodTraySide;
    private final ModelPart FoodTraySideB;
    private final ModelPart FoodTraySideC;
    private final ModelPart FoodTraySideD;
    private final ModelPart Milk;
    private final ModelPart PetFood;
    private final ModelPart Bottom;

    public MoCModelKittyBed(ModelPart root) {
        this.TableL = root.m_171324_("TableL");
        this.TableR = root.m_171324_("TableR");
        this.Table_B = root.m_171324_("Table_B");
        this.FoodT = root.m_171324_("FoodT");
        this.FoodTraySide = root.m_171324_("FoodTraySide");
        this.FoodTraySideB = root.m_171324_("FoodTraySideB");
        this.FoodTraySideC = root.m_171324_("FoodTraySideC");
        this.FoodTraySideD = root.m_171324_("FoodTraySideD");
        this.Milk = root.m_171324_("Milk");
        this.PetFood = root.m_171324_("PetFood");
        this.Bottom = root.m_171324_("Bottom");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        float limbSwing = 0.0f;
        root.m_171599_("TableL", CubeListBuilder.m_171558_().m_171514_(30, 8).m_171488_(-8.0f, 0.0f, 7.0f, 16.0f, 6.0f, 1.0f, new CubeDeformation(limbSwing)), PartPose.m_171419_((float)0.0f, (float)18.0f, (float)0.0f));
        root.m_171599_("TableR", CubeListBuilder.m_171558_().m_171514_(30, 8).m_171488_(-8.0f, 18.0f, -8.0f, 16.0f, 6.0f, 1.0f, new CubeDeformation(limbSwing)), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        root.m_171599_("Table_B", CubeListBuilder.m_171558_().m_171514_(30, 0).m_171488_(-8.0f, -3.0f, 0.0f, 16.0f, 6.0f, 1.0f, new CubeDeformation(limbSwing)), PartPose.m_171423_((float)8.0f, (float)21.0f, (float)0.0f, (float)0.0f, (float)1.5707964f, (float)0.0f));
        root.m_171599_("FoodT", CubeListBuilder.m_171558_().m_171514_(14, 0).m_171488_(1.0f, 1.0f, 1.0f, 4.0f, 1.0f, 4.0f, new CubeDeformation(limbSwing)), PartPose.m_171419_((float)-16.0f, (float)22.0f, (float)0.0f));
        root.m_171599_("FoodTraySide", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-16.0f, 21.0f, 5.0f, 5.0f, 3.0f, 1.0f, new CubeDeformation(limbSwing)), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        root.m_171599_("FoodTraySideB", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-15.0f, 21.0f, 0.0f, 5.0f, 3.0f, 1.0f, new CubeDeformation(limbSwing)), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        root.m_171599_("FoodTraySideC", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-3.0f, -1.0f, 0.0f, 5.0f, 3.0f, 1.0f, new CubeDeformation(limbSwing)), PartPose.m_171423_((float)-16.0f, (float)22.0f, (float)2.0f, (float)0.0f, (float)1.5707964f, (float)0.0f));
        root.m_171599_("FoodTraySideD", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-3.0f, -1.0f, 0.0f, 5.0f, 3.0f, 1.0f, new CubeDeformation(limbSwing)), PartPose.m_171423_((float)-11.0f, (float)22.0f, (float)3.0f, (float)0.0f, (float)1.5707964f, (float)0.0f));
        root.m_171599_("Milk", CubeListBuilder.m_171558_().m_171514_(14, 9).m_171488_(0.0f, 0.0f, 0.0f, 4.0f, 1.0f, 4.0f, new CubeDeformation(limbSwing)), PartPose.m_171419_((float)-15.0f, (float)21.0f, (float)1.0f));
        root.m_171599_("PetFood", CubeListBuilder.m_171558_().m_171514_(0, 9).m_171488_(0.0f, 0.0f, 0.0f, 4.0f, 1.0f, 4.0f, new CubeDeformation(limbSwing)), PartPose.m_171419_((float)-15.0f, (float)21.0f, (float)1.0f));
        root.m_171599_("Bottom", CubeListBuilder.m_171558_().m_171514_(16, 15).m_171488_(-10.0f, 0.0f, -7.0f, 16.0f, 1.0f, 14.0f, new CubeDeformation(limbSwing)), PartPose.m_171419_((float)2.0f, (float)23.0f, (float)0.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)64, (int)32);
    }

    public void setupAnim(T entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.hasMilk = ((MoCEntityKittyBed)((Object)entityIn)).getHasMilk();
        this.hasFood = ((MoCEntityKittyBed)((Object)entityIn)).getHasFood();
        this.pickedUp = ((MoCEntityKittyBed)((Object)entityIn)).getPickedUp();
        this.milklevel = ((MoCEntityKittyBed)((Object)entityIn)).milkLevel;
    }

    public void m_7695_(PoseStack matrixStackIn, VertexConsumer bufferIn, int packedLightIn, int packedOverlayIn, float red, float green, float blue, float alpha) {
        this.TableL.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        this.TableR.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        this.Table_B.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        this.Bottom.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        if (!this.pickedUp) {
            this.FoodT.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
            this.FoodTraySide.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
            this.FoodTraySideB.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
            this.FoodTraySideC.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
            this.FoodTraySideD.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
            if (this.hasMilk) {
                this.Milk.f_104201_ = 21.0f + this.milklevel;
                this.Milk.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
            }
            if (this.hasFood) {
                this.PetFood.f_104201_ = 21.0f + this.milklevel;
                this.PetFood.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
            }
        }
    }
}

