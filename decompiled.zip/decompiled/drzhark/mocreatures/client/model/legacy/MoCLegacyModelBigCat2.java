/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model.legacy;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.hunter.MoCEntityBigCat;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCLegacyModelBigCat2<T extends MoCEntityBigCat>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "legacy_bigcat2"), "main");
    public boolean sitting;
    public boolean tamed;
    private final ModelPart head;
    private final ModelPart snout;
    private final ModelPart ears;
    private final ModelPart collar;
    private final ModelPart body;
    private final ModelPart tail;
    private final ModelPart leg1;
    private final ModelPart leg2;
    private final ModelPart leg3;
    private final ModelPart leg4;

    public MoCLegacyModelBigCat2(ModelPart root) {
        this.ears = root.m_171324_("ears");
        this.head = root.m_171324_("head");
        this.snout = root.m_171324_("snout");
        this.collar = root.m_171324_("collar");
        this.body = root.m_171324_("body");
        this.tail = root.m_171324_("tail");
        this.leg1 = root.m_171324_("leg1");
        this.leg2 = root.m_171324_("leg2");
        this.leg3 = root.m_171324_("leg3");
        this.leg4 = root.m_171324_("leg4");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        root.m_171599_("ears", CubeListBuilder.m_171558_().m_171514_(16, 25).m_171481_(-4.0f, -7.0f, -3.0f, 8.0f, 4.0f, 1.0f), PartPose.m_171419_((float)0.0f, (float)4.0f, (float)-8.0f));
        root.m_171599_("head", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-4.0f, -4.0f, -6.0f, 8.0f, 8.0f, 6.0f), PartPose.m_171419_((float)0.0f, (float)4.0f, (float)-8.0f));
        root.m_171599_("snout", CubeListBuilder.m_171558_().m_171514_(14, 14).m_171481_(-2.0f, 0.0f, -9.0f, 4.0f, 4.0f, 6.0f), PartPose.m_171419_((float)0.0f, (float)4.0f, (float)-8.0f));
        root.m_171599_("collar", CubeListBuilder.m_171558_().m_171514_(24, 0).m_171481_(-2.5f, 4.0f, -3.0f, 5.0f, 4.0f, 1.0f), PartPose.m_171419_((float)0.0f, (float)4.0f, (float)-8.0f));
        root.m_171599_("body", CubeListBuilder.m_171558_().m_171514_(28, 0).m_171481_(-5.0f, -10.0f, -7.0f, 10.0f, 18.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)5.0f, (float)2.0f));
        root.m_171599_("tail", CubeListBuilder.m_171558_().m_171514_(26, 15).m_171481_(-5.0f, -5.0f, -2.0f, 3.0f, 3.0f, 14.0f), PartPose.m_171423_((float)3.5f, (float)9.3f, (float)9.0f, (float)-0.5235988f, (float)0.0f, (float)0.0f));
        root.m_171599_("leg1", CubeListBuilder.m_171558_().m_171514_(0, 16).m_171481_(-2.0f, 0.0f, -2.0f, 4.0f, 12.0f, 4.0f), PartPose.m_171419_((float)-3.0f, (float)12.0f, (float)7.0f));
        root.m_171599_("leg2", CubeListBuilder.m_171558_().m_171514_(0, 16).m_171481_(-2.0f, 0.0f, -2.0f, 4.0f, 12.0f, 4.0f), PartPose.m_171419_((float)3.0f, (float)12.0f, (float)7.0f));
        root.m_171599_("leg3", CubeListBuilder.m_171558_().m_171514_(0, 16).m_171481_(-2.0f, 0.0f, -2.0f, 4.0f, 12.0f, 4.0f), PartPose.m_171419_((float)-3.0f, (float)12.0f, (float)-5.0f));
        root.m_171599_("leg4", CubeListBuilder.m_171558_().m_171514_(0, 16).m_171481_(-2.0f, 0.0f, -2.0f, 4.0f, 12.0f, 4.0f), PartPose.m_171419_((float)3.0f, (float)12.0f, (float)-5.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)64, (int)32);
    }

    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float frontRightLegRot;
        this.head.f_104204_ = netHeadYaw * ((float)Math.PI / 180);
        this.head.f_104203_ = headPitch * ((float)Math.PI / 180);
        float swingFactor = 0.6662f;
        float frontLeftLegRot = Mth.m_14089_((float)(limbSwing * swingFactor)) * 1.4f * limbSwingAmount;
        float backLeftLegRot = frontRightLegRot = Mth.m_14089_((float)(limbSwing * swingFactor + (float)Math.PI)) * 1.4f * limbSwingAmount;
        float backRightLegRot = frontLeftLegRot;
        this.leg1.f_104203_ = frontLeftLegRot;
        this.leg2.f_104203_ = frontRightLegRot;
        this.leg3.f_104203_ = frontRightLegRot;
        this.leg4.f_104203_ = frontLeftLegRot;
        this.snout.f_104204_ = this.head.f_104204_;
        this.snout.f_104203_ = this.head.f_104203_;
        this.ears.f_104204_ = this.head.f_104204_;
        this.ears.f_104203_ = this.head.f_104203_;
        this.collar.f_104204_ = this.head.f_104204_;
        this.collar.f_104203_ = this.head.f_104203_;
        if (!this.sitting) {
            this.body.f_104200_ = 0.0f;
            this.body.f_104201_ = 5.0f;
            this.body.f_104202_ = 2.0f;
            this.body.f_104203_ = 1.570796f;
            this.leg1.f_104200_ = -3.0f;
            this.leg1.f_104202_ = 7.0f;
            this.leg2.f_104200_ = 3.0f;
            this.leg2.f_104202_ = 7.0f;
            this.leg3.f_104200_ = -3.0f;
            this.leg3.f_104202_ = -5.0f;
            this.leg4.f_104200_ = 3.0f;
            this.leg4.f_104202_ = -5.0f;
            this.leg4.f_104201_ = 12.0f;
            this.leg3.f_104201_ = 12.0f;
            this.leg2.f_104201_ = 12.0f;
            this.leg1.f_104201_ = 12.0f;
            this.tail.f_104200_ = 3.5f;
            this.tail.f_104201_ = 9.3f;
            this.tail.f_104202_ = 9.0f;
            this.tail.f_104203_ = -0.5235988f;
            this.tail.f_104204_ = Mth.m_14089_((float)(limbSwing * swingFactor)) * 0.7f * limbSwingAmount;
        } else {
            this.body.f_104200_ = 0.0f;
            this.body.f_104201_ = 12.0f;
            this.body.f_104202_ = 1.0f;
            this.body.f_104203_ = 0.8726646f;
            this.leg1.f_104200_ = -5.0f;
            this.leg1.f_104202_ = 0.0f;
            this.leg2.f_104200_ = 5.0f;
            this.leg2.f_104202_ = 0.0f;
            this.leg3.f_104200_ = -2.0f;
            this.leg3.f_104202_ = -8.0f;
            this.leg4.f_104200_ = 2.0f;
            this.leg4.f_104202_ = -8.0f;
            this.leg4.f_104201_ = 12.0f;
            this.leg3.f_104201_ = 12.0f;
            this.leg2.f_104201_ = 12.0f;
            this.leg1.f_104201_ = 12.0f;
            this.tail.f_104200_ = 3.5f;
            this.tail.f_104201_ = 22.0f;
            this.tail.f_104202_ = 8.0f;
            this.tail.f_104203_ = -0.1745329f;
            this.tail.f_104204_ = 0.0f;
        }
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.snout.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.tail.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.ears.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.head.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.body.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg3.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg4.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        if (this.tamed) {
            this.collar.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        }
    }
}

