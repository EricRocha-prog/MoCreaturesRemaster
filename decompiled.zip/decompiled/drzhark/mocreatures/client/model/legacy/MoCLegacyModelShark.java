/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model.legacy;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.aquatic.MoCEntityShark;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCLegacyModelShark<T extends MoCEntityShark>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "legacy_shark"), "main");
    private final ModelPart Body;
    private final ModelPart UHead;
    private final ModelPart DHead;
    private final ModelPart RHead;
    private final ModelPart LHead;
    private final ModelPart PTail;
    private final ModelPart UpperFin;
    private final ModelPart UpperTailFin;
    private final ModelPart LowerTailFin;
    private final ModelPart LeftFin;
    private final ModelPart RightFin;

    public MoCLegacyModelShark(ModelPart root) {
        this.Body = root.m_171324_("Body");
        this.UHead = root.m_171324_("UHead");
        this.DHead = root.m_171324_("DHead");
        this.RHead = root.m_171324_("RHead");
        this.LHead = root.m_171324_("LHead");
        this.PTail = root.m_171324_("PTail");
        this.UpperFin = root.m_171324_("UpperFin");
        this.UpperTailFin = root.m_171324_("UpperTailFin");
        this.LowerTailFin = root.m_171324_("LowerTailFin");
        this.LeftFin = root.m_171324_("LeftFin");
        this.RightFin = root.m_171324_("RightFin");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        root.m_171599_("Body", CubeListBuilder.m_171558_().m_171514_(6, 6).m_171481_(0.0f, 0.0f, 0.0f, 6.0f, 8.0f, 18.0f), PartPose.m_171419_((float)-3.0f, (float)17.0f, (float)-9.0f));
        root.m_171599_("UHead", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(0.0f, 0.0f, 0.0f, 5.0f, 2.0f, 8.0f), PartPose.m_171423_((float)-2.5f, (float)21.0f, (float)-15.5f, (float)0.5235988f, (float)0.0f, (float)0.0f));
        root.m_171599_("DHead", CubeListBuilder.m_171558_().m_171514_(44, 0).m_171481_(0.0f, 0.0f, 0.0f, 5.0f, 2.0f, 5.0f), PartPose.m_171423_((float)-2.5f, (float)21.5f, (float)-12.5f, (float)-0.261799f, (float)0.0f, (float)0.0f));
        root.m_171599_("RHead", CubeListBuilder.m_171558_().m_171514_(0, 3).m_171481_(0.0f, 0.0f, 0.0f, 1.0f, 6.0f, 6.0f), PartPose.m_171423_((float)-2.45f, (float)21.3f, (float)-12.85f, (float)0.7853981f, (float)0.0f, (float)0.0f));
        root.m_171599_("LHead", CubeListBuilder.m_171558_().m_171514_(0, 3).m_171481_(0.0f, 0.0f, 0.0f, 1.0f, 6.0f, 6.0f), PartPose.m_171423_((float)1.45f, (float)21.3f, (float)-12.8f, (float)0.7853981f, (float)0.0f, (float)0.0f));
        root.m_171599_("PTail", CubeListBuilder.m_171558_().m_171514_(36, 8).m_171481_(0.0f, 0.0f, 0.0f, 4.0f, 6.0f, 10.0f), PartPose.m_171419_((float)-2.0f, (float)18.0f, (float)9.0f));
        root.m_171599_("UpperFin", CubeListBuilder.m_171558_().m_171514_(6, 12).m_171481_(0.0f, 0.0f, 0.0f, 1.0f, 4.0f, 8.0f), PartPose.m_171423_((float)-0.5f, (float)17.0f, (float)0.0f, (float)0.7853981f, (float)0.0f, (float)0.0f));
        root.m_171599_("UpperTailFin", CubeListBuilder.m_171558_().m_171514_(6, 12).m_171481_(0.0f, 0.0f, 0.0f, 1.0f, 4.0f, 8.0f), PartPose.m_171423_((float)-0.5f, (float)18.0f, (float)17.0f, (float)0.5235988f, (float)0.0f, (float)0.0f));
        root.m_171599_("LowerTailFin", CubeListBuilder.m_171558_().m_171514_(8, 14).m_171481_(0.0f, 0.0f, 0.0f, 1.0f, 4.0f, 6.0f), PartPose.m_171423_((float)-0.5f, (float)21.0f, (float)19.0f, (float)-0.7853981f, (float)0.0f, (float)0.0f));
        root.m_171599_("LeftFin", CubeListBuilder.m_171558_().m_171514_(18, 0).m_171481_(0.0f, 0.0f, 0.0f, 8.0f, 1.0f, 4.0f), PartPose.m_171423_((float)3.0f, (float)24.0f, (float)-4.0f, (float)0.0f, (float)-0.5235988f, (float)0.5235988f));
        root.m_171599_("RightFin", CubeListBuilder.m_171558_().m_171514_(18, 0).m_171481_(0.0f, 0.0f, 0.0f, 8.0f, 1.0f, 4.0f), PartPose.m_171423_((float)-9.0f, (float)27.5f, (float)0.0f, (float)0.0f, (float)0.5235988f, (float)-0.5235988f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)64, (int)32);
    }

    public void setupAnim(T entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float yawMotion;
        this.UpperTailFin.f_104204_ = yawMotion = Mth.m_14089_((float)(limbSwing * 0.6662f)) * limbSwingAmount;
        this.LowerTailFin.f_104204_ = yawMotion;
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.Body.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.PTail.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.UHead.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.DHead.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RHead.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LHead.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.UpperFin.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.UpperTailFin.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LowerTailFin.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LeftFin.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RightFin.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}

