/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model.legacy;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.hostile.MoCEntityScorpion;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCLegacyModelScorpion<T extends MoCEntityScorpion>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "legacy_scorpion"), "main");
    public boolean attacking;
    public boolean isSwinging;
    private final ModelPart head;
    private final ModelPart rearEnd;
    private final ModelPart leg1;
    private final ModelPart leg2;
    private final ModelPart leg3;
    private final ModelPart leg4;
    private final ModelPart leg5;
    private final ModelPart leg6;
    private final ModelPart leg7;
    private final ModelPart leg8;
    private final ModelPart tail1;
    private final ModelPart tail2;
    private final ModelPart tail3;
    private final ModelPart tail4;
    private final ModelPart tail5;
    private final ModelPart tail7;
    private final ModelPart rArm;
    private final ModelPart lArm;
    private final ModelPart rHand;
    private final ModelPart lHand;
    private final ModelPart rHandB;
    private final ModelPart lHandB;

    public MoCLegacyModelScorpion(ModelPart root) {
        this.head = root.m_171324_("Head");
        this.rearEnd = root.m_171324_("RearEnd");
        this.leg1 = root.m_171324_("Leg1");
        this.leg2 = root.m_171324_("Leg2");
        this.leg3 = root.m_171324_("Leg3");
        this.leg4 = root.m_171324_("Leg4");
        this.leg5 = root.m_171324_("Leg5");
        this.leg6 = root.m_171324_("Leg6");
        this.leg7 = root.m_171324_("Leg7");
        this.leg8 = root.m_171324_("Leg8");
        this.tail1 = root.m_171324_("Tail1");
        this.tail2 = root.m_171324_("Tail2");
        this.tail3 = root.m_171324_("Tail3");
        this.tail4 = root.m_171324_("Tail4");
        this.tail5 = root.m_171324_("Tail5");
        this.tail7 = root.m_171324_("Tail7");
        this.rArm = root.m_171324_("RArm");
        this.lArm = root.m_171324_("LArm");
        this.rHand = root.m_171324_("RHand");
        this.lHand = root.m_171324_("LHand");
        this.rHandB = root.m_171324_("RHandB");
        this.lHandB = root.m_171324_("LHandB");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        root.m_171599_("Head", CubeListBuilder.m_171558_().m_171514_(38, 19).m_171481_(-4.0f, -3.0f, -6.0f, 8.0f, 4.0f, 5.0f), PartPose.m_171419_((float)0.0f, (float)20.0f, (float)-5.0f));
        root.m_171599_("RearEnd", CubeListBuilder.m_171558_().m_171514_(0, 11).m_171481_(-5.0f, -3.0f, -3.0f, 10.0f, 4.0f, 17.0f), PartPose.m_171423_((float)0.0f, (float)20.0f, (float)-3.0f, (float)0.13963f, (float)0.0f, (float)0.0f));
        root.m_171599_("Leg8", CubeListBuilder.m_171558_().m_171555_(true).m_171514_(20, 6).m_171481_(-1.0f, -1.0f, 1.0f, 14.0f, 2.0f, 2.0f), PartPose.m_171423_((float)4.0f, (float)20.0f, (float)-2.0f, (float)0.0f, (float)0.57596f, (float)0.19199f));
        root.m_171599_("Leg6", CubeListBuilder.m_171558_().m_171555_(true).m_171514_(20, 6).m_171481_(-1.0f, -1.0f, 1.0f, 14.0f, 2.0f, 2.0f), PartPose.m_171423_((float)4.0f, (float)20.0f, (float)1.0f, (float)0.0f, (float)0.27925f, (float)0.19199f));
        root.m_171599_("Leg4", CubeListBuilder.m_171558_().m_171555_(true).m_171514_(20, 6).m_171481_(-1.0f, -1.0f, 1.0f, 14.0f, 2.0f, 2.0f), PartPose.m_171423_((float)4.0f, (float)20.0f, (float)3.0f, (float)0.0f, (float)-0.27925f, (float)0.19199f));
        root.m_171599_("Leg2", CubeListBuilder.m_171558_().m_171555_(true).m_171514_(20, 6).m_171481_(-1.0f, -1.0f, 1.0f, 14.0f, 2.0f, 2.0f), PartPose.m_171423_((float)4.0f, (float)20.0f, (float)6.0f, (float)0.0f, (float)-0.57596f, (float)0.19199f));
        root.m_171599_("Leg7", CubeListBuilder.m_171558_().m_171514_(20, 6).m_171481_(-13.0f, -1.0f, 1.0f, 14.0f, 2.0f, 2.0f), PartPose.m_171423_((float)-4.0f, (float)20.0f, (float)-2.0f, (float)0.0f, (float)-0.57596f, (float)-0.19199f));
        root.m_171599_("Leg5", CubeListBuilder.m_171558_().m_171514_(20, 6).m_171481_(-13.0f, -1.0f, 1.0f, 14.0f, 2.0f, 2.0f), PartPose.m_171423_((float)-4.0f, (float)20.0f, (float)1.0f, (float)0.0f, (float)-0.27925f, (float)-0.19199f));
        root.m_171599_("Leg3", CubeListBuilder.m_171558_().m_171514_(20, 6).m_171481_(-13.0f, -1.0f, 1.0f, 14.0f, 2.0f, 2.0f), PartPose.m_171423_((float)-4.0f, (float)20.0f, (float)3.0f, (float)0.0f, (float)0.27925f, (float)-0.19199f));
        root.m_171599_("Leg1", CubeListBuilder.m_171558_().m_171514_(20, 6).m_171481_(-13.0f, -1.0f, 1.0f, 14.0f, 2.0f, 2.0f), PartPose.m_171423_((float)-4.0f, (float)20.0f, (float)6.0f, (float)0.0f, (float)0.57596f, (float)-0.19199f));
        root.m_171599_("Tail1", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-3.0f, -8.0f, 8.0f, 6.0f, 4.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)20.0f, (float)0.0f));
        root.m_171599_("Tail2", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-3.0f, -12.0f, 10.0f, 6.0f, 4.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)20.0f, (float)0.0f));
        root.m_171599_("Tail3", CubeListBuilder.m_171558_().m_171514_(0, 8).m_171481_(-2.0f, -14.0f, 8.0f, 4.0f, 4.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)20.0f, (float)0.0f));
        root.m_171599_("Tail4", CubeListBuilder.m_171558_().m_171514_(0, 8).m_171481_(-2.0f, -17.0f, 6.0f, 4.0f, 4.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)20.0f, (float)0.0f));
        root.m_171599_("Tail5", CubeListBuilder.m_171558_().m_171514_(0, 8).m_171481_(-2.0f, -19.0f, 3.0f, 4.0f, 4.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)20.0f, (float)0.0f));
        root.m_171599_("Tail7", CubeListBuilder.m_171558_().m_171514_(0, 20).m_171481_(-1.0f, -18.0f, 0.0f, 2.0f, 4.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)20.0f, (float)0.0f));
        root.m_171599_("RArm", CubeListBuilder.m_171558_().m_171514_(32, 0).m_171481_(-11.0f, -1.0f, -1.0f, 11.0f, 2.0f, 4.0f), PartPose.m_171423_((float)-4.0f, (float)20.0f, (float)-9.0f, (float)0.0f, (float)-0.27925f, (float)0.0f));
        root.m_171599_("LArm", CubeListBuilder.m_171558_().m_171555_(true).m_171514_(32, 0).m_171481_(-1.0f, -1.0f, -1.0f, 12.0f, 2.0f, 4.0f), PartPose.m_171423_((float)4.0f, (float)20.0f, (float)-9.0f, (float)0.0f, (float)0.27925f, (float)0.0f));
        root.m_171599_("RHand", CubeListBuilder.m_171558_().m_171514_(44, 9).m_171481_(-11.0f, -1.0f, -9.0f, 2.0f, 2.0f, 8.0f), PartPose.m_171423_((float)-4.0f, (float)20.0f, (float)-9.0f, (float)0.0f, (float)-0.27925f, (float)0.0f));
        root.m_171599_("LHand", CubeListBuilder.m_171558_().m_171514_(44, 9).m_171481_(9.0f, -1.0f, -9.0f, 2.0f, 2.0f, 8.0f), PartPose.m_171423_((float)4.0f, (float)20.0f, (float)-9.0f, (float)0.0f, (float)0.27925f, (float)0.0f));
        root.m_171599_("RHandB", CubeListBuilder.m_171558_().m_171514_(44, 9).m_171481_(-8.0f, -1.0f, -9.0f, 2.0f, 2.0f, 8.0f), PartPose.m_171423_((float)-4.0f, (float)20.0f, (float)-9.0f, (float)0.0f, (float)-0.27925f, (float)0.0f));
        root.m_171599_("LHandB", CubeListBuilder.m_171558_().m_171514_(44, 9).m_171481_(6.0f, -1.0f, -9.0f, 2.0f, 2.0f, 8.0f), PartPose.m_171423_((float)4.0f, (float)20.0f, (float)-9.0f, (float)0.0f, (float)0.27925f, (float)0.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)64, (int)32);
    }

    public void setupAnim(T entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float baseZ = 0.7853982f;
        float z74 = 0.58119464f;
        this.leg1.f_104205_ = -0.7853982f;
        this.leg2.f_104205_ = 0.7853982f;
        this.leg3.f_104205_ = -0.58119464f;
        this.leg4.f_104205_ = 0.58119464f;
        this.leg5.f_104205_ = -0.58119464f;
        this.leg6.f_104205_ = 0.58119464f;
        this.leg7.f_104205_ = -0.7853982f;
        this.leg8.f_104205_ = 0.7853982f;
        float baseY = 0.3926991f;
        float neg = -0.0f;
        this.leg1.f_104204_ = 0.7853982f;
        this.leg2.f_104204_ = -0.7853982f;
        this.leg3.f_104204_ = 0.3926991f;
        this.leg4.f_104204_ = -0.3926991f;
        this.leg5.f_104204_ = -0.3926991f;
        this.leg6.f_104204_ = 0.3926991f;
        this.leg7.f_104204_ = -0.7853982f;
        this.leg8.f_104204_ = 0.7853982f;
        float swingTimes2 = limbSwing * 0.6662f * 2.0f;
        float f9 = -Mth.m_14089_((float)(swingTimes2 + 0.0f)) * 0.4f * limbSwingAmount;
        float f10 = -Mth.m_14089_((float)(swingTimes2 + (float)Math.PI)) * 0.4f * limbSwingAmount;
        float f11 = -Mth.m_14089_((float)(swingTimes2 + 1.5707964f)) * 0.4f * limbSwingAmount;
        float f12 = -Mth.m_14089_((float)(swingTimes2 + 4.712389f)) * 0.4f * limbSwingAmount;
        float f13 = Math.abs(Mth.m_14031_((float)(limbSwing * 0.6662f + 0.0f)) * 0.4f) * limbSwingAmount;
        float f14 = Math.abs(Mth.m_14031_((float)(limbSwing * 0.6662f + (float)Math.PI)) * 0.4f) * limbSwingAmount;
        float f15 = Math.abs(Mth.m_14031_((float)(limbSwing * 0.6662f + 1.5707964f)) * 0.4f) * limbSwingAmount;
        float f16 = Math.abs(Mth.m_14031_((float)(limbSwing * 0.6662f + 4.712389f)) * 0.4f) * limbSwingAmount;
        this.leg1.f_104204_ += f9;
        this.leg2.f_104204_ -= f9;
        this.leg3.f_104204_ += f10;
        this.leg4.f_104204_ -= f10;
        this.leg5.f_104204_ += f11;
        this.leg6.f_104204_ -= f11;
        this.leg7.f_104204_ += f12;
        this.leg8.f_104204_ -= f12;
        this.leg1.f_104205_ += f13;
        this.leg2.f_104205_ -= f13;
        this.leg3.f_104205_ += f14;
        this.leg4.f_104205_ -= f14;
        this.leg5.f_104205_ += f15;
        this.leg6.f_104205_ -= f15;
        this.leg7.f_104205_ += f16;
        this.leg8.f_104205_ -= f16;
        this.head.f_104204_ = netHeadYaw * ((float)Math.PI / 180);
        this.head.f_104203_ = headPitch * ((float)Math.PI / 180);
        this.rArm.f_104204_ = -0.27925f;
        this.lArm.f_104204_ = 0.27925f;
        this.rHand.f_104204_ = -0.27925f;
        this.lHand.f_104204_ = 0.27925f;
        this.rHandB.f_104204_ = -0.27925f;
        this.lHandB.f_104204_ = 0.27925f;
        if (this.attacking) {
            this.rearEnd.f_104203_ = 0.19199f;
            this.tail1.f_104201_ = 20.0f;
            this.tail1.f_104202_ = -2.0f;
            this.tail2.f_104201_ = 20.0f;
            this.tail2.f_104202_ = -6.0f;
            this.tail3.f_104201_ = 20.0f;
            this.tail3.f_104202_ = -8.0f;
            this.tail4.f_104201_ = 21.0f;
            this.tail4.f_104202_ = -10.0f;
            this.tail5.f_104201_ = 24.0f;
            this.tail5.f_104202_ = -11.0f;
            this.tail7.f_104201_ = 25.0f;
            this.tail7.f_104202_ = -12.0f;
        } else {
            this.rearEnd.f_104203_ = 0.13963f;
            this.tail1.f_104201_ = 20.0f;
            this.tail1.f_104202_ = 0.0f;
            this.tail2.f_104201_ = 20.0f;
            this.tail2.f_104202_ = 0.0f;
            this.tail3.f_104201_ = 20.0f;
            this.tail3.f_104202_ = 0.0f;
            this.tail4.f_104201_ = 20.0f;
            this.tail4.f_104202_ = 0.0f;
            this.tail5.f_104201_ = 20.0f;
            this.tail5.f_104202_ = 0.0f;
            this.tail7.f_104201_ = 20.0f;
            this.tail7.f_104202_ = 0.0f;
        }
        if (this.isSwinging) {
            this.rArm.f_104205_ = 0.0f;
            this.lArm.f_104205_ = 0.0f;
            this.rHand.f_104205_ = 0.0f;
            this.lHand.f_104205_ = 0.0f;
            this.rHandB.f_104205_ = 0.0f;
            this.lHandB.f_104205_ = 0.0f;
            float prog = this.f_102608_;
            float f18 = prog;
            if (f18 >= 0.6f) {
                f18 = 0.6f - (prog - 0.6f);
            }
            this.rArm.f_104204_ = -0.27925f - f18;
            this.rHand.f_104204_ = -0.27925f - f18;
            this.rHandB.f_104204_ = -0.27925f - f18;
            this.lArm.f_104204_ = 0.27925f + f18;
            this.lHand.f_104204_ = 0.27925f + f18;
            this.lHandB.f_104204_ = 0.27925f + f18;
        } else {
            float mov = Mth.m_14089_((float)(limbSwing * 0.4f)) * 0.3f * limbSwingAmount;
            this.tail1.f_104203_ = mov * 0.8f;
            this.tail2.f_104203_ = mov;
            this.tail3.f_104203_ = mov;
            this.tail4.f_104203_ = mov;
            this.tail5.f_104203_ = mov;
            this.tail7.f_104203_ = mov;
            this.rArm.f_104205_ = mov;
            this.rHand.f_104205_ = mov;
            this.rHandB.f_104205_ = mov;
            this.lArm.f_104205_ = -mov;
            this.lHand.f_104205_ = -mov;
            this.lHandB.f_104205_ = -mov;
        }
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.head.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.rearEnd.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg8.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg6.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg4.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg7.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg5.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg3.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.tail1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.tail2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.tail3.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.tail4.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.tail7.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.rArm.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.lArm.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.rHand.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.lHand.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.rHandB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.lHandB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.tail5.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}

