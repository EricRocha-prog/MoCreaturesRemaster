/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  com.mojang.math.Axis
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import drzhark.mocreatures.entity.aquatic.MoCEntitySmallFish;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelSmallFish<T extends MoCEntitySmallFish>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "small_fish"), "main");
    private final ModelPart bodyFlat;
    private final ModelPart bodyRomboid;
    private final ModelPart midBodyFin;
    private final ModelPart upperFinA;
    private final ModelPart upperFinB;
    private final ModelPart upperFinC;
    private final ModelPart lowerFinA;
    private final ModelPart lowerFinB;
    private final ModelPart lowerFinC;
    private final ModelPart tail;
    private MoCEntitySmallFish smallFish;

    public MoCModelSmallFish(ModelPart root) {
        this.bodyFlat = root.m_171324_("bodyFlat");
        this.bodyRomboid = root.m_171324_("bodyRomboid");
        this.midBodyFin = root.m_171324_("midBodyFin");
        this.upperFinA = root.m_171324_("upperFinA");
        this.upperFinB = root.m_171324_("upperFinB");
        this.upperFinC = root.m_171324_("upperFinC");
        this.lowerFinA = root.m_171324_("lowerFinA");
        this.lowerFinB = root.m_171324_("lowerFinB");
        this.lowerFinC = root.m_171324_("lowerFinC");
        this.tail = root.m_171324_("tail");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        PartDefinition bodyFlat = root.m_171599_("bodyFlat", CubeListBuilder.m_171558_().m_171514_(0, 2).m_171481_(0.0f, -1.5f, -1.0f, 5.0f, 3.0f, 2.0f), PartPose.m_171419_((float)-3.0f, (float)15.0f, (float)0.0f));
        PartDefinition bodyRomboid = root.m_171599_("bodyRomboid", CubeListBuilder.m_171558_().m_171514_(0, 7).m_171481_(0.0f, 0.0f, -0.5f, 4.0f, 4.0f, 1.0f), PartPose.m_171423_((float)-4.0f, (float)15.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-0.7853982f));
        PartDefinition midBodyFin = root.m_171599_("midBodyFin", CubeListBuilder.m_171558_().m_171514_(0, 12).m_171481_(0.0f, -0.5f, 0.0f, 4.0f, 2.0f, 4.0f), PartPose.m_171423_((float)-3.0f, (float)15.0f, (float)0.0f, (float)0.0f, (float)0.7853982f, (float)0.0f));
        PartDefinition upperFinA = root.m_171599_("upperFinA", CubeListBuilder.m_171558_().m_171514_(10, 0).m_171481_(-0.5f, -1.3f, -0.5f, 2.0f, 1.0f, 1.0f), PartPose.m_171419_((float)-0.65f, (float)13.5f, (float)0.0f));
        PartDefinition upperFinB = root.m_171599_("upperFinB", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-2.5f, -1.0f, -0.5f, 4.0f, 1.0f, 1.0f), PartPose.m_171419_((float)0.0f, (float)13.5f, (float)0.0f));
        PartDefinition upperFinC = root.m_171599_("upperFinC", CubeListBuilder.m_171558_().m_171514_(0, 18).m_171481_(-5.0f, -2.0f, 0.0f, 8.0f, 3.0f, 0.0f), PartPose.m_171419_((float)0.0f, (float)13.5f, (float)0.0f));
        PartDefinition lowerFinA = root.m_171599_("lowerFinA", CubeListBuilder.m_171558_().m_171514_(16, 0).m_171481_(-0.5f, -0.3f, -0.5f, 2.0f, 1.0f, 1.0f), PartPose.m_171419_((float)-0.65f, (float)17.2f, (float)0.0f));
        PartDefinition lowerFinB = root.m_171599_("lowerFinB", CubeListBuilder.m_171558_().m_171514_(0, 21).m_171481_(0.0f, 0.0f, -3.0f, 5.0f, 0.0f, 6.0f), PartPose.m_171419_((float)-3.0f, (float)16.0f, (float)0.0f));
        PartDefinition lowerFinC = root.m_171599_("lowerFinC", CubeListBuilder.m_171558_().m_171514_(16, 18).m_171481_(-5.0f, 0.0f, 0.0f, 8.0f, 3.0f, 0.0f), PartPose.m_171419_((float)0.0f, (float)15.5f, (float)0.0f));
        PartDefinition tail = root.m_171599_("tail", CubeListBuilder.m_171558_().m_171514_(10, 7).m_171481_(0.0f, 0.0f, -0.5f, 3.0f, 3.0f, 1.0f), PartPose.m_171423_((float)1.3f, (float)15.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-0.7853982f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)32, (int)32);
    }

    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float tailMov;
        this.smallFish = entity;
        this.tail.f_104204_ = tailMov = Mth.m_14089_((float)(limbSwing * 0.8f)) * limbSwingAmount * 0.6f;
        float finMov = Mth.m_14089_((float)(ageInTicks * 0.4f)) * 0.2f;
        this.midBodyFin.f_104204_ = 0.7853982f + finMov;
        this.lowerFinB.f_104205_ = finMov;
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        if (this.smallFish == null) {
            this.smallFish = null;
        }
        float yOffset = this.smallFish != null ? this.smallFish.getAdjustedYOffset() : 0.0f;
        float xOffset = this.smallFish != null ? this.smallFish.getAdjustedXOffset() : 0.0f;
        float zOffset = this.smallFish != null ? this.smallFish.getAdjustedZOffset() : 0.0f;
        poseStack.m_85836_();
        poseStack.m_252880_(xOffset, yOffset, zOffset);
        poseStack.m_252781_(Axis.f_252436_.m_252977_(90.0f));
        this.bodyFlat.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.bodyRomboid.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.midBodyFin.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.upperFinA.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.upperFinB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.upperFinC.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.lowerFinA.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.lowerFinB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.lowerFinC.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.tail.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        poseStack.m_85849_();
    }
}

