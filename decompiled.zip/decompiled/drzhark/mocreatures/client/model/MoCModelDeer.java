/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.passive.MoCEntityDeer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelDeer<T extends MoCEntityDeer>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "deer"), "main");
    private final ModelPart Body;
    private final ModelPart Neck;
    private final ModelPart Head;
    private final ModelPart Leg1;
    private final ModelPart Leg2;
    private final ModelPart Leg3;
    private final ModelPart Leg4;
    private final ModelPart Tail;
    private final ModelPart LEar;
    private final ModelPart REar;
    private final ModelPart LeftAntler;
    private final ModelPart RightAntler;

    public MoCModelDeer(ModelPart root) {
        this.Body = root.m_171324_("Body");
        this.Neck = root.m_171324_("Neck");
        this.Head = root.m_171324_("Head");
        this.Leg1 = root.m_171324_("Leg1");
        this.Leg2 = root.m_171324_("Leg2");
        this.Leg3 = root.m_171324_("Leg3");
        this.Leg4 = root.m_171324_("Leg4");
        this.Tail = root.m_171324_("Tail");
        this.LEar = root.m_171324_("LEar");
        this.REar = root.m_171324_("REar");
        this.LeftAntler = root.m_171324_("LeftAntler");
        this.RightAntler = root.m_171324_("RightAntler");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        root.m_171599_("Head", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-1.5f, -6.0f, -9.5f, 3.0f, 3.0f, 6.0f), PartPose.m_171419_((float)1.0f, (float)11.5f, (float)-4.5f));
        root.m_171599_("Neck", CubeListBuilder.m_171558_().m_171514_(0, 9).m_171481_(-2.0f, -2.0f, -6.0f, 4.0f, 4.0f, 6.0f), PartPose.m_171423_((float)1.0f, (float)11.5f, (float)-4.5f, (float)-0.7853981f, (float)0.0f, (float)0.0f));
        root.m_171599_("LEar", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-4.0f, -7.5f, -5.0f, 2.0f, 3.0f, 1.0f), PartPose.m_171423_((float)1.0f, (float)11.5f, (float)-4.5f, (float)0.0f, (float)0.0f, (float)0.7853981f));
        root.m_171599_("REar", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(2.0f, -7.5f, -5.0f, 2.0f, 3.0f, 1.0f), PartPose.m_171423_((float)1.0f, (float)11.5f, (float)-4.5f, (float)0.0f, (float)0.0f, (float)-0.7853981f));
        root.m_171599_("LeftAntler", CubeListBuilder.m_171558_().m_171514_(54, 0).m_171481_(0.0f, -14.0f, -7.0f, 1.0f, 8.0f, 4.0f), PartPose.m_171423_((float)1.0f, (float)11.5f, (float)-4.5f, (float)0.0f, (float)0.0f, (float)0.2094395f));
        root.m_171599_("RightAntler", CubeListBuilder.m_171558_().m_171514_(54, 0).m_171481_(0.0f, -14.0f, -7.0f, 1.0f, 8.0f, 4.0f), PartPose.m_171423_((float)1.0f, (float)11.5f, (float)-4.5f, (float)0.0f, (float)0.0f, (float)-0.2094395f));
        root.m_171599_("Body", CubeListBuilder.m_171558_().m_171514_(24, 12).m_171481_(-2.0f, -3.0f, -6.0f, 6.0f, 6.0f, 14.0f), PartPose.m_171419_((float)0.0f, (float)13.0f, (float)0.0f));
        root.m_171599_("Leg1", CubeListBuilder.m_171558_().m_171514_(9, 20).m_171481_(-1.0f, 0.0f, -1.0f, 2.0f, 8.0f, 2.0f), PartPose.m_171419_((float)3.0f, (float)16.0f, (float)-4.0f));
        root.m_171599_("Leg2", CubeListBuilder.m_171558_().m_171514_(0, 20).m_171481_(-1.0f, 0.0f, -1.0f, 2.0f, 8.0f, 2.0f), PartPose.m_171419_((float)-1.0f, (float)16.0f, (float)-4.0f));
        root.m_171599_("Leg3", CubeListBuilder.m_171558_().m_171514_(9, 20).m_171481_(-1.0f, 0.0f, -1.0f, 2.0f, 8.0f, 2.0f), PartPose.m_171419_((float)3.0f, (float)16.0f, (float)6.0f));
        root.m_171599_("Leg4", CubeListBuilder.m_171558_().m_171514_(0, 20).m_171481_(-1.0f, 0.0f, -1.0f, 2.0f, 8.0f, 2.0f), PartPose.m_171419_((float)-1.0f, (float)16.0f, (float)6.0f));
        root.m_171599_("Tail", CubeListBuilder.m_171558_().m_171514_(50, 20).m_171481_(-1.5f, -1.0f, 0.0f, 3.0f, 2.0f, 4.0f), PartPose.m_171423_((float)1.0f, (float)11.0f, (float)7.0f, (float)0.7854f, (float)0.0f, (float)0.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)64, (int)32);
    }

    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.Leg1.f_104203_ = Mth.m_14089_((float)(limbSwing * 0.6662f)) * 1.4f * limbSwingAmount;
        this.Leg2.f_104203_ = Mth.m_14089_((float)(limbSwing * 0.6662f + (float)Math.PI)) * 1.4f * limbSwingAmount;
        this.Leg3.f_104203_ = Mth.m_14089_((float)(limbSwing * 0.6662f + (float)Math.PI)) * 1.4f * limbSwingAmount;
        this.Leg4.f_104203_ = Mth.m_14089_((float)(limbSwing * 0.6662f)) * 1.4f * limbSwingAmount;
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.Body.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Neck.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Head.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Leg1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Leg2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Leg3.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Leg4.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Tail.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LEar.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.REar.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LeftAntler.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RightAntler.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}

