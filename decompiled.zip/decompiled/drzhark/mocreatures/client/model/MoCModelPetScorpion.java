/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.geom.ModelPart
 */
package drzhark.mocreatures.client.model;

import drzhark.mocreatures.client.model.MoCModelAbstractScorpion;
import drzhark.mocreatures.entity.hunter.MoCEntityPetScorpion;
import net.minecraft.client.model.geom.ModelPart;

public class MoCModelPetScorpion<T extends MoCEntityPetScorpion>
extends MoCModelAbstractScorpion<T> {
    public MoCModelPetScorpion(ModelPart root) {
        super(root);
    }

    public void prepareMobModel(T entity, float limbSwing, float limbSwingAmount, float partialTick) {
        this.poisoning = ((MoCEntityPetScorpion)entity).swingingTail();
        this.isTalking = ((MoCEntityPetScorpion)entity).mouthCounter != 0;
        this.babies = ((MoCEntityPetScorpion)entity).getHasBabies();
        this.attacking = ((MoCEntityPetScorpion)entity).armCounter;
        this.sitting = ((MoCEntityPetScorpion)entity).getIsSitting();
    }
}

