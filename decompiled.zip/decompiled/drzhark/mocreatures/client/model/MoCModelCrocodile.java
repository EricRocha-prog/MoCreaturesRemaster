/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.hunter.MoCEntityCrocodile;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelCrocodile<T extends MoCEntityCrocodile>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "crocodile"), "main");
    private final ModelPart LJaw;
    private final ModelPart TailA;
    private final ModelPart TailB;
    private final ModelPart TailC;
    private final ModelPart UJaw;
    private final ModelPart Head;
    private final ModelPart Body;
    private final ModelPart Leg1;
    private final ModelPart Leg3;
    private final ModelPart Leg2;
    private final ModelPart Leg4;
    private final ModelPart TailD;
    private final ModelPart Leg1A;
    private final ModelPart Leg2A;
    private final ModelPart Leg3A;
    private final ModelPart Leg4A;
    private final ModelPart UJaw2;
    private final ModelPart LJaw2;
    private final ModelPart TeethA;
    private final ModelPart TeethB;
    private final ModelPart TeethC;
    private final ModelPart TeethD;
    private final ModelPart TeethF;
    private final ModelPart Spike0;
    private final ModelPart Spike1;
    private final ModelPart Spike2;
    private final ModelPart Spike3;
    private final ModelPart Spike4;
    private final ModelPart Spike5;
    private final ModelPart Spike6;
    private final ModelPart Spike7;
    private final ModelPart Spike8;
    private final ModelPart Spike9;
    private final ModelPart Spike10;
    private final ModelPart Spike11;
    private final ModelPart SpikeBack0;
    private final ModelPart SpikeBack1;
    private final ModelPart SpikeBack2;
    private final ModelPart SpikeBack3;
    private final ModelPart SpikeBack4;
    private final ModelPart SpikeBack5;
    private final ModelPart SpikeEye;
    private final ModelPart SpikeEye1;
    private final ModelPart TeethA1;
    private final ModelPart TeethB1;
    private final ModelPart TeethC1;
    private final ModelPart TeethD1;
    public float biteProgress;
    public boolean swimming;
    public boolean resting;

    public MoCModelCrocodile(ModelPart root) {
        this.LJaw = root.m_171324_("LJaw");
        this.TailA = root.m_171324_("TailA");
        this.TailB = root.m_171324_("TailB");
        this.TailC = root.m_171324_("TailC");
        this.UJaw = root.m_171324_("UJaw");
        this.Head = root.m_171324_("Head");
        this.Body = root.m_171324_("Body");
        this.Leg1 = root.m_171324_("Leg1");
        this.Leg3 = root.m_171324_("Leg3");
        this.Leg2 = root.m_171324_("Leg2");
        this.Leg4 = root.m_171324_("Leg4");
        this.TailD = root.m_171324_("TailD");
        this.Leg1A = root.m_171324_("Leg1A");
        this.Leg2A = root.m_171324_("Leg2A");
        this.Leg3A = root.m_171324_("Leg3A");
        this.Leg4A = root.m_171324_("Leg4A");
        this.UJaw2 = root.m_171324_("UJaw2");
        this.LJaw2 = root.m_171324_("LJaw2");
        this.TeethA = root.m_171324_("TeethA");
        this.TeethB = root.m_171324_("TeethB");
        this.TeethC = root.m_171324_("TeethC");
        this.TeethD = root.m_171324_("TeethD");
        this.TeethF = root.m_171324_("TeethF");
        this.Spike0 = root.m_171324_("Spike0");
        this.Spike1 = root.m_171324_("Spike1");
        this.Spike2 = root.m_171324_("Spike2");
        this.Spike3 = root.m_171324_("Spike3");
        this.Spike4 = root.m_171324_("Spike4");
        this.Spike5 = root.m_171324_("Spike5");
        this.Spike6 = root.m_171324_("Spike6");
        this.Spike7 = root.m_171324_("Spike7");
        this.Spike8 = root.m_171324_("Spike8");
        this.Spike9 = root.m_171324_("Spike9");
        this.Spike10 = root.m_171324_("Spike10");
        this.Spike11 = root.m_171324_("Spike11");
        this.SpikeBack0 = root.m_171324_("SpikeBack0");
        this.SpikeBack1 = root.m_171324_("SpikeBack1");
        this.SpikeBack2 = root.m_171324_("SpikeBack2");
        this.SpikeBack3 = root.m_171324_("SpikeBack3");
        this.SpikeBack4 = root.m_171324_("SpikeBack4");
        this.SpikeBack5 = root.m_171324_("SpikeBack5");
        this.SpikeEye = root.m_171324_("SpikeEye");
        this.SpikeEye1 = root.m_171324_("SpikeEye1");
        this.TeethA1 = root.m_171324_("TeethA1");
        this.TeethB1 = root.m_171324_("TeethB1");
        this.TeethC1 = root.m_171324_("TeethC1");
        this.TeethD1 = root.m_171324_("TeethD1");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        root.m_171599_("LJaw", CubeListBuilder.m_171558_().m_171514_(42, 0).m_171481_(-2.5f, 1.0f, -12.0f, 5.0f, 2.0f, 6.0f), PartPose.m_171419_((float)0.0f, (float)18.0f, (float)-8.0f));
        root.m_171599_("TailA", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-4.0f, -0.5f, 0.0f, 8.0f, 4.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)17.0f, (float)12.0f));
        root.m_171599_("TailB", CubeListBuilder.m_171558_().m_171514_(2, 0).m_171481_(-3.0f, 0.0f, 8.0f, 6.0f, 3.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)17.0f, (float)12.0f));
        root.m_171599_("TailC", CubeListBuilder.m_171558_().m_171514_(6, 2).m_171481_(-2.0f, 0.5f, 16.0f, 4.0f, 2.0f, 6.0f), PartPose.m_171419_((float)0.0f, (float)17.0f, (float)12.0f));
        root.m_171599_("TailD", CubeListBuilder.m_171558_().m_171514_(7, 2).m_171481_(-1.5f, 1.0f, 22.0f, 3.0f, 1.0f, 6.0f), PartPose.m_171419_((float)0.0f, (float)17.0f, (float)12.0f));
        root.m_171599_("UJaw", CubeListBuilder.m_171558_().m_171514_(44, 8).m_171481_(-2.0f, -1.0f, -12.0f, 4.0f, 2.0f, 6.0f), PartPose.m_171419_((float)0.0f, (float)18.0f, (float)-8.0f));
        root.m_171599_("Head", CubeListBuilder.m_171558_().m_171514_(0, 16).m_171481_(-3.0f, -2.0f, -6.0f, 6.0f, 5.0f, 6.0f), PartPose.m_171419_((float)0.0f, (float)18.0f, (float)-8.0f));
        root.m_171599_("Body", CubeListBuilder.m_171558_().m_171514_(4, 7).m_171481_(0.0f, 0.0f, 0.0f, 10.0f, 5.0f, 20.0f), PartPose.m_171419_((float)-5.0f, (float)16.0f, (float)-8.0f));
        root.m_171599_("Leg1", CubeListBuilder.m_171558_().m_171514_(49, 21).m_171481_(1.0f, 2.0f, -3.0f, 3.0f, 2.0f, 4.0f), PartPose.m_171419_((float)5.0f, (float)19.0f, (float)-3.0f));
        root.m_171599_("Leg3", CubeListBuilder.m_171558_().m_171514_(48, 20).m_171481_(1.0f, 2.0f, -3.0f, 3.0f, 2.0f, 5.0f), PartPose.m_171419_((float)5.0f, (float)19.0f, (float)9.0f));
        root.m_171599_("Leg2", CubeListBuilder.m_171558_().m_171514_(49, 21).m_171481_(-4.0f, 2.0f, -3.0f, 3.0f, 2.0f, 4.0f), PartPose.m_171419_((float)-5.0f, (float)19.0f, (float)-3.0f));
        root.m_171599_("Leg4", CubeListBuilder.m_171558_().m_171514_(48, 20).m_171481_(-4.0f, 2.0f, -3.0f, 3.0f, 2.0f, 5.0f), PartPose.m_171419_((float)-5.0f, (float)19.0f, (float)9.0f));
        root.m_171599_("Leg1A", CubeListBuilder.m_171558_().m_171514_(7, 9).m_171481_(0.0f, -1.0f, -2.0f, 3.0f, 3.0f, 3.0f), PartPose.m_171419_((float)5.0f, (float)19.0f, (float)-3.0f));
        root.m_171599_("Leg2A", CubeListBuilder.m_171558_().m_171514_(7, 9).m_171481_(-3.0f, -1.0f, -2.0f, 3.0f, 3.0f, 3.0f), PartPose.m_171419_((float)-5.0f, (float)19.0f, (float)-3.0f));
        root.m_171599_("Leg3A", CubeListBuilder.m_171558_().m_171514_(6, 8).m_171481_(0.0f, -1.0f, -2.0f, 3.0f, 3.0f, 4.0f), PartPose.m_171419_((float)5.0f, (float)19.0f, (float)9.0f));
        root.m_171599_("Leg4A", CubeListBuilder.m_171558_().m_171514_(6, 8).m_171481_(-3.0f, -1.0f, -2.0f, 3.0f, 3.0f, 4.0f), PartPose.m_171419_((float)-5.0f, (float)19.0f, (float)9.0f));
        root.m_171599_("UJaw2", CubeListBuilder.m_171558_().m_171514_(37, 0).m_171481_(-1.5f, -1.0f, -16.0f, 3.0f, 2.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)18.0f, (float)-8.0f));
        root.m_171599_("LJaw2", CubeListBuilder.m_171558_().m_171514_(24, 1).m_171481_(-2.0f, 1.0f, -16.0f, 4.0f, 2.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)18.0f, (float)-8.0f));
        root.m_171599_("TeethA", CubeListBuilder.m_171558_().m_171514_(8, 11).m_171481_(1.6f, 0.0f, -16.0f, 0.0f, 1.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)18.0f, (float)-8.0f));
        root.m_171599_("TeethB", CubeListBuilder.m_171558_().m_171514_(8, 11).m_171481_(-1.6f, 0.0f, -16.0f, 0.0f, 1.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)18.0f, (float)-8.0f));
        root.m_171599_("TeethC", CubeListBuilder.m_171558_().m_171514_(6, 9).m_171481_(2.1f, 0.0f, -12.0f, 0.0f, 1.0f, 6.0f), PartPose.m_171419_((float)0.0f, (float)18.0f, (float)-8.0f));
        root.m_171599_("TeethD", CubeListBuilder.m_171558_().m_171514_(6, 9).m_171481_(-2.1f, 0.0f, -12.0f, 0.0f, 1.0f, 6.0f), PartPose.m_171419_((float)0.0f, (float)18.0f, (float)-8.0f));
        root.m_171599_("TeethF", CubeListBuilder.m_171558_().m_171514_(19, 21).m_171481_(-1.0f, 0.0f, -16.1f, 2.0f, 1.0f, 0.0f), PartPose.m_171419_((float)0.0f, (float)18.0f, (float)-8.0f));
        root.m_171599_("Spike0", CubeListBuilder.m_171558_().m_171514_(44, 16).m_171481_(-1.0f, -1.0f, 23.0f, 0.0f, 2.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)17.0f, (float)12.0f));
        root.m_171599_("Spike1", CubeListBuilder.m_171558_().m_171514_(44, 16).m_171481_(1.0f, -1.0f, 23.0f, 0.0f, 2.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)17.0f, (float)12.0f));
        root.m_171599_("Spike2", CubeListBuilder.m_171558_().m_171514_(44, 16).m_171481_(-1.5f, -1.5f, 17.0f, 0.0f, 2.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)17.0f, (float)12.0f));
        root.m_171599_("Spike3", CubeListBuilder.m_171558_().m_171514_(44, 16).m_171481_(1.5f, -1.5f, 17.0f, 0.0f, 2.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)17.0f, (float)12.0f));
        root.m_171599_("Spike4", CubeListBuilder.m_171558_().m_171514_(44, 16).m_171481_(-2.0f, -2.0f, 12.0f, 0.0f, 2.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)17.0f, (float)12.0f));
        root.m_171599_("Spike5", CubeListBuilder.m_171558_().m_171514_(44, 16).m_171481_(2.0f, -2.0f, 12.0f, 0.0f, 2.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)17.0f, (float)12.0f));
        root.m_171599_("Spike6", CubeListBuilder.m_171558_().m_171514_(44, 16).m_171481_(-2.5f, -2.0f, 8.0f, 0.0f, 2.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)17.0f, (float)12.0f));
        root.m_171599_("Spike7", CubeListBuilder.m_171558_().m_171514_(44, 16).m_171481_(2.5f, -2.0f, 8.0f, 0.0f, 2.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)17.0f, (float)12.0f));
        root.m_171599_("Spike8", CubeListBuilder.m_171558_().m_171514_(44, 16).m_171481_(-3.0f, -2.5f, 4.0f, 0.0f, 2.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)17.0f, (float)12.0f));
        root.m_171599_("Spike9", CubeListBuilder.m_171558_().m_171514_(44, 16).m_171481_(3.0f, -2.5f, 4.0f, 0.0f, 2.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)17.0f, (float)12.0f));
        root.m_171599_("Spike10", CubeListBuilder.m_171558_().m_171514_(44, 16).m_171481_(3.5f, -2.5f, 0.0f, 0.0f, 2.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)17.0f, (float)12.0f));
        root.m_171599_("Spike11", CubeListBuilder.m_171558_().m_171514_(44, 16).m_171481_(-3.5f, -2.5f, 0.0f, 0.0f, 2.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)17.0f, (float)12.0f));
        root.m_171599_("SpikeBack0", CubeListBuilder.m_171558_().m_171514_(44, 10).m_171481_(0.0f, 0.0f, 0.0f, 0.0f, 2.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)14.0f, (float)3.0f));
        root.m_171599_("SpikeBack1", CubeListBuilder.m_171558_().m_171514_(44, 10).m_171481_(0.0f, 0.0f, 0.0f, 0.0f, 2.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)14.0f, (float)-6.0f));
        root.m_171599_("SpikeBack2", CubeListBuilder.m_171558_().m_171514_(44, 10).m_171481_(0.0f, 0.0f, 0.0f, 0.0f, 2.0f, 8.0f), PartPose.m_171419_((float)4.0f, (float)14.0f, (float)-8.0f));
        root.m_171599_("SpikeBack3", CubeListBuilder.m_171558_().m_171514_(44, 10).m_171481_(0.0f, 0.0f, 0.0f, 0.0f, 2.0f, 8.0f), PartPose.m_171419_((float)-4.0f, (float)14.0f, (float)-8.0f));
        root.m_171599_("SpikeBack4", CubeListBuilder.m_171558_().m_171514_(44, 10).m_171481_(0.0f, 0.0f, 0.0f, 0.0f, 2.0f, 8.0f), PartPose.m_171419_((float)-4.0f, (float)14.0f, (float)1.0f));
        root.m_171599_("SpikeBack5", CubeListBuilder.m_171558_().m_171514_(44, 10).m_171481_(0.0f, 0.0f, 0.0f, 0.0f, 2.0f, 8.0f), PartPose.m_171419_((float)4.0f, (float)14.0f, (float)1.0f));
        root.m_171599_("SpikeEye", CubeListBuilder.m_171558_().m_171514_(44, 14).m_171481_(-3.0f, -3.0f, -6.0f, 0.0f, 1.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)18.0f, (float)-8.0f));
        root.m_171599_("SpikeEye1", CubeListBuilder.m_171558_().m_171514_(44, 14).m_171481_(3.0f, -3.0f, -6.0f, 0.0f, 1.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)18.0f, (float)-8.0f));
        root.m_171599_("TeethA1", CubeListBuilder.m_171558_().m_171514_(52, 12).m_171481_(1.4f, 1.0f, -16.4f, 0.0f, 1.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)18.0f, (float)-8.0f));
        root.m_171599_("TeethB1", CubeListBuilder.m_171558_().m_171514_(52, 12).m_171481_(-1.4f, 1.0f, -16.4f, 0.0f, 1.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)18.0f, (float)-8.0f));
        root.m_171599_("TeethC1", CubeListBuilder.m_171558_().m_171514_(50, 10).m_171481_(1.9f, 1.0f, -12.5f, 0.0f, 1.0f, 6.0f), PartPose.m_171419_((float)0.0f, (float)18.0f, (float)-8.0f));
        root.m_171599_("TeethD1", CubeListBuilder.m_171558_().m_171514_(50, 10).m_171481_(-1.9f, 1.0f, -12.5f, 0.0f, 1.0f, 6.0f), PartPose.m_171419_((float)0.0f, (float)18.0f, (float)-8.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)64, (int)32);
    }

    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float tailYaw;
        this.biteProgress = ((MoCEntityCrocodile)entity).biteProgress;
        this.swimming = ((MoCEntityCrocodile)entity).m_6069_();
        this.resting = ((MoCEntityCrocodile)entity).getIsSitting();
        this.Head.f_104203_ = headPitch / 57.29578f;
        this.Head.f_104204_ = netHeadYaw / 57.29578f;
        this.SpikeEye.f_104203_ = this.Head.f_104203_;
        this.SpikeEye.f_104204_ = this.Head.f_104204_;
        this.SpikeEye1.f_104203_ = this.Head.f_104203_;
        this.SpikeEye1.f_104204_ = this.Head.f_104204_;
        this.LJaw.f_104204_ = this.Head.f_104204_;
        this.LJaw2.f_104204_ = this.Head.f_104204_;
        this.UJaw.f_104204_ = this.Head.f_104204_;
        this.UJaw2.f_104204_ = this.Head.f_104204_;
        if (this.swimming) {
            this.Leg1.m_104227_(9.0f, 18.0f, 0.0f);
            this.Leg1.f_104204_ = (float)Math.PI;
            this.Leg2.m_104227_(-9.0f, 18.0f, 0.0f);
            this.Leg2.f_104204_ = (float)Math.PI;
            this.Leg3.m_104227_(8.0f, 18.0f, 12.0f);
            this.Leg3.f_104204_ = (float)Math.PI;
            this.Leg4.m_104227_(-8.0f, 18.0f, 12.0f);
            this.Leg4.f_104204_ = (float)Math.PI;
            this.Leg1A.m_104227_(5.0f, 19.0f, -3.0f);
            this.Leg1A.f_104203_ = 1.5707964f;
            this.Leg2A.m_104227_(-5.0f, 19.0f, -3.0f);
            this.Leg2A.f_104203_ = 1.5707964f;
            this.Leg3A.m_104227_(5.0f, 19.0f, 9.0f);
            this.Leg3A.f_104203_ = 1.5707964f;
            this.Leg4A.m_104227_(-5.0f, 19.0f, 9.0f);
            this.Leg4A.f_104203_ = 1.5707964f;
            this.Leg1.f_104205_ = 0.0f;
            this.Leg1A.f_104205_ = 0.0f;
            this.Leg2.f_104205_ = 0.0f;
            this.Leg2A.f_104205_ = 0.0f;
            this.Leg3.f_104205_ = 0.0f;
            this.Leg3A.f_104205_ = 0.0f;
            this.Leg4.f_104205_ = 0.0f;
            this.Leg4A.f_104205_ = 0.0f;
        } else if (this.resting) {
            this.Leg1.m_104227_(6.0f, 17.0f, -6.0f);
            this.Leg1.f_104204_ = -0.7854f;
            this.Leg2.m_104227_(-6.0f, 17.0f, -6.0f);
            this.Leg2.f_104204_ = 0.7854f;
            this.Leg3.m_104227_(7.0f, 17.0f, 7.0f);
            this.Leg3.f_104204_ = -0.7854f;
            this.Leg4.m_104227_(-7.0f, 17.0f, 7.0f);
            this.Leg4.f_104204_ = 0.7854f;
            this.Leg1A.m_104227_(5.0f, 17.0f, -3.0f);
            this.Leg1A.f_104203_ = 0.0f;
            this.Leg2A.m_104227_(-5.0f, 17.0f, -3.0f);
            this.Leg2A.f_104203_ = 0.0f;
            this.Leg3A.m_104227_(5.0f, 17.0f, 9.0f);
            this.Leg3A.f_104203_ = 0.0f;
            this.Leg4A.m_104227_(-5.0f, 17.0f, 9.0f);
            this.Leg4A.f_104203_ = 0.0f;
            this.Leg1.f_104205_ = 0.0f;
            this.Leg1A.f_104205_ = 0.0f;
            this.Leg2.f_104205_ = 0.0f;
            this.Leg2A.f_104205_ = 0.0f;
            this.Leg3.f_104205_ = 0.0f;
            this.Leg3A.f_104205_ = 0.0f;
            this.Leg4.f_104205_ = 0.0f;
            this.Leg4A.f_104205_ = 0.0f;
        } else {
            float latrot;
            this.Leg1.m_104227_(5.0f, 19.0f, -3.0f);
            this.Leg2.m_104227_(-5.0f, 19.0f, -3.0f);
            this.Leg3.m_104227_(5.0f, 19.0f, 9.0f);
            this.Leg4.m_104227_(-5.0f, 19.0f, 9.0f);
            this.Leg1.f_104204_ = 0.0f;
            this.Leg2.f_104204_ = 0.0f;
            this.Leg3.f_104204_ = 0.0f;
            this.Leg4.f_104204_ = 0.0f;
            this.Leg1A.m_104227_(5.0f, 19.0f, -3.0f);
            this.Leg2A.m_104227_(-5.0f, 19.0f, -3.0f);
            this.Leg3A.m_104227_(5.0f, 19.0f, 9.0f);
            this.Leg4A.m_104227_(-5.0f, 19.0f, 9.0f);
            this.Leg1.f_104203_ = Mth.m_14089_((float)(limbSwing * 0.6662f)) * 1.4f * limbSwingAmount;
            this.Leg2.f_104203_ = Mth.m_14089_((float)(limbSwing * 0.6662f + (float)Math.PI)) * 1.4f * limbSwingAmount;
            this.Leg3.f_104203_ = Mth.m_14089_((float)(limbSwing * 0.6662f + (float)Math.PI)) * 1.4f * limbSwingAmount;
            this.Leg4.f_104203_ = Mth.m_14089_((float)(limbSwing * 0.6662f)) * 1.4f * limbSwingAmount;
            this.Leg1.f_104204_ = 0.0f;
            this.Leg2.f_104204_ = 0.0f;
            this.Leg3.f_104204_ = 0.0f;
            this.Leg4.f_104204_ = 0.0f;
            this.Leg1A.f_104203_ = this.Leg1.f_104203_;
            this.Leg2A.f_104203_ = this.Leg2.f_104203_;
            this.Leg3A.f_104203_ = this.Leg3.f_104203_;
            this.Leg4A.f_104203_ = this.Leg4.f_104203_;
            this.Leg1.f_104205_ = latrot = Mth.m_14089_((float)(limbSwing / 1.9191077f)) * 0.2617994f * limbSwingAmount * 5.0f;
            this.Leg1A.f_104205_ = latrot;
            this.Leg3.f_104205_ = latrot;
            this.Leg3A.f_104205_ = latrot;
            this.Leg2.f_104205_ = -latrot;
            this.Leg2A.f_104205_ = -latrot;
            this.Leg4.f_104205_ = -latrot;
            this.Leg4A.f_104205_ = -latrot;
        }
        this.TailA.f_104204_ = tailYaw = Mth.m_14089_((float)(limbSwing * 0.6662f)) * 0.7f * limbSwingAmount;
        this.TailB.f_104204_ = tailYaw;
        this.TailC.f_104204_ = tailYaw;
        this.TailD.f_104204_ = tailYaw;
        this.Spike0.f_104204_ = tailYaw;
        this.Spike1.f_104204_ = tailYaw;
        this.Spike2.f_104204_ = tailYaw;
        this.Spike3.f_104204_ = tailYaw;
        this.Spike4.f_104204_ = tailYaw;
        this.Spike5.f_104204_ = tailYaw;
        this.Spike6.f_104204_ = tailYaw;
        this.Spike7.f_104204_ = tailYaw;
        this.Spike8.f_104204_ = tailYaw;
        this.Spike9.f_104204_ = tailYaw;
        this.Spike10.f_104204_ = tailYaw;
        this.Spike11.f_104204_ = tailYaw;
        float f = this.biteProgress;
        float f2 = f >= 0.5f ? 0.5f - (f - 0.5f) : f;
        this.UJaw2.f_104203_ = this.UJaw.f_104203_ = this.Head.f_104203_ - f2;
        this.LJaw2.f_104203_ = this.LJaw.f_104203_ = this.Head.f_104203_ + f2 / 2.0f;
        this.TeethA.f_104203_ = this.LJaw.f_104203_;
        this.TeethB.f_104203_ = this.LJaw.f_104203_;
        this.TeethC.f_104203_ = this.LJaw.f_104203_;
        this.TeethD.f_104203_ = this.LJaw.f_104203_;
        this.TeethF.f_104203_ = this.LJaw.f_104203_;
        this.TeethA.f_104204_ = this.LJaw.f_104204_;
        this.TeethB.f_104204_ = this.LJaw.f_104204_;
        this.TeethC.f_104204_ = this.LJaw.f_104204_;
        this.TeethD.f_104204_ = this.LJaw.f_104204_;
        this.TeethF.f_104204_ = this.LJaw.f_104204_;
        this.TeethA1.f_104203_ = this.UJaw.f_104203_;
        this.TeethB1.f_104203_ = this.UJaw.f_104203_;
        this.TeethC1.f_104203_ = this.UJaw.f_104203_;
        this.TeethD1.f_104203_ = this.UJaw.f_104203_;
        this.TeethA1.f_104204_ = this.UJaw.f_104204_;
        this.TeethB1.f_104204_ = this.UJaw.f_104204_;
        this.TeethC1.f_104204_ = this.UJaw.f_104204_;
        this.TeethD1.f_104204_ = this.UJaw.f_104204_;
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.LJaw.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.TailA.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.TailB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.TailC.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.UJaw.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Head.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Body.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Leg1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Leg3.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Leg2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Leg4.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.TailD.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Leg1A.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Leg2A.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Leg3A.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Leg4A.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.UJaw2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LJaw2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.TeethA.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.TeethB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.TeethC.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.TeethD.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.TeethF.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Spike0.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Spike1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Spike2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Spike3.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Spike4.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Spike5.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Spike6.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Spike7.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Spike8.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Spike9.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Spike10.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Spike11.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.SpikeBack0.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.SpikeBack1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.SpikeBack2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.SpikeBack3.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.SpikeBack4.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.SpikeBack5.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.SpikeEye.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.SpikeEye1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.TeethA1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.TeethB1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.TeethC1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.TeethD1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}

