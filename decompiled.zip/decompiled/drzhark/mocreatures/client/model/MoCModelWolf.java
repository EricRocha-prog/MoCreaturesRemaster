/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.hostile.MoCEntityWWolf;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelWolf<T extends MoCEntityWWolf>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "wolf"), "main");
    private final ModelPart Head;
    private final ModelPart MouthB;
    private final ModelPart Nose2;
    private final ModelPart Neck;
    private final ModelPart Neck2;
    private final ModelPart LSide;
    private final ModelPart RSide;
    private final ModelPart Nose;
    private final ModelPart Mouth;
    private final ModelPart UTeeth;
    private final ModelPart LTeeth;
    private final ModelPart MouthOpen;
    private final ModelPart REar;
    private final ModelPart LEar;
    private final ModelPart Chest;
    private final ModelPart Body;
    private final ModelPart TailA;
    private final ModelPart TailB;
    private final ModelPart TailC;
    private final ModelPart TailD;
    private final ModelPart Leg1A;
    private final ModelPart Leg1B;
    private final ModelPart Leg1C;
    private final ModelPart Leg2A;
    private final ModelPart Leg2B;
    private final ModelPart Leg2C;
    private final ModelPart Leg3A;
    private final ModelPart Leg3B;
    private final ModelPart Leg3C;
    private final ModelPart Leg3D;
    private final ModelPart Leg4A;
    private final ModelPart Leg4B;
    private final ModelPart Leg4C;
    private final ModelPart Leg4D;
    private boolean openMouth;

    public MoCModelWolf(ModelPart root) {
        this.Head = root.m_171324_("Head");
        this.MouthB = root.m_171324_("MouthB");
        this.Nose2 = root.m_171324_("Nose2");
        this.Neck = root.m_171324_("Neck");
        this.Neck2 = root.m_171324_("Neck2");
        this.LSide = root.m_171324_("LSide");
        this.RSide = root.m_171324_("RSide");
        this.Nose = root.m_171324_("Nose");
        this.Mouth = root.m_171324_("Mouth");
        this.UTeeth = root.m_171324_("UTeeth");
        this.LTeeth = root.m_171324_("LTeeth");
        this.MouthOpen = root.m_171324_("MouthOpen");
        this.REar = root.m_171324_("REar");
        this.LEar = root.m_171324_("LEar");
        this.Chest = root.m_171324_("Chest");
        this.Body = root.m_171324_("Body");
        this.TailA = root.m_171324_("TailA");
        this.TailB = root.m_171324_("TailB");
        this.TailC = root.m_171324_("TailC");
        this.TailD = root.m_171324_("TailD");
        this.Leg1A = root.m_171324_("Leg1A");
        this.Leg1B = root.m_171324_("Leg1B");
        this.Leg1C = root.m_171324_("Leg1C");
        this.Leg2A = root.m_171324_("Leg2A");
        this.Leg2B = root.m_171324_("Leg2B");
        this.Leg2C = root.m_171324_("Leg2C");
        this.Leg3A = root.m_171324_("Leg3A");
        this.Leg3B = root.m_171324_("Leg3B");
        this.Leg3C = root.m_171324_("Leg3C");
        this.Leg3D = root.m_171324_("Leg3D");
        this.Leg4A = root.m_171324_("Leg4A");
        this.Leg4B = root.m_171324_("Leg4B");
        this.Leg4C = root.m_171324_("Leg4C");
        this.Leg4D = root.m_171324_("Leg4D");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition part = mesh.m_171576_();
        part.m_171599_("Head", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-4.0f, -3.0f, -6.0f, 8.0f, 8.0f, 6.0f), PartPose.m_171419_((float)0.0f, (float)7.0f, (float)-10.0f));
        part.m_171599_("MouthB", CubeListBuilder.m_171558_().m_171514_(16, 33).m_171481_(-2.0f, 4.0f, -7.0f, 4.0f, 1.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)7.0f, (float)-10.0f));
        part.m_171599_("Nose2", CubeListBuilder.m_171558_().m_171514_(0, 25).m_171481_(-2.0f, 2.0f, -12.0f, 4.0f, 2.0f, 6.0f), PartPose.m_171419_((float)0.0f, (float)7.0f, (float)-10.0f));
        part.m_171599_("Neck", CubeListBuilder.m_171558_().m_171514_(28, 0).m_171481_(-3.5f, -3.0f, -7.0f, 7.0f, 8.0f, 7.0f), PartPose.m_171423_((float)0.0f, (float)10.0f, (float)-6.0f, (float)-0.4537856f, (float)0.0f, (float)0.0f));
        part.m_171599_("Neck2", CubeListBuilder.m_171558_().m_171514_(0, 14).m_171481_(-1.5f, -2.0f, -5.0f, 3.0f, 4.0f, 7.0f), PartPose.m_171423_((float)0.0f, (float)14.0f, (float)-10.0f, (float)-0.4537856f, (float)0.0f, (float)0.0f));
        part.m_171599_("LSide", CubeListBuilder.m_171558_().m_171514_(28, 33).m_171481_(3.0f, -0.5f, -2.0f, 2.0f, 6.0f, 6.0f), PartPose.m_171423_((float)0.0f, (float)7.0f, (float)-10.0f, (float)-0.2094395f, (float)0.418879f, (float)-0.0872665f));
        part.m_171599_("RSide", CubeListBuilder.m_171558_().m_171514_(28, 45).m_171481_(-5.0f, -0.5f, -2.0f, 2.0f, 6.0f, 6.0f), PartPose.m_171423_((float)0.0f, (float)7.0f, (float)-10.0f, (float)-0.2094395f, (float)-0.418879f, (float)0.0872665f));
        part.m_171599_("Nose", CubeListBuilder.m_171558_().m_171514_(44, 33).m_171481_(-1.5f, -1.8f, -12.4f, 3.0f, 2.0f, 7.0f), PartPose.m_171423_((float)0.0f, (float)7.0f, (float)-10.0f, (float)0.2792527f, (float)0.0f, (float)0.0f));
        part.m_171599_("Mouth", CubeListBuilder.m_171558_().m_171514_(1, 34).m_171481_(-2.0f, 4.0f, -11.5f, 4.0f, 1.0f, 5.0f), PartPose.m_171419_((float)0.0f, (float)7.0f, (float)-10.0f));
        part.m_171599_("UTeeth", CubeListBuilder.m_171558_().m_171514_(46, 18).m_171481_(-2.0f, 4.0f, -12.0f, 4.0f, 2.0f, 5.0f), PartPose.m_171419_((float)0.0f, (float)7.0f, (float)-10.0f));
        part.m_171599_("LTeeth", CubeListBuilder.m_171558_().m_171514_(20, 109).m_171481_(-1.5f, -12.9f, 1.2f, 3.0f, 5.0f, 2.0f), PartPose.m_171423_((float)0.0f, (float)7.0f, (float)-10.0f, (float)2.5307274f, (float)0.0f, (float)0.0f));
        part.m_171599_("MouthOpen", CubeListBuilder.m_171558_().m_171514_(42, 69).m_171481_(-1.5f, -12.9f, -0.81f, 3.0f, 9.0f, 2.0f), PartPose.m_171423_((float)0.0f, (float)7.0f, (float)-10.0f, (float)2.5307274f, (float)0.0f, (float)0.0f));
        part.m_171599_("REar", CubeListBuilder.m_171558_().m_171514_(22, 0).m_171481_(-3.5f, -7.0f, -1.5f, 3.0f, 5.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)7.0f, (float)-10.0f, (float)0.0f, (float)0.0f, (float)-0.1745329f));
        part.m_171599_("LEar", CubeListBuilder.m_171558_().m_171514_(13, 14).m_171481_(0.5f, -7.0f, -1.5f, 3.0f, 5.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)7.0f, (float)-10.0f, (float)0.0f, (float)0.0f, (float)0.1745329f));
        part.m_171599_("Chest", CubeListBuilder.m_171558_().m_171514_(20, 15).m_171481_(-4.0f, -11.0f, -12.0f, 8.0f, 8.0f, 10.0f), PartPose.m_171423_((float)0.0f, (float)5.0f, (float)2.0f, (float)1.570796f, (float)0.0f, (float)0.0f));
        part.m_171599_("Body", CubeListBuilder.m_171558_().m_171514_(0, 40).m_171481_(-3.0f, -8.0f, -9.0f, 6.0f, 16.0f, 8.0f), PartPose.m_171423_((float)0.0f, (float)6.5f, (float)2.0f, (float)1.570796f, (float)0.0f, (float)0.0f));
        part.m_171599_("TailA", CubeListBuilder.m_171558_().m_171514_(52, 42).m_171481_(-1.5f, 0.0f, -1.5f, 3.0f, 4.0f, 3.0f), PartPose.m_171423_((float)0.0f, (float)8.5f, (float)9.0f, (float)1.064651f, (float)0.0f, (float)0.0f));
        part.m_171599_("TailB", CubeListBuilder.m_171558_().m_171514_(48, 49).m_171481_(-2.0f, 3.0f, -1.0f, 4.0f, 6.0f, 4.0f), PartPose.m_171423_((float)0.0f, (float)8.5f, (float)9.0f, (float)0.7504916f, (float)0.0f, (float)0.0f));
        part.m_171599_("TailC", CubeListBuilder.m_171558_().m_171514_(48, 59).m_171481_(-2.0f, 7.8f, -4.1f, 4.0f, 6.0f, 4.0f), PartPose.m_171423_((float)0.0f, (float)8.5f, (float)9.0f, (float)1.099557f, (float)0.0f, (float)0.0f));
        part.m_171599_("TailD", CubeListBuilder.m_171558_().m_171514_(52, 69).m_171481_(-1.5f, 9.8f, -3.6f, 3.0f, 5.0f, 3.0f), PartPose.m_171423_((float)0.0f, (float)8.5f, (float)9.0f, (float)1.099557f, (float)0.0f, (float)0.0f));
        part.m_171599_("Leg1A", CubeListBuilder.m_171558_().m_171514_(28, 57).m_171481_(0.01f, -4.0f, -2.5f, 2.0f, 8.0f, 4.0f), PartPose.m_171423_((float)4.0f, (float)12.5f, (float)-5.5f, (float)0.2617994f, (float)0.0f, (float)0.0f));
        part.m_171599_("Leg1B", CubeListBuilder.m_171558_().m_171514_(28, 69).m_171481_(0.0f, 3.2f, 0.5f, 2.0f, 8.0f, 2.0f), PartPose.m_171423_((float)4.0f, (float)12.5f, (float)-5.5f, (float)-0.1745329f, (float)0.0f, (float)0.0f));
        part.m_171599_("Leg1C", CubeListBuilder.m_171558_().m_171514_(28, 79).m_171481_(-0.5066667f, 9.5f, -2.5f, 3.0f, 2.0f, 3.0f), PartPose.m_171419_((float)4.0f, (float)12.5f, (float)-5.5f));
        part.m_171599_("Leg2A", CubeListBuilder.m_171558_().m_171514_(28, 84).m_171481_(-2.01f, -4.0f, -2.5f, 2.0f, 8.0f, 4.0f), PartPose.m_171423_((float)-4.0f, (float)12.5f, (float)-5.5f, (float)0.2617994f, (float)0.0f, (float)0.0f));
        part.m_171599_("Leg2B", CubeListBuilder.m_171558_().m_171514_(28, 96).m_171481_(-2.0f, 3.2f, 0.5f, 2.0f, 8.0f, 2.0f), PartPose.m_171423_((float)-4.0f, (float)12.5f, (float)-5.5f, (float)-0.1745329f, (float)0.0f, (float)0.0f));
        part.m_171599_("Leg2C", CubeListBuilder.m_171558_().m_171514_(28, 106).m_171481_(-2.506667f, 9.5f, -2.5f, 3.0f, 2.0f, 3.0f), PartPose.m_171419_((float)-4.0f, (float)12.5f, (float)-5.5f));
        part.m_171599_("Leg3A", CubeListBuilder.m_171558_().m_171514_(0, 64).m_171481_(0.0f, -3.8f, -3.5f, 2.0f, 7.0f, 5.0f), PartPose.m_171423_((float)3.0f, (float)12.5f, (float)7.0f, (float)-0.3665191f, (float)0.0f, (float)0.0f));
        part.m_171599_("Leg3B", CubeListBuilder.m_171558_().m_171514_(0, 76).m_171481_(-0.1f, 1.9f, -1.8f, 2.0f, 2.0f, 5.0f), PartPose.m_171423_((float)3.0f, (float)12.5f, (float)7.0f, (float)-0.7330383f, (float)0.0f, (float)0.0f));
        part.m_171599_("Leg3C", CubeListBuilder.m_171558_().m_171514_(0, 83).m_171481_(0.0f, 3.2f, 0.0f, 2.0f, 8.0f, 2.0f), PartPose.m_171423_((float)3.0f, (float)12.5f, (float)7.0f, (float)-0.1745329f, (float)0.0f, (float)0.0f));
        part.m_171599_("Leg3D", CubeListBuilder.m_171558_().m_171514_(0, 93).m_171481_(-0.5066667f, 9.5f, -3.0f, 3.0f, 2.0f, 3.0f), PartPose.m_171419_((float)3.0f, (float)12.5f, (float)7.0f));
        part.m_171599_("Leg4A", CubeListBuilder.m_171558_().m_171514_(14, 64).m_171481_(-2.0f, -3.8f, -3.5f, 2.0f, 7.0f, 5.0f), PartPose.m_171423_((float)-3.0f, (float)12.5f, (float)7.0f, (float)-0.3665191f, (float)0.0f, (float)0.0f));
        part.m_171599_("Leg4B", CubeListBuilder.m_171558_().m_171514_(14, 76).m_171481_(-1.9f, 1.9f, -1.8f, 2.0f, 2.0f, 5.0f), PartPose.m_171423_((float)-3.0f, (float)12.5f, (float)7.0f, (float)-0.7330383f, (float)0.0f, (float)0.0f));
        part.m_171599_("Leg4C", CubeListBuilder.m_171558_().m_171514_(14, 83).m_171481_(-2.0f, 3.2f, 0.0f, 2.0f, 8.0f, 2.0f), PartPose.m_171423_((float)-3.0f, (float)12.5f, (float)7.0f, (float)-0.1745329f, (float)0.0f, (float)0.0f));
        part.m_171599_("Leg4D", CubeListBuilder.m_171558_().m_171514_(14, 93).m_171481_(-2.506667f, 9.5f, -3.0f, 3.0f, 2.0f, 3.0f), PartPose.m_171419_((float)-3.0f, (float)12.5f, (float)7.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)64, (int)128);
    }

    public void prepareMobModel(T entity, float limbSwing, float limbSwingAmount, float partialTick) {
        this.openMouth = ((MoCEntityWWolf)entity).mouthCounter != 0;
    }

    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.Head.f_104203_ = headPitch / 57.29578f;
        this.Head.f_104204_ = netHeadYaw / 57.29578f;
        float LLegX = Mth.m_14089_((float)(limbSwing * 0.6662f)) * 0.8f * limbSwingAmount;
        float RLegX = Mth.m_14089_((float)(limbSwing * 0.6662f + (float)Math.PI)) * 0.8f * limbSwingAmount;
        this.Mouth.f_104203_ = this.Head.f_104203_;
        this.Mouth.f_104204_ = this.Head.f_104204_;
        this.MouthB.f_104203_ = this.Head.f_104203_;
        this.MouthB.f_104204_ = this.Head.f_104204_;
        this.Nose2.f_104203_ = this.Head.f_104203_;
        this.Nose2.f_104204_ = this.Head.f_104204_;
        this.UTeeth.f_104203_ = this.Head.f_104203_;
        this.UTeeth.f_104204_ = this.Head.f_104204_;
        this.MouthOpen.f_104203_ = 2.5307274f + this.Head.f_104203_;
        this.MouthOpen.f_104204_ = this.Head.f_104204_;
        this.LTeeth.f_104203_ = 2.5307274f + this.Head.f_104203_;
        this.LTeeth.f_104204_ = this.Head.f_104204_;
        this.Nose.f_104203_ = 0.27925268f + this.Head.f_104203_;
        this.Nose.f_104204_ = this.Head.f_104204_;
        this.LSide.f_104203_ = -0.2094395f + this.Head.f_104203_;
        this.LSide.f_104204_ = 0.418879f + this.Head.f_104204_;
        this.RSide.f_104203_ = -0.2094395f + this.Head.f_104203_;
        this.RSide.f_104204_ = -0.418879f + this.Head.f_104204_;
        this.REar.f_104203_ = this.Head.f_104203_;
        this.REar.f_104204_ = this.Head.f_104204_;
        this.LEar.f_104203_ = this.Head.f_104203_;
        this.LEar.f_104204_ = this.Head.f_104204_;
        this.Leg1A.f_104203_ = 0.2617994f + LLegX;
        this.Leg1B.f_104203_ = -0.17453292f + LLegX;
        this.Leg1C.f_104203_ = LLegX;
        this.Leg2A.f_104203_ = 0.2617994f + RLegX;
        this.Leg2B.f_104203_ = -0.17453292f + RLegX;
        this.Leg2C.f_104203_ = RLegX;
        this.Leg3A.f_104203_ = -0.36651915f + RLegX;
        this.Leg3B.f_104203_ = -0.7330383f + RLegX;
        this.Leg3C.f_104203_ = -0.17453292f + RLegX;
        this.Leg3D.f_104203_ = RLegX;
        this.Leg4A.f_104203_ = -0.36651915f + LLegX;
        this.Leg4B.f_104203_ = -0.7330383f + LLegX;
        this.Leg4C.f_104203_ = -0.17453292f + LLegX;
        this.Leg4D.f_104203_ = LLegX;
        float tailMov = -1.3089f + limbSwingAmount * 1.5f;
        if (((MoCEntityWWolf)entity).tailCounter != 0) {
            this.TailA.f_104204_ = Mth.m_14089_((float)(ageInTicks * 0.5f));
            tailMov = 0.0f;
        } else {
            this.TailA.f_104204_ = 0.0f;
        }
        this.TailA.f_104203_ = 1.0647582f - tailMov;
        this.TailB.f_104203_ = 0.75056726f - tailMov;
        this.TailC.f_104203_ = 1.0996684f - tailMov;
        this.TailD.f_104203_ = 1.0996684f - tailMov;
        this.TailB.f_104204_ = this.TailA.f_104204_;
        this.TailC.f_104204_ = this.TailA.f_104204_;
        this.TailD.f_104204_ = this.TailA.f_104204_;
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.Head.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Nose2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Neck.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Neck2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LSide.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RSide.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Nose.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        if (this.openMouth) {
            this.MouthOpen.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.UTeeth.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.LTeeth.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        } else {
            this.Mouth.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.MouthB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        }
        this.REar.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LEar.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Chest.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Body.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.TailA.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.TailB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.TailC.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.TailD.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Leg4A.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Leg4D.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Leg4B.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Leg4C.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Leg3B.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Leg2A.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Leg2B.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Leg2C.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Leg3D.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Leg3C.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Leg3A.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Leg1A.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Leg1B.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Leg1C.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}

