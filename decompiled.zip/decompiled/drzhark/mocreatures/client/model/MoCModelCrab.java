/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.ambient.MoCEntityCrab;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelCrab<T extends MoCEntityCrab>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "crab"), "main");
    private final ModelPart shell;
    private final ModelPart shell_right;
    private final ModelPart shell_left;
    private final ModelPart shell_back;
    private final ModelPart left_eye;
    private final ModelPart left_eye_base;
    private final ModelPart right_eye_base;
    private final ModelPart right_eye;
    private final ModelPart right_arm_a;
    private final ModelPart right_arm_b;
    private final ModelPart right_arm_c;
    private final ModelPart right_arm_d;
    private final ModelPart left_arm_a;
    private final ModelPart left_arm_b;
    private final ModelPart left_arm_c;
    private final ModelPart left_arm_d;
    private final ModelPart right_leg1_a;
    private final ModelPart right_leg1_b;
    private final ModelPart right_leg2_a;
    private final ModelPart right_leg2_b;
    private final ModelPart right_leg3_a;
    private final ModelPart right_leg3_b;
    private final ModelPart right_leg4_a;
    private final ModelPart right_leg4_b;
    private final ModelPart right_leg4_c;
    private final ModelPart left_leg1_a;
    private final ModelPart left_leg1_b;
    private final ModelPart left_leg2_a;
    private final ModelPart left_leg2_b;
    private final ModelPart left_leg3_a;
    private final ModelPart left_leg3_b;
    private final ModelPart left_leg4_a;
    private final ModelPart left_leg4_b;
    private final ModelPart left_leg4_c;

    public MoCModelCrab(ModelPart root) {
        this.shell = root.m_171324_("shell");
        this.shell_right = root.m_171324_("shell_right");
        this.shell_left = root.m_171324_("shell_left");
        this.shell_back = root.m_171324_("shell_back");
        this.left_eye = root.m_171324_("left_eye");
        this.left_eye_base = root.m_171324_("left_eye_base");
        this.right_eye_base = root.m_171324_("right_eye_base");
        this.right_eye = root.m_171324_("right_eye");
        this.right_arm_a = root.m_171324_("right_arm_a");
        this.right_arm_b = this.right_arm_a.m_171324_("right_arm_b");
        this.right_arm_c = this.right_arm_b.m_171324_("right_arm_c");
        this.right_arm_d = this.right_arm_b.m_171324_("right_arm_d");
        this.left_arm_a = root.m_171324_("left_arm_a");
        this.left_arm_b = this.left_arm_a.m_171324_("left_arm_b");
        this.left_arm_c = this.left_arm_b.m_171324_("left_arm_c");
        this.left_arm_d = this.left_arm_b.m_171324_("left_arm_d");
        this.right_leg1_a = root.m_171324_("right_leg1_a");
        this.right_leg1_b = this.right_leg1_a.m_171324_("right_leg1_b");
        this.right_leg2_a = root.m_171324_("right_leg2_a");
        this.right_leg2_b = this.right_leg2_a.m_171324_("right_leg2_b");
        this.right_leg3_a = root.m_171324_("right_leg3_a");
        this.right_leg3_b = this.right_leg3_a.m_171324_("right_leg3_b");
        this.right_leg4_a = root.m_171324_("right_leg4_a");
        this.right_leg4_b = this.right_leg4_a.m_171324_("right_leg4_b");
        this.right_leg4_c = this.right_leg4_b.m_171324_("right_leg4_c");
        this.left_leg1_a = root.m_171324_("left_leg1_a");
        this.left_leg1_b = this.left_leg1_a.m_171324_("left_leg1_b");
        this.left_leg2_a = root.m_171324_("left_leg2_a");
        this.left_leg2_b = this.left_leg2_a.m_171324_("left_leg2_b");
        this.left_leg3_a = root.m_171324_("left_leg3_a");
        this.left_leg3_b = this.left_leg3_a.m_171324_("left_leg3_b");
        this.left_leg4_a = root.m_171324_("left_leg4_a");
        this.left_leg4_b = this.left_leg4_a.m_171324_("left_leg4_b");
        this.left_leg4_c = this.left_leg4_b.m_171324_("left_leg4_c");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        root.m_171599_("shell", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-5.0f, 0.0f, -4.0f, 10.0f, 4.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)16.0f, (float)0.0f));
        root.m_171599_("shell_right", CubeListBuilder.m_171558_().m_171514_(0, 23).m_171481_(4.6f, -2.0f, -4.0f, 3.0f, 3.0f, 8.0f), PartPose.m_171423_((float)0.0f, (float)16.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.418879f));
        root.m_171599_("shell_left", CubeListBuilder.m_171558_().m_171514_(0, 12).m_171481_(-7.6f, -2.0f, -4.0f, 3.0f, 3.0f, 8.0f), PartPose.m_171423_((float)0.0f, (float)16.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-0.418879f));
        root.m_171599_("shell_back", CubeListBuilder.m_171558_().m_171514_(10, 42).m_171481_(-5.0f, -1.6f, 3.6f, 10.0f, 3.0f, 3.0f), PartPose.m_171423_((float)0.0f, (float)16.0f, (float)0.0f, (float)-0.418879f, (float)0.0f, (float)0.0f));
        root.m_171599_("left_eye", CubeListBuilder.m_171558_().m_171514_(0, 4).m_171481_(1.0f, -2.0f, -4.5f, 1.0f, 3.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)16.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.1745329f));
        root.m_171599_("left_eye_base", CubeListBuilder.m_171558_().m_171514_(0, 16).m_171481_(1.0f, 1.0f, -5.0f, 2.0f, 3.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)16.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.2094395f));
        root.m_171599_("right_eye_base", CubeListBuilder.m_171558_().m_171514_(0, 12).m_171481_(-3.0f, 1.0f, -5.0f, 2.0f, 3.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)16.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-0.2094395f));
        root.m_171599_("right_eye", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-2.0f, -2.0f, -4.5f, 1.0f, 3.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)16.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-0.1745329f));
        PartDefinition rightArmA = root.m_171599_("right_arm_a", CubeListBuilder.m_171558_().m_171514_(0, 34).m_171481_(-4.0f, -1.0f, -1.0f, 4.0f, 2.0f, 2.0f), PartPose.m_171423_((float)-4.0f, (float)19.0f, (float)-4.0f, (float)0.0f, (float)-0.5235988f, (float)0.0f));
        PartDefinition rightArmB = rightArmA.m_171599_("right_arm_b", CubeListBuilder.m_171558_().m_171514_(22, 12).m_171481_(-4.0f, -1.5f, -1.0f, 4.0f, 3.0f, 2.0f), PartPose.m_171423_((float)-4.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-2.094395f, (float)0.0f));
        rightArmB.m_171599_("right_arm_c", CubeListBuilder.m_171558_().m_171514_(22, 17).m_171481_(-3.0f, -1.5f, -1.0f, 3.0f, 1.0f, 2.0f), PartPose.m_171419_((float)-4.0f, (float)0.0f, (float)0.0f));
        rightArmB.m_171599_("right_arm_d", CubeListBuilder.m_171558_().m_171514_(16, 12).m_171481_(-2.0f, 0.5f, -0.5f, 2.0f, 1.0f, 1.0f), PartPose.m_171419_((float)-4.0f, (float)0.0f, (float)0.0f));
        PartDefinition leftArmA = root.m_171599_("left_arm_a", CubeListBuilder.m_171558_().m_171514_(0, 38).m_171481_(0.0f, -1.0f, -1.0f, 4.0f, 2.0f, 2.0f), PartPose.m_171423_((float)4.0f, (float)19.0f, (float)-4.0f, (float)0.0f, (float)0.5235988f, (float)0.0f));
        PartDefinition leftArmB = leftArmA.m_171599_("left_arm_b", CubeListBuilder.m_171558_().m_171514_(22, 20).m_171481_(0.0f, -1.5f, -1.0f, 4.0f, 3.0f, 2.0f), PartPose.m_171423_((float)4.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)2.094395f, (float)0.0f));
        leftArmB.m_171599_("left_arm_c", CubeListBuilder.m_171558_().m_171514_(22, 25).m_171481_(0.0f, -1.5f, -1.0f, 3.0f, 1.0f, 2.0f), PartPose.m_171419_((float)4.0f, (float)0.0f, (float)0.0f));
        leftArmB.m_171599_("left_arm_d", CubeListBuilder.m_171558_().m_171514_(16, 23).m_171481_(0.0f, 0.5f, -0.5f, 2.0f, 1.0f, 1.0f), PartPose.m_171419_((float)4.0f, (float)0.0f, (float)0.0f));
        PartDefinition rightLeg1A = root.m_171599_("right_leg1_a", CubeListBuilder.m_171558_().m_171514_(0, 42).m_171481_(-4.0f, -0.5f, -0.5f, 4.0f, 1.0f, 1.0f), PartPose.m_171423_((float)-5.0f, (float)19.5f, (float)-2.5f, (float)0.0f, (float)-0.1745329f, (float)-0.418879f));
        rightLeg1A.m_171599_("right_leg1_b", CubeListBuilder.m_171558_().m_171514_(0, 48).m_171481_(-4.0f, -0.5f, -0.5f, 4.0f, 1.0f, 1.0f), PartPose.m_171423_((float)-4.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-0.5235988f));
        PartDefinition rightLeg2A = root.m_171599_("right_leg2_a", CubeListBuilder.m_171558_().m_171514_(0, 44).m_171481_(-4.0f, -0.5f, -0.5f, 4.0f, 1.0f, 1.0f), PartPose.m_171423_((float)-5.0f, (float)19.5f, (float)0.0f, (float)0.0f, (float)0.0872665f, (float)-0.418879f));
        rightLeg2A.m_171599_("right_leg2_b", CubeListBuilder.m_171558_().m_171514_(0, 50).m_171481_(-4.0f, -0.5f, -0.5f, 4.0f, 1.0f, 1.0f), PartPose.m_171423_((float)-4.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-0.5235988f));
        PartDefinition rightLeg3A = root.m_171599_("right_leg3_a", CubeListBuilder.m_171558_().m_171514_(0, 46).m_171481_(-4.0f, -0.5f, -0.5f, 4.0f, 1.0f, 1.0f), PartPose.m_171423_((float)-5.0f, (float)19.5f, (float)2.5f, (float)0.0f, (float)0.6981317f, (float)-0.418879f));
        rightLeg3A.m_171599_("right_leg3_b", CubeListBuilder.m_171558_().m_171514_(0, 52).m_171481_(-4.0f, -0.5f, -0.5f, 4.0f, 1.0f, 1.0f), PartPose.m_171423_((float)-4.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-0.5235988f));
        PartDefinition rightLeg4A = root.m_171599_("right_leg4_a", CubeListBuilder.m_171558_().m_171514_(12, 34).m_171481_(-4.0f, -0.5f, -0.5f, 4.0f, 1.0f, 1.0f), PartPose.m_171423_((float)-3.0f, (float)19.5f, (float)3.5f, (float)0.0f, (float)0.6108652f, (float)-0.418879f));
        PartDefinition rightLeg4B = rightLeg4A.m_171599_("right_leg4_b", CubeListBuilder.m_171558_().m_171514_(12, 36).m_171481_(-3.0f, -0.5f, -1.0f, 3.0f, 1.0f, 2.0f), PartPose.m_171423_((float)-4.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)1.308997f, (float)-0.418879f));
        rightLeg4B.m_171599_("right_leg4_c", CubeListBuilder.m_171558_().m_171514_(12, 39).m_171481_(-3.0f, -0.5f, -1.0f, 3.0f, 1.0f, 2.0f), PartPose.m_171423_((float)-3.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.8726646f, (float)-0.418879f));
        PartDefinition leftLeg1A = root.m_171599_("left_leg1_a", CubeListBuilder.m_171558_().m_171514_(0, 54).m_171481_(0.0f, -0.5f, -0.5f, 4.0f, 1.0f, 1.0f), PartPose.m_171423_((float)5.0f, (float)19.5f, (float)-2.5f, (float)0.0f, (float)0.1745329f, (float)0.418879f));
        leftLeg1A.m_171599_("left_leg1_b", CubeListBuilder.m_171558_().m_171514_(0, 56).m_171481_(0.0f, -0.5f, -0.5f, 4.0f, 1.0f, 1.0f), PartPose.m_171423_((float)4.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.5235988f));
        PartDefinition leftLeg2A = root.m_171599_("left_leg2_a", CubeListBuilder.m_171558_().m_171514_(0, 62).m_171481_(0.0f, -0.5f, -0.5f, 4.0f, 1.0f, 1.0f), PartPose.m_171423_((float)5.0f, (float)19.5f, (float)0.0f, (float)0.0f, (float)-0.0872665f, (float)0.418879f));
        leftLeg2A.m_171599_("left_leg2_b", CubeListBuilder.m_171558_().m_171514_(10, 62).m_171481_(0.0f, -0.5f, -0.5f, 4.0f, 1.0f, 1.0f), PartPose.m_171423_((float)4.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.5235988f));
        PartDefinition leftLeg3A = root.m_171599_("left_leg3_a", CubeListBuilder.m_171558_().m_171514_(0, 58).m_171481_(0.0f, -0.5f, -0.5f, 4.0f, 1.0f, 1.0f), PartPose.m_171423_((float)5.0f, (float)19.5f, (float)2.5f, (float)0.0f, (float)-0.6981317f, (float)0.418879f));
        leftLeg3A.m_171599_("left_leg3_b", CubeListBuilder.m_171558_().m_171514_(0, 60).m_171481_(0.0f, -0.5f, -0.5f, 4.0f, 1.0f, 1.0f), PartPose.m_171423_((float)4.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.5235988f));
        PartDefinition leftLeg4A = root.m_171599_("left_leg4_a", CubeListBuilder.m_171558_().m_171514_(22, 34).m_171481_(0.0f, -0.5f, -0.5f, 4.0f, 1.0f, 1.0f), PartPose.m_171423_((float)2.0f, (float)19.5f, (float)3.5f, (float)0.0f, (float)-0.6108652f, (float)0.418879f));
        PartDefinition leftLeg4B = leftLeg4A.m_171599_("left_leg4_b", CubeListBuilder.m_171558_().m_171514_(22, 36).m_171481_(0.0f, -0.5f, -1.0f, 3.0f, 1.0f, 2.0f), PartPose.m_171423_((float)4.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-1.308997f, (float)0.418879f));
        leftLeg4B.m_171599_("left_leg4_c", CubeListBuilder.m_171558_().m_171514_(22, 39).m_171481_(0.0f, -0.5f, -1.0f, 3.0f, 1.0f, 2.0f), PartPose.m_171423_((float)3.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-0.8726646f, (float)0.418879f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)64, (int)64);
    }

    public void setupAnim(T entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        if (((MoCEntityCrab)entityIn).isFleeing()) {
            this.left_arm_a.f_104203_ = -1.5707963f;
            this.right_arm_a.f_104203_ = -1.5707963f;
        } else {
            this.left_arm_a.f_104203_ = 0.0f;
            this.right_arm_a.f_104203_ = 0.0f;
        }
        if (limbSwingAmount < 0.1f) {
            this.right_arm_a.f_104204_ = -0.5235988f;
            this.right_arm_b.f_104204_ = -2.0943952f;
            float lHand = 0.0f;
            float f2a = ageInTicks % 100.0f;
            if (f2a > 0.0f && f2a < 10.0f) {
                lHand = f2a * 2.0f / 57.29578f;
            }
            this.left_arm_a.f_104204_ = 0.5235988f + lHand;
            this.left_arm_b.f_104204_ = 2.0943952f + lHand;
            float rHand = 0.0f;
            float f2b = ageInTicks % 75.0f;
            if (f2b > 30.0f && f2b < 40.0f) {
                rHand = (f2b - 29.0f) * 2.0f / 57.29578f;
            }
            this.right_arm_a.f_104204_ = -0.5235988f - rHand;
            this.right_arm_b.f_104204_ = -2.0943952f - rHand;
        }
        float f9 = -Mth.m_14089_((float)(limbSwing * 5.0f)) * limbSwingAmount * 2.0f;
        float f10 = -Mth.m_14089_((float)(limbSwing * 5.0f + (float)Math.PI)) * limbSwingAmount * 2.0f;
        float f11 = -Mth.m_14089_((float)(limbSwing * 5.0f + 1.5707964f)) * limbSwingAmount * 2.0f;
        float f12 = -Mth.m_14089_((float)(limbSwing * 5.0f + 4.712389f)) * limbSwingAmount * 2.0f;
        float f13 = Math.abs(Mth.m_14031_((float)(limbSwing * 0.6662f + 0.0f)) * 0.4f) * limbSwingAmount * 5.0f;
        float f14 = Math.abs(Mth.m_14031_((float)(limbSwing * 0.6662f + (float)Math.PI)) * 0.4f) * limbSwingAmount;
        float f15 = Math.abs(Mth.m_14031_((float)(limbSwing * 0.6662f + 1.5707964f)) * 0.4f) * limbSwingAmount;
        float f16 = Math.abs(Mth.m_14031_((float)(limbSwing * 0.6662f + 4.712389f)) * 0.4f) * limbSwingAmount;
        this.right_leg1_a.f_104204_ = -0.1745329f;
        this.right_leg1_a.f_104205_ = -0.418879f;
        this.right_leg1_a.f_104204_ += f9;
        this.right_leg1_a.f_104205_ += f13;
        this.right_leg1_b.f_104205_ = -0.5235988f;
        this.right_leg1_b.f_104205_ -= f13;
        this.right_leg2_a.f_104204_ = 0.0872665f;
        this.right_leg2_a.f_104205_ = -0.418879f;
        this.right_leg2_a.f_104204_ += f10;
        this.right_leg2_a.f_104205_ += f14;
        this.right_leg2_b.f_104205_ = -0.5235988f;
        this.right_leg2_b.f_104205_ -= f14;
        this.right_leg3_a.f_104204_ = 0.6981317f;
        this.right_leg3_a.f_104205_ = -0.418879f;
        this.right_leg3_a.f_104204_ += f11;
        this.right_leg3_a.f_104205_ += f15;
        this.right_leg3_b.f_104205_ = -0.5235988f;
        this.right_leg3_b.f_104205_ -= f15;
        this.right_leg4_a.f_104204_ = 0.6108652f;
        this.right_leg4_a.f_104205_ = -0.418879f;
        this.right_leg4_a.f_104204_ += f12;
        this.right_leg4_a.f_104205_ += f16;
        this.left_leg1_a.f_104204_ = 0.1745329f;
        this.left_leg1_a.f_104205_ = 0.418879f;
        this.left_leg1_a.f_104204_ -= f9;
        this.left_leg1_a.f_104205_ -= f13;
        this.left_leg1_b.f_104205_ = 0.5235988f;
        this.left_leg1_b.f_104205_ += f13;
        this.left_leg2_a.f_104204_ = -0.0872665f;
        this.left_leg2_a.f_104205_ = 0.418879f;
        this.left_leg2_a.f_104204_ -= f10;
        this.left_leg2_a.f_104205_ -= f14;
        this.left_leg2_b.f_104205_ = 0.5235988f;
        this.left_leg2_b.f_104205_ += f14;
        this.left_leg3_a.f_104204_ = -0.6981317f;
        this.left_leg3_a.f_104205_ = 0.418879f;
        this.left_leg3_a.f_104204_ -= f11;
        this.left_leg3_a.f_104205_ -= f15;
        this.left_leg3_b.f_104205_ = 0.5235988f;
        this.left_leg3_b.f_104205_ += f15;
        this.left_leg4_a.f_104204_ = -0.6108652f;
        this.left_leg4_a.f_104205_ = 0.418879f;
        this.left_leg4_a.f_104204_ -= f12;
        this.left_leg4_a.f_104205_ -= f16;
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.shell.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.shell_right.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.shell_left.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.shell_back.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.left_eye.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.left_eye_base.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.right_eye_base.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.right_eye.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.right_arm_a.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.left_arm_a.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.left_leg1_a.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.left_leg2_a.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.left_leg3_a.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.left_leg4_a.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.right_leg1_a.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.right_leg2_a.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.right_leg3_a.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.right_leg4_a.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}

