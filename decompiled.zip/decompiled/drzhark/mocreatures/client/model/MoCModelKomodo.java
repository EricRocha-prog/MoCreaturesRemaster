/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.hunter.MoCEntityKomodo;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelKomodo<T extends MoCEntityKomodo>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "komodo"), "main");
    private final float radianF = 57.29578f;
    private final ModelPart head;
    private final ModelPart neck;
    private final ModelPart nose;
    private final ModelPart mouth;
    private final ModelPart tongue;
    private final ModelPart chest;
    private final ModelPart abdomen;
    private final ModelPart tail;
    private final ModelPart tail1;
    private final ModelPart tail2;
    private final ModelPart tail3;
    private final ModelPart tail4;
    private final ModelPart legFrontLeft;
    private final ModelPart legFrontLeft1;
    private final ModelPart legFrontLeft2;
    private final ModelPart legFrontLeft3;
    private final ModelPart legBackLeft;
    private final ModelPart legBackLeft1;
    private final ModelPart legBackLeft2;
    private final ModelPart legBackLeft3;
    private final ModelPart legFrontRight;
    private final ModelPart legFrontRight1;
    private final ModelPart legFrontRight2;
    private final ModelPart legFrontRight3;
    private final ModelPart legBackRight;
    private final ModelPart legBackRight1;
    private final ModelPart legBackRight2;
    private final ModelPart legBackRight3;
    private final ModelPart saddleA;
    private final ModelPart saddleB;
    private final ModelPart saddleC;
    private boolean isRideable;

    public MoCModelKomodo(ModelPart root) {
        this.head = root.m_171324_("Head");
        this.neck = this.head.m_171324_("Neck");
        this.nose = this.neck.m_171324_("Nose");
        this.mouth = this.neck.m_171324_("Mouth");
        this.tongue = this.mouth.m_171324_("Tongue");
        this.chest = root.m_171324_("Chest");
        this.abdomen = root.m_171324_("Abdomen");
        this.tail = root.m_171324_("Tail");
        this.tail1 = this.tail.m_171324_("Tail1");
        this.tail2 = this.tail1.m_171324_("Tail2");
        this.tail3 = this.tail2.m_171324_("Tail3");
        this.tail4 = this.tail3.m_171324_("Tail4");
        this.legFrontLeft = root.m_171324_("LegFrontLeft");
        this.legFrontLeft1 = this.legFrontLeft.m_171324_("LegFrontLeft1");
        this.legFrontLeft2 = this.legFrontLeft1.m_171324_("LegFrontLeft2");
        this.legFrontLeft3 = this.legFrontLeft2.m_171324_("LegFrontLeft3");
        this.legBackLeft = root.m_171324_("LegBackLeft");
        this.legBackLeft1 = this.legBackLeft.m_171324_("LegBackLeft1");
        this.legBackLeft2 = this.legBackLeft1.m_171324_("LegBackLeft2");
        this.legBackLeft3 = this.legBackLeft2.m_171324_("LegBackLeft3");
        this.legFrontRight = root.m_171324_("LegFrontRight");
        this.legFrontRight1 = this.legFrontRight.m_171324_("LegFrontRight1");
        this.legFrontRight2 = this.legFrontRight1.m_171324_("LegFrontRight2");
        this.legFrontRight3 = this.legFrontRight2.m_171324_("LegFrontRight3");
        this.legBackRight = root.m_171324_("LegBackRight");
        this.legBackRight1 = this.legBackRight.m_171324_("LegBackRight1");
        this.legBackRight2 = this.legBackRight1.m_171324_("LegBackRight2");
        this.legBackRight3 = this.legBackRight2.m_171324_("LegBackRight3");
        this.saddleA = root.m_171324_("SaddleA");
        this.saddleB = root.m_171324_("SaddleB");
        this.saddleC = root.m_171324_("SaddleC");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        PartDefinition head = root.m_171599_("Head", CubeListBuilder.m_171558_(), PartPose.m_171419_((float)0.0f, (float)13.0f, (float)-8.0f));
        PartDefinition neck = head.m_171599_("Neck", CubeListBuilder.m_171558_().m_171514_(22, 34).m_171481_(-2.0f, 0.0f, -6.0f, 4.0f, 5.0f, 6.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        PartDefinition nose = neck.m_171599_("Nose", CubeListBuilder.m_171558_().m_171514_(24, 45).m_171481_(-1.5f, -1.0f, -6.5f, 3.0f, 2.0f, 6.0f), PartPose.m_171419_((float)0.0f, (float)1.0f, (float)-5.0f));
        PartDefinition mouth = neck.m_171599_("Mouth", CubeListBuilder.m_171558_().m_171514_(0, 12).m_171481_(-1.0f, -0.3f, -5.0f, 2.0f, 1.0f, 6.0f), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-5.8f));
        mouth.m_171599_("Tongue", CubeListBuilder.m_171558_().m_171514_(48, 44).m_171481_(-1.5f, 0.0f, -5.0f, 3.0f, 0.0f, 5.0f), PartPose.m_171419_((float)0.0f, (float)-0.4f, (float)-4.7f));
        root.m_171599_("Chest", CubeListBuilder.m_171558_().m_171514_(36, 2).m_171481_(-3.0f, 0.0f, -8.0f, 6.0f, 6.0f, 7.0f), PartPose.m_171419_((float)0.0f, (float)13.0f, (float)0.0f));
        root.m_171599_("Abdomen", CubeListBuilder.m_171558_().m_171514_(36, 49).m_171481_(-3.0f, 0.0f, -1.0f, 6.0f, 7.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)13.0f, (float)0.0f));
        PartDefinition tail = root.m_171599_("Tail", CubeListBuilder.m_171558_(), PartPose.m_171419_((float)0.0f, (float)13.0f, (float)7.0f));
        PartDefinition tail1 = tail.m_171599_("Tail1", CubeListBuilder.m_171558_().m_171514_(0, 21).m_171481_(-2.0f, 0.0f, 0.0f, 4.0f, 5.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        PartDefinition tail2 = tail1.m_171599_("Tail2", CubeListBuilder.m_171558_().m_171514_(0, 34).m_171481_(-1.5f, 0.0f, 0.0f, 3.0f, 4.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)0.1f, (float)7.7f));
        PartDefinition tail3 = tail2.m_171599_("Tail3", CubeListBuilder.m_171558_().m_171514_(0, 46).m_171481_(-1.0f, 0.0f, 0.0f, 2.0f, 3.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)0.1f, (float)7.3f));
        tail3.m_171599_("Tail4", CubeListBuilder.m_171558_().m_171514_(24, 21).m_171481_(-0.5f, 0.0f, 0.0f, 1.0f, 2.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)0.1f, (float)7.0f));
        PartDefinition legFrontLeft = root.m_171599_("LegFrontLeft", CubeListBuilder.m_171558_(), PartPose.m_171419_((float)2.0f, (float)17.0f, (float)-7.0f));
        PartDefinition legFrontLeft1 = legFrontLeft.m_171599_("LegFrontLeft1", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(0.0f, -1.0f, -1.5f, 4.0f, 3.0f, 3.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        PartDefinition legFrontLeft2 = legFrontLeft1.m_171599_("LegFrontLeft2", CubeListBuilder.m_171558_().m_171514_(22, 0).m_171481_(-1.5f, 0.0f, -1.5f, 3.0f, 4.0f, 3.0f), PartPose.m_171419_((float)3.0f, (float)0.5f, (float)0.0f));
        legFrontLeft2.m_171599_("LegFrontLeft3", CubeListBuilder.m_171558_().m_171514_(16, 58).m_171481_(-1.5f, 0.0f, -3.5f, 3.0f, 1.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)4.0f, (float)0.0f, (float)0.0f, (float)-0.17453292f, (float)0.0f));
        PartDefinition legBackLeft = root.m_171599_("LegBackLeft", CubeListBuilder.m_171558_(), PartPose.m_171419_((float)2.0f, (float)17.0f, (float)6.0f));
        PartDefinition legBackLeft1 = legBackLeft.m_171599_("LegBackLeft1", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(0.0f, -1.0f, -1.5f, 4.0f, 3.0f, 3.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        PartDefinition legBackLeft2 = legBackLeft1.m_171599_("LegBackLeft2", CubeListBuilder.m_171558_().m_171514_(22, 0).m_171481_(-1.5f, 0.0f, -1.5f, 3.0f, 4.0f, 3.0f), PartPose.m_171419_((float)3.0f, (float)0.5f, (float)0.0f));
        legBackLeft2.m_171599_("LegBackLeft3", CubeListBuilder.m_171558_().m_171514_(16, 58).m_171481_(-1.5f, 0.0f, -3.5f, 3.0f, 1.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)4.0f, (float)0.0f, (float)0.0f, (float)-0.17453292f, (float)0.0f));
        PartDefinition legFrontRight = root.m_171599_("LegFrontRight", CubeListBuilder.m_171558_(), PartPose.m_171419_((float)-2.0f, (float)17.0f, (float)-7.0f));
        PartDefinition legFrontRight1 = legFrontRight.m_171599_("LegFrontRight1", CubeListBuilder.m_171558_().m_171514_(0, 6).m_171481_(-4.0f, -1.0f, -1.5f, 4.0f, 3.0f, 3.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        PartDefinition legFrontRight2 = legFrontRight1.m_171599_("LegFrontRight2", CubeListBuilder.m_171558_().m_171514_(22, 7).m_171481_(-1.5f, 0.0f, -1.5f, 3.0f, 4.0f, 3.0f), PartPose.m_171419_((float)-3.0f, (float)0.5f, (float)0.0f));
        legFrontRight2.m_171599_("LegFrontRight3", CubeListBuilder.m_171558_().m_171514_(0, 58).m_171481_(-1.5f, 0.0f, -3.5f, 3.0f, 1.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)4.0f, (float)0.0f, (float)0.0f, (float)0.17453292f, (float)0.0f));
        PartDefinition legBackRight = root.m_171599_("LegBackRight", CubeListBuilder.m_171558_(), PartPose.m_171419_((float)-2.0f, (float)17.0f, (float)6.0f));
        PartDefinition legBackRight1 = legBackRight.m_171599_("LegBackRight1", CubeListBuilder.m_171558_().m_171514_(0, 6).m_171481_(-4.0f, -1.0f, -1.5f, 4.0f, 3.0f, 3.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        PartDefinition legBackRight2 = legBackRight1.m_171599_("LegBackRight2", CubeListBuilder.m_171558_().m_171514_(22, 7).m_171481_(-1.5f, 0.0f, -1.5f, 3.0f, 4.0f, 3.0f), PartPose.m_171419_((float)-3.0f, (float)0.5f, (float)0.0f));
        legBackRight2.m_171599_("LegBackRight3", CubeListBuilder.m_171558_().m_171514_(0, 58).m_171481_(-1.5f, 0.0f, -3.5f, 3.0f, 1.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)4.0f, (float)0.0f, (float)0.0f, (float)0.17453292f, (float)0.0f));
        root.m_171599_("SaddleA", CubeListBuilder.m_171558_().m_171514_(36, 28).m_171481_(-2.5f, 0.5f, -4.0f, 5.0f, 1.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)12.0f, (float)0.0f));
        root.m_171599_("SaddleC", CubeListBuilder.m_171558_().m_171514_(36, 37).m_171481_(-2.5f, 0.0f, 2.0f, 5.0f, 1.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)12.0f, (float)0.0f));
        root.m_171599_("SaddleB", CubeListBuilder.m_171558_().m_171514_(54, 37).m_171481_(-1.5f, 0.0f, -4.0f, 3.0f, 1.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)12.0f, (float)0.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)64, (int)64);
    }

    public void setupAnim(T entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float tailLat;
        boolean mouth = ((MoCEntityKomodo)entityIn).mouthCounter != 0;
        boolean sitting = ((MoCEntityKomodo)entityIn).getIsSitting();
        boolean swimming = ((MoCEntityKomodo)entityIn).m_6069_();
        boolean moveTail = ((MoCEntityKomodo)entityIn).tailCounter != 0;
        boolean tongue = ((MoCEntityKomodo)entityIn).tongueCounter != 0;
        float tailXRot = Mth.m_14089_((float)(limbSwing * 0.4f)) * 0.2f * limbSwingAmount;
        float LLegXRot = Mth.m_14089_((float)(limbSwing * 1.2f)) * 1.2f * limbSwingAmount;
        float RLegXRot = Mth.m_14089_((float)(limbSwing * 1.2f + (float)Math.PI)) * 1.2f * limbSwingAmount;
        if (netHeadYaw > 60.0f) {
            netHeadYaw = 60.0f;
        }
        if (netHeadYaw < -60.0f) {
            netHeadYaw = -60.0f;
        }
        float adjustY = 0.0f;
        if (swimming) {
            adjustY = 4.0f;
            this.tail1.f_104203_ = 0.0f - tailXRot;
            this.legFrontLeft1.f_104205_ = 0.0f;
            this.legFrontLeft2.f_104205_ = -1.134464f;
            this.legFrontLeft1.f_104204_ = -1.3962634f;
            this.legBackLeft1.f_104205_ = 0.0f;
            this.legBackLeft2.f_104205_ = -1.134464f;
            this.legBackLeft1.f_104204_ = -1.3962634f;
            this.legFrontRight1.f_104205_ = 0.0f;
            this.legFrontRight2.f_104205_ = 1.134464f;
            this.legFrontRight1.f_104204_ = 1.3962634f;
            this.legBackRight1.f_104205_ = 0.0f;
            this.legBackRight2.f_104205_ = 1.134464f;
            this.legBackRight1.f_104204_ = 1.3962634f;
        } else if (sitting) {
            adjustY = 4.0f;
            this.tail1.f_104203_ = -0.08726646f - tailXRot;
            this.legFrontLeft1.f_104205_ = -0.5235988f;
            this.legFrontLeft2.f_104205_ = 0.0f;
            this.legFrontLeft1.f_104204_ = 0.0f;
            this.legBackLeft1.f_104205_ = 0.0f;
            this.legBackLeft2.f_104205_ = -1.134464f;
            this.legBackLeft1.f_104204_ = -0.6981317f;
            this.legFrontRight1.f_104205_ = 0.5235988f;
            this.legFrontRight2.f_104205_ = 0.0f;
            this.legFrontRight1.f_104204_ = 0.0f;
            this.legBackRight1.f_104205_ = 0.0f;
            this.legBackRight2.f_104205_ = 1.134464f;
            this.legBackRight1.f_104204_ = 0.6981317f;
        } else {
            this.tail1.f_104203_ = -0.2617994f - tailXRot;
            this.legFrontLeft1.f_104205_ = 0.5235988f;
            this.legFrontLeft2.f_104205_ = -0.5235988f;
            this.legFrontLeft1.f_104204_ = LLegXRot;
            this.legFrontLeft2.f_104203_ = -LLegXRot;
            this.legBackLeft1.f_104205_ = 0.5235988f;
            this.legBackLeft2.f_104205_ = -0.5235988f;
            this.legBackLeft1.f_104204_ = RLegXRot;
            this.legBackLeft2.f_104203_ = -RLegXRot;
            this.legFrontRight1.f_104205_ = -0.5235988f;
            this.legFrontRight2.f_104205_ = 0.5235988f;
            this.legFrontRight1.f_104204_ = -RLegXRot;
            this.legFrontRight2.f_104203_ = -RLegXRot;
            this.legBackRight1.f_104205_ = -0.5235988f;
            this.legBackRight2.f_104205_ = 0.5235988f;
            this.legBackRight1.f_104204_ = -LLegXRot;
            this.legBackRight2.f_104203_ = -LLegXRot;
        }
        this.tail.f_104201_ = adjustY + 13.0f;
        this.head.f_104201_ = adjustY + 13.0f;
        this.chest.f_104201_ = adjustY + 13.0f;
        this.legFrontLeft.f_104201_ = adjustY + 17.0f;
        this.legBackLeft.f_104201_ = adjustY + 17.0f;
        this.legFrontRight.f_104201_ = adjustY + 17.0f;
        this.legBackRight.f_104201_ = adjustY + 17.0f;
        this.abdomen.f_104201_ = adjustY + 13.0f;
        this.saddleA.f_104201_ = adjustY + 12.0f;
        this.saddleB.f_104201_ = adjustY + 12.0f;
        this.saddleC.f_104201_ = adjustY + 12.0f;
        float tongueF = 0.0f;
        if (!mouth && tongue) {
            tongueF = Mth.m_14089_((float)(ageInTicks * 3.0f)) / 10.0f;
            this.tongue.f_104202_ = -4.7f;
        } else {
            this.tongue.f_104202_ = 0.3f;
        }
        float mouthF = 0.0f;
        if (mouth) {
            mouthF = 0.61086524f;
            this.tongue.f_104202_ = -0.8f;
        }
        this.neck.f_104203_ = 0.19198622f + headPitch * 0.33f / 57.29578f;
        this.nose.f_104203_ = 0.1850049f + headPitch * 0.66f / 57.29578f;
        this.mouth.f_104203_ = mouthF + -0.052359875f + headPitch * 0.66f / 57.29578f;
        this.tongue.f_104203_ = tongueF;
        this.neck.f_104204_ = netHeadYaw * 0.33f / 57.29578f;
        this.nose.f_104204_ = netHeadYaw * 0.66f / 57.29578f;
        this.mouth.f_104204_ = netHeadYaw * 0.66f / 57.29578f;
        this.tail2.f_104203_ = -0.29670596f + tailXRot;
        this.tail3.f_104203_ = 0.2268928f + tailXRot;
        this.tail4.f_104203_ = 0.19198622f + tailXRot;
        float t = limbSwing / 2.0f;
        if (moveTail) {
            t = ageInTicks / 4.0f;
        }
        float A = 0.35f;
        float w = 0.6f;
        float k = 0.6f;
        int i = 0;
        this.tail1.f_104204_ = tailLat = A * Mth.m_14031_((float)(w * t - k * (float)i++));
        this.tail2.f_104204_ = tailLat = A * Mth.m_14031_((float)(w * t - k * (float)i++));
        this.tail3.f_104204_ = tailLat = A * Mth.m_14031_((float)(w * t - k * (float)i++));
        this.tail4.f_104204_ = tailLat = A * Mth.m_14031_((float)(w * t - k * (float)i++));
        this.isRideable = ((MoCEntityKomodo)entityIn).getIsRideable();
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.tail.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.head.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.chest.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.legFrontLeft.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.legBackLeft.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.legFrontRight.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.legBackRight.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.abdomen.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        if (this.isRideable) {
            this.saddleA.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.saddleC.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.saddleB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        }
    }
}

