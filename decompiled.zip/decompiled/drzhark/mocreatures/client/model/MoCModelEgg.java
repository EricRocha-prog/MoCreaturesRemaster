/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.item.MoCEntityEgg;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelEgg<T extends MoCEntityEgg>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "egg"), "main");
    private final ModelPart egg1;
    private final ModelPart egg2;
    private final ModelPart egg3;
    private final ModelPart egg4;
    private final ModelPart egg5;

    public MoCModelEgg(ModelPart root) {
        this.egg1 = root.m_171324_("egg1");
        this.egg2 = root.m_171324_("egg2");
        this.egg3 = root.m_171324_("egg3");
        this.egg4 = root.m_171324_("egg4");
        this.egg5 = root.m_171324_("egg5");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        root.m_171599_("egg1", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(0.0f, 0.0f, 0.0f, 3.0f, 3.0f, 3.0f), PartPose.m_171419_((float)0.0f, (float)20.0f, (float)0.0f));
        root.m_171599_("egg2", CubeListBuilder.m_171558_().m_171514_(10, 0).m_171481_(0.0f, 0.0f, 0.0f, 2.0f, 1.0f, 2.0f), PartPose.m_171419_((float)0.5f, (float)19.5f, (float)0.5f));
        root.m_171599_("egg3", CubeListBuilder.m_171558_().m_171514_(30, 0).m_171481_(0.0f, 0.0f, 0.0f, 2.0f, 1.0f, 2.0f), PartPose.m_171419_((float)0.5f, (float)22.5f, (float)0.5f));
        root.m_171599_("egg4", CubeListBuilder.m_171558_().m_171514_(24, 0).m_171481_(0.0f, 0.0f, 0.0f, 1.0f, 2.0f, 2.0f), PartPose.m_171419_((float)-0.5f, (float)20.5f, (float)0.5f));
        root.m_171599_("egg5", CubeListBuilder.m_171558_().m_171514_(18, 0).m_171481_(0.0f, 0.0f, 0.0f, 1.0f, 2.0f, 2.0f), PartPose.m_171419_((float)2.5f, (float)20.5f, (float)0.5f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)64, (int)32);
    }

    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.egg1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.egg2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.egg3.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.egg4.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.egg5.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}

