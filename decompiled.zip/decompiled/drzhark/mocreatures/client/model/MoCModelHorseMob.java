/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.client.model.MoCModelAbstractHorse;
import drzhark.mocreatures.entity.MoCEntityMob;
import drzhark.mocreatures.entity.hostile.MoCEntityHorseMob;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelHorseMob<T extends MoCEntityHorseMob>
extends MoCModelAbstractHorse<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "horse"), "main");
    private int typeMob;
    private boolean openMouth;
    private boolean flyer;
    private boolean isUnicorned;

    public MoCModelHorseMob(ModelPart root) {
        super(root);
    }

    public void setupAnim(T entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.type = 0;
        this.typeMob = ((MoCEntityMob)entityIn).getTypeMoC();
        this.wings = ((MoCEntityHorseMob)entityIn).isFlyer();
        this.flyer = ((MoCEntityHorseMob)entityIn).isFlyer();
        this.eating = ((MoCEntityHorseMob)entityIn).eatingCounter != 0;
        this.standing = ((MoCEntityHorseMob)entityIn).standCounter != 0 && entityIn.m_20202_() == null;
        this.openMouth = ((MoCEntityHorseMob)entityIn).mouthCounter != 0;
        this.moveTail = ((MoCEntityHorseMob)entityIn).tailCounter != 0;
        this.flapwings = ((MoCEntityHorseMob)entityIn).wingFlapCounter != 0;
        this.rider = entityIn.m_20159_();
        this.floating = ((MoCEntityHorseMob)entityIn).isFlyer() && ((MoCEntityHorseMob)entityIn).isOnAir();
        this.isUnicorned = ((MoCEntityHorseMob)entityIn).isUnicorned();
        this.saddled = false;
        this.shuffling = false;
        super.m_6973_(entityIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
    }

    @Override
    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.ear1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.ear2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.neck.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.head.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        if (this.openMouth) {
            this.uMouth2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.lMouth2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        } else {
            this.uMouth.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.lMouth.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        }
        this.mane.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.body.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.tailA.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.tailB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.tailC.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg1A.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg1B.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg1C.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg2A.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg2B.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg2C.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg3A.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg3B.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg3C.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg4A.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg4B.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg4C.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        if (this.isUnicorned) {
            this.unicorn.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        }
        if (this.flyer && this.typeMob != 34 && this.typeMob != 36) {
            this.midWing.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.innerWing.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.outerWing.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.innerWingR.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.midWingR.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.outerWingR.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        }
    }

    public static LayerDefinition createBodyLayer() {
        return MoCModelAbstractHorse.createBodyLayer();
    }
}

