/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeDeformation
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.neutral.MoCEntityGoat;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelGoat<T extends MoCEntityGoat>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "goat"), "main");
    public int typeInt;
    public int attacking;
    public float age;
    public boolean bleat;
    public int legMov;
    public int earMov;
    public int tailMov;
    public int eatMov;
    private float prevTailAngleX;
    private float prevLEarAngleX;
    private float prevREarAngleX;
    private float prevMouthAngleX;
    private final ModelPart leg1;
    private final ModelPart leg2;
    private final ModelPart leg3;
    private final ModelPart leg4;
    private final ModelPart body;
    private final ModelPart tail;
    private final ModelPart lEar;
    private final ModelPart rEar;
    private final ModelPart head;
    private final ModelPart nose;
    private final ModelPart tongue;
    private final ModelPart mouth;
    private final ModelPart rHorn1;
    private final ModelPart rHorn2;
    private final ModelPart rHorn3;
    private final ModelPart rHorn4;
    private final ModelPart rHorn5;
    private final ModelPart lHorn1;
    private final ModelPart lHorn2;
    private final ModelPart lHorn3;
    private final ModelPart lHorn4;
    private final ModelPart lHorn5;
    private final ModelPart goatie;
    private final ModelPart neck;
    private final ModelPart tits;

    public MoCModelGoat(ModelPart root) {
        this.leg1 = root.m_171324_("leg1");
        this.leg2 = root.m_171324_("leg2");
        this.leg3 = root.m_171324_("leg3");
        this.leg4 = root.m_171324_("leg4");
        this.body = root.m_171324_("body");
        this.tail = root.m_171324_("tail");
        this.lEar = root.m_171324_("l_ear");
        this.rEar = root.m_171324_("r_ear");
        this.head = root.m_171324_("head");
        this.nose = root.m_171324_("nose");
        this.tongue = root.m_171324_("tongue");
        this.mouth = root.m_171324_("mouth");
        this.rHorn1 = root.m_171324_("r_horn1");
        this.rHorn2 = root.m_171324_("r_horn2");
        this.rHorn3 = root.m_171324_("r_horn3");
        this.rHorn4 = root.m_171324_("r_horn4");
        this.rHorn5 = root.m_171324_("r_horn5");
        this.lHorn1 = root.m_171324_("l_horn1");
        this.lHorn2 = root.m_171324_("l_horn2");
        this.lHorn3 = root.m_171324_("l_horn3");
        this.lHorn4 = root.m_171324_("l_horn4");
        this.lHorn5 = root.m_171324_("l_horn5");
        this.goatie = root.m_171324_("goatie");
        this.neck = root.m_171324_("neck");
        this.tits = root.m_171324_("tits");
    }

    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float interpMouth;
        float interpTail;
        this.leg1.f_104203_ = Mth.m_14089_((float)(limbSwing * 0.6662f)) * 1.4f * limbSwingAmount;
        this.leg2.f_104203_ = Mth.m_14089_((float)(limbSwing * 0.6662f + (float)Math.PI)) * 1.4f * limbSwingAmount;
        this.leg3.f_104203_ = Mth.m_14089_((float)(limbSwing * 0.6662f + (float)Math.PI)) * 1.4f * limbSwingAmount;
        this.leg4.f_104203_ = Mth.m_14089_((float)(limbSwing * 0.6662f)) * 1.4f * limbSwingAmount;
        float headYawClamped = netHeadYaw;
        if (headYawClamped > 20.0f) {
            headYawClamped = 20.0f;
        }
        if (headYawClamped < -20.0f) {
            headYawClamped = -20.0f;
        }
        float headYawRad = headYawClamped * ((float)Math.PI / 180);
        float headPitchRad = headPitch * ((float)Math.PI / 180);
        float baseAngle = 0.5235988f + headPitchRad;
        this.head.f_104204_ = headYawRad;
        this.neck.f_104203_ = -0.5235988f;
        this.head.f_104203_ = baseAngle;
        if (this.bleat) {
            this.head.f_104203_ = -0.2617994f;
        }
        if (this.attacking != 0) {
            float attackRad;
            this.head.f_104203_ = attackRad = (float)this.attacking * ((float)Math.PI / 180);
            this.neck.f_104203_ = (1.33f * (float)this.attacking - 70.0f) * ((float)Math.PI / 180);
            if (this.legMov != 0) {
                this.leg1.f_104203_ = (float)this.legMov * ((float)Math.PI / 180);
            }
        }
        this.nose.f_104203_ = this.head.f_104203_;
        this.nose.f_104204_ = this.head.f_104204_;
        this.tongue.f_104203_ = this.head.f_104203_;
        this.tongue.f_104204_ = this.head.f_104204_;
        this.goatie.f_104203_ = this.head.f_104203_;
        this.goatie.f_104204_ = this.head.f_104204_;
        this.rHorn1.f_104203_ = this.head.f_104203_;
        this.rHorn1.f_104204_ = this.head.f_104204_;
        this.lHorn1.f_104203_ = this.head.f_104203_;
        this.lHorn1.f_104204_ = this.head.f_104204_;
        this.rHorn2.f_104203_ = this.head.f_104203_;
        this.rHorn2.f_104204_ = this.head.f_104204_;
        this.lHorn2.f_104203_ = this.head.f_104203_;
        this.lHorn2.f_104204_ = this.head.f_104204_;
        this.rHorn3.f_104203_ = this.head.f_104203_;
        this.rHorn3.f_104204_ = this.head.f_104204_;
        this.lHorn3.f_104203_ = this.head.f_104203_;
        this.lHorn3.f_104204_ = this.head.f_104204_;
        this.rHorn4.f_104203_ = this.head.f_104203_;
        this.rHorn4.f_104204_ = this.head.f_104204_;
        this.lHorn4.f_104203_ = this.head.f_104203_;
        this.lHorn4.f_104204_ = this.head.f_104204_;
        this.rHorn5.f_104203_ = this.head.f_104203_;
        this.rHorn5.f_104204_ = this.head.f_104204_;
        this.lHorn5.f_104203_ = this.head.f_104203_;
        this.lHorn5.f_104204_ = this.head.f_104204_;
        this.mouth.f_104204_ = this.head.f_104204_;
        this.lEar.f_104204_ = this.head.f_104204_;
        this.rEar.f_104204_ = this.head.f_104204_;
        float interp = 0.1f;
        float targetTailX = (float)this.tailMov * ((float)Math.PI / 180);
        this.tail.f_104203_ = interpTail = this.prevTailAngleX + (targetTailX - this.prevTailAngleX) * interp;
        float targetEarX = !this.bleat && this.attacking == 0 ? baseAngle + (float)this.earMov * ((float)Math.PI / 180) : this.head.f_104203_;
        float interpLEar = this.prevLEarAngleX + (targetEarX - this.prevLEarAngleX) * interp;
        float interpREar = this.prevREarAngleX + (targetEarX - this.prevREarAngleX) * interp;
        this.lEar.f_104203_ = interpLEar;
        this.rEar.f_104203_ = interpREar;
        float targetMouthX = this.bleat ? 0.0f : (this.attacking != 0 ? (float)this.attacking * ((float)Math.PI / 180) : baseAngle);
        this.mouth.f_104203_ = interpMouth = this.prevMouthAngleX + (targetMouthX - this.prevMouthAngleX) * interp;
        this.prevTailAngleX = interpTail;
        this.prevLEarAngleX = interpLEar;
        this.prevREarAngleX = interpREar;
        this.prevMouthAngleX = interpMouth;
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.leg1.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg2.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg3.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg4.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.body.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.tail.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.neck.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        if (this.typeInt > 1 && this.typeInt < 5) {
            this.tits.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        }
        poseStack.m_85836_();
        if (this.attacking != 0) {
            float yOff = (float)this.attacking / 150.0f - 0.2f;
            float zOff = (float)this.attacking / 450.0f - 0.06666667f;
            poseStack.m_252880_(0.0f, yOff, -zOff);
        }
        this.lEar.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.rEar.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.head.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.nose.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        if (this.typeInt > 1) {
            if (this.age > 0.7f) {
                this.rHorn1.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
                this.lHorn1.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
            }
            if (this.age > 0.8f) {
                this.rHorn2.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
                this.lHorn2.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
            }
        }
        if (this.typeInt > 4) {
            if (this.age > 0.8f) {
                this.rHorn3.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
                this.lHorn3.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
            }
            if (this.age > 0.85f) {
                this.rHorn4.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
                this.lHorn4.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
            }
            if (this.age > 0.9f) {
                this.rHorn5.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
                this.lHorn5.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
            }
        }
        if (this.eatMov != 0 && !this.bleat) {
            poseStack.m_252880_((float)this.eatMov / 100.0f, 0.0f, 0.0f);
        }
        if (this.typeInt > 4 && this.age > 0.9f) {
            this.goatie.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        }
        this.tongue.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.mouth.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        poseStack.m_85849_();
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        root.m_171599_("leg1", CubeListBuilder.m_171558_().m_171514_(0, 23).m_171488_(-1.0f, 0.0f, -1.0f, 2.0f, 7.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)2.0f, (float)17.0f, (float)-6.0f));
        root.m_171599_("leg2", CubeListBuilder.m_171558_().m_171514_(0, 23).m_171488_(-1.0f, 0.0f, -1.0f, 2.0f, 7.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-2.0f, (float)17.0f, (float)-6.0f));
        root.m_171599_("leg3", CubeListBuilder.m_171558_().m_171514_(0, 23).m_171488_(-1.0f, 0.0f, -1.0f, 2.0f, 7.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-2.0f, (float)17.0f, (float)6.0f));
        root.m_171599_("leg4", CubeListBuilder.m_171558_().m_171514_(0, 23).m_171488_(-1.0f, 0.0f, -1.0f, 2.0f, 7.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)2.0f, (float)17.0f, (float)6.0f));
        root.m_171599_("body", CubeListBuilder.m_171558_().m_171514_(20, 8).m_171488_(-3.0f, -4.0f, -8.0f, 6.0f, 8.0f, 16.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)13.0f, (float)0.0f));
        root.m_171599_("tail", CubeListBuilder.m_171558_().m_171514_(22, 8).m_171488_(-1.5f, -1.0f, 0.0f, 3.0f, 2.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)10.0f, (float)8.0f));
        root.m_171599_("l_ear", CubeListBuilder.m_171558_().m_171514_(52, 8).m_171488_(1.5f, -2.0f, 0.0f, 2.0f, 1.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)8.0f, (float)-12.0f));
        root.m_171599_("r_ear", CubeListBuilder.m_171558_().m_171514_(52, 8).m_171488_(-3.5f, -2.0f, 0.0f, 2.0f, 1.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)8.0f, (float)-12.0f));
        root.m_171599_("head", CubeListBuilder.m_171558_().m_171514_(52, 16).m_171488_(-1.5f, -2.0f, -2.0f, 3.0f, 5.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)8.0f, (float)-12.0f));
        root.m_171599_("nose", CubeListBuilder.m_171558_().m_171514_(52, 10).m_171488_(-1.5f, -1.0f, -5.0f, 3.0f, 3.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)8.0f, (float)-12.0f));
        root.m_171599_("tongue", CubeListBuilder.m_171558_().m_171514_(56, 5).m_171488_(-0.5f, 2.0f, -5.0f, 1.0f, 0.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)8.0f, (float)-12.0f));
        root.m_171599_("mouth", CubeListBuilder.m_171558_().m_171514_(54, 0).m_171488_(-1.0f, 2.0f, -5.0f, 2.0f, 1.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)8.0f, (float)-12.0f));
        root.m_171599_("r_horn1", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-1.5f, -3.0f, -0.7f, 1.0f, 1.0f, 1.0f, new CubeDeformation(0.1f)), PartPose.m_171419_((float)0.0f, (float)8.0f, (float)-12.0f));
        root.m_171599_("r_horn2", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-1.9f, -4.0f, -0.2f, 1.0f, 1.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)8.0f, (float)-12.0f));
        root.m_171599_("r_horn3", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-2.1f, -4.8f, 0.5f, 1.0f, 1.0f, 1.0f, new CubeDeformation(-0.05f)), PartPose.m_171419_((float)0.0f, (float)8.0f, (float)-12.0f));
        root.m_171599_("r_horn4", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-2.3f, -5.2f, 1.4f, 1.0f, 1.0f, 1.0f, new CubeDeformation(-0.1f)), PartPose.m_171419_((float)0.0f, (float)8.0f, (float)-12.0f));
        root.m_171599_("r_horn5", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-2.6f, -4.9f, 2.0f, 1.0f, 1.0f, 1.0f, new CubeDeformation(-0.15f)), PartPose.m_171419_((float)0.0f, (float)8.0f, (float)-12.0f));
        root.m_171599_("l_horn1", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(0.5f, -3.0f, -0.7f, 1.0f, 1.0f, 1.0f, new CubeDeformation(0.1f)), PartPose.m_171419_((float)0.0f, (float)8.0f, (float)-12.0f));
        root.m_171599_("l_horn2", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(0.9f, -4.0f, -0.2f, 1.0f, 1.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)8.0f, (float)-12.0f));
        root.m_171599_("l_horn3", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(1.2f, -4.9f, 0.5f, 1.0f, 1.0f, 1.0f, new CubeDeformation(-0.05f)), PartPose.m_171419_((float)0.0f, (float)8.0f, (float)-12.0f));
        root.m_171599_("l_horn4", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(1.4f, -5.3f, 1.4f, 1.0f, 1.0f, 1.0f, new CubeDeformation(-0.1f)), PartPose.m_171419_((float)0.0f, (float)8.0f, (float)-12.0f));
        root.m_171599_("l_horn5", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(1.7f, -4.9f, 2.1f, 1.0f, 1.0f, 1.0f, new CubeDeformation(-0.15f)), PartPose.m_171419_((float)0.0f, (float)8.0f, (float)-12.0f));
        root.m_171599_("goatie", CubeListBuilder.m_171558_().m_171514_(52, 5).m_171488_(-0.5f, 3.0f, -4.0f, 1.0f, 2.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)8.0f, (float)-12.0f));
        root.m_171599_("neck", CubeListBuilder.m_171558_().m_171514_(18, 14).m_171488_(-1.5f, -2.0f, -5.0f, 3.0f, 4.0f, 6.0f, new CubeDeformation(-0.2f)), PartPose.m_171423_((float)0.0f, (float)11.0f, (float)-8.0f, (float)-0.418879f, (float)0.0f, (float)0.0f));
        root.m_171599_("tits", CubeListBuilder.m_171558_().m_171514_(18, 0).m_171488_(-2.5f, 0.0f, -2.0f, 5.0f, 1.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)17.0f, (float)3.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)64, (int)32);
    }
}

