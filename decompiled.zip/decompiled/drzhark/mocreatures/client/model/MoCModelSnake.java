/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeDeformation
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.MoCEntityAnimal;
import drzhark.mocreatures.entity.hunter.MoCEntitySnake;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelSnake<T extends MoCEntitySnake>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "snake"), "main");
    private static final int BODY_PARTS = 40;
    private final ModelPart[] bodySnake = new ModelPart[40];
    private final ModelPart head;
    private final ModelPart nose;
    private final ModelPart lNose;
    private final ModelPart teethUR;
    private final ModelPart teethUL;
    private final ModelPart tongue0;
    private final ModelPart tongue;
    private final ModelPart tongue1;
    private final ModelPart tail;
    private final ModelPart wing1L;
    private final ModelPart wing1R;
    private final ModelPart wing2L;
    private final ModelPart wing2R;
    private final ModelPart wing3L;
    private final ModelPart wing3R;
    private final ModelPart wing4L;
    private final ModelPart wing4R;
    private final ModelPart wing5L;
    private final ModelPart wing5R;
    private int typeI;
    private float tongueOff;
    private float mouthOff;
    private float rattleOff;
    private boolean climbing;
    private boolean isResting;
    private int movInt;
    private float f6;
    private boolean nearPlayer;
    private boolean picked;
    private float limbSwing;

    public MoCModelSnake(ModelPart root) {
        for (int i = 0; i < 40; ++i) {
            this.bodySnake[i] = root.m_171324_("bodySnake" + i);
        }
        this.head = root.m_171324_("head");
        this.nose = root.m_171324_("nose");
        this.lNose = root.m_171324_("lNose");
        this.teethUR = root.m_171324_("teethUR");
        this.teethUL = root.m_171324_("teethUL");
        this.tongue0 = root.m_171324_("tongue0");
        this.tongue = root.m_171324_("tongue");
        this.tongue1 = root.m_171324_("tongue1");
        this.tail = root.m_171324_("tail");
        this.wing1L = root.m_171324_("wing1L");
        this.wing1R = root.m_171324_("wing1R");
        this.wing2L = root.m_171324_("wing2L");
        this.wing2R = root.m_171324_("wing2R");
        this.wing3L = root.m_171324_("wing3L");
        this.wing3R = root.m_171324_("wing3R");
        this.wing4L = root.m_171324_("wing4L");
        this.wing4R = root.m_171324_("wing4R");
        this.wing5L = root.m_171324_("wing5L");
        this.wing5R = root.m_171324_("wing5R");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        float fsegm = 0.125f;
        float fsep = -1.6f;
        for (int i = 0; i < 40; ++i) {
            float fport = ((float)i + 1.0f) / 40.0f;
            float factor = fport < fsegm ? -0.2f : (fport < fsegm * 2.0f ? -0.15f : (fport < fsegm * 4.0f ? 0.0f : (fport < fsegm * 6.0f ? 0.0f : (fport < fsegm * 7.0f ? -0.15f : -0.2f))));
            int j = i % 2 == 0 ? 0 : 4;
            float flength = (20.0f - (float)i) * fsep;
            root.m_171599_("bodySnake" + i, CubeListBuilder.m_171558_().m_171514_(8, j).m_171488_(-1.0f, -0.5f, 0.0f, 2.0f, 2.0f, 2.0f, new CubeDeformation(factor)), PartPose.m_171419_((float)0.0f, (float)23.0f, (float)flength));
        }
        float flengthTail = -19.0f * fsep;
        root.m_171599_("tail", CubeListBuilder.m_171558_().m_171514_(36, 0).m_171481_(-0.5f, 0.5f, -1.0f, 1.0f, 1.0f, 5.0f), PartPose.m_171419_((float)0.0f, (float)23.0f, (float)flengthTail));
        float flengthHead = 20.0f * fsep;
        root.m_171599_("head", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-1.0f, -0.5f, -2.0f, 2.0f, 2.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)23.0f, (float)flengthHead));
        root.m_171599_("nose", CubeListBuilder.m_171558_().m_171514_(16, 0).m_171481_(-0.5f, -0.3f, -4.0f, 1.0f, 1.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)23.0f, (float)flengthHead));
        root.m_171599_("lNose", CubeListBuilder.m_171558_().m_171514_(22, 0).m_171481_(-0.5f, 0.3f, -4.0f, 1.0f, 1.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)23.0f, (float)flengthHead));
        root.m_171599_("teethUR", CubeListBuilder.m_171558_().m_171514_(46, 0).m_171481_(-0.4f, 0.3f, -3.8f, 0.0f, 1.0f, 1.0f), PartPose.m_171419_((float)0.0f, (float)23.0f, (float)flengthHead));
        root.m_171599_("teethUL", CubeListBuilder.m_171558_().m_171514_(44, 0).m_171481_(0.4f, 0.3f, -3.8f, 0.0f, 1.0f, 1.0f), PartPose.m_171419_((float)0.0f, (float)23.0f, (float)flengthHead));
        root.m_171599_("tongue0", CubeListBuilder.m_171558_().m_171514_(28, 0).m_171481_(-0.5f, 0.25f, -4.0f, 1.0f, 0.0f, 3.0f), PartPose.m_171419_((float)0.0f, (float)23.0f, (float)flengthHead));
        root.m_171599_("tongue", CubeListBuilder.m_171558_().m_171514_(28, 0).m_171481_(-0.5f, 0.5f, -6.0f, 1.0f, 0.0f, 3.0f), PartPose.m_171419_((float)0.0f, (float)23.0f, (float)flengthHead));
        root.m_171599_("tongue1", CubeListBuilder.m_171558_().m_171514_(28, 0).m_171481_(-0.5f, 0.5f, -5.0f, 1.0f, 0.0f, 3.0f), PartPose.m_171419_((float)0.0f, (float)23.0f, (float)flengthHead));
        float z1 = 19.0f * fsep;
        root.m_171599_("wing1L", CubeListBuilder.m_171558_().m_171514_(8, 4).m_171481_(0.0f, -0.5f, 0.0f, 2.0f, 2.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)23.0f, (float)z1));
        root.m_171599_("wing1R", CubeListBuilder.m_171558_().m_171514_(8, 4).m_171480_().m_171481_(-2.0f, -0.5f, 0.0f, 2.0f, 2.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)23.0f, (float)z1));
        float z2 = 18.0f * fsep;
        root.m_171599_("wing2L", CubeListBuilder.m_171558_().m_171514_(8, 4).m_171481_(0.5f, -0.5f, 0.0f, 2.0f, 2.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)23.0f, (float)z2));
        root.m_171599_("wing2R", CubeListBuilder.m_171558_().m_171514_(8, 4).m_171480_().m_171481_(-2.5f, -0.5f, 0.0f, 2.0f, 2.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)23.0f, (float)z2));
        float z3 = 17.0f * fsep;
        root.m_171599_("wing3L", CubeListBuilder.m_171558_().m_171514_(16, 4).m_171481_(1.0f, -0.5f, 0.0f, 2.0f, 2.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)23.0f, (float)z3));
        root.m_171599_("wing3R", CubeListBuilder.m_171558_().m_171514_(16, 4).m_171480_().m_171481_(-3.0f, -0.5f, 0.0f, 2.0f, 2.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)23.0f, (float)z3));
        float z4 = 16.0f * fsep;
        root.m_171599_("wing4L", CubeListBuilder.m_171558_().m_171514_(16, 8).m_171481_(0.5f, -0.5f, 0.0f, 2.0f, 2.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)23.0f, (float)z4));
        root.m_171599_("wing4R", CubeListBuilder.m_171558_().m_171514_(16, 8).m_171480_().m_171481_(-2.5f, -0.5f, 0.0f, 2.0f, 2.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)23.0f, (float)z4));
        float z5 = 15.0f * fsep;
        root.m_171599_("wing5L", CubeListBuilder.m_171558_().m_171514_(16, 8).m_171481_(0.0f, -0.5f, 0.0f, 2.0f, 2.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)23.0f, (float)z5));
        root.m_171599_("wing5R", CubeListBuilder.m_171558_().m_171514_(16, 8).m_171480_().m_171481_(-2.0f, -0.5f, 0.0f, 2.0f, 2.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)23.0f, (float)z5));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)64, (int)32);
    }

    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.typeI = ((MoCEntityAnimal)entity).getTypeMoC();
        this.tongueOff = ((MoCEntitySnake)entity).getfTongue();
        this.mouthOff = ((MoCEntitySnake)entity).getfMouth();
        this.rattleOff = ((MoCEntitySnake)entity).getfRattle();
        this.climbing = ((MoCEntitySnake)entity).isClimbing();
        this.isResting = ((MoCEntitySnake)entity).isResting();
        this.movInt = ((MoCEntitySnake)entity).getMovInt();
        this.f6 = ((MoCEntitySnake)entity).bodyswing;
        this.nearPlayer = ((MoCEntitySnake)entity).getNearPlayer();
        this.picked = ((MoCEntitySnake)entity).pickedUp();
        this.limbSwing = limbSwing;
        float rAX = headPitch / 57.29578f;
        float rAY = netHeadYaw / 57.29578f;
        this.head.f_104203_ = rAX;
        this.head.f_104204_ = rAY;
        this.bodySnake[0].f_104203_ = rAX * 0.95f;
        this.bodySnake[1].f_104203_ = rAX * 0.9f;
        this.bodySnake[2].f_104203_ = rAX * 0.85f;
        this.bodySnake[3].f_104203_ = rAX * 0.8f;
        this.bodySnake[4].f_104203_ = rAX * 0.75f;
        float f8 = Mth.m_14089_((float)(this.tongueOff * 10.0f)) / 40.0f;
        this.nose.f_104203_ = this.head.f_104203_ - this.mouthOff;
        this.lNose.f_104203_ = this.head.f_104203_ + this.mouthOff;
        this.tongue1.f_104203_ = this.head.f_104203_ + f8;
        this.tongue.f_104203_ = this.head.f_104203_ + f8;
        this.tongue0.f_104203_ = this.lNose.f_104203_;
        this.teethUR.f_104203_ = this.head.f_104203_ - this.mouthOff;
        this.teethUL.f_104203_ = this.head.f_104203_ - this.mouthOff;
        this.bodySnake[0].f_104204_ = rAY * 0.85f;
        this.bodySnake[1].f_104204_ = rAY * 0.65f;
        this.bodySnake[2].f_104204_ = rAY * 0.45f;
        this.bodySnake[3].f_104204_ = rAY * 0.25f;
        this.bodySnake[4].f_104204_ = rAY * 0.1f;
        this.nose.f_104204_ = this.head.f_104204_;
        this.lNose.f_104204_ = this.head.f_104204_;
        this.tongue0.f_104204_ = this.head.f_104204_;
        this.tongue.f_104204_ = this.head.f_104204_;
        this.tongue1.f_104204_ = this.head.f_104204_;
        this.teethUR.f_104204_ = this.head.f_104204_;
        this.teethUL.f_104204_ = this.head.f_104204_;
        if (this.typeI == 6) {
            this.wing1L.f_104203_ = this.bodySnake[1].f_104203_;
            this.wing1L.f_104204_ = this.bodySnake[1].f_104204_;
            this.wing1R.f_104203_ = this.bodySnake[1].f_104203_;
            this.wing1R.f_104204_ = this.bodySnake[1].f_104204_;
            this.wing2L.f_104203_ = this.bodySnake[2].f_104203_;
            this.wing2L.f_104204_ = this.bodySnake[2].f_104204_;
            this.wing2R.f_104203_ = this.bodySnake[2].f_104203_;
            this.wing2R.f_104204_ = this.bodySnake[2].f_104204_;
            this.wing3L.f_104203_ = this.bodySnake[3].f_104203_;
            this.wing3L.f_104204_ = this.bodySnake[3].f_104204_;
            this.wing3R.f_104203_ = this.bodySnake[3].f_104203_;
            this.wing3R.f_104204_ = this.bodySnake[3].f_104204_;
            this.wing4L.f_104203_ = this.bodySnake[4].f_104203_;
            this.wing4L.f_104204_ = this.bodySnake[4].f_104204_;
            this.wing4R.f_104203_ = this.bodySnake[4].f_104203_;
            this.wing4R.f_104204_ = this.bodySnake[4].f_104204_;
            this.wing5L.f_104203_ = this.bodySnake[4].f_104203_;
            this.wing5L.f_104204_ = this.bodySnake[4].f_104204_;
            this.wing5R.f_104203_ = this.bodySnake[4].f_104203_;
            this.wing5R.f_104204_ = this.bodySnake[4].f_104204_;
        }
        if (this.typeI == 7) {
            this.tail.f_104203_ = this.nearPlayer || this.rattleOff != 0.0f ? (Mth.m_14089_((float)(netHeadYaw * 10.0f)) * 20.0f + 90.0f) / 57.29578f : 0.0f;
        }
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        float A = 0.4f;
        float w = 1.5f;
        float t = this.limbSwing / 2.0f;
        for (int i = 0; i < 40; ++i) {
            float yOff;
            float sideperf = 1.0f;
            poseStack.m_85836_();
            if (!this.isResting) {
                if (this.climbing && i < 20) {
                    yOff = ((float)i - 20.0f) * 0.08f;
                    poseStack.m_252880_(0.0f, yOff / 3.0f, -yOff * 1.2f);
                } else if ((this.nearPlayer || this.picked) && i < 13) {
                    yOff = ((float)i - 13.333333f) * 0.09f;
                    float zOff = ((float)i - 13.333333f) * 0.065f;
                    poseStack.m_252880_(0.0f, yOff / 1.5f, -zOff * this.f6);
                    if (i < 6) {
                        sideperf = 0.0f;
                    } else {
                        sideperf = (float)(i - 7) / 13.333333f;
                        if (sideperf > 1.0f) {
                            sideperf = 1.0f;
                        }
                    }
                }
            }
            if (this.typeI == 7 && this.nearPlayer && i > 33 && !this.picked) {
                yOff = 0.55f + (float)(i - 40) * 0.08f;
                poseStack.m_252880_(0.0f, -yOff / 1.5f, 0.0f);
            }
            if (this.picked && i > 20) {
                yOff = ((float)i - 20.0f) * 0.08f;
                poseStack.m_252880_(0.0f, yOff / 1.5f, -yOff);
            }
            float sidef = 0.5f * Mth.m_14031_((float)(w * t - 0.3f * (float)i)) - (float)this.movInt / 20.0f * Mth.m_14031_((float)(0.8f * t - 0.2f * (float)i));
            poseStack.m_252880_(sidef *= sideperf, 0.0f, 0.0f);
            this.bodySnake[i].m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            if (i == 0) {
                this.head.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.nose.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.lNose.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.teethUR.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                this.teethUL.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                if (this.tongueOff != 0.0f) {
                    if (this.mouthOff != 0.0f || this.tongueOff < 2.0f || this.tongueOff > 7.0f) {
                        this.tongue1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                    } else {
                        this.tongue.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                    }
                } else {
                    this.tongue0.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                }
            }
            if (this.typeI == 6 && this.nearPlayer) {
                if (i == 1) {
                    this.wing1L.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                    this.wing1R.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                }
                if (i == 2) {
                    this.wing2L.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                    this.wing2R.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                }
                if (i == 3) {
                    this.wing3L.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                    this.wing3R.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                }
                if (i == 4) {
                    this.wing4L.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                    this.wing4R.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                }
                if (i == 5) {
                    this.wing5L.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                    this.wing5R.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
                }
            }
            if (i == 39 && this.typeI == 7) {
                this.tail.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            }
            poseStack.m_85849_();
        }
    }
}

