/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import drzhark.mocreatures.client.model.MoCModelAbstractBigCat;
import drzhark.mocreatures.entity.MoCEntityAnimal;
import drzhark.mocreatures.entity.hunter.MoCEntityBigCat;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelBigCat<T extends MoCEntityBigCat>
extends MoCModelAbstractBigCat<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "bigcat"), "main");

    public MoCModelBigCat(ModelPart root) {
        super(root);
    }

    public static LayerDefinition createBodyLayer() {
        return MoCModelAbstractBigCat.createBodyLayer();
    }

    public void prepareMobModel(T entityIn, float limbSwing, float limbSwingAmount, float partialTick) {
        this.bigcat = entityIn;
        this.isFlyer = ((MoCEntityAnimal)entityIn).isFlyer();
        this.isSaddled = ((MoCEntityBigCat)entityIn).getIsRideable();
        this.flapwings = ((MoCEntityBigCat)entityIn).wingFlapCounter != 0;
        this.onAir = ((MoCEntityAnimal)entityIn).isOnAir();
        this.floating = this.isFlyer && this.onAir;
        this.openMouthCounter = ((MoCEntityBigCat)entityIn).mouthCounter;
        this.isRidden = entityIn.m_20159_();
        this.hasMane = ((MoCEntityBigCat)entityIn).hasMane();
        this.isTamed = ((MoCEntityBigCat)entityIn).getHasAmulet();
        this.isSitting = ((MoCEntityBigCat)entityIn).getIsSitting();
        this.movingTail = ((MoCEntityBigCat)entityIn).tailCounter != 0;
        this.hasSaberTeeth = ((MoCEntityBigCat)entityIn).hasSaberTeeth();
        this.hasChest = ((MoCEntityBigCat)entityIn).getIsChested();
        this.hasStinger = ((MoCEntityBigCat)entityIn).getHasStinger();
        this.isGhost = ((MoCEntityBigCat)entityIn).getIsGhost();
        this.isMovingVertically = entityIn.m_20184_().f_82480_ != 0.0 && !entityIn.m_20096_();
    }

    @Override
    public float updateGhostTransparency() {
        return ((MoCEntityBigCat)this.bigcat).tFloat();
    }
}

