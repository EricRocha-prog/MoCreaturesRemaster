/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  net.minecraftforge.client.event.EntityRenderersEvent$RegisterLayerDefinitions
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber$Bus
 */
package drzhark.mocreatures.client.model;

import drzhark.mocreatures.client.model.MoCModelAbstractBigCat;
import drzhark.mocreatures.client.model.MoCModelAbstractScorpion;
import drzhark.mocreatures.client.model.MoCModelAnt;
import drzhark.mocreatures.client.model.MoCModelBear;
import drzhark.mocreatures.client.model.MoCModelBee;
import drzhark.mocreatures.client.model.MoCModelBigCat;
import drzhark.mocreatures.client.model.MoCModelBird;
import drzhark.mocreatures.client.model.MoCModelBoar;
import drzhark.mocreatures.client.model.MoCModelBunny;
import drzhark.mocreatures.client.model.MoCModelButterfly;
import drzhark.mocreatures.client.model.MoCModelCrab;
import drzhark.mocreatures.client.model.MoCModelCricket;
import drzhark.mocreatures.client.model.MoCModelCrocodile;
import drzhark.mocreatures.client.model.MoCModelDeer;
import drzhark.mocreatures.client.model.MoCModelDolphin;
import drzhark.mocreatures.client.model.MoCModelDragonfly;
import drzhark.mocreatures.client.model.MoCModelDuck;
import drzhark.mocreatures.client.model.MoCModelEgg;
import drzhark.mocreatures.client.model.MoCModelElephant;
import drzhark.mocreatures.client.model.MoCModelEnt;
import drzhark.mocreatures.client.model.MoCModelFilchLizard;
import drzhark.mocreatures.client.model.MoCModelFirefly;
import drzhark.mocreatures.client.model.MoCModelFishy;
import drzhark.mocreatures.client.model.MoCModelFly;
import drzhark.mocreatures.client.model.MoCModelFox;
import drzhark.mocreatures.client.model.MoCModelGoat;
import drzhark.mocreatures.client.model.MoCModelGolem;
import drzhark.mocreatures.client.model.MoCModelGrasshopper;
import drzhark.mocreatures.client.model.MoCModelHorse;
import drzhark.mocreatures.client.model.MoCModelHorseMob;
import drzhark.mocreatures.client.model.MoCModelJellyFish;
import drzhark.mocreatures.client.model.MoCModelKitty;
import drzhark.mocreatures.client.model.MoCModelKittyBed;
import drzhark.mocreatures.client.model.MoCModelKittyBed2;
import drzhark.mocreatures.client.model.MoCModelKomodo;
import drzhark.mocreatures.client.model.MoCModelLitterBox;
import drzhark.mocreatures.client.model.MoCModelMaggot;
import drzhark.mocreatures.client.model.MoCModelMediumFish;
import drzhark.mocreatures.client.model.MoCModelMiniGolem;
import drzhark.mocreatures.client.model.MoCModelMole;
import drzhark.mocreatures.client.model.MoCModelMouse;
import drzhark.mocreatures.client.model.MoCModelOgre;
import drzhark.mocreatures.client.model.MoCModelOstrich;
import drzhark.mocreatures.client.model.MoCModelRaccoon;
import drzhark.mocreatures.client.model.MoCModelRat;
import drzhark.mocreatures.client.model.MoCModelRay;
import drzhark.mocreatures.client.model.MoCModelRoach;
import drzhark.mocreatures.client.model.MoCModelShark;
import drzhark.mocreatures.client.model.MoCModelSilverSkeleton;
import drzhark.mocreatures.client.model.MoCModelSmallFish;
import drzhark.mocreatures.client.model.MoCModelSnail;
import drzhark.mocreatures.client.model.MoCModelSnake;
import drzhark.mocreatures.client.model.MoCModelTurkey;
import drzhark.mocreatures.client.model.MoCModelTurtle;
import drzhark.mocreatures.client.model.MoCModelWerehuman;
import drzhark.mocreatures.client.model.MoCModelWerewolf;
import drzhark.mocreatures.client.model.MoCModelWolf;
import drzhark.mocreatures.client.model.MoCModelWraith;
import drzhark.mocreatures.client.model.MoCModelWyvern;
import drzhark.mocreatures.client.model.legacy.MoCLegacyModelBigCat1;
import drzhark.mocreatures.client.model.legacy.MoCLegacyModelBigCat2;
import drzhark.mocreatures.client.model.legacy.MoCLegacyModelScorpion;
import drzhark.mocreatures.client.model.legacy.MoCLegacyModelShark;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid="mocreatures", value={Dist.CLIENT}, bus=Mod.EventBusSubscriber.Bus.MOD)
@OnlyIn(value=Dist.CLIENT)
public class MoCModelRegistry {
    public static final ModelLayerLocation BUNNY = MoCModelRegistry.createModelLayer("bunny");
    public static final ModelLayerLocation BIRD = MoCModelRegistry.createModelLayer("bird");
    public static final ModelLayerLocation TURTLE = MoCModelRegistry.createModelLayer("turtle");
    public static final ModelLayerLocation MOUSE = MoCModelRegistry.createModelLayer("mouse");
    public static final ModelLayerLocation SNAKE = MoCModelRegistry.createModelLayer("snake");
    public static final ModelLayerLocation TURKEY = MoCModelRegistry.createModelLayer("turkey");
    public static final ModelLayerLocation BUTTERFLY = MoCModelRegistry.createModelLayer("butterfly");
    public static final ModelLayerLocation HORSE = MoCModelRegistry.createModelLayer("horse");
    public static final ModelLayerLocation HORSE_MOB = MoCModelRegistry.createModelLayer("horse_mob");
    public static final ModelLayerLocation BOAR = MoCModelRegistry.createModelLayer("boar");
    public static final ModelLayerLocation BEAR = MoCModelRegistry.createModelLayer("bear");
    public static final ModelLayerLocation DUCK = MoCModelRegistry.createModelLayer("duck");
    public static final ModelLayerLocation DEER = MoCModelRegistry.createModelLayer("deer");
    public static final ModelLayerLocation WOLF = MoCModelRegistry.createModelLayer("wolf");
    public static final ModelLayerLocation WRAITH = MoCModelRegistry.createModelLayer("wraith");
    public static final ModelLayerLocation WEREHUMAN = MoCModelRegistry.createModelLayer("werehuman");
    public static final ModelLayerLocation WEREWOLF = MoCModelRegistry.createModelLayer("werewolf");
    public static final ModelLayerLocation FILCH_LIZARD = MoCModelRegistry.createModelLayer("filch_lizard");
    public static final ModelLayerLocation FOX = MoCModelRegistry.createModelLayer("fox");
    public static final ModelLayerLocation SHARK = MoCModelRegistry.createModelLayer("shark");
    public static final ModelLayerLocation DOLPHIN = MoCModelRegistry.createModelLayer("dolphin");
    public static final ModelLayerLocation FISHY = MoCModelRegistry.createModelLayer("fishy");
    public static final ModelLayerLocation EGG = MoCModelRegistry.createModelLayer("egg");
    public static final ModelLayerLocation KITTY = MoCModelRegistry.createModelLayer("kitty");
    public static final ModelLayerLocation KITTY_BED = MoCModelRegistry.createModelLayer("kitty_bed");
    public static final ModelLayerLocation KITTY_BED2 = MoCModelRegistry.createModelLayer("kitty_bed2");
    public static final ModelLayerLocation LITTER_BOX = MoCModelRegistry.createModelLayer("litter_box");
    public static final ModelLayerLocation RAT = MoCModelRegistry.createModelLayer("rat");
    public static final ModelLayerLocation SCORPION = MoCModelRegistry.createModelLayer("scorpion");
    public static final ModelLayerLocation PET_SCORPION = MoCModelRegistry.createModelLayer("pet_scorpion");
    public static final ModelLayerLocation CROCODILE = MoCModelRegistry.createModelLayer("crocodile");
    public static final ModelLayerLocation RAY = MoCModelRegistry.createModelLayer("ray");
    public static final ModelLayerLocation JELLYFISH = MoCModelRegistry.createModelLayer("jellyfish");
    public static final ModelLayerLocation GOAT = MoCModelRegistry.createModelLayer("goat");
    public static final ModelLayerLocation OSTRICH = MoCModelRegistry.createModelLayer("ostrich");
    public static final ModelLayerLocation BEE = MoCModelRegistry.createModelLayer("bee");
    public static final ModelLayerLocation FLY = MoCModelRegistry.createModelLayer("fly");
    public static final ModelLayerLocation DRAGONFLY = MoCModelRegistry.createModelLayer("dragonfly");
    public static final ModelLayerLocation FIREFLY = MoCModelRegistry.createModelLayer("firefly");
    public static final ModelLayerLocation CRICKET = MoCModelRegistry.createModelLayer("cricket");
    public static final ModelLayerLocation GRASSHOPPER = MoCModelRegistry.createModelLayer("grasshopper");
    public static final ModelLayerLocation SNAIL = MoCModelRegistry.createModelLayer("snail");
    public static final ModelLayerLocation BIG_GOLEM = MoCModelRegistry.createModelLayer("big_golem");
    public static final ModelLayerLocation ELEPHANT = MoCModelRegistry.createModelLayer("elephant");
    public static final ModelLayerLocation KOMODO = MoCModelRegistry.createModelLayer("komodo");
    public static final ModelLayerLocation WYVERN = MoCModelRegistry.createModelLayer("wyvern");
    public static final ModelLayerLocation OGRE = MoCModelRegistry.createModelLayer("ogre");
    public static final ModelLayerLocation ROACH = MoCModelRegistry.createModelLayer("roach");
    public static final ModelLayerLocation MAGGOT = MoCModelRegistry.createModelLayer("maggot");
    public static final ModelLayerLocation CRAB = MoCModelRegistry.createModelLayer("crab");
    public static final ModelLayerLocation RACCOON = MoCModelRegistry.createModelLayer("raccoon");
    public static final ModelLayerLocation MINI_GOLEM = MoCModelRegistry.createModelLayer("mini_golem");
    public static final ModelLayerLocation SILVER_SKELETON = MoCModelRegistry.createModelLayer("silver_skeleton");
    public static final ModelLayerLocation ANT = MoCModelRegistry.createModelLayer("ant");
    public static final ModelLayerLocation MEDIUM_FISH = MoCModelRegistry.createModelLayer("medium_fish");
    public static final ModelLayerLocation SMALL_FISH = MoCModelRegistry.createModelLayer("small_fish");
    public static final ModelLayerLocation ENT = MoCModelRegistry.createModelLayer("ent");
    public static final ModelLayerLocation MOLE = MoCModelRegistry.createModelLayer("mole");
    public static final ModelLayerLocation MANTICORE = MoCModelRegistry.createModelLayer("manticore");
    public static final ModelLayerLocation MANTICORE_PET = MoCModelRegistry.createModelLayer("manticore_pet");
    public static final ModelLayerLocation BIG_CAT = MoCModelRegistry.createModelLayer("big_cat");
    public static final ModelLayerLocation LEGACY_BIG_CAT1 = MoCModelRegistry.createModelLayer("legacy_big_cat1");
    public static final ModelLayerLocation LEGACY_BIG_CAT2 = MoCModelRegistry.createModelLayer("legacy_big_cat2");
    public static final ModelLayerLocation LEGACY_SCORPION = MoCModelRegistry.createModelLayer("legacy_scorpion");
    public static final ModelLayerLocation LEGACY_SHARK = MoCModelRegistry.createModelLayer("legacy_shark");

    private static ModelLayerLocation createModelLayer(String name) {
        return new ModelLayerLocation(new ResourceLocation("mocreatures", name), "main");
    }

    @SubscribeEvent
    public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(BUNNY, MoCModelBunny::createBodyLayer);
        event.registerLayerDefinition(BIRD, MoCModelBird::createBodyLayer);
        event.registerLayerDefinition(TURTLE, MoCModelTurtle::createBodyLayer);
        event.registerLayerDefinition(MOUSE, MoCModelMouse::createBodyLayer);
        event.registerLayerDefinition(SNAKE, MoCModelSnake::createBodyLayer);
        event.registerLayerDefinition(TURKEY, MoCModelTurkey::createBodyLayer);
        event.registerLayerDefinition(BUTTERFLY, MoCModelButterfly::createBodyLayer);
        event.registerLayerDefinition(HORSE, MoCModelHorse::createBodyLayer);
        event.registerLayerDefinition(HORSE_MOB, MoCModelHorseMob::createBodyLayer);
        event.registerLayerDefinition(BOAR, MoCModelBoar::createBodyLayer);
        event.registerLayerDefinition(BEAR, MoCModelBear::createBodyLayer);
        event.registerLayerDefinition(DUCK, MoCModelDuck::createBodyLayer);
        event.registerLayerDefinition(DEER, MoCModelDeer::createBodyLayer);
        event.registerLayerDefinition(WOLF, MoCModelWolf::createBodyLayer);
        event.registerLayerDefinition(WRAITH, MoCModelWraith::createBodyLayer);
        event.registerLayerDefinition(WEREHUMAN, MoCModelWerehuman::createBodyLayer);
        event.registerLayerDefinition(WEREWOLF, MoCModelWerewolf::createBodyLayer);
        event.registerLayerDefinition(FILCH_LIZARD, MoCModelFilchLizard::createBodyLayer);
        event.registerLayerDefinition(FOX, MoCModelFox::createBodyLayer);
        event.registerLayerDefinition(SHARK, MoCModelShark::createBodyLayer);
        event.registerLayerDefinition(DOLPHIN, MoCModelDolphin::createBodyLayer);
        event.registerLayerDefinition(FISHY, MoCModelFishy::createBodyLayer);
        event.registerLayerDefinition(EGG, MoCModelEgg::createBodyLayer);
        event.registerLayerDefinition(KITTY, MoCModelKitty::createBodyLayer);
        event.registerLayerDefinition(KITTY_BED, MoCModelKittyBed::createBodyLayer);
        event.registerLayerDefinition(KITTY_BED2, MoCModelKittyBed2::createBodyLayer);
        event.registerLayerDefinition(LITTER_BOX, MoCModelLitterBox::createBodyLayer);
        event.registerLayerDefinition(RAT, MoCModelRat::createBodyLayer);
        event.registerLayerDefinition(SCORPION, MoCModelAbstractScorpion::createBodyLayer);
        event.registerLayerDefinition(PET_SCORPION, MoCModelAbstractScorpion::createBodyLayer);
        event.registerLayerDefinition(CROCODILE, MoCModelCrocodile::createBodyLayer);
        event.registerLayerDefinition(RAY, MoCModelRay::createBodyLayer);
        event.registerLayerDefinition(JELLYFISH, MoCModelJellyFish::createBodyLayer);
        event.registerLayerDefinition(GOAT, MoCModelGoat::createBodyLayer);
        event.registerLayerDefinition(OSTRICH, MoCModelOstrich::createBodyLayer);
        event.registerLayerDefinition(BEE, MoCModelBee::createBodyLayer);
        event.registerLayerDefinition(FLY, MoCModelFly::createBodyLayer);
        event.registerLayerDefinition(DRAGONFLY, MoCModelDragonfly::createBodyLayer);
        event.registerLayerDefinition(FIREFLY, MoCModelFirefly::createBodyLayer);
        event.registerLayerDefinition(CRICKET, MoCModelCricket::createBodyLayer);
        event.registerLayerDefinition(GRASSHOPPER, MoCModelGrasshopper::createBodyLayer);
        event.registerLayerDefinition(SNAIL, MoCModelSnail::createBodyLayer);
        event.registerLayerDefinition(BIG_GOLEM, MoCModelGolem::createBodyLayer);
        event.registerLayerDefinition(ELEPHANT, MoCModelElephant::createBodyLayer);
        event.registerLayerDefinition(KOMODO, MoCModelKomodo::createBodyLayer);
        event.registerLayerDefinition(WYVERN, MoCModelWyvern::createBodyLayer);
        event.registerLayerDefinition(OGRE, MoCModelOgre::createBodyLayer);
        event.registerLayerDefinition(ROACH, MoCModelRoach::createBodyLayer);
        event.registerLayerDefinition(MAGGOT, MoCModelMaggot::createBodyLayer);
        event.registerLayerDefinition(CRAB, MoCModelCrab::createBodyLayer);
        event.registerLayerDefinition(RACCOON, MoCModelRaccoon::createBodyLayer);
        event.registerLayerDefinition(MINI_GOLEM, MoCModelMiniGolem::createBodyLayer);
        event.registerLayerDefinition(SILVER_SKELETON, MoCModelSilverSkeleton::createBodyLayer);
        event.registerLayerDefinition(ANT, MoCModelAnt::createBodyLayer);
        event.registerLayerDefinition(MEDIUM_FISH, MoCModelMediumFish::createBodyLayer);
        event.registerLayerDefinition(SMALL_FISH, MoCModelSmallFish::createBodyLayer);
        event.registerLayerDefinition(ENT, MoCModelEnt::createBodyLayer);
        event.registerLayerDefinition(MOLE, MoCModelMole::createBodyLayer);
        event.registerLayerDefinition(MANTICORE, MoCModelAbstractBigCat::createBodyLayer);
        event.registerLayerDefinition(MANTICORE_PET, MoCModelBigCat::createBodyLayer);
        event.registerLayerDefinition(BIG_CAT, MoCModelBigCat::createBodyLayer);
        event.registerLayerDefinition(LEGACY_BIG_CAT1, MoCLegacyModelBigCat1::createBodyLayer);
        event.registerLayerDefinition(LEGACY_BIG_CAT2, MoCLegacyModelBigCat2::createBodyLayer);
        event.registerLayerDefinition(LEGACY_SCORPION, MoCLegacyModelScorpion::createBodyLayer);
        event.registerLayerDefinition(LEGACY_SHARK, MoCLegacyModelShark::createBodyLayer);
    }
}

