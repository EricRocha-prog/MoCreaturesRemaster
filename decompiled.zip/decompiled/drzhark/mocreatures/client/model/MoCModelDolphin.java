/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeDeformation
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.aquatic.MoCEntityDolphin;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelDolphin<T extends MoCEntityDolphin>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "dolphin"), "main");
    private final ModelPart Body;
    private final ModelPart UHead;
    private final ModelPart DHead;
    private final ModelPart PTail;
    private final ModelPart UpperFin;
    private final ModelPart LTailFin;
    private final ModelPart RTailFin;
    private final ModelPart LeftFin;
    private final ModelPart RightFin;

    public MoCModelDolphin(ModelPart root) {
        this.Body = root.m_171324_("Body");
        this.UHead = root.m_171324_("UHead");
        this.DHead = root.m_171324_("DHead");
        this.PTail = root.m_171324_("PTail");
        this.UpperFin = root.m_171324_("UpperFin");
        this.LTailFin = root.m_171324_("LTailFin");
        this.RTailFin = root.m_171324_("RTailFin");
        this.LeftFin = root.m_171324_("LeftFin");
        this.RightFin = root.m_171324_("RightFin");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        root.m_171599_("Body", CubeListBuilder.m_171558_().m_171514_(4, 6).m_171481_(0.0f, 0.0f, 0.0f, 6.0f, 8.0f, 18.0f), PartPose.m_171419_((float)-3.0f, (float)17.0f, (float)-4.0f));
        root.m_171599_("UHead", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(0.0f, 0.0f, 0.0f, 5.0f, 7.0f, 8.0f), PartPose.m_171419_((float)-2.5f, (float)18.0f, (float)-10.5f));
        root.m_171599_("DHead", CubeListBuilder.m_171558_().m_171514_(50, 0).m_171481_(0.0f, 0.0f, 0.0f, 3.0f, 3.0f, 4.0f), PartPose.m_171419_((float)-1.5f, (float)21.5f, (float)-14.5f));
        root.m_171599_("PTail", CubeListBuilder.m_171558_().m_171514_(34, 9).m_171481_(0.0f, 0.0f, 0.0f, 5.0f, 5.0f, 10.0f), PartPose.m_171419_((float)-2.5f, (float)19.0f, (float)14.0f));
        root.m_171599_("UpperFin", CubeListBuilder.m_171558_().m_171514_(4, 12).m_171481_(0.0f, 0.0f, 0.0f, 1.0f, 4.0f, 8.0f), PartPose.m_171423_((float)-0.5f, (float)18.0f, (float)2.0f, (float)0.7853981f, (float)0.0f, (float)0.0f));
        root.m_171599_("LTailFin", CubeListBuilder.m_171558_().m_171514_(34, 0).m_171488_(0.0f, 0.0f, 0.0f, 4.0f, 1.0f, 8.0f, new CubeDeformation(0.3f)), PartPose.m_171423_((float)-1.0f, (float)21.5f, (float)24.0f, (float)0.0f, (float)0.7853981f, (float)0.0f));
        root.m_171599_("RTailFin", CubeListBuilder.m_171558_().m_171514_(34, 0).m_171488_(0.0f, 0.0f, 0.0f, 4.0f, 1.0f, 8.0f, new CubeDeformation(0.3f)), PartPose.m_171423_((float)-2.0f, (float)21.5f, (float)21.0f, (float)0.0f, (float)-0.7853981f, (float)0.0f));
        root.m_171599_("LeftFin", CubeListBuilder.m_171558_().m_171514_(14, 0).m_171481_(0.0f, 0.0f, 0.0f, 8.0f, 1.0f, 4.0f), PartPose.m_171423_((float)3.0f, (float)24.0f, (float)-1.0f, (float)0.0f, (float)-0.5235988f, (float)0.5235988f));
        root.m_171599_("RightFin", CubeListBuilder.m_171558_().m_171514_(14, 0).m_171481_(0.0f, 0.0f, 0.0f, 8.0f, 1.0f, 4.0f), PartPose.m_171423_((float)-9.0f, (float)27.5f, (float)3.0f, (float)0.0f, (float)0.5235988f, (float)-0.5235988f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)64, (int)32);
    }

    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.RTailFin.f_104203_ = Mth.m_14089_((float)(limbSwing * 0.4f)) * limbSwingAmount;
        this.LTailFin.f_104203_ = Mth.m_14089_((float)(limbSwing * 0.4f)) * limbSwingAmount;
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.Body.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.PTail.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.UHead.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.DHead.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.UpperFin.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LTailFin.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RTailFin.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LeftFin.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RightFin.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}

