/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.passive.MoCEntityBunny;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelBunny<T extends MoCEntityBunny>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "bunny"), "main");
    private final ModelPart part1;
    private final ModelPart part2;
    private final ModelPart part3;
    private final ModelPart part4;
    private final ModelPart part5;
    private final ModelPart part6;
    private final ModelPart part7;
    private final ModelPart part8;
    private final ModelPart part9;
    private final ModelPart part10;
    private final ModelPart part11;

    public MoCModelBunny(ModelPart root) {
        this.part1 = root.m_171324_("part1");
        this.part8 = root.m_171324_("part8");
        this.part9 = root.m_171324_("part9");
        this.part10 = root.m_171324_("part10");
        this.part11 = root.m_171324_("part11");
        this.part2 = root.m_171324_("part2");
        this.part3 = root.m_171324_("part3");
        this.part4 = root.m_171324_("part4");
        this.part5 = root.m_171324_("part5");
        this.part6 = root.m_171324_("part6");
        this.part7 = root.m_171324_("part7");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        root.m_171599_("part1", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-2.0f, -1.0f, -4.0f, 4.0f, 4.0f, 6.0f), PartPose.m_171419_((float)0.0f, (float)15.0f, (float)-4.0f));
        root.m_171599_("part8", CubeListBuilder.m_171558_().m_171514_(14, 0).m_171481_(-2.0f, -5.0f, -3.0f, 1.0f, 4.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)15.0f, (float)-4.0f));
        root.m_171599_("part9", CubeListBuilder.m_171558_().m_171514_(14, 0).m_171481_(1.0f, -5.0f, -3.0f, 1.0f, 4.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)15.0f, (float)-4.0f));
        root.m_171599_("part10", CubeListBuilder.m_171558_().m_171514_(20, 0).m_171481_(-4.0f, 0.0f, -3.0f, 2.0f, 3.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)15.0f, (float)-4.0f));
        root.m_171599_("part11", CubeListBuilder.m_171558_().m_171514_(20, 0).m_171481_(2.0f, 0.0f, -3.0f, 2.0f, 3.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)15.0f, (float)-4.0f));
        root.m_171599_("part2", CubeListBuilder.m_171558_().m_171514_(0, 10).m_171481_(-3.0f, -4.0f, -3.0f, 6.0f, 8.0f, 6.0f), PartPose.m_171419_((float)0.0f, (float)16.0f, (float)0.0f));
        root.m_171599_("part3", CubeListBuilder.m_171558_().m_171514_(0, 24).m_171481_(-2.0f, 4.0f, -2.0f, 4.0f, 3.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)16.0f, (float)0.0f));
        root.m_171599_("part4", CubeListBuilder.m_171558_().m_171514_(24, 16).m_171481_(-2.0f, 0.0f, -1.0f, 2.0f, 2.0f, 2.0f), PartPose.m_171419_((float)3.0f, (float)19.0f, (float)-3.0f));
        root.m_171599_("part5", CubeListBuilder.m_171558_().m_171514_(24, 16).m_171481_(0.0f, 0.0f, -1.0f, 2.0f, 2.0f, 2.0f), PartPose.m_171419_((float)-3.0f, (float)19.0f, (float)-3.0f));
        root.m_171599_("part6", CubeListBuilder.m_171558_().m_171514_(16, 24).m_171481_(-2.0f, 0.0f, -4.0f, 2.0f, 2.0f, 4.0f), PartPose.m_171419_((float)3.0f, (float)19.0f, (float)4.0f));
        root.m_171599_("part7", CubeListBuilder.m_171558_().m_171514_(16, 24).m_171481_(0.0f, 0.0f, -4.0f, 2.0f, 2.0f, 4.0f), PartPose.m_171419_((float)-3.0f, (float)19.0f, (float)4.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)64, (int)32);
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.part1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.part8.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.part9.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.part10.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.part11.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.part2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.part3.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.part4.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.part5.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.part6.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.part7.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }

    public void setupAnim(T entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float headX = -headPitch * ((float)Math.PI / 180);
        float headY = netHeadYaw * ((float)Math.PI / 180);
        this.part1.f_104203_ = headX;
        this.part1.f_104204_ = headY;
        this.part8.f_104203_ = headX;
        this.part8.f_104204_ = headY;
        this.part9.f_104203_ = headX;
        this.part9.f_104204_ = headY;
        this.part10.f_104203_ = headX;
        this.part10.f_104204_ = headY;
        this.part11.f_104203_ = headX;
        this.part11.f_104204_ = headY;
        this.part2.f_104203_ = 1.5707964f;
        this.part3.f_104203_ = 1.5707964f;
        if (entityIn.m_20202_() == null) {
            float frontLeg = Mth.m_14089_((float)(limbSwing * 0.6662f)) * 1.0f * limbSwingAmount;
            float hindLeg = Mth.m_14089_((float)(limbSwing * 0.6662f + (float)Math.PI)) * 1.2f * limbSwingAmount;
            this.part4.f_104203_ = frontLeg;
            this.part5.f_104203_ = frontLeg;
            this.part6.f_104203_ = hindLeg;
            this.part7.f_104203_ = hindLeg;
        }
    }
}

