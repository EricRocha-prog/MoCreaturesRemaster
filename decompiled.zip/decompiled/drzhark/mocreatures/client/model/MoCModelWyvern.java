/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraft.world.entity.player.Player
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.MoCTools;
import drzhark.mocreatures.entity.MoCEntityAnimal;
import drzhark.mocreatures.entity.neutral.MoCEntityWyvern;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelWyvern<T extends MoCEntityWyvern>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "wyvern"), "main");
    private final ModelPart Tail;
    private final ModelPart back1;
    private final ModelPart tail1;
    private final ModelPart back2;
    private final ModelPart tail2;
    private final ModelPart back3;
    private final ModelPart tail3;
    private final ModelPart back4;
    private final ModelPart tail4;
    private final ModelPart tail5;
    private final ModelPart chest;
    private final ModelPart neckplate3;
    private final ModelPart neck3;
    private final ModelPart MainHead;
    private final ModelPart neck2;
    private final ModelPart neckplate2;
    private final ModelPart neck1;
    private final ModelPart neckplate1;
    private final ModelPart head;
    private final ModelPart snout;
    private final ModelPart headplate;
    private final ModelPart beak;
    private final ModelPart righteyesock;
    private final ModelPart lefteyesock;
    private final ModelPart Jaw;
    private final ModelPart leftupjaw;
    private final ModelPart rightupjaw;
    private final ModelPart mouthrod;
    private final ModelPart helmetstrap1;
    private final ModelPart helmetstrap2;
    private final ModelPart controlrope1;
    private final ModelPart controlrope2;
    private final ModelPart rightearskin;
    private final ModelPart leftearskin;
    private final ModelPart rightspine1;
    private final ModelPart rightspine2;
    private final ModelPart rightspine3;
    private final ModelPart leftspine1;
    private final ModelPart leftspine2;
    private final ModelPart leftspine3;
    private final ModelPart ironhelmethorn1;
    private final ModelPart ironhelmethorn2;
    private final ModelPart ironhelmet;
    private final ModelPart ironhelmetsnout;
    private final ModelPart goldhelmethorn1;
    private final ModelPart goldhelmethorn2;
    private final ModelPart goldhelmet;
    private final ModelPart goldhelmetsnout;
    private final ModelPart diamondhelmet;
    private final ModelPart diamondhelmethorn2;
    private final ModelPart diamondhelmethorn1;
    private final ModelPart diamondhelmetsnout;
    private final ModelPart torso;
    private final ModelPart saddle;
    private final ModelPart rightshoulder;
    private final ModelPart leftshoulder;
    private final ModelPart LeftWing;
    private final ModelPart leftuparm;
    private final ModelPart leftlowarm;
    private final ModelPart leftfing1a;
    private final ModelPart leftfing1b;
    private final ModelPart leftfing2a;
    private final ModelPart leftfing2b;
    private final ModelPart leftfing3a;
    private final ModelPart leftfing3b;
    private final ModelPart leftwingflap1;
    private final ModelPart leftwingflap2;
    private final ModelPart leftwingflap3;
    private final ModelPart RightWing;
    private final ModelPart rightuparm;
    private final ModelPart rightlowarm;
    private final ModelPart rightfing1a;
    private final ModelPart rightfing1b;
    private final ModelPart rightwingflap1;
    private final ModelPart rightfing2a;
    private final ModelPart rightfing2b;
    private final ModelPart rightwingflap2;
    private final ModelPart rightfing3a;
    private final ModelPart rightfing3b;
    private final ModelPart rightwingflap3;
    private final ModelPart leftupleg;
    private final ModelPart leftmidleg;
    private final ModelPart leftlowleg;
    private final ModelPart leftfoot;
    private final ModelPart lefttoe1;
    private final ModelPart lefttoe3;
    private final ModelPart lefttoe2;
    private final ModelPart leftclaw1;
    private final ModelPart leftclaw2;
    private final ModelPart leftclaw3;
    private final ModelPart ironleftlegarmor;
    private final ModelPart goldleftlegarmor;
    private final ModelPart diamondleftlegarmor;
    private final ModelPart rightupleg;
    private final ModelPart rightmidleg;
    private final ModelPart rightlowleg;
    private final ModelPart rightfoot;
    private final ModelPart righttoe1;
    private final ModelPart righttoe3;
    private final ModelPart righttoe2;
    private final ModelPart rightclaw1;
    private final ModelPart rightclaw2;
    private final ModelPart rightclaw3;
    private final ModelPart ironrightlegarmor;
    private final ModelPart goldrightlegarmor;
    private final ModelPart diamondrightlegarmor;
    private final ModelPart storage;
    private final ModelPart chestbelt;
    private final ModelPart stomachbelt;
    private final ModelPart ironchestarmor;
    private final ModelPart ironrightshoulderpad;
    private final ModelPart ironleftshoulderpad;
    private final ModelPart goldleftshoulder;
    private final ModelPart goldchestarmor;
    private final ModelPart goldrightshoulder;
    private final ModelPart diamondleftshoulder;
    private final ModelPart diamondrightshoulder;
    private final ModelPart diamondchestarmor;
    private int armor;
    private boolean isRidden;
    private boolean isChested;
    private boolean isSaddled;
    private boolean flapwings;
    private boolean onAir;
    private boolean diving;
    private boolean isSitting;
    private boolean isGhost;
    private int openMouth;
    private float yOffset;
    private float transparency;

    public MoCModelWyvern(ModelPart root) {
        this.Tail = root.m_171324_("Tail");
        this.back1 = this.Tail.m_171324_("back1");
        this.tail1 = this.Tail.m_171324_("tail1");
        this.back2 = this.tail1.m_171324_("back2");
        this.tail2 = this.tail1.m_171324_("tail2");
        this.back3 = this.tail2.m_171324_("back3");
        this.tail3 = this.tail2.m_171324_("tail3");
        this.back4 = this.tail3.m_171324_("back4");
        this.tail4 = this.tail3.m_171324_("tail4");
        this.tail5 = this.tail4.m_171324_("tail5");
        this.chest = root.m_171324_("chest");
        this.neckplate3 = root.m_171324_("neckplate3");
        this.neck3 = root.m_171324_("neck3");
        this.MainHead = root.m_171324_("MainHead");
        this.neck2 = this.MainHead.m_171324_("neck2");
        this.neckplate2 = this.neck2.m_171324_("neckplate2");
        this.neck1 = this.neck2.m_171324_("neck1");
        this.neckplate1 = this.neck1.m_171324_("neckplate1");
        this.head = this.neck1.m_171324_("head");
        this.snout = this.head.m_171324_("snout");
        this.headplate = this.head.m_171324_("headplate");
        this.beak = this.snout.m_171324_("beak");
        this.righteyesock = this.head.m_171324_("righteyesock");
        this.lefteyesock = this.head.m_171324_("lefteyesock");
        this.Jaw = this.head.m_171324_("Jaw");
        this.leftupjaw = this.head.m_171324_("leftupjaw");
        this.rightupjaw = this.head.m_171324_("rightupjaw");
        this.mouthrod = this.head.m_171324_("mouthrod");
        this.helmetstrap1 = this.head.m_171324_("helmetstrap1");
        this.helmetstrap2 = this.head.m_171324_("helmetstrap2");
        this.controlrope1 = this.head.m_171324_("mouthrod").m_171324_("controlrope1");
        this.controlrope2 = this.head.m_171324_("mouthrod").m_171324_("controlrope2");
        this.rightearskin = this.head.m_171324_("rightearskin");
        this.leftearskin = this.head.m_171324_("leftearskin");
        this.rightspine1 = this.rightearskin.m_171324_("rightspine1");
        this.rightspine2 = this.rightearskin.m_171324_("rightspine2");
        this.rightspine3 = this.rightearskin.m_171324_("rightspine3");
        this.leftspine1 = this.leftearskin.m_171324_("leftspine1");
        this.leftspine2 = this.leftearskin.m_171324_("leftspine2");
        this.leftspine3 = this.leftearskin.m_171324_("leftspine3");
        this.ironhelmethorn1 = this.leftspine1.m_171324_("ironhelmethorn1");
        this.ironhelmethorn2 = this.rightspine1.m_171324_("ironhelmethorn2");
        this.ironhelmet = this.head.m_171324_("ironhelmet");
        this.ironhelmetsnout = this.snout.m_171324_("ironhelmetsnout");
        this.goldhelmethorn1 = this.leftspine1.m_171324_("goldhelmethorn1");
        this.goldhelmethorn2 = this.rightspine1.m_171324_("goldhelmethorn2");
        this.goldhelmet = this.head.m_171324_("goldhelmet");
        this.goldhelmetsnout = this.snout.m_171324_("goldhelmetsnout");
        this.diamondhelmet = this.head.m_171324_("diamondhelmet");
        this.diamondhelmethorn2 = this.rightspine1.m_171324_("diamondhelmethorn2");
        this.diamondhelmethorn1 = this.leftspine1.m_171324_("diamondhelmethorn1");
        this.diamondhelmetsnout = this.snout.m_171324_("diamondhelmetsnout");
        this.torso = root.m_171324_("torso");
        this.saddle = root.m_171324_("saddle");
        this.rightshoulder = root.m_171324_("rightshoulder");
        this.leftshoulder = root.m_171324_("leftshoulder");
        this.LeftWing = root.m_171324_("LeftWing");
        this.leftuparm = this.LeftWing.m_171324_("leftuparm");
        this.leftlowarm = this.leftuparm.m_171324_("leftlowarm");
        this.leftfing1a = this.leftlowarm.m_171324_("leftfing1a");
        this.leftfing1b = this.leftfing1a.m_171324_("leftfing1b");
        this.leftfing2a = this.leftlowarm.m_171324_("leftfing2a");
        this.leftfing2b = this.leftfing2a.m_171324_("leftfing2b");
        this.leftfing3a = this.leftlowarm.m_171324_("leftfing3a");
        this.leftfing3b = this.leftfing3a.m_171324_("leftfing3b");
        this.leftwingflap1 = this.leftfing1a.m_171324_("leftwingflap1");
        this.leftwingflap2 = this.leftfing2a.m_171324_("leftwingflap2");
        this.leftwingflap3 = this.leftfing3a.m_171324_("leftwingflap3");
        this.RightWing = root.m_171324_("RightWing");
        this.rightuparm = this.RightWing.m_171324_("rightuparm");
        this.rightlowarm = this.rightuparm.m_171324_("rightlowarm");
        this.rightfing1a = this.rightlowarm.m_171324_("rightfing1a");
        this.rightfing1b = this.rightfing1a.m_171324_("rightfing1b");
        this.rightwingflap1 = this.rightfing1a.m_171324_("rightwingflap1");
        this.rightfing2a = this.rightlowarm.m_171324_("rightfing2a");
        this.rightfing2b = this.rightfing2a.m_171324_("rightfing2b");
        this.rightwingflap2 = this.rightfing2a.m_171324_("rightwingflap2");
        this.rightfing3a = this.rightlowarm.m_171324_("rightfing3a");
        this.rightfing3b = this.rightfing3a.m_171324_("rightfing3b");
        this.rightwingflap3 = this.rightfing3a.m_171324_("rightwingflap3");
        this.leftupleg = root.m_171324_("leftupleg");
        this.leftmidleg = this.leftupleg.m_171324_("leftmidleg");
        this.leftlowleg = this.leftmidleg.m_171324_("leftlowleg");
        this.leftfoot = this.leftlowleg.m_171324_("leftfoot");
        this.lefttoe1 = this.leftfoot.m_171324_("lefttoe1");
        this.lefttoe3 = this.leftfoot.m_171324_("lefttoe3");
        this.lefttoe2 = this.leftfoot.m_171324_("lefttoe2");
        this.leftclaw1 = this.lefttoe1.m_171324_("leftclaw1");
        this.leftclaw2 = this.lefttoe2.m_171324_("leftclaw2");
        this.leftclaw3 = this.lefttoe3.m_171324_("leftclaw3");
        this.ironleftlegarmor = this.leftlowleg.m_171324_("ironleftlegarmor");
        this.goldleftlegarmor = this.leftlowleg.m_171324_("goldleftlegarmor");
        this.diamondleftlegarmor = this.leftlowleg.m_171324_("diamondleftlegarmor");
        this.rightupleg = root.m_171324_("rightupleg");
        this.rightmidleg = this.rightupleg.m_171324_("rightmidleg");
        this.rightlowleg = this.rightmidleg.m_171324_("rightlowleg");
        this.rightfoot = this.rightlowleg.m_171324_("rightfoot");
        this.righttoe1 = this.rightfoot.m_171324_("righttoe1");
        this.righttoe3 = this.rightfoot.m_171324_("righttoe3");
        this.righttoe2 = this.rightfoot.m_171324_("righttoe2");
        this.rightclaw1 = this.righttoe1.m_171324_("rightclaw1");
        this.rightclaw2 = this.righttoe2.m_171324_("rightclaw2");
        this.rightclaw3 = this.righttoe3.m_171324_("rightclaw3");
        this.ironrightlegarmor = this.rightlowleg.m_171324_("ironrightlegarmor");
        this.goldrightlegarmor = this.rightlowleg.m_171324_("goldrightlegarmor");
        this.diamondrightlegarmor = this.rightlowleg.m_171324_("diamondrightlegarmor");
        this.storage = root.m_171324_("storage");
        this.chestbelt = root.m_171324_("chestbelt");
        this.stomachbelt = root.m_171324_("stomachbelt");
        this.ironchestarmor = root.m_171324_("ironchestarmor");
        this.ironrightshoulderpad = root.m_171324_("ironrightshoulderpad");
        this.ironleftshoulderpad = root.m_171324_("ironleftshoulderpad");
        this.goldleftshoulder = root.m_171324_("goldleftshoulder");
        this.goldchestarmor = root.m_171324_("goldchestarmor");
        this.goldrightshoulder = root.m_171324_("goldrightshoulder");
        this.diamondleftshoulder = root.m_171324_("diamondleftshoulder");
        this.diamondrightshoulder = root.m_171324_("diamondrightshoulder");
        this.diamondchestarmor = root.m_171324_("diamondchestarmor");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        PartDefinition Tail = root.m_171599_("Tail", CubeListBuilder.m_171558_(), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        Tail.m_171599_("back1", CubeListBuilder.m_171558_().m_171514_(92, 0).m_171481_(-3.0f, -2.0f, -12.0f, 6.0f, 2.0f, 12.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        PartDefinition tail1 = Tail.m_171599_("tail1", CubeListBuilder.m_171558_().m_171514_(0, 22).m_171481_(-4.0f, 0.0f, 0.0f, 8.0f, 8.0f, 10.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        tail1.m_171599_("back2", CubeListBuilder.m_171558_().m_171514_(100, 14).m_171481_(-2.0f, -2.0f, 0.0f, 4.0f, 2.0f, 10.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        PartDefinition tail2 = tail1.m_171599_("tail2", CubeListBuilder.m_171558_().m_171514_(0, 40).m_171481_(-3.0f, 0.0f, 0.0f, 6.0f, 6.0f, 9.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)10.0f));
        tail2.m_171599_("back3", CubeListBuilder.m_171558_().m_171514_(104, 26).m_171481_(-1.5f, -2.0f, 0.0f, 3.0f, 2.0f, 9.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        PartDefinition tail3 = tail2.m_171599_("tail3", CubeListBuilder.m_171558_().m_171514_(0, 55).m_171481_(-2.0f, 0.0f, 0.0f, 4.0f, 5.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)8.0f));
        tail3.m_171599_("back4", CubeListBuilder.m_171558_().m_171514_(108, 37).m_171481_(-1.0f, -2.0f, 0.0f, 2.0f, 2.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        PartDefinition tail4 = tail3.m_171599_("tail4", CubeListBuilder.m_171558_().m_171514_(0, 68).m_171481_(-1.0f, 0.0f, 0.0f, 2.0f, 5.0f, 7.0f), PartPose.m_171419_((float)0.0f, (float)-1.0f, (float)7.0f));
        tail4.m_171599_("tail5", CubeListBuilder.m_171558_().m_171514_(0, 80).m_171481_(-0.5f, 0.0f, 0.0f, 1.0f, 3.0f, 7.0f), PartPose.m_171419_((float)0.0f, (float)1.0f, (float)6.0f));
        root.m_171599_("chest", CubeListBuilder.m_171558_().m_171514_(44, 0).m_171481_(-4.5f, 2.7f, -13.0f, 9.0f, 10.0f, 4.0f), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)-0.2602503f, (float)0.0f, (float)0.0f));
        PartDefinition neckplate3 = root.m_171599_("neckplate3", CubeListBuilder.m_171558_().m_171514_(112, 64).m_171481_(-2.0f, -2.0f, -2.0f, 4.0f, 2.0f, 4.0f), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)-12.0f, (float)-0.669215f, (float)0.0f, (float)0.0f));
        PartDefinition neck3 = root.m_171599_("neck3", CubeListBuilder.m_171558_().m_171514_(100, 113).m_171481_(-3.0f, 0.0f, -2.0f, 6.0f, 7.0f, 8.0f), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)-12.0f, (float)-0.669215f, (float)0.0f, (float)0.0f));
        PartDefinition MainHead = root.m_171599_("MainHead", CubeListBuilder.m_171558_(), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)-15.0f));
        PartDefinition neck2 = MainHead.m_171599_("neck2", CubeListBuilder.m_171558_().m_171514_(102, 99).m_171481_(-2.5f, -3.0f, -8.0f, 5.0f, 6.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        neck2.m_171599_("neckplate2", CubeListBuilder.m_171558_().m_171514_(106, 54).m_171481_(-1.5f, -2.0f, -8.0f, 3.0f, 2.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)-3.0f, (float)0.0f));
        PartDefinition neck1 = neck2.m_171599_("neck1", CubeListBuilder.m_171558_().m_171514_(104, 85).m_171481_(-2.0f, -3.0f, -8.0f, 4.0f, 6.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)-0.5f, (float)-5.5f));
        neck1.m_171599_("neckplate1", CubeListBuilder.m_171558_().m_171514_(80, 108).m_171481_(-1.0f, -2.0f, -8.0f, 2.0f, 2.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)-3.0f, (float)0.0f));
        PartDefinition head = neck1.m_171599_("head", CubeListBuilder.m_171558_().m_171514_(98, 70).m_171481_(-3.5f, -3.5f, -8.0f, 7.0f, 7.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)-7.0f));
        head.m_171599_("snout", CubeListBuilder.m_171558_().m_171514_(72, 70).m_171481_(-2.0f, -1.5f, -9.0f, 4.0f, 3.0f, 9.0f), PartPose.m_171423_((float)0.0f, (float)-1.5f, (float)-8.0f, (float)((float)Math.PI / 90), (float)0.0f, (float)0.0f));
        head.m_171599_("headplate", CubeListBuilder.m_171558_().m_171514_(80, 118).m_171481_(-1.0f, -1.0f, -4.0f, 2.0f, 2.0f, 8.0f), PartPose.m_171423_((float)0.0f, (float)-3.0f, (float)-1.0f, (float)0.17453292f, (float)0.0f, (float)0.0f));
        head.m_171597_("snout").m_171599_("beak", CubeListBuilder.m_171558_().m_171514_(60, 85).m_171481_(-1.5f, -2.5f, -1.5f, 3.0f, 5.0f, 3.0f), PartPose.m_171423_((float)0.0f, (float)0.8f, (float)-8.0f, (float)-0.10471975f, (float)0.7853981f, (float)-0.10471975f));
        head.m_171599_("righteyesock", CubeListBuilder.m_171558_().m_171514_(70, 108).m_171481_(0.0f, 0.0f, 0.0f, 1.0f, 2.0f, 4.0f), PartPose.m_171419_((float)-3.5f, (float)-2.5f, (float)-8.0f));
        head.m_171599_("lefteyesock", CubeListBuilder.m_171558_().m_171514_(70, 114).m_171481_(0.0f, 0.0f, 0.0f, 1.0f, 2.0f, 4.0f), PartPose.m_171419_((float)2.5f, (float)-2.5f, (float)-8.0f));
        head.m_171599_("Jaw", CubeListBuilder.m_171558_().m_171514_(72, 82).m_171481_(-2.0f, -1.0f, -9.0f, 4.0f, 2.0f, 9.0f), PartPose.m_171423_((float)0.0f, (float)2.5f, (float)-7.5f, (float)-0.17453292f, (float)0.0f, (float)0.0f));
        head.m_171599_("leftupjaw", CubeListBuilder.m_171558_().m_171514_(42, 93).m_171481_(-1.0f, -1.0f, -6.5f, 2.0f, 2.0f, 13.0f), PartPose.m_171423_((float)2.0f, (float)0.0f, (float)-10.5f, (float)-0.17453292f, (float)0.17453292f, (float)0.0f));
        head.m_171599_("rightupjaw", CubeListBuilder.m_171558_().m_171514_(72, 93).m_171481_(-1.0f, -1.0f, -6.5f, 2.0f, 2.0f, 13.0f), PartPose.m_171423_((float)-2.0f, (float)0.0f, (float)-10.5f, (float)-0.17453292f, (float)-0.17453292f, (float)0.0f));
        head.m_171599_("mouthrod", CubeListBuilder.m_171558_().m_171514_(104, 50).m_171481_(-5.0f, -1.0f, -1.0f, 10.0f, 2.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)1.0f, (float)-8.0f));
        head.m_171599_("helmetstrap1", CubeListBuilder.m_171558_().m_171514_(32, 146).m_171481_(-4.0f, -2.0f, 0.0f, 8.0f, 4.0f, 1.0f), PartPose.m_171419_((float)0.0f, (float)2.0f, (float)-7.5f));
        head.m_171599_("helmetstrap2", CubeListBuilder.m_171558_().m_171514_(32, 141).m_171481_(-4.0f, -2.0f, 0.0f, 8.0f, 4.0f, 1.0f), PartPose.m_171419_((float)0.0f, (float)2.0f, (float)-3.5f));
        head.m_171597_("mouthrod").m_171599_("controlrope1", CubeListBuilder.m_171558_().m_171514_(66, 43).m_171481_(0.0f, -2.0f, 0.0f, 0.0f, 4.0f, 23.0f), PartPose.m_171419_((float)4.5f, (float)1.0f, (float)0.0f));
        head.m_171597_("mouthrod").m_171599_("controlrope2", CubeListBuilder.m_171558_().m_171514_(66, 43).m_171481_(0.0f, -2.0f, 0.0f, 0.0f, 4.0f, 23.0f), PartPose.m_171419_((float)-4.5f, (float)1.0f, (float)0.0f));
        PartDefinition rightearskin = head.m_171599_("rightearskin", CubeListBuilder.m_171558_().m_171514_(112, 201).m_171481_(0.0f, -4.0f, 0.0f, 0.0f, 8.0f, 8.0f), PartPose.m_171419_((float)-3.0f, (float)-0.5f, (float)0.0f));
        PartDefinition leftearskin = head.m_171599_("leftearskin", CubeListBuilder.m_171558_().m_171514_(96, 201).m_171481_(0.0f, -4.0f, 0.0f, 0.0f, 8.0f, 8.0f), PartPose.m_171419_((float)3.0f, (float)-0.5f, (float)0.0f));
        rightearskin.m_171599_("rightspine1", CubeListBuilder.m_171558_().m_171514_(50, 141).m_171481_(-0.5f, -1.0f, 0.0f, 1.0f, 2.0f, 8.0f), PartPose.m_171423_((float)0.0f, (float)-2.0f, (float)0.0f, (float)0.2617994f, (float)0.0f, (float)0.0f));
        rightearskin.m_171599_("rightspine2", CubeListBuilder.m_171558_().m_171514_(50, 141).m_171481_(-0.5f, -1.0f, 0.0f, 1.0f, 2.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        rightearskin.m_171599_("rightspine3", CubeListBuilder.m_171558_().m_171514_(50, 141).m_171481_(-0.5f, -1.0f, 0.0f, 1.0f, 2.0f, 8.0f), PartPose.m_171423_((float)0.0f, (float)2.0f, (float)0.0f, (float)-0.2617994f, (float)0.0f, (float)0.0f));
        leftearskin.m_171599_("leftspine1", CubeListBuilder.m_171558_().m_171514_(68, 141).m_171481_(-0.5f, -1.0f, 0.0f, 1.0f, 2.0f, 8.0f), PartPose.m_171423_((float)0.0f, (float)-2.0f, (float)0.0f, (float)0.2617994f, (float)0.0f, (float)0.0f));
        leftearskin.m_171599_("leftspine2", CubeListBuilder.m_171558_().m_171514_(68, 141).m_171481_(-0.5f, -1.0f, 0.0f, 1.0f, 2.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        leftearskin.m_171599_("leftspine3", CubeListBuilder.m_171558_().m_171514_(68, 141).m_171481_(-0.5f, -1.0f, 0.0f, 1.0f, 2.0f, 8.0f), PartPose.m_171423_((float)0.0f, (float)2.0f, (float)0.0f, (float)-0.2617994f, (float)0.0f, (float)0.0f));
        leftearskin.m_171597_("leftspine1").m_171599_("ironhelmethorn1", CubeListBuilder.m_171558_().m_171514_(106, 139).m_171481_(-1.5f, -1.5f, 0.0f, 3.0f, 3.0f, 8.0f), PartPose.m_171419_((float)-0.5f, (float)0.0f, (float)0.1f));
        rightearskin.m_171597_("rightspine1").m_171599_("ironhelmethorn2", CubeListBuilder.m_171558_().m_171514_(106, 128).m_171481_(-1.5f, -1.5f, 0.0f, 3.0f, 3.0f, 8.0f), PartPose.m_171419_((float)0.5f, (float)0.0f, (float)0.1f));
        head.m_171599_("ironhelmet", CubeListBuilder.m_171558_().m_171514_(32, 128).m_171481_(-4.0f, -4.0f, -9.0f, 8.0f, 4.0f, 9.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        head.m_171597_("snout").m_171599_("ironhelmetsnout", CubeListBuilder.m_171558_().m_171514_(0, 144).m_171481_(-2.5f, -2.0f, -7.0f, 5.0f, 2.0f, 7.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)-1.0f));
        leftearskin.m_171597_("leftspine1").m_171599_("goldhelmethorn1", CubeListBuilder.m_171558_().m_171514_(106, 161).m_171481_(-1.5f, -1.5f, 0.0f, 3.0f, 3.0f, 8.0f), PartPose.m_171419_((float)-0.5f, (float)0.0f, (float)0.1f));
        rightearskin.m_171597_("rightspine1").m_171599_("goldhelmethorn2", CubeListBuilder.m_171558_().m_171514_(106, 150).m_171481_(-1.5f, -1.5f, 0.0f, 3.0f, 3.0f, 8.0f), PartPose.m_171419_((float)0.5f, (float)0.0f, (float)0.1f));
        head.m_171599_("goldhelmet", CubeListBuilder.m_171558_().m_171514_(94, 226).m_171481_(-4.0f, -4.0f, -9.0f, 8.0f, 4.0f, 9.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        head.m_171597_("snout").m_171599_("goldhelmetsnout", CubeListBuilder.m_171558_().m_171514_(71, 235).m_171481_(-2.5f, -2.0f, -7.0f, 5.0f, 2.0f, 7.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)-1.0f));
        head.m_171599_("diamondhelmet", CubeListBuilder.m_171558_().m_171514_(23, 226).m_171481_(-4.0f, -4.0f, -9.0f, 8.0f, 4.0f, 9.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        rightearskin.m_171597_("rightspine1").m_171599_("diamondhelmethorn2", CubeListBuilder.m_171558_().m_171514_(49, 234).m_171481_(-1.5f, -1.5f, 0.0f, 3.0f, 3.0f, 8.0f), PartPose.m_171419_((float)0.5f, (float)0.0f, (float)0.1f));
        leftearskin.m_171597_("leftspine1").m_171599_("diamondhelmethorn1", CubeListBuilder.m_171558_().m_171514_(49, 245).m_171481_(-1.5f, -1.5f, 0.0f, 3.0f, 3.0f, 8.0f), PartPose.m_171419_((float)-0.5f, (float)0.0f, (float)0.1f));
        head.m_171597_("snout").m_171599_("diamondhelmetsnout", CubeListBuilder.m_171558_().m_171514_(0, 235).m_171481_(-2.5f, -2.0f, -7.0f, 5.0f, 2.0f, 7.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)-1.0f));
        root.m_171599_("torso", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-5.0f, 0.0f, -12.0f, 10.0f, 10.0f, 12.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        root.m_171599_("saddle", CubeListBuilder.m_171558_().m_171514_(38, 70).m_171481_(-3.5f, -2.5f, -8.0f, 7.0f, 3.0f, 10.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        root.m_171599_("rightshoulder", CubeListBuilder.m_171558_().m_171514_(42, 83).m_171481_(-6.0f, 1.0f, -12.5f, 4.0f, 5.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)-0.2617994f, (float)0.0f, (float)0.0f));
        root.m_171599_("leftshoulder", CubeListBuilder.m_171558_().m_171514_(24, 83).m_171481_(2.0f, 1.0f, -12.5f, 4.0f, 5.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)-0.2617994f, (float)0.0f, (float)0.0f));
        PartDefinition LeftWing = root.m_171599_("LeftWing", CubeListBuilder.m_171558_(), PartPose.m_171419_((float)4.0f, (float)1.0f, (float)-11.0f));
        PartDefinition leftuparm = LeftWing.m_171599_("leftuparm", CubeListBuilder.m_171558_().m_171514_(44, 14).m_171481_(0.0f, -2.0f, -2.0f, 10.0f, 4.0f, 4.0f), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-0.17453292f, (float)0.0f));
        PartDefinition leftlowarm = leftuparm.m_171599_("leftlowarm", CubeListBuilder.m_171558_().m_171514_(72, 14).m_171481_(0.0f, -2.0f, -2.0f, 10.0f, 4.0f, 4.0f), PartPose.m_171423_((float)9.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.17453292f, (float)0.0f));
        PartDefinition leftfing1a = leftlowarm.m_171599_("leftfing1a", CubeListBuilder.m_171558_().m_171514_(52, 30).m_171481_(0.0f, 0.0f, -1.0f, 2.0f, 15.0f, 2.0f), PartPose.m_171423_((float)9.0f, (float)1.0f, (float)0.0f, (float)1.5707963f, (float)1.2217305f, (float)0.0f));
        leftfing1a.m_171599_("leftfing1b", CubeListBuilder.m_171558_().m_171514_(52, 47).m_171481_(0.0f, 0.0f, -1.0f, 2.0f, 10.0f, 2.0f), PartPose.m_171423_((float)0.0f, (float)14.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.61086524f));
        PartDefinition leftfing2a = leftlowarm.m_171599_("leftfing2a", CubeListBuilder.m_171558_().m_171514_(44, 30).m_171481_(-1.0f, 0.0f, 0.0f, 2.0f, 15.0f, 2.0f), PartPose.m_171423_((float)9.0f, (float)1.0f, (float)0.0f, (float)1.5707963f, (float)0.61086524f, (float)0.0f));
        leftfing2a.m_171599_("leftfing2b", CubeListBuilder.m_171558_().m_171514_(44, 47).m_171481_(-1.0f, 0.0f, 0.0f, 2.0f, 10.0f, 2.0f), PartPose.m_171423_((float)0.0f, (float)14.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.5235988f));
        PartDefinition leftfing3a = leftlowarm.m_171599_("leftfing3a", CubeListBuilder.m_171558_().m_171514_(36, 30).m_171481_(-1.0f, 0.0f, 1.0f, 2.0f, 15.0f, 2.0f), PartPose.m_171423_((float)9.0f, (float)1.0f, (float)0.0f, (float)1.5707963f, (float)-0.08726646f, (float)0.0f));
        leftfing3a.m_171599_("leftfing3b", CubeListBuilder.m_171558_().m_171514_(36, 47).m_171481_(-1.0f, 0.0f, 1.0f, 2.0f, 10.0f, 2.0f), PartPose.m_171423_((float)0.0f, (float)14.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.5235988f));
        leftfing1a.m_171599_("leftwingflap1", CubeListBuilder.m_171558_().m_171514_(74, 153).m_171481_(3.5f, -3.0f, 0.95f, 14.0f, 24.0f, 0.0f), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)1.2217305f));
        leftfing2a.m_171599_("leftwingflap2", CubeListBuilder.m_171558_().m_171514_(36, 153).m_171481_(-7.0f, 1.05f, 1.05f, 19.0f, 24.0f, 0.0f), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.6981317f));
        leftfing3a.m_171599_("leftwingflap3", CubeListBuilder.m_171558_().m_171514_(0, 153).m_171481_(-17.5f, 1.0f, 1.1f, 18.0f, 24.0f, 0.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        PartDefinition RightWing = root.m_171599_("RightWing", CubeListBuilder.m_171558_(), PartPose.m_171419_((float)-4.0f, (float)1.0f, (float)-11.0f));
        PartDefinition rightuparm = RightWing.m_171599_("rightuparm", CubeListBuilder.m_171558_().m_171514_(44, 22).m_171481_(-10.0f, -2.0f, -2.0f, 10.0f, 4.0f, 4.0f), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.17453292f, (float)0.0f));
        PartDefinition rightlowarm = rightuparm.m_171599_("rightlowarm", CubeListBuilder.m_171558_().m_171514_(72, 22).m_171481_(-10.0f, -2.0f, -2.0f, 10.0f, 4.0f, 4.0f), PartPose.m_171423_((float)-9.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-0.17453292f, (float)0.0f));
        PartDefinition rightfing1a = rightlowarm.m_171599_("rightfing1a", CubeListBuilder.m_171558_().m_171514_(36, 30).m_171481_(-1.0f, 0.0f, -1.0f, 2.0f, 15.0f, 2.0f), PartPose.m_171423_((float)-9.0f, (float)1.0f, (float)-1.0f, (float)1.5707963f, (float)-1.2217305f, (float)0.0f));
        rightfing1a.m_171599_("rightfing1b", CubeListBuilder.m_171558_().m_171514_(36, 47).m_171481_(-1.0f, 0.0f, -1.0f, 2.0f, 10.0f, 2.0f), PartPose.m_171423_((float)0.0f, (float)14.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-0.61086524f));
        rightfing1a.m_171599_("rightwingflap1", CubeListBuilder.m_171558_().m_171514_(74, 177).m_171481_(-17.5f, -3.0f, 0.95f, 14.0f, 24.0f, 0.0f), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-1.2217305f));
        PartDefinition rightfing2a = rightlowarm.m_171599_("rightfing2a", CubeListBuilder.m_171558_().m_171514_(44, 30).m_171481_(-1.0f, 0.0f, 0.0f, 2.0f, 15.0f, 2.0f), PartPose.m_171423_((float)-9.0f, (float)1.0f, (float)0.0f, (float)1.5707963f, (float)-0.61086524f, (float)0.0f));
        rightfing2a.m_171599_("rightfing2b", CubeListBuilder.m_171558_().m_171514_(44, 47).m_171481_(-1.0f, 0.0f, 0.0f, 2.0f, 10.0f, 2.0f), PartPose.m_171423_((float)0.0f, (float)14.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-0.5235988f));
        rightfing2a.m_171599_("rightwingflap2", CubeListBuilder.m_171558_().m_171514_(36, 177).m_171481_(-19.0f, 1.05f, 1.05f, 19.0f, 24.0f, 0.0f), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-0.6981317f));
        PartDefinition rightfing3a = rightlowarm.m_171599_("rightfing3a", CubeListBuilder.m_171558_().m_171514_(52, 30).m_171481_(-1.0f, 0.0f, 1.0f, 2.0f, 15.0f, 2.0f), PartPose.m_171423_((float)-9.0f, (float)1.0f, (float)0.0f, (float)1.5707963f, (float)0.08726646f, (float)0.0f));
        rightfing3a.m_171599_("rightfing3b", CubeListBuilder.m_171558_().m_171514_(52, 47).m_171481_(-1.0f, 0.0f, 1.0f, 2.0f, 10.0f, 2.0f), PartPose.m_171423_((float)0.0f, (float)14.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-0.5235988f));
        rightfing3a.m_171599_("rightwingflap3", CubeListBuilder.m_171558_().m_171514_(0, 177).m_171481_(-0.5f, 1.0f, 1.1f, 18.0f, 24.0f, 0.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        PartDefinition leftupleg = root.m_171599_("leftupleg", CubeListBuilder.m_171558_().m_171514_(0, 111).m_171481_(-2.0f, -3.0f, -3.0f, 4.0f, 10.0f, 7.0f), PartPose.m_171423_((float)5.0f, (float)6.0f, (float)-5.0f, (float)-0.43633232f, (float)0.0f, (float)0.0f));
        PartDefinition leftmidleg = leftupleg.m_171599_("leftmidleg", CubeListBuilder.m_171558_().m_171514_(0, 102).m_171481_(-1.5f, -2.0f, 0.0f, 3.0f, 4.0f, 5.0f), PartPose.m_171419_((float)0.0f, (float)5.0f, (float)4.0f));
        PartDefinition leftlowleg = leftmidleg.m_171599_("leftlowleg", CubeListBuilder.m_171558_().m_171514_(0, 91).m_171481_(-1.5f, 0.0f, -1.5f, 3.0f, 8.0f, 3.0f), PartPose.m_171419_((float)0.0f, (float)2.0f, (float)3.5f));
        PartDefinition leftfoot = leftlowleg.m_171599_("leftfoot", CubeListBuilder.m_171558_().m_171514_(44, 121).m_171481_(-2.0f, -1.0f, -3.0f, 4.0f, 3.0f, 4.0f), PartPose.m_171423_((float)0.0f, (float)7.0f, (float)0.5f, (float)0.43633232f, (float)0.0f, (float)0.0f));
        leftfoot.m_171599_("lefttoe1", CubeListBuilder.m_171558_().m_171514_(96, 35).m_171481_(-0.5f, -1.0f, -3.0f, 1.0f, 2.0f, 3.0f), PartPose.m_171419_((float)-1.5f, (float)1.0f, (float)-3.0f));
        leftfoot.m_171599_("lefttoe3", CubeListBuilder.m_171558_().m_171514_(96, 30).m_171481_(-0.5f, -1.0f, -3.0f, 1.0f, 2.0f, 3.0f), PartPose.m_171419_((float)1.5f, (float)1.0f, (float)-3.0f));
        leftfoot.m_171599_("lefttoe2", CubeListBuilder.m_171558_().m_171514_(84, 30).m_171481_(-1.0f, -1.5f, -4.0f, 2.0f, 3.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)0.5f, (float)-3.0f));
        leftfoot.m_171597_("lefttoe1").m_171599_("leftclaw1", CubeListBuilder.m_171558_().m_171514_(100, 26).m_171481_(-0.5f, 0.0f, -0.5f, 1.0f, 2.0f, 1.0f), PartPose.m_171423_((float)0.5f, (float)-0.5f, (float)-2.5f, (float)-0.43633232f, (float)0.0f, (float)0.0f));
        leftfoot.m_171597_("lefttoe2").m_171599_("leftclaw2", CubeListBuilder.m_171558_().m_171514_(100, 26).m_171481_(-0.5f, 0.0f, -0.5f, 1.0f, 3.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)-1.0f, (float)-3.5f, (float)-0.43633232f, (float)0.0f, (float)0.0f));
        leftfoot.m_171597_("lefttoe3").m_171599_("leftclaw3", CubeListBuilder.m_171558_().m_171514_(100, 26).m_171481_(-0.5f, 0.0f, -0.5f, 1.0f, 2.0f, 1.0f), PartPose.m_171423_((float)-0.5f, (float)-0.5f, (float)-2.5f, (float)-0.43633232f, (float)0.0f, (float)0.0f));
        leftlowleg.m_171599_("ironleftlegarmor", CubeListBuilder.m_171558_().m_171514_(39, 97).m_171481_(-2.0f, -2.5f, -2.0f, 4.0f, 5.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)2.5f, (float)0.0f));
        leftlowleg.m_171599_("goldleftlegarmor", CubeListBuilder.m_171558_().m_171514_(112, 181).m_171481_(-2.0f, -2.5f, -2.0f, 4.0f, 5.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)2.5f, (float)0.0f));
        leftlowleg.m_171599_("diamondleftlegarmor", CubeListBuilder.m_171558_().m_171514_(43, 215).m_171481_(-2.0f, -2.5f, -2.0f, 4.0f, 5.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)2.5f, (float)0.0f));
        PartDefinition rightupleg = root.m_171599_("rightupleg", CubeListBuilder.m_171558_().m_171514_(0, 111).m_171481_(-2.0f, -3.0f, -3.0f, 4.0f, 10.0f, 7.0f), PartPose.m_171423_((float)-5.0f, (float)6.0f, (float)-5.0f, (float)-0.43633232f, (float)0.0f, (float)0.0f));
        PartDefinition rightmidleg = rightupleg.m_171599_("rightmidleg", CubeListBuilder.m_171558_().m_171514_(0, 102).m_171481_(-1.5f, -2.0f, 0.0f, 3.0f, 4.0f, 5.0f), PartPose.m_171419_((float)0.0f, (float)5.0f, (float)4.0f));
        PartDefinition rightlowleg = rightmidleg.m_171599_("rightlowleg", CubeListBuilder.m_171558_().m_171514_(0, 91).m_171481_(-1.5f, 0.0f, -1.5f, 3.0f, 8.0f, 3.0f), PartPose.m_171419_((float)0.0f, (float)2.0f, (float)3.5f));
        PartDefinition rightfoot = rightlowleg.m_171599_("rightfoot", CubeListBuilder.m_171558_().m_171514_(44, 121).m_171481_(-2.0f, -1.0f, -3.0f, 4.0f, 3.0f, 4.0f), PartPose.m_171423_((float)0.0f, (float)7.0f, (float)0.5f, (float)0.43633232f, (float)0.0f, (float)0.0f));
        rightfoot.m_171599_("righttoe1", CubeListBuilder.m_171558_().m_171514_(96, 35).m_171481_(-0.5f, -1.0f, -3.0f, 1.0f, 2.0f, 3.0f), PartPose.m_171419_((float)-1.5f, (float)1.0f, (float)-3.0f));
        rightfoot.m_171599_("righttoe3", CubeListBuilder.m_171558_().m_171514_(96, 30).m_171481_(-0.5f, -1.0f, -3.0f, 1.0f, 2.0f, 3.0f), PartPose.m_171419_((float)1.5f, (float)1.0f, (float)-3.0f));
        rightfoot.m_171599_("righttoe2", CubeListBuilder.m_171558_().m_171514_(84, 30).m_171481_(-1.0f, -1.5f, -4.0f, 2.0f, 3.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)0.5f, (float)-3.0f));
        rightfoot.m_171597_("righttoe1").m_171599_("rightclaw1", CubeListBuilder.m_171558_().m_171514_(100, 26).m_171481_(-0.5f, 0.0f, -0.5f, 1.0f, 2.0f, 1.0f), PartPose.m_171423_((float)0.5f, (float)-0.5f, (float)-2.5f, (float)-0.43633232f, (float)0.0f, (float)0.0f));
        rightfoot.m_171597_("righttoe2").m_171599_("rightclaw2", CubeListBuilder.m_171558_().m_171514_(100, 26).m_171481_(-0.5f, 0.0f, -0.5f, 1.0f, 3.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)-1.0f, (float)-3.5f, (float)-0.43633232f, (float)0.0f, (float)0.0f));
        rightfoot.m_171597_("righttoe3").m_171599_("rightclaw3", CubeListBuilder.m_171558_().m_171514_(100, 26).m_171481_(-0.5f, 0.0f, -0.5f, 1.0f, 2.0f, 1.0f), PartPose.m_171423_((float)-0.5f, (float)-0.5f, (float)-2.5f, (float)-0.43633232f, (float)0.0f, (float)0.0f));
        rightlowleg.m_171599_("ironrightlegarmor", CubeListBuilder.m_171558_().m_171514_(39, 97).m_171481_(-2.0f, -2.5f, -2.0f, 4.0f, 5.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)2.5f, (float)0.0f));
        rightlowleg.m_171599_("goldrightlegarmor", CubeListBuilder.m_171558_().m_171514_(112, 181).m_171481_(-2.0f, -2.5f, -2.0f, 4.0f, 5.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)2.5f, (float)0.0f));
        rightlowleg.m_171599_("diamondrightlegarmor", CubeListBuilder.m_171558_().m_171514_(43, 215).m_171481_(-2.0f, -2.5f, -2.0f, 4.0f, 5.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)2.5f, (float)0.0f));
        root.m_171599_("storage", CubeListBuilder.m_171558_().m_171514_(28, 59).m_171481_(-5.0f, -4.5f, 1.5f, 10.0f, 5.0f, 6.0f), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)-0.2268928f, (float)0.0f, (float)0.0f));
        root.m_171599_("chestbelt", CubeListBuilder.m_171558_().m_171514_(0, 201).m_171481_(-5.5f, -0.5f, -9.0f, 11.0f, 11.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        root.m_171599_("stomachbelt", CubeListBuilder.m_171558_().m_171514_(0, 201).m_171481_(-5.5f, -0.5f, -3.0f, 11.0f, 11.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.0f));
        root.m_171599_("ironchestarmor", CubeListBuilder.m_171558_().m_171514_(0, 128).m_171481_(-5.5f, 2.2f, -13.5f, 11.0f, 11.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)-0.2602503f, (float)0.0f, (float)0.0f));
        root.m_171599_("ironrightshoulderpad", CubeListBuilder.m_171558_().m_171514_(74, 201).m_171481_(-6.5f, 0.5f, -13.0f, 5.0f, 6.0f, 6.0f), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)-0.2617994f, (float)0.0f, (float)0.0f));
        root.m_171599_("ironleftshoulderpad", CubeListBuilder.m_171558_().m_171514_(26, 201).m_171481_(1.5f, 0.5f, -13.0f, 5.0f, 6.0f, 6.0f), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)-0.2617994f, (float)0.0f, (float)0.0f));
        root.m_171599_("goldleftshoulder", CubeListBuilder.m_171558_().m_171514_(71, 244).m_171481_(1.5f, 0.5f, -13.0f, 5.0f, 6.0f, 6.0f), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)-0.2617994f, (float)0.0f, (float)0.0f));
        root.m_171599_("goldchestarmor", CubeListBuilder.m_171558_().m_171514_(71, 219).m_171481_(-5.5f, 2.2f, -13.5f, 11.0f, 11.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)-0.2602503f, (float)0.0f, (float)0.0f));
        root.m_171599_("goldrightshoulder", CubeListBuilder.m_171558_().m_171514_(93, 244).m_171481_(-6.5f, 0.5f, -13.0f, 5.0f, 6.0f, 6.0f), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)-0.2617994f, (float)0.0f, (float)0.0f));
        root.m_171599_("diamondleftshoulder", CubeListBuilder.m_171558_().m_171514_(0, 244).m_171481_(1.5f, 0.5f, -13.0f, 5.0f, 6.0f, 6.0f), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)-0.2617994f, (float)0.0f, (float)0.0f));
        root.m_171599_("diamondrightshoulder", CubeListBuilder.m_171558_().m_171514_(22, 244).m_171481_(-6.5f, 0.5f, -13.0f, 5.0f, 6.0f, 6.0f), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)-0.2617994f, (float)0.0f, (float)0.0f));
        root.m_171599_("diamondchestarmor", CubeListBuilder.m_171558_().m_171514_(0, 219).m_171481_(-5.5f, 2.2f, -13.5f, 11.0f, 11.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)-0.2602503f, (float)0.0f, (float)0.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)128, (int)256);
    }

    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float tailLat;
        float maxYaw;
        this.armor = ((MoCEntityWyvern)entity).getArmorType();
        this.isRidden = entity.m_20160_() && ((MoCEntityAnimal)entity).m_6688_() instanceof Player;
        this.isChested = ((MoCEntityWyvern)entity).getIsChested();
        this.isSaddled = ((MoCEntityWyvern)entity).getIsRideable();
        this.flapwings = ((MoCEntityWyvern)entity).wingFlapCounter != 0;
        this.onAir = ((MoCEntityWyvern)entity).isOnAir() || ((MoCEntityWyvern)entity).getIsFlying();
        this.diving = ((MoCEntityWyvern)entity).diveCounter != 0;
        this.isSitting = ((MoCEntityWyvern)entity).getIsSitting();
        this.isGhost = ((MoCEntityWyvern)entity).getIsGhost();
        this.openMouth = ((MoCEntityWyvern)entity).mouthCounter;
        this.yOffset = ((MoCEntityWyvern)entity).getAdjustedYOffset();
        this.transparency = ((MoCEntityWyvern)entity).tFloat();
        float RLegXRot = Mth.m_14089_((float)(limbSwing * 0.6662f + (float)Math.PI)) * 0.8f * limbSwingAmount;
        float LLegXRot = Mth.m_14089_((float)(limbSwing * 0.6662f)) * 0.8f * limbSwingAmount;
        if ((netHeadYaw = MoCTools.realAngle(netHeadYaw)) > (maxYaw = 60.0f)) {
            netHeadYaw = maxYaw;
        }
        if (netHeadYaw < -maxYaw) {
            netHeadYaw = -maxYaw;
        }
        this.neck2.f_104203_ = -1.1519173f + headPitch * 0.33333334f / 57.29578f;
        this.neck1.f_104203_ = 0.5235988f + headPitch * 0.6666667f / 57.29578f;
        this.head.f_104203_ = 0.7853981f;
        this.neck2.f_104204_ = netHeadYaw * 0.6666667f / 57.29578f;
        this.neck1.f_104204_ = netHeadYaw * 0.33333334f / 57.29578f;
        this.head.f_104204_ = 0.0f;
        this.head.f_104205_ = 0.0f;
        if (this.isRidden) {
            this.neck1.f_104204_ = 0.0f;
            this.neck2.f_104204_ = 0.0f;
            if (this.onAir) {
                this.neck1.f_104203_ = 0.0f;
                this.neck2.f_104203_ = 0.0f;
            } else {
                this.neck2.f_104203_ = -1.1519173f + RLegXRot * 0.016666668f;
                this.neck1.f_104203_ = 0.5235988f + RLegXRot * 0.033333335f;
            }
        }
        float TailXRot = Mth.m_14089_((float)(limbSwing * 0.4f)) * 0.2f * limbSwingAmount;
        this.tail1.f_104203_ = -0.33161256f;
        this.tail2.f_104203_ = -0.27925268f;
        this.tail3.f_104203_ = 0.12217305f;
        this.tail4.f_104203_ = 0.19198622f;
        this.tail5.f_104203_ = 0.13962634f;
        float t = limbSwing / 2.0f;
        float A = 0.15f;
        float w = 0.9f;
        float k = 0.6f;
        int i = 0;
        this.tail1.f_104204_ = tailLat = A * Mth.m_14031_((float)(w * t - k * (float)i++));
        this.tail2.f_104204_ = tailLat = A * Mth.m_14031_((float)(w * t - k * (float)i++));
        this.tail3.f_104204_ = tailLat = A * Mth.m_14031_((float)(w * t - k * (float)i++));
        this.tail4.f_104204_ = tailLat = A * Mth.m_14031_((float)(w * t - k * (float)i++));
        this.tail5.f_104204_ = tailLat = A * Mth.m_14031_((float)(w * t - k * (float)i++));
        float WingSpread = this.flapwings && !this.isGhost ? Mth.m_14089_((float)(ageInTicks * 0.3f + (float)Math.PI)) * 1.2f : Mth.m_14089_((float)(limbSwing * 0.5f)) * 0.1f;
        if (this.onAir || this.isGhost) {
            float speedMov = limbSwingAmount * 0.5f;
            if (this.isGhost) {
                speedMov = 0.5f;
            }
            this.leftuparm.f_104205_ = WingSpread * 2.0f / 3.0f;
            this.rightuparm.f_104205_ = -WingSpread * 2.0f / 3.0f;
            this.leftlowarm.f_104205_ = WingSpread * 0.1f;
            this.leftfing1a.f_104205_ = WingSpread;
            this.leftfing2a.f_104205_ = WingSpread * 0.8f;
            this.rightlowarm.f_104205_ = -WingSpread * 0.1f;
            this.rightfing1a.f_104205_ = -WingSpread;
            this.rightfing2a.f_104205_ = -WingSpread * 0.8f;
            this.leftuparm.f_104204_ = -0.17453292f - WingSpread / 2.0f;
            this.leftlowarm.f_104204_ = 0.2617994f + WingSpread / 2.0f;
            this.leftfing1a.f_104204_ = 1.2217305f;
            this.leftfing2a.f_104204_ = 0.61086524f;
            this.leftfing3a.f_104204_ = -0.08726646f;
            this.rightuparm.f_104204_ = 0.17453292f + WingSpread / 2.0f;
            this.rightlowarm.f_104204_ = -0.2617994f - WingSpread / 2.0f;
            this.rightfing1a.f_104204_ = -1.2217305f;
            this.rightfing2a.f_104204_ = -0.61086524f;
            this.rightfing3a.f_104204_ = 0.08726646f;
            this.leftupleg.f_104203_ = speedMov;
            this.leftmidleg.f_104203_ = speedMov;
            this.leftfoot.f_104203_ = 0.43633232f;
            this.lefttoe1.f_104203_ = speedMov;
            this.lefttoe2.f_104203_ = speedMov;
            this.lefttoe3.f_104203_ = speedMov;
            this.rightfoot.f_104203_ = 0.43633232f;
            this.rightupleg.f_104203_ = speedMov;
            this.rightmidleg.f_104203_ = speedMov;
            this.righttoe1.f_104203_ = speedMov;
            this.righttoe2.f_104203_ = speedMov;
            this.righttoe3.f_104203_ = speedMov;
        } else {
            this.leftlowarm.f_104205_ = 0.0f;
            this.leftfing1a.f_104205_ = 0.0f;
            this.leftfing2a.f_104205_ = 0.0f;
            this.rightlowarm.f_104205_ = 0.0f;
            this.rightfing1a.f_104205_ = 0.0f;
            this.rightfing2a.f_104205_ = 0.0f;
            this.leftuparm.f_104205_ = 0.5235988f;
            this.leftuparm.f_104204_ = -1.0471976f + LLegXRot / 5.0f;
            this.leftlowarm.f_104204_ = 1.8325957f;
            this.leftfing1a.f_104204_ = -0.34906584f;
            this.leftfing2a.f_104204_ = -0.4537856f;
            this.leftfing3a.f_104204_ = -0.55850536f;
            this.rightuparm.f_104204_ = 1.0471976f - RLegXRot / 5.0f;
            this.rightuparm.f_104205_ = -0.5235988f;
            this.rightlowarm.f_104204_ = -1.8325957f;
            this.rightfing1a.f_104204_ = 0.27925268f;
            this.rightfing2a.f_104204_ = 0.4537856f;
            this.rightfing3a.f_104204_ = 0.55850536f;
            this.leftupleg.f_104203_ = -0.43633232f + LLegXRot;
            this.rightupleg.f_104203_ = -0.43633232f + RLegXRot;
            this.leftmidleg.f_104203_ = 0.0f;
            this.leftlowleg.f_104203_ = 0.0f;
            this.leftfoot.f_104203_ = 0.43633232f - LLegXRot;
            this.lefttoe1.f_104203_ = LLegXRot;
            this.lefttoe2.f_104203_ = LLegXRot;
            this.lefttoe3.f_104203_ = LLegXRot;
            this.rightmidleg.f_104203_ = 0.0f;
            this.rightlowleg.f_104203_ = 0.0f;
            this.rightfoot.f_104203_ = 0.43633232f - RLegXRot;
            this.righttoe1.f_104203_ = RLegXRot;
            this.righttoe2.f_104203_ = RLegXRot;
            this.righttoe3.f_104203_ = RLegXRot;
        }
        if (this.isSitting) {
            this.leftupleg.f_104203_ = 0.7853981f + LLegXRot;
            this.rightupleg.f_104203_ = 0.7853981f + RLegXRot;
            this.leftmidleg.f_104203_ = 0.5235988f;
            this.rightmidleg.f_104203_ = 0.5235988f;
            this.neck2.f_104203_ = -0.62831855f + headPitch * 0.33333334f / 57.29578f;
            this.neck1.f_104203_ = 0.5235988f + headPitch * 0.6666667f / 57.29578f;
        }
        if (this.diving) {
            this.leftuparm.f_104205_ = -0.6981317f;
            this.rightuparm.f_104205_ = 0.6981317f;
            this.leftlowarm.f_104205_ = 0.0f;
            this.leftfing1a.f_104205_ = 0.0f;
            this.leftfing2a.f_104205_ = 0.0f;
            this.rightlowarm.f_104205_ = 0.0f;
            this.rightfing1a.f_104205_ = 0.0f;
            this.rightfing2a.f_104205_ = 0.0f;
            this.leftuparm.f_104204_ = -0.87266463f;
            this.leftlowarm.f_104204_ = 0.5235988f;
            this.leftfing1a.f_104204_ = 0.87266463f;
            this.leftfing2a.f_104204_ = 0.5235988f;
            this.leftfing3a.f_104204_ = 0.17453292f;
            this.rightuparm.f_104204_ = 0.87266463f;
            this.rightlowarm.f_104204_ = -0.5235988f;
            this.rightfing1a.f_104204_ = -0.87266463f;
            this.rightfing2a.f_104204_ = -0.5235988f;
            this.rightfing3a.f_104204_ = -0.17453292f;
        }
        if (this.openMouth != 0) {
            float mouthMov = Mth.m_14089_((float)((float)(this.openMouth - 15) * 0.11f)) * 0.8f;
            this.Jaw.f_104203_ = -0.17453292f + mouthMov;
            this.leftearskin.f_104204_ = mouthMov;
            this.rightearskin.f_104204_ = -mouthMov;
        } else {
            this.Jaw.f_104203_ = -0.17453292f;
            this.leftearskin.f_104204_ = 0.0f;
            this.rightearskin.f_104204_ = 0.0f;
        }
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        poseStack.m_85836_();
        poseStack.m_252880_(0.0f, this.yOffset, 0.0f);
        if (this.isGhost) {
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.clearColor((float)0.8f, (float)0.8f, (float)0.8f, (float)this.transparency);
        }
        this.back1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Tail.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.chest.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LeftWing.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RightWing.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.rightshoulder.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leftshoulder.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.neckplate3.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.neck3.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.torso.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        if (this.isChested) {
            this.storage.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        }
        if (this.isSaddled) {
            this.saddle.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.mouthrod.f_104207_ = true;
            this.helmetstrap1.f_104207_ = true;
            this.helmetstrap2.f_104207_ = true;
            this.chestbelt.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.stomachbelt.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            if (this.isRidden) {
                this.controlrope1.f_104207_ = true;
                this.controlrope2.f_104207_ = true;
            } else {
                this.controlrope1.f_104207_ = false;
                this.controlrope2.f_104207_ = false;
            }
        } else {
            this.mouthrod.f_104207_ = false;
            this.helmetstrap1.f_104207_ = false;
            this.helmetstrap2.f_104207_ = false;
        }
        this.ironhelmethorn1.f_104207_ = false;
        this.ironhelmethorn2.f_104207_ = false;
        this.ironhelmet.f_104207_ = false;
        this.ironhelmetsnout.f_104207_ = false;
        this.ironrightlegarmor.f_104207_ = false;
        this.ironleftlegarmor.f_104207_ = false;
        this.ironchestarmor.f_104207_ = false;
        this.ironrightshoulderpad.f_104207_ = false;
        this.ironleftshoulderpad.f_104207_ = false;
        this.goldleftshoulder.f_104207_ = false;
        this.goldchestarmor.f_104207_ = false;
        this.goldrightshoulder.f_104207_ = false;
        this.goldleftlegarmor.f_104207_ = false;
        this.goldrightlegarmor.f_104207_ = false;
        this.goldhelmethorn1.f_104207_ = false;
        this.goldhelmethorn2.f_104207_ = false;
        this.goldhelmet.f_104207_ = false;
        this.goldhelmetsnout.f_104207_ = false;
        this.diamondleftshoulder.f_104207_ = false;
        this.diamondrightshoulder.f_104207_ = false;
        this.diamondchestarmor.f_104207_ = false;
        this.diamondleftlegarmor.f_104207_ = false;
        this.diamondrightlegarmor.f_104207_ = false;
        this.diamondhelmet.f_104207_ = false;
        this.diamondhelmethorn2.f_104207_ = false;
        this.diamondhelmethorn1.f_104207_ = false;
        this.diamondhelmetsnout.f_104207_ = false;
        switch (this.armor) {
            case 1: {
                this.ironhelmethorn1.f_104207_ = true;
                this.ironhelmethorn2.f_104207_ = true;
                this.ironhelmet.f_104207_ = true;
                this.ironhelmetsnout.f_104207_ = true;
                this.ironrightlegarmor.f_104207_ = true;
                this.ironleftlegarmor.f_104207_ = true;
                this.ironchestarmor.f_104207_ = true;
                this.ironrightshoulderpad.f_104207_ = true;
                this.ironleftshoulderpad.f_104207_ = true;
                break;
            }
            case 2: {
                this.goldleftshoulder.f_104207_ = true;
                this.goldchestarmor.f_104207_ = true;
                this.goldrightshoulder.f_104207_ = true;
                this.goldleftlegarmor.f_104207_ = true;
                this.goldrightlegarmor.f_104207_ = true;
                this.goldhelmethorn1.f_104207_ = true;
                this.goldhelmethorn2.f_104207_ = true;
                this.goldhelmet.f_104207_ = true;
                this.goldhelmetsnout.f_104207_ = true;
                break;
            }
            case 3: {
                this.diamondleftshoulder.f_104207_ = true;
                this.diamondrightshoulder.f_104207_ = true;
                this.diamondchestarmor.f_104207_ = true;
                this.diamondleftlegarmor.f_104207_ = true;
                this.diamondrightlegarmor.f_104207_ = true;
                this.diamondhelmet.f_104207_ = true;
                this.diamondhelmethorn2.f_104207_ = true;
                this.diamondhelmethorn1.f_104207_ = true;
                this.diamondhelmetsnout.f_104207_ = true;
            }
        }
        this.MainHead.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leftupleg.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.rightupleg.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.ironchestarmor.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.ironrightshoulderpad.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.ironleftshoulderpad.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.goldleftshoulder.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.goldchestarmor.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.goldrightshoulder.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.diamondleftshoulder.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.diamondrightshoulder.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.diamondchestarmor.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        if (this.isGhost) {
            RenderSystem.disableBlend();
        }
        poseStack.m_85849_();
    }
}

