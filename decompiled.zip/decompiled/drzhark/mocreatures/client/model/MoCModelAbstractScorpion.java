/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeDeformation
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraft.world.entity.Entity
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public abstract class MoCModelAbstractScorpion<T extends Entity>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "scorpion"), "main");
    private final ModelPart head;
    private final ModelPart mouthL;
    private final ModelPart mouthR;
    private final ModelPart body;
    private final ModelPart tail1;
    private final ModelPart tail2;
    private final ModelPart tail3;
    private final ModelPart tail4;
    private final ModelPart tail5;
    private final ModelPart sting1;
    private final ModelPart sting2;
    private final ModelPart lArm1;
    private final ModelPart lArm2;
    private final ModelPart lArm3;
    private final ModelPart lArm4;
    private final ModelPart rArm1;
    private final ModelPart rArm2;
    private final ModelPart rArm3;
    private final ModelPart rArm4;
    private final ModelPart leg1A;
    private final ModelPart leg1B;
    private final ModelPart leg1C;
    private final ModelPart leg2A;
    private final ModelPart leg2B;
    private final ModelPart leg2C;
    private final ModelPart leg3A;
    private final ModelPart leg3B;
    private final ModelPart leg3C;
    private final ModelPart leg4A;
    private final ModelPart leg4B;
    private final ModelPart leg4C;
    private final ModelPart leg5A;
    private final ModelPart leg5B;
    private final ModelPart leg5C;
    private final ModelPart leg6A;
    private final ModelPart leg6B;
    private final ModelPart leg6C;
    private final ModelPart leg7A;
    private final ModelPart leg7B;
    private final ModelPart leg7C;
    private final ModelPart leg8A;
    private final ModelPart leg8B;
    private final ModelPart leg8C;
    private final ModelPart baby1;
    private final ModelPart baby2;
    private final ModelPart baby3;
    private final ModelPart baby4;
    private final ModelPart baby5;
    protected boolean poisoning;
    protected boolean isAdult;
    protected boolean isTalking;
    protected boolean babies;
    protected int attacking;
    protected boolean sitting;
    private float radianF = 57.29578f;

    public MoCModelAbstractScorpion(ModelPart root) {
        this.head = root.m_171324_("head");
        this.mouthL = root.m_171324_("mouth_l");
        this.mouthR = root.m_171324_("mouth_r");
        this.body = root.m_171324_("body");
        this.tail1 = root.m_171324_("tail1");
        this.tail2 = root.m_171324_("tail2");
        this.tail3 = root.m_171324_("tail3");
        this.tail4 = root.m_171324_("tail4");
        this.tail5 = root.m_171324_("tail5");
        this.sting1 = root.m_171324_("sting1");
        this.sting2 = root.m_171324_("sting2");
        this.lArm1 = root.m_171324_("l_arm1");
        this.lArm2 = root.m_171324_("l_arm2");
        this.lArm3 = root.m_171324_("l_arm3");
        this.lArm4 = root.m_171324_("l_arm4");
        this.rArm1 = root.m_171324_("r_arm1");
        this.rArm2 = root.m_171324_("r_arm2");
        this.rArm3 = root.m_171324_("r_arm3");
        this.rArm4 = root.m_171324_("r_arm4");
        this.leg1A = root.m_171324_("leg1a");
        this.leg1B = root.m_171324_("leg1b");
        this.leg1C = root.m_171324_("leg1c");
        this.leg2A = root.m_171324_("leg2a");
        this.leg2B = root.m_171324_("leg2b");
        this.leg2C = root.m_171324_("leg2c");
        this.leg3A = root.m_171324_("leg3a");
        this.leg3B = root.m_171324_("leg3b");
        this.leg3C = root.m_171324_("leg3c");
        this.leg4A = root.m_171324_("leg4a");
        this.leg4B = root.m_171324_("leg4b");
        this.leg4C = root.m_171324_("leg4c");
        this.leg5A = root.m_171324_("leg5a");
        this.leg5B = root.m_171324_("leg5b");
        this.leg5C = root.m_171324_("leg5c");
        this.leg6A = root.m_171324_("leg6a");
        this.leg6B = root.m_171324_("leg6b");
        this.leg6C = root.m_171324_("leg6c");
        this.leg7A = root.m_171324_("leg7a");
        this.leg7B = root.m_171324_("leg7b");
        this.leg7C = root.m_171324_("leg7c");
        this.leg8A = root.m_171324_("leg8a");
        this.leg8B = root.m_171324_("leg8b");
        this.leg8C = root.m_171324_("leg8c");
        this.baby1 = root.m_171324_("baby1");
        this.baby2 = root.m_171324_("baby2");
        this.baby3 = root.m_171324_("baby3");
        this.baby4 = root.m_171324_("baby4");
        this.baby5 = root.m_171324_("baby5");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        PartDefinition head = root.m_171599_("head", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-5.0f, 0.0f, 0.0f, 10.0f, 5.0f, 13.0f, CubeDeformation.f_171458_), PartPose.m_171419_((float)0.0f, (float)14.0f, (float)-9.0f));
        PartDefinition mouthL = root.m_171599_("mouth_l", CubeListBuilder.m_171558_().m_171514_(18, 58).m_171488_(-3.0f, -2.0f, -1.0f, 4.0f, 4.0f, 2.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)3.0f, (float)17.0f, (float)-9.0f, (float)0.0f, (float)-0.3839724f, (float)0.0f));
        PartDefinition mouthR = root.m_171599_("mouth_r", CubeListBuilder.m_171558_().m_171514_(30, 58).m_171488_(-1.0f, -2.0f, -1.0f, 4.0f, 4.0f, 2.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)-3.0f, (float)17.0f, (float)-9.0f, (float)0.0f, (float)0.3839724f, (float)0.0f));
        PartDefinition body = root.m_171599_("body", CubeListBuilder.m_171558_().m_171514_(0, 18).m_171488_(-4.0f, -2.0f, 0.0f, 8.0f, 4.0f, 10.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)0.0f, (float)17.0f, (float)3.0f, (float)0.0872665f, (float)0.0f, (float)0.0f));
        PartDefinition tail1 = root.m_171599_("tail1", CubeListBuilder.m_171558_().m_171514_(0, 32).m_171488_(-3.0f, -2.0f, 0.0f, 6.0f, 4.0f, 6.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)0.0f, (float)16.0f, (float)12.0f, (float)0.6108652f, (float)0.0f, (float)0.0f));
        PartDefinition tail2 = root.m_171599_("tail2", CubeListBuilder.m_171558_().m_171514_(0, 42).m_171488_(-2.0f, -2.0f, 0.0f, 4.0f, 4.0f, 6.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)0.0f, (float)13.0f, (float)16.5f, (float)1.134464f, (float)0.0f, (float)0.0f));
        PartDefinition tail3 = root.m_171599_("tail3", CubeListBuilder.m_171558_().m_171514_(0, 52).m_171488_(-1.5f, -1.5f, 0.0f, 3.0f, 3.0f, 6.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)0.0f, (float)8.0f, (float)18.5f, (float)1.692143f, (float)0.0f, (float)0.0f));
        PartDefinition tail4 = root.m_171599_("tail4", CubeListBuilder.m_171558_().m_171514_(24, 32).m_171488_(-1.5f, -1.5f, 0.0f, 3.0f, 3.0f, 6.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)0.0f, (float)3.0f, (float)18.0f, (float)2.510073f, (float)0.0f, (float)0.0f));
        PartDefinition tail5 = root.m_171599_("tail5", CubeListBuilder.m_171558_().m_171514_(24, 41).m_171488_(-1.5f, -1.5f, 0.0f, 3.0f, 3.0f, 6.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)0.0f, (float)-0.2f, (float)14.0f, (float)3.067752f, (float)0.0f, (float)0.0f));
        PartDefinition sting1 = root.m_171599_("sting1", CubeListBuilder.m_171558_().m_171514_(30, 50).m_171488_(-1.5f, 0.0f, -1.5f, 3.0f, 5.0f, 3.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)0.0f, (float)-1.0f, (float)7.0f, (float)0.4089647f, (float)0.0f, (float)0.0f));
        PartDefinition sting2 = root.m_171599_("sting2", CubeListBuilder.m_171558_().m_171514_(26, 50).m_171488_(-0.5f, 0.0f, 0.5f, 1.0f, 4.0f, 1.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)0.0f, (float)2.6f, (float)8.8f, (float)-0.2230717f, (float)0.0f, (float)0.0f));
        PartDefinition lArm1 = root.m_171599_("l_arm1", CubeListBuilder.m_171558_().m_171514_(26, 18).m_171488_(-1.0f, -7.0f, -1.0f, 2.0f, 7.0f, 2.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)5.0f, (float)18.0f, (float)-8.0f, (float)-0.3490659f, (float)0.0f, (float)0.8726646f));
        PartDefinition lArm2 = root.m_171599_("l_arm2", CubeListBuilder.m_171558_().m_171514_(42, 55).m_171488_(-1.5f, -1.5f, -6.0f, 3.0f, 3.0f, 6.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)10.0f, (float)14.0f, (float)-6.0f, (float)0.1745329f, (float)-0.3490659f, (float)-0.2617994f));
        PartDefinition lArm3 = root.m_171599_("l_arm3", CubeListBuilder.m_171558_().m_171514_(42, 39).m_171488_(-0.5f, -0.5f, -7.0f, 2.0f, 1.0f, 7.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)12.0f, (float)15.0f, (float)-11.0f, (float)0.2617994f, (float)0.1570796f, (float)-0.1570796f));
        PartDefinition lArm4 = root.m_171599_("l_arm4", CubeListBuilder.m_171558_().m_171514_(42, 31).m_171488_(-1.5f, -0.5f, -6.0f, 1.0f, 1.0f, 7.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)11.0f, (float)15.0f, (float)-11.0f, (float)0.2617994f, (float)0.0f, (float)-0.1570796f));
        PartDefinition rArm1 = root.m_171599_("r_arm1", CubeListBuilder.m_171558_().m_171514_(0, 18).m_171488_(-1.0f, -7.0f, -1.0f, 2.0f, 7.0f, 2.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)-5.0f, (float)18.0f, (float)-8.0f, (float)-0.3490659f, (float)0.0f, (float)-0.8726646f));
        PartDefinition rArm2 = root.m_171599_("r_arm2", CubeListBuilder.m_171558_().m_171514_(42, 55).m_171488_(-1.5f, -1.5f, -6.0f, 3.0f, 3.0f, 6.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)-10.0f, (float)14.0f, (float)-6.0f, (float)0.1745329f, (float)0.3490659f, (float)0.2617994f));
        PartDefinition rArm3 = root.m_171599_("r_arm3", CubeListBuilder.m_171558_().m_171514_(42, 47).m_171488_(-1.5f, -0.5f, -7.0f, 2.0f, 1.0f, 7.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)-12.0f, (float)15.0f, (float)-11.0f, (float)0.2617994f, (float)-0.1570796f, (float)0.1570796f));
        PartDefinition rArm4 = root.m_171599_("r_arm4", CubeListBuilder.m_171558_().m_171514_(42, 31).m_171488_(0.5f, -0.5f, -6.0f, 1.0f, 1.0f, 7.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)-11.0f, (float)15.0f, (float)-11.0f, (float)0.2617994f, (float)0.0f, (float)0.1570796f));
        PartDefinition leg1A = root.m_171599_("leg1a", CubeListBuilder.m_171558_().m_171514_(38, 0).m_171488_(-1.0f, -7.0f, -1.0f, 2.0f, 7.0f, 2.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)5.0f, (float)18.0f, (float)-5.0f, (float)-0.17453292f, (float)0.0f, (float)1.3089969f));
        PartDefinition leg1B = root.m_171599_("leg1b", CubeListBuilder.m_171558_().m_171514_(50, 0).m_171488_(2.0f, -8.0f, -1.0f, 5.0f, 2.0f, 2.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)5.0f, (float)18.0f, (float)-5.0f, (float)-0.17453292f, (float)0.0f, (float)1.0471976f));
        PartDefinition leg1C = root.m_171599_("leg1c", CubeListBuilder.m_171558_().m_171514_(52, 16).m_171488_(4.5f, -9.0f, -0.7f, 5.0f, 1.0f, 1.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)5.0f, (float)18.0f, (float)-5.0f, (float)-0.17453292f, (float)0.0f, (float)1.3089969f));
        PartDefinition leg2A = root.m_171599_("leg2a", CubeListBuilder.m_171558_().m_171514_(38, 0).m_171488_(-1.0f, -7.0f, -1.0f, 2.0f, 7.0f, 2.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)5.0f, (float)18.0f, (float)-2.0f, (float)-0.5235988f, (float)0.0f, (float)1.2217305f));
        PartDefinition leg2B = root.m_171599_("leg2b", CubeListBuilder.m_171558_().m_171514_(50, 4).m_171488_(1.0f, -8.0f, -1.0f, 5.0f, 2.0f, 2.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)5.0f, (float)18.0f, (float)-2.0f, (float)-0.5235988f, (float)0.0f, (float)1.0471976f));
        PartDefinition leg2C = root.m_171599_("leg2c", CubeListBuilder.m_171558_().m_171514_(50, 18).m_171488_(4.0f, -8.5f, -1.0f, 6.0f, 1.0f, 1.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)5.0f, (float)18.0f, (float)-2.0f, (float)-0.5235988f, (float)0.0f, (float)1.2217305f));
        PartDefinition leg3A = root.m_171599_("leg3a", CubeListBuilder.m_171558_().m_171514_(38, 0).m_171488_(-1.0f, -7.0f, -1.0f, 2.0f, 7.0f, 2.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)5.0f, (float)17.5f, (float)1.0f, (float)-0.7853982f, (float)0.0f, (float)1.2217305f));
        PartDefinition leg3B = root.m_171599_("leg3b", CubeListBuilder.m_171558_().m_171514_(48, 8).m_171488_(1.0f, -8.0f, -1.0f, 6.0f, 2.0f, 2.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)5.0f, (float)17.5f, (float)1.0f, (float)-0.7853982f, (float)0.0f, (float)1.0471976f));
        PartDefinition leg3C = root.m_171599_("leg3c", CubeListBuilder.m_171558_().m_171514_(50, 20).m_171488_(4.5f, -8.2f, -1.3f, 6.0f, 1.0f, 1.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)5.0f, (float)17.5f, (float)1.0f, (float)-0.7853982f, (float)0.0f, (float)1.2217305f));
        PartDefinition leg4A = root.m_171599_("leg4a", CubeListBuilder.m_171558_().m_171514_(38, 0).m_171488_(-1.0f, -7.0f, -1.0f, 2.0f, 7.0f, 2.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)5.0f, (float)17.0f, (float)4.0f, (float)-1.0471976f, (float)0.0f, (float)1.2217305f));
        PartDefinition leg4B = root.m_171599_("leg4b", CubeListBuilder.m_171558_().m_171514_(46, 12).m_171488_(0.5f, -8.5f, -1.0f, 7.0f, 2.0f, 2.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)5.0f, (float)17.0f, (float)4.0f, (float)-1.0471976f, (float)0.0f, (float)1.0471976f));
        PartDefinition leg4C = root.m_171599_("leg4c", CubeListBuilder.m_171558_().m_171514_(48, 22).m_171488_(3.5f, -8.5f, -1.5f, 7.0f, 1.0f, 1.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)5.0f, (float)17.0f, (float)4.0f, (float)-1.0471976f, (float)0.0f, (float)1.2217305f));
        PartDefinition leg5A = root.m_171599_("leg5a", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-1.0f, -7.0f, -1.0f, 2.0f, 7.0f, 2.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)-5.0f, (float)18.0f, (float)-5.0f, (float)-0.17453292f, (float)0.0f, (float)-1.3089969f));
        PartDefinition leg5B = root.m_171599_("leg5b", CubeListBuilder.m_171558_().m_171514_(50, 0).m_171488_(-7.0f, -8.0f, -1.0f, 5.0f, 2.0f, 2.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)-5.0f, (float)18.0f, (float)-5.0f, (float)-0.17453292f, (float)0.0f, (float)-1.0471976f));
        PartDefinition leg5C = root.m_171599_("leg5c", CubeListBuilder.m_171558_().m_171514_(52, 16).m_171488_(-9.5f, -9.0f, -0.7f, 5.0f, 1.0f, 1.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)-5.0f, (float)18.0f, (float)-5.0f, (float)-0.17453292f, (float)0.0f, (float)-1.3089969f));
        PartDefinition leg6A = root.m_171599_("leg6a", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-1.0f, -7.0f, -1.0f, 2.0f, 7.0f, 2.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)-5.0f, (float)18.0f, (float)-2.0f, (float)-0.5235988f, (float)0.0f, (float)-1.2217305f));
        PartDefinition leg6B = root.m_171599_("leg6b", CubeListBuilder.m_171558_().m_171514_(50, 4).m_171488_(-6.0f, -8.0f, -1.0f, 5.0f, 2.0f, 2.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)-5.0f, (float)18.0f, (float)-2.0f, (float)-0.5235988f, (float)0.0f, (float)-1.0471976f));
        PartDefinition leg6C = root.m_171599_("leg6c", CubeListBuilder.m_171558_().m_171514_(50, 18).m_171488_(-10.0f, -8.5f, -1.0f, 6.0f, 1.0f, 1.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)-5.0f, (float)18.0f, (float)-2.0f, (float)-0.5235988f, (float)0.0f, (float)-1.0471976f));
        PartDefinition leg7A = root.m_171599_("leg7a", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-1.0f, -7.0f, -1.0f, 2.0f, 7.0f, 2.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)-5.0f, (float)17.5f, (float)1.0f, (float)-0.7853982f, (float)0.0f, (float)-1.2217305f));
        PartDefinition leg7B = root.m_171599_("leg7b", CubeListBuilder.m_171558_().m_171514_(48, 8).m_171488_(-7.0f, -8.5f, -1.0f, 6.0f, 2.0f, 2.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)-5.0f, (float)17.5f, (float)1.0f, (float)-0.7853982f, (float)0.0f, (float)-1.0471976f));
        PartDefinition leg7C = root.m_171599_("leg7c", CubeListBuilder.m_171558_().m_171514_(50, 20).m_171488_(-10.5f, -8.7f, -1.3f, 6.0f, 1.0f, 1.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)-5.0f, (float)17.5f, (float)1.0f, (float)-0.7853982f, (float)0.0f, (float)-1.2217305f));
        PartDefinition leg8A = root.m_171599_("leg8a", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-1.0f, -7.0f, -1.0f, 2.0f, 7.0f, 2.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)-5.0f, (float)17.0f, (float)4.0f, (float)-1.0471976f, (float)0.0f, (float)-1.2217305f));
        PartDefinition leg8B = root.m_171599_("leg8b", CubeListBuilder.m_171558_().m_171514_(46, 12).m_171488_(-7.5f, -8.5f, -1.0f, 7.0f, 2.0f, 2.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)-5.0f, (float)17.0f, (float)4.0f, (float)-1.0471976f, (float)0.0f, (float)-1.0471976f));
        PartDefinition leg8C = root.m_171599_("leg8c", CubeListBuilder.m_171558_().m_171514_(48, 22).m_171488_(-10.5f, -8.5f, -1.5f, 7.0f, 1.0f, 1.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)-5.0f, (float)17.0f, (float)4.0f, (float)-1.0471976f, (float)0.0f, (float)-1.2217305f));
        PartDefinition baby1 = root.m_171599_("baby1", CubeListBuilder.m_171558_().m_171514_(48, 24).m_171488_(-1.5f, 0.0f, -2.5f, 3.0f, 2.0f, 5.0f, CubeDeformation.f_171458_), PartPose.m_171419_((float)0.0f, (float)12.0f, (float)0.0f));
        PartDefinition baby2 = root.m_171599_("baby2", CubeListBuilder.m_171558_().m_171514_(48, 24).m_171488_(-1.5f, 0.0f, -2.5f, 3.0f, 2.0f, 5.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)-5.0f, (float)13.4f, (float)-1.0f, (float)0.4461433f, (float)2.490967f, (float)0.5205006f));
        PartDefinition baby3 = root.m_171599_("baby3", CubeListBuilder.m_171558_().m_171514_(48, 24).m_171488_(-1.5f, 0.0f, -2.5f, 3.0f, 2.0f, 5.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)-2.0f, (float)13.0f, (float)4.0f, (float)0.0f, (float)0.8551081f, (float)0.0f));
        PartDefinition baby4 = root.m_171599_("baby4", CubeListBuilder.m_171558_().m_171514_(48, 24).m_171488_(-1.5f, 0.0f, -2.5f, 3.0f, 2.0f, 5.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)4.0f, (float)13.0f, (float)2.0f, (float)0.0f, (float)2.714039f, (float)-0.3717861f));
        PartDefinition baby5 = root.m_171599_("baby5", CubeListBuilder.m_171558_().m_171514_(48, 24).m_171488_(-1.5f, 0.0f, -2.5f, 3.0f, 2.0f, 5.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)1.0f, (float)13.0f, (float)8.0f, (float)0.0f, (float)-1.189716f, (float)0.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)64, (int)64);
    }

    public void m_7695_(PoseStack stack, VertexConsumer builder, int packedLight, int packedOverlay, float r, float g, float b, float a) {
        this.head.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.mouthL.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.mouthR.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.body.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.tail1.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.tail2.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.tail3.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.tail4.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.tail5.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.sting1.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.sting2.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.lArm1.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.lArm2.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.lArm3.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.lArm4.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.rArm1.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.rArm2.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.rArm3.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.rArm4.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.leg1A.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.leg1B.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.leg1C.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.leg2A.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.leg2B.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.leg2C.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.leg3A.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.leg3B.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.leg3C.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.leg4A.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.leg4B.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.leg4C.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.leg5A.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.leg5B.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.leg5C.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.leg6A.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.leg6B.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.leg6C.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.leg7A.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.leg7B.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.leg7C.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.leg8A.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.leg8B.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        this.leg8C.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        if (this.babies && this.isAdult) {
            this.baby1.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
            this.baby2.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
            this.baby3.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
            this.baby4.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
            this.baby5.m_104306_(stack, builder, packedLight, packedOverlay, r, g, b, a);
        }
    }

    public void m_6973_(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        if (!this.poisoning) {
            this.body.f_104203_ = 5.0f / this.radianF;
            this.tail1.f_104203_ = 35.0f / this.radianF;
            this.tail1.f_104201_ = 16.0f;
            this.tail1.f_104202_ = 12.0f;
            this.tail2.f_104203_ = 65.0f / this.radianF;
            this.tail2.f_104201_ = 13.0f;
            this.tail2.f_104202_ = 16.5f;
            this.tail3.f_104203_ = 90.0f / this.radianF;
            this.tail3.f_104201_ = 8.0f;
            this.tail3.f_104202_ = 18.5f;
            this.tail4.f_104203_ = 143.0f / this.radianF;
            this.tail4.f_104201_ = 3.0f;
            this.tail4.f_104202_ = 18.0f;
            this.tail5.f_104203_ = 175.0f / this.radianF;
            this.tail5.f_104201_ = -0.2f;
            this.tail5.f_104202_ = 14.0f;
            this.sting1.f_104203_ = 24.0f / this.radianF;
            this.sting1.f_104201_ = -1.0f;
            this.sting1.f_104202_ = 7.0f;
            this.sting2.f_104203_ = -12.0f / this.radianF;
            this.sting2.f_104201_ = 2.6f;
            this.sting2.f_104202_ = 8.8f;
        } else {
            this.body.f_104203_ = 50.0f / this.radianF;
            this.tail1.f_104203_ = 100.0f / this.radianF;
            this.tail1.f_104201_ = 9.0f;
            this.tail1.f_104202_ = 10.0f;
            this.tail2.f_104203_ = 160.0f / this.radianF;
            this.tail2.f_104201_ = 3.0f;
            this.tail2.f_104202_ = 9.5f;
            this.tail3.f_104203_ = -170.0f / this.radianF;
            this.tail3.f_104201_ = 1.0f;
            this.tail3.f_104202_ = 3.5f;
            this.tail4.f_104203_ = -156.0f / this.radianF;
            this.tail4.f_104201_ = 1.8f;
            this.tail4.f_104202_ = -2.0f;
            this.tail5.f_104203_ = -154.0f / this.radianF;
            this.tail5.f_104201_ = 3.8f;
            this.tail5.f_104202_ = -7.0f;
            this.sting1.f_104203_ = -57.0f / this.radianF;
            this.sting1.f_104201_ = 6.0f;
            this.sting1.f_104202_ = -12.0f;
            this.sting2.f_104203_ = -93.7f / this.radianF;
            this.sting2.f_104201_ = 8.0f;
            this.sting2.f_104202_ = -15.2f;
        }
        float mouthRot = 0.0f;
        if (this.isTalking) {
            mouthRot = Mth.m_14089_((float)(ageInTicks * 1.1f)) * 0.2f;
        }
        this.mouthR.f_104204_ = 22.0f / this.radianF + mouthRot;
        this.mouthL.f_104204_ = -22.0f / this.radianF - mouthRot;
        this.lArm1.f_104203_ = -20.0f / this.radianF;
        this.lArm2.m_104227_(10.0f, 14.0f, -6.0f);
        this.lArm3.m_104227_(12.0f, 15.0f, -11.0f);
        this.lArm4.m_104227_(11.0f, 15.0f, -11.0f);
        this.lArm4.f_104204_ = 0.0f;
        this.rArm1.f_104203_ = -20.0f / this.radianF;
        this.rArm2.m_104227_(-10.0f, 14.0f, -6.0f);
        this.rArm3.m_104227_(-12.0f, 15.0f, -11.0f);
        this.rArm4.m_104227_(-11.0f, 15.0f, -11.0f);
        this.rArm4.f_104204_ = 0.0f;
        if (this.attacking == 0) {
            float lHand = 0.0f;
            float f2a = ageInTicks % 100.0f;
            if (f2a > 0.0f && f2a < 20.0f) {
                lHand = f2a / this.radianF;
            }
            this.lArm3.f_104204_ = 9.0f / this.radianF - lHand;
            this.lArm4.f_104204_ = lHand;
            float rHand = 0.0f;
            float f2b = ageInTicks % 75.0f;
            if (f2b > 30.0f && f2b < 50.0f) {
                rHand = (f2b - 29.0f) / this.radianF;
            }
            this.rArm3.f_104204_ = -9.0f / this.radianF + rHand;
            this.rArm4.f_104204_ = -rHand;
        } else {
            if (this.attacking > 0 && this.attacking < 5) {
                this.lArm1.f_104203_ = 50.0f / this.radianF;
                this.lArm2.m_104227_(8.0f, 15.0f, -13.0f);
                this.lArm3.m_104227_(10.0f, 16.0f, -18.0f);
                this.lArm4.m_104227_(9.0f, 16.0f, -18.0f);
                this.lArm4.f_104204_ = 40.0f / this.radianF;
            }
            if (this.attacking >= 5 && this.attacking < 10) {
                this.lArm1.f_104203_ = 70.0f / this.radianF;
                this.lArm2.m_104227_(7.0f, 16.0f, -14.0f);
                this.lArm3.m_104227_(9.0f, 17.0f, -19.0f);
                this.lArm4.m_104227_(8.0f, 17.0f, -19.0f);
                this.lArm4.f_104204_ = 0.0f;
            }
            if (this.attacking >= 10 && this.attacking < 15) {
                this.rArm1.f_104203_ = 50.0f / this.radianF;
                this.rArm2.m_104227_(-8.0f, 15.0f, -13.0f);
                this.rArm3.m_104227_(-10.0f, 16.0f, -18.0f);
                this.rArm4.m_104227_(-9.0f, 16.0f, -18.0f);
                this.rArm4.f_104204_ = -40.0f / this.radianF;
            }
            if (this.attacking >= 15 && this.attacking < 20) {
                this.rArm1.f_104203_ = 70.0f / this.radianF;
                this.rArm2.m_104227_(-7.0f, 16.0f, -14.0f);
                this.rArm3.m_104227_(-9.0f, 17.0f, -19.0f);
                this.rArm4.m_104227_(-8.0f, 17.0f, -19.0f);
                this.rArm4.f_104204_ = 0.0f;
            }
        }
        if (this.babies && this.isAdult) {
            float fmov = ageInTicks % 100.0f;
            float fb1 = 0.0f;
            float fb2 = 142.0f / this.radianF;
            float fb3 = 49.0f / this.radianF;
            float fb4 = 155.0f / this.radianF;
            float fb5 = -68.0f / this.radianF;
            if (fmov > 0.0f && fmov < 20.0f) {
                fb2 -= Mth.m_14089_((float)(ageInTicks * 0.8f)) * 0.3f;
                fb3 -= Mth.m_14089_((float)(ageInTicks * 0.6f)) * 0.2f;
                fb1 += Mth.m_14089_((float)(ageInTicks * 0.4f)) * 0.4f;
                fb5 += Mth.m_14089_((float)(ageInTicks * 0.7f)) * 0.5f;
            }
            if (fmov > 30.0f && fmov < 50.0f) {
                fb4 -= Mth.m_14089_((float)(ageInTicks * 0.8f)) * 0.4f;
                fb1 += Mth.m_14089_((float)(ageInTicks * 0.7f)) * 0.1f;
                fb3 -= Mth.m_14089_((float)(ageInTicks * 0.6f)) * 0.2f;
            }
            if (fmov > 80.0f) {
                fb5 += Mth.m_14089_((float)(ageInTicks * 0.2f)) * 0.4f;
                fb2 -= Mth.m_14089_((float)(ageInTicks * 0.6f)) * 0.3f;
                fb4 -= Mth.m_14089_((float)(ageInTicks * 0.4f)) * 0.2f;
            }
            this.baby1.f_104204_ = fb1;
            this.baby2.f_104204_ = fb2;
            this.baby3.f_104204_ = fb3;
            this.baby4.f_104204_ = fb4;
            this.baby5.f_104204_ = fb5;
        }
        float f9 = -Mth.m_14089_((float)(limbSwing * 0.6662f * 2.0f + 0.0f)) * 0.4f * limbSwingAmount;
        float f10 = -Mth.m_14089_((float)(limbSwing * 0.6662f * 2.0f + (float)Math.PI)) * 0.4f * limbSwingAmount;
        float f11 = -Mth.m_14089_((float)(limbSwing * 0.6662f * 2.0f + 1.5707964f)) * 0.4f * limbSwingAmount;
        float f12 = -Mth.m_14089_((float)(limbSwing * 0.6662f * 2.0f + 4.712389f)) * 0.4f * limbSwingAmount;
        float f13 = Math.abs(Mth.m_14031_((float)(limbSwing * 0.6662f + 0.0f))) * 0.4f * limbSwingAmount;
        float f14 = Math.abs(Mth.m_14031_((float)(limbSwing * 0.6662f + (float)Math.PI))) * 0.4f * limbSwingAmount;
        float f15 = Math.abs(Mth.m_14031_((float)(limbSwing * 0.6662f + 1.5707964f))) * 0.4f * limbSwingAmount;
        float f16 = Math.abs(Mth.m_14031_((float)(limbSwing * 0.6662f + 4.712389f))) * 0.4f * limbSwingAmount;
        if (this.sitting) {
            this.leg1A.f_104203_ = -10.0f / this.radianF;
            this.leg1A.f_104205_ = 35.0f / this.radianF;
            this.leg1B.f_104205_ = 20.0f / this.radianF;
            this.leg1C.f_104205_ = 35.0f / this.radianF;
            this.leg2A.f_104203_ = -30.0f / this.radianF;
            this.leg2A.f_104205_ = 35.0f / this.radianF;
            this.leg2B.f_104205_ = 20.0f / this.radianF;
            this.leg2C.f_104205_ = 35.0f / this.radianF;
            this.leg3A.f_104203_ = -45.0f / this.radianF;
            this.leg3A.f_104205_ = 35.0f / this.radianF;
            this.leg3B.f_104205_ = 20.0f / this.radianF;
            this.leg3C.f_104205_ = 35.0f / this.radianF;
            this.leg4A.f_104203_ = -60.0f / this.radianF;
            this.leg4A.f_104205_ = 35.0f / this.radianF;
            this.leg4B.f_104205_ = 20.0f / this.radianF;
            this.leg4C.f_104205_ = 35.0f / this.radianF;
            this.leg5A.f_104203_ = -10.0f / this.radianF;
            this.leg5A.f_104205_ = -35.0f / this.radianF;
            this.leg5B.f_104205_ = -20.0f / this.radianF;
            this.leg5C.f_104205_ = -35.0f / this.radianF;
            this.leg6A.f_104203_ = -30.0f / this.radianF;
            this.leg6A.f_104205_ = -35.0f / this.radianF;
            this.leg6B.f_104205_ = -20.0f / this.radianF;
            this.leg6C.f_104205_ = -35.0f / this.radianF;
            this.leg7A.f_104203_ = -45.0f / this.radianF;
            this.leg7A.f_104205_ = -35.0f / this.radianF;
            this.leg7B.f_104205_ = -20.0f / this.radianF;
            this.leg7C.f_104205_ = -35.0f / this.radianF;
            this.leg8A.f_104203_ = -60.0f / this.radianF;
            this.leg8A.f_104205_ = -35.0f / this.radianF;
            this.leg8B.f_104205_ = -20.0f / this.radianF;
            this.leg8C.f_104205_ = -35.0f / this.radianF;
        } else {
            this.leg1A.f_104203_ = -10.0f / this.radianF;
            this.leg1A.f_104205_ = 75.0f / this.radianF;
            this.leg1B.f_104205_ = 60.0f / this.radianF;
            this.leg1C.f_104205_ = 75.0f / this.radianF;
            this.leg1A.f_104203_ += f9;
            this.leg1B.f_104203_ = this.leg1A.f_104203_;
            this.leg1C.f_104203_ = this.leg1A.f_104203_;
            this.leg1A.f_104205_ += f13;
            this.leg1B.f_104205_ += f13;
            this.leg1C.f_104205_ += f13;
            this.leg2A.f_104203_ = -30.0f / this.radianF;
            this.leg2A.f_104205_ = 70.0f / this.radianF;
            this.leg2B.f_104205_ = 60.0f / this.radianF;
            this.leg2C.f_104205_ = 70.0f / this.radianF;
            this.leg2A.f_104203_ += f10;
            this.leg2B.f_104203_ = this.leg2A.f_104203_;
            this.leg2C.f_104203_ = this.leg2A.f_104203_;
            this.leg2A.f_104205_ += f14;
            this.leg2B.f_104205_ += f14;
            this.leg2C.f_104205_ += f14;
            this.leg3A.f_104203_ = -45.0f / this.radianF;
            this.leg3A.f_104205_ = 70.0f / this.radianF;
            this.leg3B.f_104205_ = 60.0f / this.radianF;
            this.leg3C.f_104205_ = 70.0f / this.radianF;
            this.leg3A.f_104203_ += f11;
            this.leg3B.f_104203_ = this.leg3A.f_104203_;
            this.leg3C.f_104203_ = this.leg3A.f_104203_;
            this.leg3A.f_104205_ += f15;
            this.leg3B.f_104205_ += f15;
            this.leg3C.f_104205_ += f15;
            this.leg4A.f_104203_ = -60.0f / this.radianF;
            this.leg4A.f_104205_ = 70.0f / this.radianF;
            this.leg4B.f_104205_ = 60.0f / this.radianF;
            this.leg4C.f_104205_ = 70.0f / this.radianF;
            this.leg4A.f_104203_ += f12;
            this.leg4B.f_104203_ = this.leg4A.f_104203_;
            this.leg4C.f_104203_ = this.leg4A.f_104203_;
            this.leg4A.f_104205_ += f16;
            this.leg4B.f_104205_ += f16;
            this.leg4C.f_104205_ += f16;
            this.leg5A.f_104203_ = -10.0f / this.radianF;
            this.leg5A.f_104205_ = -75.0f / this.radianF;
            this.leg5B.f_104205_ = -60.0f / this.radianF;
            this.leg5C.f_104205_ = -75.0f / this.radianF;
            this.leg5A.f_104203_ -= f9;
            this.leg5B.f_104203_ = this.leg5A.f_104203_;
            this.leg5C.f_104203_ = this.leg5A.f_104203_;
            this.leg5A.f_104205_ -= f13;
            this.leg5B.f_104205_ -= f13;
            this.leg5C.f_104205_ -= f13;
            this.leg6A.f_104203_ = -30.0f / this.radianF;
            this.leg6A.f_104205_ = -70.0f / this.radianF;
            this.leg6B.f_104205_ = -60.0f / this.radianF;
            this.leg6C.f_104205_ = -70.0f / this.radianF;
            this.leg6A.f_104203_ -= f10;
            this.leg6B.f_104203_ = this.leg6A.f_104203_;
            this.leg6C.f_104203_ = this.leg6A.f_104203_;
            this.leg6A.f_104205_ -= f14;
            this.leg6B.f_104205_ -= f14;
            this.leg6C.f_104205_ -= f14;
            this.leg7A.f_104203_ = -45.0f / this.radianF;
            this.leg7A.f_104205_ = -70.0f / this.radianF;
            this.leg7B.f_104205_ = -60.0f / this.radianF;
            this.leg7C.f_104205_ = -70.0f / this.radianF;
            this.leg7A.f_104203_ -= f11;
            this.leg7B.f_104203_ = this.leg7A.f_104203_;
            this.leg7C.f_104203_ = this.leg7A.f_104203_;
            this.leg7A.f_104205_ -= f15;
            this.leg7B.f_104205_ -= f15;
            this.leg7C.f_104205_ -= f15;
            this.leg8A.f_104203_ = -60.0f / this.radianF;
            this.leg8A.f_104205_ = -70.0f / this.radianF;
            this.leg8B.f_104205_ = -60.0f / this.radianF;
            this.leg8C.f_104205_ = -70.0f / this.radianF;
            this.leg8A.f_104203_ -= f12;
            this.leg8B.f_104203_ = this.leg8A.f_104203_;
            this.leg8C.f_104203_ = this.leg8A.f_104203_;
            this.leg8A.f_104205_ -= f16;
            this.leg8B.f_104205_ -= f16;
            this.leg8C.f_104205_ -= f16;
        }
    }
}

