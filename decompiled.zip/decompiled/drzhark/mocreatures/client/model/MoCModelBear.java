/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  org.jetbrains.annotations.NotNull
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.hunter.MoCEntityBear;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.jetbrains.annotations.NotNull;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelBear<T extends MoCEntityBear>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "bear"), "main");
    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart mouth;
    private final ModelPart mouthOpen;
    private final ModelPart lEar;
    private final ModelPart rEar;
    private final ModelPart snout;
    private final ModelPart neck;
    private final ModelPart abdomen;
    private final ModelPart torso;
    private final ModelPart tail;
    private final ModelPart legFL1;
    private final ModelPart legFL2;
    private final ModelPart legFL3;
    private final ModelPart legFR1;
    private final ModelPart legFR2;
    private final ModelPart legFR3;
    private final ModelPart legRL1;
    private final ModelPart legRL2;
    private final ModelPart legRL3;
    private final ModelPart legRR1;
    private final ModelPart legRR2;
    private final ModelPart legRR3;
    private final ModelPart bHead;
    private final ModelPart bSnout;
    private final ModelPart bMouth;
    private final ModelPart bMouthOpen;
    private final ModelPart bNeck;
    private final ModelPart bLEar;
    private final ModelPart bREar;
    private final ModelPart bTorso;
    private final ModelPart bAbdomen;
    private final ModelPart bTail;
    private final ModelPart bLegFL1;
    private final ModelPart bLegFL2;
    private final ModelPart bLegFL3;
    private final ModelPart bLegFR1;
    private final ModelPart bLegFR2;
    private final ModelPart bLegFR3;
    private final ModelPart bLegRL1;
    private final ModelPart bLegRL2;
    private final ModelPart bLegRL3;
    private final ModelPart bLegRR1;
    private final ModelPart bLegRR2;
    private final ModelPart bLegRR3;
    private final ModelPart cHead;
    private final ModelPart cSnout;
    private final ModelPart cMouth;
    private final ModelPart cMouthOpen;
    private final ModelPart cLEar;
    private final ModelPart cREar;
    private final ModelPart cNeck;
    private final ModelPart cTorso;
    private final ModelPart cAbdomen;
    private final ModelPart cTail;
    private final ModelPart cLegFL1;
    private final ModelPart cLegFL2;
    private final ModelPart cLegFL3;
    private final ModelPart cLegFR1;
    private final ModelPart cLegFR2;
    private final ModelPart cLegFR3;
    private final ModelPart cLegRL1;
    private final ModelPart cLegRL2;
    private final ModelPart cLegRL3;
    private final ModelPart cLegRR1;
    private final ModelPart cLegRR2;
    private final ModelPart cLegRR3;
    private final ModelPart saddle;
    private final ModelPart saddleBack;
    private final ModelPart saddleFront;
    private final ModelPart bag;
    private final ModelPart saddleSitted;
    private final ModelPart saddleBackSitted;
    private final ModelPart saddleFrontSitted;
    private final ModelPart bagSitted;
    private int bearState;
    private float attackSwing;
    private MoCEntityBear entityBear;

    public MoCModelBear(ModelPart root) {
        this.root = root;
        this.head = root.m_171324_("head");
        this.mouth = root.m_171324_("mouth");
        this.mouthOpen = root.m_171324_("mouth_open");
        this.lEar = root.m_171324_("l_ear");
        this.rEar = root.m_171324_("r_ear");
        this.snout = root.m_171324_("snout");
        this.neck = root.m_171324_("neck");
        this.abdomen = root.m_171324_("abdomen");
        this.torso = root.m_171324_("torso");
        this.tail = root.m_171324_("tail");
        this.legFL1 = root.m_171324_("leg_fl1");
        this.legFL2 = root.m_171324_("leg_fl2");
        this.legFL3 = root.m_171324_("leg_fl3");
        this.legFR1 = root.m_171324_("leg_fr1");
        this.legFR2 = root.m_171324_("leg_fr2");
        this.legFR3 = root.m_171324_("leg_fr3");
        this.legRL1 = root.m_171324_("leg_rl1");
        this.legRL2 = root.m_171324_("leg_rl2");
        this.legRL3 = root.m_171324_("leg_rl3");
        this.legRR1 = root.m_171324_("leg_rr1");
        this.legRR2 = root.m_171324_("leg_rr2");
        this.legRR3 = root.m_171324_("leg_rr3");
        this.bHead = root.m_171324_("b_head");
        this.bSnout = root.m_171324_("b_snout");
        this.bMouth = root.m_171324_("b_mouth");
        this.bMouthOpen = root.m_171324_("b_mouth_open");
        this.bNeck = root.m_171324_("b_neck");
        this.bLEar = root.m_171324_("b_l_ear");
        this.bREar = root.m_171324_("b_r_ear");
        this.bTorso = root.m_171324_("b_torso");
        this.bAbdomen = root.m_171324_("b_abdomen");
        this.bTail = root.m_171324_("b_tail");
        this.bLegFL1 = root.m_171324_("b_leg_fl1");
        this.bLegFL2 = root.m_171324_("b_leg_fl2");
        this.bLegFL3 = root.m_171324_("b_leg_fl3");
        this.bLegFR1 = root.m_171324_("b_leg_fr1");
        this.bLegFR2 = root.m_171324_("b_leg_fr2");
        this.bLegFR3 = root.m_171324_("b_leg_fr3");
        this.bLegRL1 = root.m_171324_("b_leg_rl1");
        this.bLegRL2 = root.m_171324_("b_leg_rl2");
        this.bLegRL3 = root.m_171324_("b_leg_rl3");
        this.bLegRR1 = root.m_171324_("b_leg_rr1");
        this.bLegRR2 = root.m_171324_("b_leg_rr2");
        this.bLegRR3 = root.m_171324_("b_leg_rr3");
        this.cHead = root.m_171324_("c_head");
        this.cSnout = root.m_171324_("c_snout");
        this.cMouth = root.m_171324_("c_mouth");
        this.cMouthOpen = root.m_171324_("c_mouth_open");
        this.cLEar = root.m_171324_("c_l_ear");
        this.cREar = root.m_171324_("c_r_ear");
        this.cNeck = root.m_171324_("c_neck");
        this.cTorso = root.m_171324_("c_torso");
        this.cAbdomen = root.m_171324_("c_abdomen");
        this.cTail = root.m_171324_("c_tail");
        this.cLegFL1 = root.m_171324_("c_leg_fl1");
        this.cLegFL2 = root.m_171324_("c_leg_fl2");
        this.cLegFL3 = root.m_171324_("c_leg_fl3");
        this.cLegFR1 = root.m_171324_("c_leg_fr1");
        this.cLegFR2 = root.m_171324_("c_leg_fr2");
        this.cLegFR3 = root.m_171324_("c_leg_fr3");
        this.cLegRL1 = root.m_171324_("c_leg_rl1");
        this.cLegRL2 = root.m_171324_("c_leg_rl2");
        this.cLegRL3 = root.m_171324_("c_leg_rl3");
        this.cLegRR1 = root.m_171324_("c_leg_rr1");
        this.cLegRR2 = root.m_171324_("c_leg_rr2");
        this.cLegRR3 = root.m_171324_("c_leg_rr3");
        this.saddle = root.m_171324_("saddle");
        this.saddleBack = root.m_171324_("saddle_back");
        this.saddleFront = root.m_171324_("saddle_front");
        this.bag = root.m_171324_("bag");
        this.saddleSitted = root.m_171324_("saddle_sitted");
        this.saddleBackSitted = root.m_171324_("saddle_back_sitted");
        this.saddleFrontSitted = root.m_171324_("saddle_front_sitted");
        this.bagSitted = root.m_171324_("bag_sitted");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        root.m_171599_("head", CubeListBuilder.m_171558_().m_171514_(19, 0).m_171481_(-4.0f, 0.0f, -4.0f, 8.0f, 8.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)6.0f, (float)-10.0f, (float)0.1502636f, (float)0.0f, (float)0.0f));
        root.m_171599_("mouth", CubeListBuilder.m_171558_().m_171514_(24, 21).m_171481_(-1.5f, 6.0f, -6.8f, 3.0f, 2.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)6.0f, (float)-10.0f, (float)-0.0068161f, (float)0.0f, (float)0.0f));
        root.m_171599_("mouth_open", CubeListBuilder.m_171558_().m_171514_(24, 21).m_171481_(-1.5f, 4.0f, -9.5f, 3.0f, 2.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)6.0f, (float)-10.0f, (float)0.534236f, (float)0.0f, (float)0.0f));
        root.m_171599_("l_ear", CubeListBuilder.m_171558_().m_171514_(40, 0).m_171481_(2.0f, -2.0f, -2.0f, 3.0f, 3.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)6.0f, (float)-10.0f, (float)0.1502636f, (float)-0.3490659f, (float)0.1396263f));
        root.m_171599_("r_ear", CubeListBuilder.m_171558_().m_171514_(16, 0).m_171481_(-5.0f, -2.0f, -2.0f, 3.0f, 3.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)6.0f, (float)-10.0f, (float)0.1502636f, (float)0.3490659f, (float)-0.1396263f));
        root.m_171599_("snout", CubeListBuilder.m_171558_().m_171514_(23, 13).m_171481_(-2.0f, 3.0f, -8.0f, 4.0f, 3.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)6.0f, (float)-10.0f, (float)0.1502636f, (float)0.0f, (float)0.0f));
        root.m_171599_("neck", CubeListBuilder.m_171558_().m_171514_(18, 28).m_171481_(-3.5f, 0.0f, -7.0f, 7.0f, 7.0f, 7.0f), PartPose.m_171423_((float)0.0f, (float)5.0f, (float)-5.0f, (float)0.2617994f, (float)0.0f, (float)0.0f));
        root.m_171599_("abdomen", CubeListBuilder.m_171558_().m_171514_(13, 62).m_171481_(-4.5f, 0.0f, 0.0f, 9.0f, 11.0f, 10.0f), PartPose.m_171423_((float)0.0f, (float)5.0f, (float)5.0f, (float)-0.4363323f, (float)0.0f, (float)0.0f));
        root.m_171599_("torso", CubeListBuilder.m_171558_().m_171514_(12, 42).m_171481_(-5.0f, 0.0f, 0.0f, 10.0f, 10.0f, 10.0f), PartPose.m_171419_((float)0.0f, (float)5.0f, (float)-5.0f));
        root.m_171599_("tail", CubeListBuilder.m_171558_().m_171514_(26, 83).m_171481_(-1.5f, 0.0f, 0.0f, 3.0f, 3.0f, 3.0f), PartPose.m_171423_((float)0.0f, (float)8.466666f, (float)12.0f, (float)0.4363323f, (float)0.0f, (float)0.0f));
        root.m_171599_("leg_fl1", CubeListBuilder.m_171558_().m_171514_(40, 22).m_171481_(-2.5f, 0.0f, -2.5f, 5.0f, 8.0f, 5.0f), PartPose.m_171423_((float)4.0f, (float)10.0f, (float)-4.0f, (float)0.2617994f, (float)0.0f, (float)0.0f));
        root.m_171599_("leg_fl2", CubeListBuilder.m_171558_().m_171514_(46, 35).m_171481_(-2.0f, 7.0f, 0.0f, 4.0f, 6.0f, 4.0f), PartPose.m_171419_((float)4.0f, (float)10.0f, (float)-4.0f));
        root.m_171599_("leg_fl3", CubeListBuilder.m_171558_().m_171514_(46, 45).m_171481_(-2.0f, 12.0f, -1.0f, 4.0f, 2.0f, 5.0f), PartPose.m_171419_((float)4.0f, (float)10.0f, (float)-4.0f));
        root.m_171599_("leg_fr1", CubeListBuilder.m_171558_().m_171514_(4, 22).m_171481_(-2.5f, 0.0f, -2.5f, 5.0f, 8.0f, 5.0f), PartPose.m_171423_((float)-4.0f, (float)10.0f, (float)-4.0f, (float)0.2617994f, (float)0.0f, (float)0.0f));
        root.m_171599_("leg_fr2", CubeListBuilder.m_171558_().m_171514_(2, 35).m_171481_(-2.0f, 7.0f, 0.0f, 4.0f, 6.0f, 4.0f), PartPose.m_171419_((float)-4.0f, (float)10.0f, (float)-4.0f));
        root.m_171599_("leg_fr3", CubeListBuilder.m_171558_().m_171514_(0, 45).m_171481_(-2.0f, 12.0f, -1.0f, 4.0f, 2.0f, 5.0f), PartPose.m_171419_((float)-4.0f, (float)10.0f, (float)-4.0f));
        root.m_171599_("leg_rl1", CubeListBuilder.m_171558_().m_171514_(34, 83).m_171481_(-1.5f, 0.0f, -2.5f, 4.0f, 8.0f, 6.0f), PartPose.m_171423_((float)3.5f, (float)11.0f, (float)9.0f, (float)-0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("leg_rl2", CubeListBuilder.m_171558_().m_171514_(41, 97).m_171481_(-2.0f, 6.0f, -1.0f, 4.0f, 6.0f, 4.0f), PartPose.m_171419_((float)3.5f, (float)11.0f, (float)9.0f));
        root.m_171599_("leg_rl3", CubeListBuilder.m_171558_().m_171514_(44, 107).m_171481_(-2.0f, 11.0f, -2.0f, 4.0f, 2.0f, 5.0f), PartPose.m_171419_((float)3.5f, (float)11.0f, (float)9.0f));
        root.m_171599_("leg_rr1", CubeListBuilder.m_171558_().m_171514_(10, 83).m_171481_(-2.5f, 0.0f, -2.5f, 4.0f, 8.0f, 6.0f), PartPose.m_171423_((float)-3.5f, (float)11.0f, (float)9.0f, (float)-0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("leg_rr2", CubeListBuilder.m_171558_().m_171514_(7, 97).m_171481_(-2.0f, 6.0f, -1.0f, 4.0f, 6.0f, 4.0f), PartPose.m_171419_((float)-3.5f, (float)11.0f, (float)9.0f));
        root.m_171599_("leg_rr3", CubeListBuilder.m_171558_().m_171514_(2, 107).m_171481_(-2.0f, 11.0f, -2.0f, 4.0f, 2.0f, 5.0f), PartPose.m_171419_((float)-3.5f, (float)11.0f, (float)9.0f));
        root.m_171599_("b_head", CubeListBuilder.m_171558_().m_171514_(19, 0).m_171481_(-4.0f, 0.0f, -4.0f, 8.0f, 8.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)-12.0f, (float)5.0f, (float)-0.0242694f, (float)0.0f, (float)0.0f));
        root.m_171599_("b_snout", CubeListBuilder.m_171558_().m_171514_(23, 13).m_171481_(-2.0f, 2.5f, -8.5f, 4.0f, 3.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)-12.0f, (float)5.0f, (float)-0.0242694f, (float)0.0f, (float)0.0f));
        root.m_171599_("b_mouth", CubeListBuilder.m_171558_().m_171514_(24, 21).m_171481_(-1.5f, 5.5f, -8.0f, 3.0f, 2.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)-12.0f, (float)5.0f, (float)-0.08726f, (float)0.0f, (float)0.0f));
        root.m_171599_("b_mouth_open", CubeListBuilder.m_171558_().m_171514_(24, 21).m_171481_(-1.5f, 3.5f, -11.0f, 3.0f, 2.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)-12.0f, (float)5.0f, (float)0.5235988f, (float)0.0f, (float)0.0f));
        root.m_171599_("b_neck", CubeListBuilder.m_171558_().m_171514_(18, 28).m_171481_(-3.5f, 0.0f, -7.0f, 7.0f, 6.0f, 7.0f), PartPose.m_171423_((float)0.0f, (float)-3.0f, (float)11.0f, (float)-1.336881f, (float)0.0f, (float)0.0f));
        root.m_171599_("b_l_ear", CubeListBuilder.m_171558_().m_171514_(40, 0).m_171481_(2.0f, -2.0f, -2.0f, 3.0f, 3.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)-12.0f, (float)5.0f, (float)-0.0242694f, (float)-0.3490659f, (float)0.1396263f));
        root.m_171599_("b_r_ear", CubeListBuilder.m_171558_().m_171514_(16, 0).m_171481_(-5.0f, -2.0f, -2.0f, 3.0f, 3.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)-12.0f, (float)5.0f, (float)-0.0242694f, (float)0.3490659f, (float)-0.1396263f));
        root.m_171599_("b_torso", CubeListBuilder.m_171558_().m_171514_(12, 42).m_171481_(-5.0f, 0.0f, 0.0f, 10.0f, 10.0f, 10.0f), PartPose.m_171423_((float)0.0f, (float)-3.5f, (float)12.3f, (float)-1.396263f, (float)0.0f, (float)0.0f));
        root.m_171599_("b_abdomen", CubeListBuilder.m_171558_().m_171514_(13, 62).m_171481_(-4.5f, 0.0f, 0.0f, 9.0f, 11.0f, 10.0f), PartPose.m_171423_((float)0.0f, (float)6.0f, (float)14.0f, (float)-1.570796f, (float)0.0f, (float)0.0f));
        root.m_171599_("b_tail", CubeListBuilder.m_171558_().m_171514_(26, 83).m_171481_(-1.5f, 0.0f, 0.0f, 3.0f, 3.0f, 3.0f), PartPose.m_171423_((float)0.0f, (float)12.46667f, (float)12.6f, (float)0.3619751f, (float)0.0f, (float)0.0f));
        root.m_171599_("b_leg_fl1", CubeListBuilder.m_171558_().m_171514_(40, 22).m_171481_(-2.5f, 0.0f, -2.5f, 5.0f, 8.0f, 5.0f), PartPose.m_171423_((float)5.0f, (float)-1.0f, (float)6.0f, (float)0.2617994f, (float)0.0f, (float)-0.2617994f));
        root.m_171599_("b_leg_fl2", CubeListBuilder.m_171558_().m_171514_(46, 35).m_171481_(0.0f, 5.0f, 3.0f, 4.0f, 6.0f, 4.0f), PartPose.m_171423_((float)5.0f, (float)-1.0f, (float)6.0f, (float)-0.5576792f, (float)0.0f, (float)0.0f));
        root.m_171599_("b_leg_fl3", CubeListBuilder.m_171558_().m_171514_(46, 45).m_171481_(0.1f, -7.0f, -14.0f, 4.0f, 2.0f, 5.0f), PartPose.m_171423_((float)5.0f, (float)-1.0f, (float)6.0f, (float)2.007645f, (float)0.0f, (float)0.0f));
        root.m_171599_("b_leg_fr1", CubeListBuilder.m_171558_().m_171514_(4, 22).m_171481_(-2.5f, 0.0f, -2.5f, 5.0f, 8.0f, 5.0f), PartPose.m_171423_((float)-5.0f, (float)-1.0f, (float)6.0f, (float)0.2617994f, (float)0.0f, (float)0.2617994f));
        root.m_171599_("b_leg_fr2", CubeListBuilder.m_171558_().m_171514_(2, 35).m_171481_(-4.0f, 5.0f, 3.0f, 4.0f, 6.0f, 4.0f), PartPose.m_171423_((float)-5.0f, (float)-1.0f, (float)6.0f, (float)-0.5576792f, (float)0.0f, (float)0.0f));
        root.m_171599_("b_leg_fr3", CubeListBuilder.m_171558_().m_171514_(0, 45).m_171481_(-4.1f, -7.0f, -14.0f, 4.0f, 2.0f, 5.0f), PartPose.m_171423_((float)-5.0f, (float)-1.0f, (float)6.0f, (float)2.007129f, (float)0.0f, (float)0.0f));
        root.m_171599_("b_leg_rl1", CubeListBuilder.m_171558_().m_171514_(34, 83).m_171481_(-1.5f, 0.0f, -2.5f, 4.0f, 8.0f, 6.0f), PartPose.m_171423_((float)3.0f, (float)11.0f, (float)9.0f, (float)-0.5235988f, (float)-0.2617994f, (float)0.0f));
        root.m_171599_("b_leg_rl2", CubeListBuilder.m_171558_().m_171514_(41, 97).m_171481_(-1.3f, 6.0f, -3.0f, 4.0f, 6.0f, 4.0f), PartPose.m_171423_((float)3.0f, (float)11.0f, (float)9.0f, (float)0.0f, (float)-0.2617994f, (float)0.0f));
        root.m_171599_("b_leg_rl3", CubeListBuilder.m_171558_().m_171514_(44, 107).m_171481_(-1.2f, 11.0f, -4.0f, 4.0f, 2.0f, 5.0f), PartPose.m_171423_((float)3.0f, (float)11.0f, (float)9.0f, (float)0.0f, (float)-0.2617994f, (float)0.0f));
        root.m_171599_("b_leg_rr1", CubeListBuilder.m_171558_().m_171514_(10, 83).m_171481_(-2.5f, 0.0f, -2.5f, 4.0f, 8.0f, 6.0f), PartPose.m_171423_((float)-3.0f, (float)11.0f, (float)9.0f, (float)-0.1745329f, (float)0.2617994f, (float)0.0f));
        root.m_171599_("b_leg_rr2", CubeListBuilder.m_171558_().m_171514_(7, 97).m_171481_(-2.4f, 6.0f, -1.0f, 4.0f, 6.0f, 4.0f), PartPose.m_171423_((float)-3.0f, (float)11.0f, (float)9.0f, (float)0.0f, (float)0.2617994f, (float)0.0f));
        root.m_171599_("b_leg_rr3", CubeListBuilder.m_171558_().m_171514_(2, 107).m_171481_(-2.5f, 11.0f, -2.0f, 4.0f, 2.0f, 5.0f), PartPose.m_171423_((float)-3.0f, (float)11.0f, (float)9.0f, (float)0.0f, (float)0.2617994f, (float)0.0f));
        root.m_171599_("c_head", CubeListBuilder.m_171558_().m_171514_(19, 0).m_171481_(-4.0f, 0.0f, -4.0f, 8.0f, 8.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)3.0f, (float)-3.5f, (float)0.1502636f, (float)0.0f, (float)0.0f));
        root.m_171599_("c_snout", CubeListBuilder.m_171558_().m_171514_(23, 13).m_171481_(-2.0f, 3.0f, -8.5f, 4.0f, 3.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)3.0f, (float)-3.5f, (float)0.1502636f, (float)0.0f, (float)0.0f));
        root.m_171599_("c_mouth", CubeListBuilder.m_171558_().m_171514_(24, 21).m_171481_(-1.5f, 6.0f, -7.0f, 3.0f, 2.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)3.0f, (float)-3.5f, (float)-0.0068161f, (float)0.0f, (float)0.0f));
        root.m_171599_("c_mouth_open", CubeListBuilder.m_171558_().m_171514_(24, 21).m_171481_(-1.5f, 5.5f, -9.0f, 3.0f, 2.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)3.0f, (float)-3.5f, (float)0.3665191f, (float)0.0f, (float)0.0f));
        root.m_171599_("c_l_ear", CubeListBuilder.m_171558_().m_171514_(40, 0).m_171481_(2.0f, -2.0f, -2.0f, 3.0f, 3.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)3.0f, (float)-3.5f, (float)0.1502636f, (float)-0.3490659f, (float)0.1396263f));
        root.m_171599_("c_r_ear", CubeListBuilder.m_171558_().m_171514_(16, 0).m_171481_(-5.0f, -2.0f, -2.0f, 3.0f, 3.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)3.0f, (float)-3.5f, (float)0.1502636f, (float)0.3490659f, (float)-0.1396263f));
        root.m_171599_("c_neck", CubeListBuilder.m_171558_().m_171514_(18, 28).m_171481_(-3.5f, 0.0f, -7.0f, 7.0f, 7.0f, 7.0f), PartPose.m_171423_((float)0.0f, (float)5.8f, (float)3.4f, (float)-0.3316126f, (float)0.0f, (float)0.0f));
        root.m_171599_("c_torso", CubeListBuilder.m_171558_().m_171514_(12, 42).m_171481_(-5.0f, 0.0f, 0.0f, 10.0f, 10.0f, 10.0f), PartPose.m_171423_((float)0.0f, (float)5.8f, (float)3.4f, (float)-0.9712912f, (float)0.0f, (float)0.0f));
        root.m_171599_("c_abdomen", CubeListBuilder.m_171558_().m_171514_(13, 62).m_171481_(-4.5f, 0.0f, 0.0f, 9.0f, 11.0f, 10.0f), PartPose.m_171423_((float)0.0f, (float)14.0f, (float)9.0f, (float)-1.570796f, (float)0.0f, (float)0.0f));
        root.m_171599_("c_tail", CubeListBuilder.m_171558_().m_171514_(26, 83).m_171481_(-1.5f, 0.0f, 0.0f, 3.0f, 3.0f, 3.0f), PartPose.m_171423_((float)0.0f, (float)21.46667f, (float)8.0f, (float)0.4363323f, (float)0.0f, (float)0.0f));
        root.m_171599_("c_leg_fl1", CubeListBuilder.m_171558_().m_171514_(40, 22).m_171481_(-2.5f, 0.0f, -1.5f, 5.0f, 8.0f, 5.0f), PartPose.m_171423_((float)4.0f, (float)10.0f, (float)0.0f, (float)-0.2617994f, (float)0.0f, (float)0.0f));
        root.m_171599_("c_leg_fl2", CubeListBuilder.m_171558_().m_171514_(46, 35).m_171481_(-2.0f, 0.0f, -1.2f, 4.0f, 6.0f, 4.0f), PartPose.m_171423_((float)4.0f, (float)17.0f, (float)-2.0f, (float)-0.3490659f, (float)0.0f, (float)0.2617994f));
        root.m_171599_("c_leg_fl3", CubeListBuilder.m_171558_().m_171514_(46, 45).m_171481_(-2.0f, 0.0f, -3.0f, 4.0f, 2.0f, 5.0f), PartPose.m_171423_((float)2.5f, (float)22.0f, (float)-4.0f, (float)0.0f, (float)0.1745329f, (float)0.0f));
        root.m_171599_("c_leg_fr1", CubeListBuilder.m_171558_().m_171514_(4, 22).m_171481_(-2.5f, 0.0f, -1.5f, 5.0f, 8.0f, 5.0f), PartPose.m_171423_((float)-4.0f, (float)10.0f, (float)0.0f, (float)-0.2617994f, (float)0.0f, (float)0.0f));
        root.m_171599_("c_leg_fr2", CubeListBuilder.m_171558_().m_171514_(2, 35).m_171481_(-2.0f, 0.0f, -1.2f, 4.0f, 6.0f, 4.0f), PartPose.m_171423_((float)-4.0f, (float)17.0f, (float)-2.0f, (float)-0.3490659f, (float)0.0f, (float)-0.2617994f));
        root.m_171599_("c_leg_fr3", CubeListBuilder.m_171558_().m_171514_(0, 45).m_171481_(-2.0f, 0.0f, -3.0f, 4.0f, 2.0f, 5.0f), PartPose.m_171423_((float)-2.5f, (float)22.0f, (float)-4.0f, (float)0.0f, (float)-0.1745329f, (float)0.0f));
        root.m_171599_("c_leg_rl1", CubeListBuilder.m_171558_().m_171514_(34, 83).m_171481_(-1.5f, 0.0f, -2.5f, 4.0f, 8.0f, 6.0f), PartPose.m_171423_((float)3.0f, (float)21.0f, (float)5.0f, (float)-1.396263f, (float)-0.3490659f, (float)0.3490659f));
        root.m_171599_("c_leg_rl2", CubeListBuilder.m_171558_().m_171514_(41, 97).m_171481_(-2.0f, 0.0f, -2.0f, 4.0f, 6.0f, 4.0f), PartPose.m_171423_((float)5.2f, (float)22.5f, (float)-1.0f, (float)-1.570796f, (float)0.0f, (float)0.3490659f));
        root.m_171599_("c_leg_rl3", CubeListBuilder.m_171558_().m_171514_(44, 107).m_171481_(-2.0f, 0.0f, -3.0f, 4.0f, 2.0f, 5.0f), PartPose.m_171423_((float)5.5f, (float)22.0f, (float)-6.0f, (float)-1.375609f, (float)0.0f, (float)0.3490659f));
        root.m_171599_("c_leg_rr1", CubeListBuilder.m_171558_().m_171514_(10, 83).m_171481_(-2.5f, 0.0f, -2.5f, 4.0f, 8.0f, 6.0f), PartPose.m_171423_((float)-3.0f, (float)21.0f, (float)5.0f, (float)-1.396263f, (float)0.3490659f, (float)-0.3490659f));
        root.m_171599_("c_leg_rr2", CubeListBuilder.m_171558_().m_171514_(7, 97).m_171481_(-2.0f, 0.0f, -2.0f, 4.0f, 6.0f, 4.0f), PartPose.m_171423_((float)-5.2f, (float)22.5f, (float)-1.0f, (float)-1.570796f, (float)0.0f, (float)-0.3490659f));
        root.m_171599_("c_leg_rr3", CubeListBuilder.m_171558_().m_171514_(2, 107).m_171481_(-2.0f, 0.0f, -3.0f, 4.0f, 2.0f, 5.0f), PartPose.m_171423_((float)-5.5f, (float)22.0f, (float)-6.0f, (float)-1.375609f, (float)0.0f, (float)-0.3490659f));
        root.m_171599_("saddle", CubeListBuilder.m_171558_().m_171514_(36, 114).m_171481_(-4.0f, -0.5f, -3.0f, 8.0f, 2.0f, 6.0f), PartPose.m_171419_((float)0.0f, (float)4.0f, (float)-2.0f));
        root.m_171599_("saddle_back", CubeListBuilder.m_171558_().m_171514_(20, 108).m_171481_(-4.0f, -0.2f, 2.9f, 8.0f, 2.0f, 4.0f), PartPose.m_171423_((float)0.0f, (float)4.0f, (float)-2.0f, (float)0.10088f, (float)0.0f, (float)0.0f));
        root.m_171599_("saddle_front", CubeListBuilder.m_171558_().m_171514_(36, 122).m_171481_(-2.5f, -1.0f, -3.0f, 5.0f, 2.0f, 3.0f), PartPose.m_171423_((float)0.0f, (float)4.0f, (float)-2.0f, (float)-0.1850049f, (float)0.0f, (float)0.0f));
        root.m_171599_("bag", CubeListBuilder.m_171558_().m_171514_(0, 114).m_171481_(-5.0f, -3.0f, -2.5f, 10.0f, 2.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)7.0f, (float)7.0f, (float)-0.4363323f, (float)0.0f, (float)0.0f));
        root.m_171599_("bag_sitted", CubeListBuilder.m_171558_().m_171514_(0, 114).m_171481_(-5.0f, -3.0f, -2.5f, 10.0f, 2.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)17.0f, (float)8.0f, (float)-1.570796f, (float)0.0f, (float)0.0f));
        root.m_171599_("saddle_sitted", CubeListBuilder.m_171558_().m_171514_(36, 114).m_171481_(-4.0f, -0.5f, -3.0f, 8.0f, 2.0f, 6.0f), PartPose.m_171423_((float)0.0f, (float)7.5f, (float)6.5f, (float)-0.9686577f, (float)0.0f, (float)0.0f));
        root.m_171599_("saddle_back_sitted", CubeListBuilder.m_171558_().m_171514_(20, 108).m_171481_(-4.0f, -0.3f, 2.9f, 8.0f, 2.0f, 4.0f), PartPose.m_171423_((float)0.0f, (float)7.5f, (float)6.5f, (float)-0.9162979f, (float)0.0f, (float)0.0f));
        root.m_171599_("saddle_front_sitted", CubeListBuilder.m_171558_().m_171514_(36, 122).m_171481_(-2.5f, -1.0f, -3.0f, 5.0f, 2.0f, 3.0f), PartPose.m_171423_((float)0.0f, (float)7.5f, (float)6.5f, (float)-1.151917f, (float)0.0f, (float)0.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)128, (int)128);
    }

    public void setLivingAnimations(T entityIn, float limbSwing, float limbSwingAmount, float partialTick) {
        this.entityBear = entityIn;
        this.bearState = this.entityBear.getBearState();
        this.attackSwing = this.entityBear.getAttackSwing();
    }

    public void setupAnim(@NotNull T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.entityBear = entity;
        this.bearState = ((MoCEntityBear)entity).getBearState();
        this.attackSwing = ((MoCEntityBear)entity).getAttackSwing();
        float lLegRotX = Mth.m_14089_((float)(limbSwing * 0.6662f)) * 0.8f * limbSwingAmount;
        float rLegRotX = Mth.m_14089_((float)(limbSwing * 0.6662f + (float)Math.PI)) * 0.8f * limbSwingAmount;
        float xAngle = headPitch * ((float)Math.PI / 180);
        float yAngle = netHeadYaw * ((float)Math.PI / 180);
        this.setAllVisible(false);
        if (this.bearState == 0) {
            boolean openMouth = ((MoCEntityBear)entity).mouthCounter != 0;
            boolean chested = ((MoCEntityBear)entity).getIsChested();
            boolean saddled = ((MoCEntityBear)entity).getIsRideable();
            this.head.f_104203_ = 0.1502636f + xAngle;
            this.head.f_104204_ = yAngle;
            this.snout.f_104203_ = 0.1502636f + xAngle;
            this.snout.f_104204_ = yAngle;
            this.mouth.f_104203_ = -0.0068161f + xAngle;
            this.mouth.f_104204_ = yAngle;
            this.mouthOpen.f_104203_ = 0.534236f + xAngle;
            this.mouthOpen.f_104204_ = yAngle;
            this.lEar.f_104203_ = 0.1502636f + xAngle;
            this.lEar.f_104204_ = -0.3490659f + yAngle;
            this.rEar.f_104203_ = 0.1502636f + xAngle;
            this.rEar.f_104204_ = 0.3490659f + yAngle;
            this.legFL1.f_104203_ = 0.2617994f + lLegRotX;
            this.legFL2.f_104203_ = lLegRotX;
            this.legFL3.f_104203_ = lLegRotX;
            this.legRR1.f_104203_ = -0.1745329f + lLegRotX;
            this.legRR2.f_104203_ = lLegRotX;
            this.legRR3.f_104203_ = lLegRotX;
            this.legFR1.f_104203_ = 0.2617994f + rLegRotX;
            this.legFR2.f_104203_ = rLegRotX;
            this.legFR3.f_104203_ = rLegRotX;
            this.legRL1.f_104203_ = -0.1745329f + rLegRotX;
            this.legRL2.f_104203_ = rLegRotX;
            this.legRL3.f_104203_ = rLegRotX;
            this.tail.f_104205_ = lLegRotX * 0.2f;
            this.head.f_104207_ = true;
            (openMouth ? this.mouthOpen : this.mouth).f_104207_ = true;
            this.lEar.f_104207_ = true;
            this.rEar.f_104207_ = true;
            this.snout.f_104207_ = true;
            this.neck.f_104207_ = true;
            this.abdomen.f_104207_ = true;
            this.torso.f_104207_ = true;
            this.tail.f_104207_ = true;
            this.legFR1.f_104207_ = true;
            this.legFR2.f_104207_ = true;
            this.legFR3.f_104207_ = true;
            this.legFL1.f_104207_ = true;
            this.legFL2.f_104207_ = true;
            this.legFL3.f_104207_ = true;
            this.legRL1.f_104207_ = true;
            this.legRL2.f_104207_ = true;
            this.legRL3.f_104207_ = true;
            this.legRR1.f_104207_ = true;
            this.legRR2.f_104207_ = true;
            this.legRR3.f_104207_ = true;
            if (saddled) {
                this.saddle.f_104207_ = true;
                this.saddleBack.f_104207_ = true;
                this.saddleFront.f_104207_ = true;
            }
            if (chested) {
                this.bag.f_104207_ = true;
            }
        } else if (this.bearState == 1) {
            boolean openMouth = ((MoCEntityBear)entity).mouthCounter != 0;
            this.bHead.f_104203_ = -0.0242694f - xAngle;
            this.bHead.f_104204_ = yAngle;
            this.bSnout.f_104203_ = -0.0242694f - xAngle;
            this.bSnout.f_104204_ = yAngle;
            this.bMouth.f_104203_ = -0.08726f - xAngle;
            this.bMouth.f_104204_ = yAngle;
            this.bMouthOpen.f_104203_ = 0.5235988f - xAngle;
            this.bMouthOpen.f_104204_ = yAngle;
            this.bLEar.f_104203_ = -0.0242694f - xAngle;
            this.bLEar.f_104204_ = -0.3490659f + yAngle;
            this.bREar.f_104203_ = -0.0242694f - xAngle;
            this.bREar.f_104204_ = 0.3490659f + yAngle;
            float breathing = Mth.m_14089_((float)(ageInTicks * 0.09f)) * 0.05f + 0.05f;
            this.bLegFR1.f_104205_ = 0.2617994f + breathing;
            this.bLegFR2.f_104205_ = breathing;
            this.bLegFR3.f_104205_ = breathing;
            this.bLegFL1.f_104205_ = -0.2617994f - breathing;
            this.bLegFL2.f_104205_ = -breathing;
            this.bLegFL3.f_104205_ = -breathing;
            this.bLegFL1.f_104203_ = 0.2617994f + this.attackSwing;
            this.bLegFL2.f_104203_ = -0.5576792f + this.attackSwing;
            this.bLegFL3.f_104203_ = 2.007645f + this.attackSwing;
            this.bLegFR1.f_104203_ = 0.2617994f + this.attackSwing;
            this.bLegFR2.f_104203_ = -0.5576792f + this.attackSwing;
            this.bLegFR3.f_104203_ = 2.007645f + this.attackSwing;
            this.bLegRR1.f_104203_ = -0.1745329f + lLegRotX;
            this.bLegRR2.f_104203_ = lLegRotX;
            this.bLegRR3.f_104203_ = lLegRotX;
            this.bLegRL1.f_104203_ = -0.5235988f + rLegRotX;
            this.bLegRL2.f_104203_ = rLegRotX;
            this.bLegRL3.f_104203_ = rLegRotX;
            this.bHead.f_104207_ = true;
            (openMouth ? this.bMouthOpen : this.bMouth).f_104207_ = true;
            this.bSnout.f_104207_ = true;
            this.bLEar.f_104207_ = true;
            this.bREar.f_104207_ = true;
            this.bNeck.f_104207_ = true;
            this.bTorso.f_104207_ = true;
            this.bAbdomen.f_104207_ = true;
            this.bTail.f_104207_ = true;
            this.bLegFL1.f_104207_ = true;
            this.bLegFL2.f_104207_ = true;
            this.bLegFL3.f_104207_ = true;
            this.bLegFR1.f_104207_ = true;
            this.bLegFR2.f_104207_ = true;
            this.bLegFR3.f_104207_ = true;
            this.bLegRL1.f_104207_ = true;
            this.bLegRL2.f_104207_ = true;
            this.bLegRL3.f_104207_ = true;
            this.bLegRR1.f_104207_ = true;
            this.bLegRR2.f_104207_ = true;
            this.bLegRR3.f_104207_ = true;
        } else if (this.bearState == 2) {
            boolean openMouth = ((MoCEntityBear)entity).mouthCounter != 0;
            boolean chested = ((MoCEntityBear)entity).getIsChested();
            boolean saddled = ((MoCEntityBear)entity).getIsRideable();
            this.cHead.f_104203_ = 0.1502636f + xAngle;
            this.cHead.f_104204_ = yAngle;
            this.cSnout.f_104203_ = 0.1502636f + xAngle;
            this.cSnout.f_104204_ = yAngle;
            this.cMouth.f_104203_ = -0.0068161f + xAngle;
            this.cMouth.f_104204_ = yAngle;
            this.cMouthOpen.f_104203_ = 0.3665191f + xAngle;
            this.cMouthOpen.f_104204_ = yAngle;
            this.cLEar.f_104203_ = 0.1502636f + xAngle;
            this.cLEar.f_104204_ = -0.3490659f + yAngle;
            this.cREar.f_104203_ = 0.1502636f + xAngle;
            this.cREar.f_104204_ = 0.3490659f + yAngle;
            this.cHead.f_104207_ = true;
            (openMouth ? this.cMouthOpen : this.cMouth).f_104207_ = true;
            this.cSnout.f_104207_ = true;
            this.cLEar.f_104207_ = true;
            this.cREar.f_104207_ = true;
            this.cNeck.f_104207_ = true;
            this.cTorso.f_104207_ = true;
            this.cAbdomen.f_104207_ = true;
            this.cTail.f_104207_ = true;
            this.cLegFL1.f_104207_ = true;
            this.cLegFL2.f_104207_ = true;
            this.cLegFL3.f_104207_ = true;
            this.cLegFR1.f_104207_ = true;
            this.cLegFR2.f_104207_ = true;
            this.cLegFR3.f_104207_ = true;
            this.cLegRL1.f_104207_ = true;
            this.cLegRL2.f_104207_ = true;
            this.cLegRL3.f_104207_ = true;
            this.cLegRR1.f_104207_ = true;
            this.cLegRR2.f_104207_ = true;
            this.cLegRR3.f_104207_ = true;
            if (saddled) {
                this.saddleSitted.f_104207_ = true;
                this.saddleBackSitted.f_104207_ = true;
                this.saddleFrontSitted.f_104207_ = true;
            }
            if (chested) {
                this.bagSitted.f_104207_ = true;
            }
        }
    }

    public void m_7695_(@NotNull PoseStack poseStack, @NotNull VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.root.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }

    private void setAllVisible(boolean visible) {
        this.head.f_104207_ = visible;
        this.mouth.f_104207_ = visible;
        this.mouthOpen.f_104207_ = visible;
        this.lEar.f_104207_ = visible;
        this.rEar.f_104207_ = visible;
        this.snout.f_104207_ = visible;
        this.neck.f_104207_ = visible;
        this.abdomen.f_104207_ = visible;
        this.torso.f_104207_ = visible;
        this.tail.f_104207_ = visible;
        this.legFL1.f_104207_ = visible;
        this.legFL2.f_104207_ = visible;
        this.legFL3.f_104207_ = visible;
        this.legFR1.f_104207_ = visible;
        this.legFR2.f_104207_ = visible;
        this.legFR3.f_104207_ = visible;
        this.legRL1.f_104207_ = visible;
        this.legRL2.f_104207_ = visible;
        this.legRL3.f_104207_ = visible;
        this.legRR1.f_104207_ = visible;
        this.legRR2.f_104207_ = visible;
        this.legRR3.f_104207_ = visible;
        this.bHead.f_104207_ = visible;
        this.bSnout.f_104207_ = visible;
        this.bMouth.f_104207_ = visible;
        this.bMouthOpen.f_104207_ = visible;
        this.bNeck.f_104207_ = visible;
        this.bLEar.f_104207_ = visible;
        this.bREar.f_104207_ = visible;
        this.bTorso.f_104207_ = visible;
        this.bAbdomen.f_104207_ = visible;
        this.bTail.f_104207_ = visible;
        this.bLegFL1.f_104207_ = visible;
        this.bLegFL2.f_104207_ = visible;
        this.bLegFL3.f_104207_ = visible;
        this.bLegFR1.f_104207_ = visible;
        this.bLegFR2.f_104207_ = visible;
        this.bLegFR3.f_104207_ = visible;
        this.bLegRL1.f_104207_ = visible;
        this.bLegRL2.f_104207_ = visible;
        this.bLegRL3.f_104207_ = visible;
        this.bLegRR1.f_104207_ = visible;
        this.bLegRR2.f_104207_ = visible;
        this.bLegRR3.f_104207_ = visible;
        this.cHead.f_104207_ = visible;
        this.cSnout.f_104207_ = visible;
        this.cMouth.f_104207_ = visible;
        this.cMouthOpen.f_104207_ = visible;
        this.cLEar.f_104207_ = visible;
        this.cREar.f_104207_ = visible;
        this.cNeck.f_104207_ = visible;
        this.cTorso.f_104207_ = visible;
        this.cAbdomen.f_104207_ = visible;
        this.cTail.f_104207_ = visible;
        this.cLegFL1.f_104207_ = visible;
        this.cLegFL2.f_104207_ = visible;
        this.cLegFL3.f_104207_ = visible;
        this.cLegFR1.f_104207_ = visible;
        this.cLegFR2.f_104207_ = visible;
        this.cLegFR3.f_104207_ = visible;
        this.cLegRL1.f_104207_ = visible;
        this.cLegRL2.f_104207_ = visible;
        this.cLegRL3.f_104207_ = visible;
        this.cLegRR1.f_104207_ = visible;
        this.cLegRR2.f_104207_ = visible;
        this.cLegRR3.f_104207_ = visible;
        this.saddle.f_104207_ = visible;
        this.saddleBack.f_104207_ = visible;
        this.saddleFront.f_104207_ = visible;
        this.bag.f_104207_ = visible;
        this.saddleSitted.f_104207_ = visible;
        this.saddleBackSitted.f_104207_ = visible;
        this.saddleFrontSitted.f_104207_ = visible;
        this.bagSitted.f_104207_ = visible;
    }
}

