/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.neutral.MoCEntityBoar;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelBoar<T extends MoCEntityBoar>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "boar"), "main");
    private final ModelPart head;
    private final ModelPart trout;
    private final ModelPart tusks;
    private final ModelPart jaw;
    private final ModelPart leftEar;
    private final ModelPart rightEar;
    private final ModelPart headMane;
    private final ModelPart body;
    private final ModelPart bodyMane;
    private final ModelPart tail;
    private final ModelPart upperLegRight;
    private final ModelPart lowerLegRight;
    private final ModelPart upperLegLeft;
    private final ModelPart lowerLegLeft;
    private final ModelPart upperHindLegRight;
    private final ModelPart lowerHindLegRight;
    private final ModelPart upperHindLegLeft;
    private final ModelPart lowerHindLegLeft;

    public MoCModelBoar(ModelPart root) {
        this.head = root.m_171324_("head");
        this.trout = root.m_171324_("trout");
        this.tusks = root.m_171324_("tusks");
        this.jaw = root.m_171324_("jaw");
        this.leftEar = root.m_171324_("left_ear");
        this.rightEar = root.m_171324_("right_ear");
        this.headMane = root.m_171324_("head_mane");
        this.body = root.m_171324_("body");
        this.bodyMane = root.m_171324_("body_mane");
        this.tail = root.m_171324_("tail");
        this.upperLegRight = root.m_171324_("upper_leg_right");
        this.lowerLegRight = root.m_171324_("lower_leg_right");
        this.upperLegLeft = root.m_171324_("upper_leg_left");
        this.lowerLegLeft = root.m_171324_("lower_leg_left");
        this.upperHindLegRight = root.m_171324_("upper_hind_leg_right");
        this.lowerHindLegRight = root.m_171324_("lower_hind_leg_right");
        this.upperHindLegLeft = root.m_171324_("upper_hind_leg_left");
        this.lowerHindLegLeft = root.m_171324_("lower_hind_leg_left");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        root.m_171599_("head", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-3.0f, 0.0f, -5.0f, 6.0f, 6.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)11.0f, (float)-5.0f, (float)0.2617994f, (float)0.0f, (float)0.0f));
        root.m_171599_("trout", CubeListBuilder.m_171558_().m_171514_(0, 11).m_171481_(-1.5f, 1.5f, -9.5f, 3.0f, 3.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)11.0f, (float)-5.0f, (float)0.3490659f, (float)0.0f, (float)0.0f));
        root.m_171599_("tusks", CubeListBuilder.m_171558_().m_171514_(0, 24).m_171481_(-2.0f, 3.0f, -8.0f, 4.0f, 2.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)11.0f, (float)-5.0f, (float)0.3490659f, (float)0.0f, (float)0.0f));
        root.m_171599_("jaw", CubeListBuilder.m_171558_().m_171514_(0, 19).m_171481_(-1.0f, 4.9f, -8.5f, 2.0f, 1.0f, 4.0f), PartPose.m_171423_((float)0.0f, (float)11.0f, (float)-5.0f, (float)0.2617994f, (float)0.0f, (float)0.0f));
        root.m_171599_("left_ear", CubeListBuilder.m_171558_().m_171514_(16, 11).m_171481_(1.0f, -4.0f, -2.0f, 2.0f, 4.0f, 2.0f), PartPose.m_171423_((float)0.0f, (float)11.0f, (float)-5.0f, (float)0.6981317f, (float)0.0f, (float)0.3490659f));
        root.m_171599_("right_ear", CubeListBuilder.m_171558_().m_171514_(16, 17).m_171481_(-3.0f, -4.0f, -2.0f, 2.0f, 4.0f, 2.0f), PartPose.m_171423_((float)0.0f, (float)11.0f, (float)-5.0f, (float)0.6981317f, (float)0.0f, (float)-0.3490659f));
        root.m_171599_("head_mane", CubeListBuilder.m_171558_().m_171514_(23, 0).m_171481_(-1.0f, -2.0f, -5.0f, 2.0f, 2.0f, 5.0f), PartPose.m_171423_((float)0.0f, (float)11.0f, (float)-5.0f, (float)0.4363323f, (float)0.0f, (float)0.0f));
        root.m_171599_("body", CubeListBuilder.m_171558_().m_171514_(24, 0).m_171481_(-3.5f, 0.0f, 0.0f, 7.0f, 8.0f, 13.0f), PartPose.m_171423_((float)0.0f, (float)11.0f, (float)-5.0f, (float)-0.0872665f, (float)0.0f, (float)0.0f));
        root.m_171599_("body_mane", CubeListBuilder.m_171558_().m_171514_(0, 27).m_171481_(-1.0f, -2.0f, -1.0f, 2.0f, 2.0f, 9.0f), PartPose.m_171423_((float)0.0f, (float)11.3f, (float)-4.0f, (float)-0.2617994f, (float)0.0f, (float)0.0f));
        root.m_171599_("tail", CubeListBuilder.m_171558_().m_171514_(60, 38).m_171481_(-0.5f, 0.0f, 0.0f, 1.0f, 5.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)13.0f, (float)7.5f, (float)0.0872665f, (float)0.0f, (float)0.0f));
        root.m_171599_("upper_leg_right", CubeListBuilder.m_171558_().m_171514_(32, 21).m_171481_(-1.0f, -2.0f, -2.0f, 1.0f, 5.0f, 3.0f), PartPose.m_171423_((float)-3.5f, (float)16.0f, (float)-2.5f, (float)0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("lower_leg_right", CubeListBuilder.m_171558_().m_171514_(32, 29).m_171481_(-0.5f, 2.0f, -1.0f, 2.0f, 6.0f, 2.0f), PartPose.m_171419_((float)-3.5f, (float)16.0f, (float)-2.5f));
        root.m_171599_("upper_leg_left", CubeListBuilder.m_171558_().m_171514_(24, 21).m_171481_(0.0f, -2.0f, -2.0f, 1.0f, 5.0f, 3.0f), PartPose.m_171423_((float)3.5f, (float)16.0f, (float)-2.5f, (float)0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("lower_leg_left", CubeListBuilder.m_171558_().m_171514_(24, 29).m_171481_(-1.5f, 2.0f, -1.0f, 2.0f, 6.0f, 2.0f), PartPose.m_171419_((float)3.5f, (float)16.0f, (float)-2.5f));
        root.m_171599_("upper_hind_leg_right", CubeListBuilder.m_171558_().m_171514_(44, 21).m_171481_(-1.5f, -2.0f, -2.0f, 1.0f, 5.0f, 4.0f), PartPose.m_171423_((float)-3.0f, (float)16.0f, (float)5.5f, (float)-0.2617994f, (float)0.0f, (float)0.0f));
        root.m_171599_("lower_hind_leg_right", CubeListBuilder.m_171558_().m_171514_(46, 30).m_171481_(-1.0f, 2.0f, 0.0f, 2.0f, 6.0f, 2.0f), PartPose.m_171419_((float)-3.0f, (float)16.0f, (float)5.5f));
        root.m_171599_("upper_hind_leg_left", CubeListBuilder.m_171558_().m_171514_(54, 21).m_171481_(0.5f, -2.0f, -2.0f, 1.0f, 5.0f, 4.0f), PartPose.m_171423_((float)3.0f, (float)16.0f, (float)5.5f, (float)-0.2617994f, (float)0.0f, (float)0.0f));
        root.m_171599_("lower_hind_leg_left", CubeListBuilder.m_171558_().m_171514_(56, 30).m_171481_(-1.0f, 2.0f, 0.0f, 2.0f, 6.0f, 2.0f), PartPose.m_171419_((float)3.0f, (float)16.0f, (float)5.5f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)64, (int)64);
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.head.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.trout.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.tusks.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.jaw.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leftEar.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.rightEar.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.headMane.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.body.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.bodyMane.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.tail.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.upperLegRight.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.lowerLegRight.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.upperLegLeft.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.lowerLegLeft.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.upperHindLegRight.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.lowerHindLegRight.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.upperHindLegLeft.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.lowerHindLegLeft.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }

    public void setupAnim(T entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float xAngle = headPitch * ((float)Math.PI / 180);
        float yAngle = netHeadYaw * ((float)Math.PI / 180);
        this.head.f_104203_ = 0.2617994f + xAngle;
        this.head.f_104204_ = yAngle;
        this.headMane.f_104203_ = 0.4363323f + xAngle;
        this.headMane.f_104204_ = yAngle;
        this.trout.f_104203_ = 0.3490659f + xAngle;
        this.trout.f_104204_ = yAngle;
        this.jaw.f_104203_ = 0.2617994f + xAngle;
        this.jaw.f_104204_ = yAngle;
        this.tusks.f_104203_ = 0.3490659f + xAngle;
        this.tusks.f_104204_ = yAngle;
        this.leftEar.f_104203_ = 0.6981317f + xAngle;
        this.leftEar.f_104204_ = yAngle;
        this.rightEar.f_104203_ = 0.6981317f + xAngle;
        this.rightEar.f_104204_ = yAngle;
        float leftLegRot = Mth.m_14089_((float)(limbSwing * 0.6662f)) * 1.4f * limbSwingAmount;
        float rightLegRot = Mth.m_14089_((float)(limbSwing * 0.6662f + (float)Math.PI)) * 1.4f * limbSwingAmount;
        this.upperLegLeft.f_104203_ = leftLegRot;
        this.lowerLegLeft.f_104203_ = leftLegRot;
        this.upperHindLegRight.f_104203_ = leftLegRot;
        this.lowerHindLegRight.f_104203_ = leftLegRot;
        this.upperLegRight.f_104203_ = rightLegRot;
        this.lowerLegRight.f_104203_ = rightLegRot;
        this.upperHindLegLeft.f_104203_ = rightLegRot;
        this.lowerHindLegLeft.f_104203_ = rightLegRot;
        this.tail.f_104205_ = leftLegRot * 0.2f;
    }
}

