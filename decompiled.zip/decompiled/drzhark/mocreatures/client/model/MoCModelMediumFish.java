/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  com.mojang.math.Axis
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeDeformation
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import drzhark.mocreatures.entity.aquatic.MoCEntityMediumFish;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelMediumFish<T extends MoCEntityMediumFish>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "medium_fish"), "main");
    private final ModelPart Head;
    private final ModelPart LowerHead;
    private final ModelPart Nose;
    private final ModelPart MouthBottom;
    private final ModelPart MouthBottomB;
    private final ModelPart Body;
    private final ModelPart BackUp;
    private final ModelPart BackDown;
    private final ModelPart Tail;
    private final ModelPart TailFin;
    private final ModelPart RightPectoralFin;
    private final ModelPart LeftPectoralFin;
    private final ModelPart UpperFin;
    private final ModelPart LowerFin;
    private final ModelPart RightLowerFin;
    private final ModelPart LeftLowerFin;
    private MoCEntityMediumFish mediumFish;

    public MoCModelMediumFish(ModelPart root) {
        this.Head = root.m_171324_("Head");
        this.LowerHead = root.m_171324_("LowerHead");
        this.Nose = root.m_171324_("Nose");
        this.MouthBottom = root.m_171324_("MouthBottom");
        this.MouthBottomB = root.m_171324_("MouthBottomB");
        this.Body = root.m_171324_("Body");
        this.BackUp = root.m_171324_("BackUp");
        this.BackDown = root.m_171324_("BackDown");
        this.Tail = root.m_171324_("Tail");
        this.TailFin = root.m_171324_("TailFin");
        this.RightPectoralFin = root.m_171324_("RightPectoralFin");
        this.LeftPectoralFin = root.m_171324_("LeftPectoralFin");
        this.UpperFin = root.m_171324_("UpperFin");
        this.LowerFin = root.m_171324_("LowerFin");
        this.RightLowerFin = root.m_171324_("RightLowerFin");
        this.LeftLowerFin = root.m_171324_("LeftLowerFin");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        root.m_171599_("Head", CubeListBuilder.m_171558_().m_171514_(0, 10).m_171488_(-5.0f, 0.0f, -1.5f, 5.0f, 3.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-8.0f, (float)6.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-0.4461433f));
        root.m_171599_("LowerHead", CubeListBuilder.m_171558_().m_171514_(0, 16).m_171488_(-4.0f, -3.0f, -1.5f, 4.0f, 3.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-8.0f, (float)12.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.3346075f));
        root.m_171599_("Nose", CubeListBuilder.m_171558_().m_171514_(14, 17).m_171488_(-1.0f, -1.0f, -1.0f, 1.0f, 3.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-11.0f, (float)8.2f, (float)0.0f, (float)0.0f, (float)0.0f, (float)1.412787f));
        root.m_171599_("MouthBottom", CubeListBuilder.m_171558_().m_171514_(16, 10).m_171488_(-2.0f, -0.4f, -1.0f, 2.0f, 1.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-11.5f, (float)10.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.3346075f));
        root.m_171599_("MouthBottomB", CubeListBuilder.m_171558_().m_171514_(16, 13).m_171488_(-1.5f, -2.4f, -0.5f, 1.0f, 1.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-11.5f, (float)10.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-0.7132579f));
        root.m_171599_("Body", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(0.0f, -3.0f, -2.0f, 9.0f, 6.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-8.0f, (float)9.0f, (float)0.0f));
        root.m_171599_("BackUp", CubeListBuilder.m_171558_().m_171514_(26, 0).m_171488_(0.0f, 0.0f, -1.5f, 8.0f, 3.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)1.0f, (float)6.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.1858931f));
        root.m_171599_("BackDown", CubeListBuilder.m_171558_().m_171514_(26, 6).m_171488_(0.0f, -3.0f, -1.5f, 8.0f, 3.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)1.0f, (float)12.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-0.1919862f));
        root.m_171599_("Tail", CubeListBuilder.m_171558_().m_171514_(48, 0).m_171488_(0.0f, -1.5f, -1.0f, 4.0f, 3.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)8.0f, (float)9.0f, (float)0.0f));
        root.m_171599_("TailFin", CubeListBuilder.m_171558_().m_171514_(48, 5).m_171488_(3.0f, -5.3f, 0.0f, 5.0f, 11.0f, 0.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)8.0f, (float)9.0f, (float)0.0f));
        root.m_171599_("RightPectoralFin", CubeListBuilder.m_171558_().m_171514_(28, 12).m_171488_(0.0f, -2.0f, 0.0f, 5.0f, 4.0f, 0.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-6.5f, (float)10.0f, (float)2.0f, (float)0.0f, (float)-0.8726646f, (float)0.185895f));
        root.m_171599_("LeftPectoralFin", CubeListBuilder.m_171558_().m_171514_(38, 12).m_171488_(0.0f, -2.0f, 0.0f, 5.0f, 4.0f, 0.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-6.5f, (float)10.0f, (float)-2.0f, (float)0.0f, (float)0.8726646f, (float)0.1858931f));
        root.m_171599_("UpperFin", CubeListBuilder.m_171558_().m_171514_(0, 22).m_171488_(0.0f, -4.0f, 0.0f, 15.0f, 4.0f, 0.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-7.0f, (float)6.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.1047198f));
        root.m_171599_("LowerFin", CubeListBuilder.m_171558_().m_171514_(46, 20).m_171488_(0.0f, 0.0f, 0.0f, 9.0f, 4.0f, 0.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)12.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-0.1858931f));
        root.m_171599_("RightLowerFin", CubeListBuilder.m_171558_().m_171514_(28, 16).m_171488_(0.0f, 0.0f, 0.0f, 9.0f, 4.0f, 0.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-7.0f, (float)12.0f, (float)1.0f, (float)0.5235988f, (float)0.0f, (float)0.0f));
        root.m_171599_("LeftLowerFin", CubeListBuilder.m_171558_().m_171514_(46, 16).m_171488_(0.0f, 0.0f, 0.0f, 9.0f, 4.0f, 0.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-7.0f, (float)12.0f, (float)-1.0f, (float)-0.5235988f, (float)0.0f, (float)0.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)64, (int)32);
    }

    public void prepareMobModel(T entity, float limbSwing, float limbSwingAmount, float partialTick) {
        this.mediumFish = entity;
    }

    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float tailMov = Mth.m_14089_((float)(limbSwing * 0.6662f)) * limbSwingAmount * 0.6f;
        float finMov = Mth.m_14089_((float)(ageInTicks * 0.2f)) * 0.4f;
        float mouthMov = Mth.m_14089_((float)(ageInTicks * 0.3f)) * 0.2f;
        this.Tail.f_104204_ = tailMov;
        this.TailFin.f_104204_ = tailMov;
        this.LeftPectoralFin.f_104204_ = 0.8726646f + finMov;
        this.RightPectoralFin.f_104204_ = -0.8726646f - finMov;
        this.MouthBottom.f_104205_ = 0.3346075f + mouthMov;
        this.MouthBottomB.f_104205_ = -0.7132579f + mouthMov;
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        float yOffset = this.mediumFish.getAdjustedYOffset();
        float xOffset = this.mediumFish.getAdjustedXOffset();
        float zOffset = this.mediumFish.getAdjustedZOffset();
        poseStack.m_85836_();
        poseStack.m_252880_(xOffset, yOffset, zOffset);
        poseStack.m_252781_(Axis.f_252436_.m_252977_(90.0f));
        this.Head.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LowerHead.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Nose.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.MouthBottom.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.MouthBottomB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Body.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.BackUp.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.BackDown.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Tail.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.TailFin.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RightPectoralFin.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LeftPectoralFin.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.UpperFin.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LowerFin.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RightLowerFin.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LeftLowerFin.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        poseStack.m_85849_();
    }
}

