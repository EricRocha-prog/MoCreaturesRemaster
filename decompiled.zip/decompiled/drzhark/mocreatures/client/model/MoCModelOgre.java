/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeDeformation
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.MoCEntityMob;
import drzhark.mocreatures.entity.hostile.MoCEntityOgre;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelOgre<T extends MoCEntityOgre>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "ogre"), "main");
    private static final float RADIAN_CONV = 57.29578f;
    private final ModelPart Head;
    private final ModelPart Brow;
    private final ModelPart NoseBridge;
    private final ModelPart Nose;
    private final ModelPart RgtTusk;
    private final ModelPart RgtTooth;
    private final ModelPart LftTooth;
    private final ModelPart LftTusk;
    private final ModelPart Lip;
    private final ModelPart RgtEar;
    private final ModelPart RgtRing;
    private final ModelPart RgtRingHole;
    private final ModelPart LftEar;
    private final ModelPart LftRing;
    private final ModelPart LftRingHole;
    private final ModelPart HairRope;
    private final ModelPart Hair1;
    private final ModelPart Hair2;
    private final ModelPart Hair3;
    private final ModelPart DiamondHorn;
    private final ModelPart RgtHorn;
    private final ModelPart RgtHornTip;
    private final ModelPart LftHorn;
    private final ModelPart LftHornTip;
    private final ModelPart RgtShoulder;
    private final ModelPart LftShoulder;
    private final ModelPart NeckRest;
    private final ModelPart Chest;
    private final ModelPart Stomach;
    private final ModelPart ButtCover;
    private final ModelPart LoinCloth;
    private final ModelPart RgtThigh;
    private final ModelPart RgtLeg;
    private final ModelPart RgtKnee;
    private final ModelPart RgtToes;
    private final ModelPart RgtBigToe;
    private final ModelPart LftThigh;
    private final ModelPart LftLeg;
    private final ModelPart LftKnee;
    private final ModelPart LftToes;
    private final ModelPart LftBigToe;
    private final ModelPart LftArm;
    private final ModelPart LftElbow;
    private final ModelPart LftHand;
    private final ModelPart LftWeaponRoot;
    private final ModelPart LftWeaponEnd;
    private final ModelPart LftWeaponLump;
    private final ModelPart LftWeaponBetween;
    private final ModelPart LftWeaponTip;
    private final ModelPart LftHammerNeck;
    private final ModelPart LftHammerHeadSupport;
    private final ModelPart LftHammerHead;
    private final ModelPart LftSpike;
    private final ModelPart LftSpike1;
    private final ModelPart LftSpike2;
    private final ModelPart LftSpike3;
    private final ModelPart LftSpike4;
    private final ModelPart RgtArm;
    private final ModelPart RgtElbow;
    private final ModelPart RgtHand;
    private final ModelPart RgtWeaponRoot;
    private final ModelPart RgtWeaponEnd;
    private final ModelPart RgtWeaponLump;
    private final ModelPart RgtWeaponBetween;
    private final ModelPart RgtWeaponTip;
    private final ModelPart RgtHammerNeck;
    private final ModelPart RgtHammerHeadSupport;
    private final ModelPart RgtHammerHead;
    private final ModelPart RgtSpike;
    private final ModelPart RgtSpike1;
    private final ModelPart RgtSpike2;
    private final ModelPart RgtSpike3;
    private final ModelPart RgtSpike4;
    private final ModelPart Head3RgtEar;
    private final ModelPart Head3LftEar;
    private final ModelPart Head3Eyelid;
    private final ModelPart Head3Nose;
    private final ModelPart Head3;
    private final ModelPart Head3Brow;
    private final ModelPart Head3Hair;
    private final ModelPart Head3Lip;
    private final ModelPart Head3RgtTusk;
    private final ModelPart Head3RgtTooth;
    private final ModelPart Head3LftTooth;
    private final ModelPart Head3LftTusk;
    private final ModelPart Head3RingHole;
    private final ModelPart Head3Ring;
    private final ModelPart Head2Chin;
    private final ModelPart Head2;
    private final ModelPart Head2Lip;
    private final ModelPart Head2LftTusk;
    private final ModelPart Head2RgtTusk;
    private final ModelPart Head2Nose;
    private final ModelPart Head2NoseBridge;
    private final ModelPart Head2Brow;
    private final ModelPart Head2RgtHorn;
    private final ModelPart Head2LftHorn;
    private final ModelPart Head2DiamondHorn;
    private int type;
    private int attackCounter;
    private int headMoving;
    private int armToAnimate;

    public MoCModelOgre(ModelPart root) {
        this.Head = root.m_171324_("Head");
        this.Brow = root.m_171324_("Brow");
        this.NoseBridge = root.m_171324_("NoseBridge");
        this.Nose = root.m_171324_("Nose");
        this.RgtTusk = root.m_171324_("RgtTusk");
        this.RgtTooth = root.m_171324_("RgtTooth");
        this.LftTooth = root.m_171324_("LftTooth");
        this.LftTusk = root.m_171324_("LftTusk");
        this.Lip = root.m_171324_("Lip");
        this.RgtEar = root.m_171324_("RgtEar");
        this.RgtRing = root.m_171324_("RgtRing");
        this.RgtRingHole = root.m_171324_("RgtRingHole");
        this.LftEar = root.m_171324_("LftEar");
        this.LftRing = root.m_171324_("LftRing");
        this.LftRingHole = root.m_171324_("LftRingHole");
        this.HairRope = root.m_171324_("HairRope");
        this.Hair1 = root.m_171324_("Hair1");
        this.Hair2 = root.m_171324_("Hair2");
        this.Hair3 = root.m_171324_("Hair3");
        this.DiamondHorn = root.m_171324_("DiamondHorn");
        this.RgtHorn = root.m_171324_("RgtHorn");
        this.RgtHornTip = root.m_171324_("RgtHornTip");
        this.LftHorn = root.m_171324_("LftHorn");
        this.LftHornTip = root.m_171324_("LftHornTip");
        this.NeckRest = root.m_171324_("NeckRest");
        this.Chest = root.m_171324_("Chest");
        this.Stomach = root.m_171324_("Stomach");
        this.ButtCover = root.m_171324_("ButtCover");
        this.LoinCloth = root.m_171324_("LoinCloth");
        this.RgtThigh = root.m_171324_("RgtThigh");
        this.RgtLeg = this.RgtThigh.m_171324_("RgtLeg");
        this.RgtKnee = this.RgtLeg.m_171324_("RgtKnee");
        this.RgtToes = this.RgtLeg.m_171324_("RgtToes");
        this.RgtBigToe = this.RgtLeg.m_171324_("RgtBigToe");
        this.LftThigh = root.m_171324_("LftThigh");
        this.LftLeg = this.LftThigh.m_171324_("LftLeg");
        this.LftKnee = this.LftLeg.m_171324_("LftKnee");
        this.LftToes = this.LftLeg.m_171324_("LftToes");
        this.LftBigToe = this.LftLeg.m_171324_("LftBigToe");
        this.LftShoulder = root.m_171324_("LftShoulder");
        this.LftArm = this.LftShoulder.m_171324_("LftArm");
        this.LftHand = this.LftArm.m_171324_("LftHand");
        this.LftElbow = this.LftHand.m_171324_("LftElbow");
        this.LftWeaponRoot = this.LftHand.m_171324_("LftWeaponRoot");
        this.LftWeaponEnd = this.LftWeaponRoot.m_171324_("LftWeaponEnd");
        this.LftWeaponLump = this.LftWeaponRoot.m_171324_("LftWeaponLump");
        this.LftWeaponBetween = this.LftWeaponLump.m_171324_("LftWeaponBetween");
        this.LftWeaponTip = this.LftWeaponBetween.m_171324_("LftWeaponTip");
        this.LftHammerNeck = this.LftWeaponTip.m_171324_("LftHammerNeck");
        this.LftHammerHeadSupport = this.LftWeaponTip.m_171324_("LftHammerHeadSupport");
        this.LftHammerHead = this.LftHammerHeadSupport.m_171324_("LftHammerHead");
        this.LftSpike = this.LftWeaponTip.m_171324_("LftSpike");
        this.LftSpike1 = this.LftWeaponTip.m_171324_("LftSpike1");
        this.LftSpike2 = this.LftWeaponTip.m_171324_("LftSpike2");
        this.LftSpike3 = this.LftWeaponTip.m_171324_("LftSpike3");
        this.LftSpike4 = this.LftWeaponTip.m_171324_("LftSpike4");
        this.RgtShoulder = root.m_171324_("RgtShoulder");
        this.RgtArm = this.RgtShoulder.m_171324_("RgtArm");
        this.RgtHand = this.RgtArm.m_171324_("RgtHand");
        this.RgtElbow = this.RgtHand.m_171324_("RgtElbow");
        this.RgtWeaponRoot = this.RgtHand.m_171324_("RgtWeaponRoot");
        this.RgtWeaponEnd = this.RgtWeaponRoot.m_171324_("RgtWeaponEnd");
        this.RgtWeaponLump = this.RgtWeaponRoot.m_171324_("RgtWeaponLump");
        this.RgtWeaponBetween = this.RgtWeaponLump.m_171324_("RgtWeaponBetween");
        this.RgtWeaponTip = this.RgtWeaponBetween.m_171324_("RgtWeaponTip");
        this.RgtHammerNeck = this.RgtWeaponTip.m_171324_("RgtHammerNeck");
        this.RgtHammerHeadSupport = this.RgtWeaponTip.m_171324_("RgtHammerHeadSupport");
        this.RgtHammerHead = this.RgtHammerHeadSupport.m_171324_("RgtHammerHead");
        this.RgtSpike = this.RgtWeaponTip.m_171324_("RgtSpike");
        this.RgtSpike1 = this.RgtWeaponTip.m_171324_("RgtSpike1");
        this.RgtSpike2 = this.RgtWeaponTip.m_171324_("RgtSpike2");
        this.RgtSpike3 = this.RgtWeaponTip.m_171324_("RgtSpike3");
        this.RgtSpike4 = this.RgtWeaponTip.m_171324_("RgtSpike4");
        this.Head3RgtEar = root.m_171324_("Head3RgtEar");
        this.Head3LftEar = root.m_171324_("Head3LftEar");
        this.Head3Eyelid = root.m_171324_("Head3Eyelid");
        this.Head3Nose = root.m_171324_("Head3Nose");
        this.Head3 = root.m_171324_("Head3");
        this.Head3Brow = root.m_171324_("Head3Brow");
        this.Head3Hair = root.m_171324_("Head3Hair");
        this.Head3Lip = root.m_171324_("Head3Lip");
        this.Head3RgtTusk = root.m_171324_("Head3RgtTusk");
        this.Head3RgtTooth = root.m_171324_("Head3RgtTooth");
        this.Head3LftTooth = root.m_171324_("Head3LftTooth");
        this.Head3LftTusk = root.m_171324_("Head3LftTusk");
        this.Head3RingHole = root.m_171324_("Head3RingHole");
        this.Head3Ring = root.m_171324_("Head3Ring");
        this.Head2Chin = root.m_171324_("Head2Chin");
        this.Head2 = root.m_171324_("Head2");
        this.Head2Lip = root.m_171324_("Head2Lip");
        this.Head2LftTusk = root.m_171324_("Head2LftTusk");
        this.Head2RgtTusk = root.m_171324_("Head2RgtTusk");
        this.Head2Nose = root.m_171324_("Head2Nose");
        this.Head2NoseBridge = root.m_171324_("Head2NoseBridge");
        this.Head2Brow = root.m_171324_("Head2Brow");
        this.Head2RgtHorn = root.m_171324_("Head2RgtHorn");
        this.Head2LftHorn = root.m_171324_("Head2LftHorn");
        this.Head2DiamondHorn = root.m_171324_("Head2DiamondHorn");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        root.m_171599_("Head", CubeListBuilder.m_171558_().m_171514_(80, 0).m_171488_(-6.0f, -12.0f, -6.0f, 12.0f, 12.0f, 12.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)-13.0f, (float)0.0f));
        root.m_171599_("Brow", CubeListBuilder.m_171558_().m_171514_(68, 7).m_171488_(-5.0f, -10.5f, -8.0f, 10.0f, 3.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-13.0f, (float)0.0f, (float)-0.0872665f, (float)0.0f, (float)0.0f));
        root.m_171599_("NoseBridge", CubeListBuilder.m_171558_().m_171514_(80, 4).m_171488_(-1.0f, -7.0f, -8.0f, 2.0f, 2.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-13.0f, (float)0.0f, (float)-0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("Nose", CubeListBuilder.m_171558_().m_171514_(80, 0).m_171488_(-2.0f, -7.0f, -7.0f, 4.0f, 2.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-13.0f, (float)0.0f, (float)0.0872665f, (float)0.0f, (float)0.0f));
        root.m_171599_("RgtTusk", CubeListBuilder.m_171558_().m_171514_(60, 4).m_171488_(-3.5f, -6.0f, -6.5f, 1.0f, 2.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-13.0f, (float)0.0f, (float)0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("RgtTooth", CubeListBuilder.m_171558_().m_171514_(64, 4).m_171488_(-1.5f, -5.0f, -6.5f, 1.0f, 1.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-13.0f, (float)0.0f, (float)0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("LftTooth", CubeListBuilder.m_171558_().m_171514_(72, 4).m_171488_(0.5f, -5.0f, -6.5f, 1.0f, 1.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-13.0f, (float)0.0f, (float)0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("LftTusk", CubeListBuilder.m_171558_().m_171514_(76, 4).m_171488_(2.5f, -6.0f, -6.5f, 1.0f, 2.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-13.0f, (float)0.0f, (float)0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("Lip", CubeListBuilder.m_171558_().m_171514_(60, 0).m_171488_(-4.0f, -4.0f, -7.0f, 8.0f, 2.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-13.0f, (float)0.0f, (float)0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("RgtEar", CubeListBuilder.m_171558_().m_171514_(60, 12).m_171488_(-9.0f, -9.0f, -1.0f, 3.0f, 5.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)-13.0f, (float)0.0f));
        root.m_171599_("RgtRing", CubeListBuilder.m_171558_().m_171514_(32, 58).m_171488_(-8.0f, -6.0f, -2.0f, 1.0f, 4.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)-13.0f, (float)0.0f));
        root.m_171599_("RgtRingHole", CubeListBuilder.m_171558_().m_171514_(26, 50).m_171488_(-8.0f, -5.0f, -1.0f, 1.0f, 2.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)-13.0f, (float)0.0f));
        root.m_171599_("LftEar", CubeListBuilder.m_171558_().m_171514_(70, 12).m_171488_(6.0f, -9.0f, -1.0f, 3.0f, 5.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)-13.0f, (float)0.0f));
        root.m_171599_("LftRing", CubeListBuilder.m_171558_().m_171514_(32, 58).m_171488_(7.0f, -6.0f, -2.0f, 1.0f, 4.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)-13.0f, (float)0.0f));
        root.m_171599_("LftRingHole", CubeListBuilder.m_171558_().m_171514_(26, 50).m_171488_(7.0f, -5.0f, -1.0f, 1.0f, 2.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)-13.0f, (float)0.0f));
        root.m_171599_("HairRope", CubeListBuilder.m_171558_().m_171514_(82, 83).m_171488_(-2.0f, -8.0f, 9.0f, 4.0f, 4.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-13.0f, (float)0.0f, (float)0.6108652f, (float)0.0f, (float)0.0f));
        root.m_171599_("Hair1", CubeListBuilder.m_171558_().m_171514_(78, 107).m_171488_(-3.0f, -9.0f, 13.0f, 6.0f, 8.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-13.0f, (float)0.0f, (float)0.6108652f, (float)0.0f, (float)0.0f));
        root.m_171599_("Hair2", CubeListBuilder.m_171558_().m_171514_(60, 107).m_171488_(-3.0f, -6.5f, 11.6f, 6.0f, 8.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-13.0f, (float)0.0f, (float)0.2617994f, (float)0.0f, (float)0.0f));
        root.m_171599_("Hair3", CubeListBuilder.m_171558_().m_171514_(42, 107).m_171488_(-3.0f, -2.4f, 11.4f, 6.0f, 8.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)-13.0f, (float)0.0f));
        root.m_171599_("DiamondHorn", CubeListBuilder.m_171558_().m_171514_(120, 31).m_171488_(-1.0f, -17.0f, -6.0f, 2.0f, 6.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-13.0f, (float)0.0f, (float)0.0872665f, (float)0.0f, (float)0.0f));
        root.m_171599_("RgtHorn", CubeListBuilder.m_171558_().m_171514_(46, 6).m_171488_(-6.0f, -12.0f, -11.0f, 2.0f, 2.0f, 5.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)-13.0f, (float)0.0f));
        root.m_171599_("RgtHornTip", CubeListBuilder.m_171558_().m_171514_(44, 13).m_171488_(-6.0f, -15.0f, -11.0f, 2.0f, 3.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)-13.0f, (float)0.0f));
        root.m_171599_("LftHorn", CubeListBuilder.m_171558_().m_171514_(46, 6).m_171488_(4.0f, -12.0f, -11.0f, 2.0f, 2.0f, 5.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)-13.0f, (float)0.0f));
        root.m_171599_("LftHornTip", CubeListBuilder.m_171558_().m_171514_(52, 13).m_171488_(4.0f, -15.0f, -11.0f, 2.0f, 3.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)-13.0f, (float)0.0f));
        root.m_171599_("NeckRest", CubeListBuilder.m_171558_().m_171514_(39, 20).m_171488_(-7.0f, -19.0f, -3.0f, 14.0f, 3.0f, 11.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)5.0f, (float)0.0f));
        root.m_171599_("Chest", CubeListBuilder.m_171558_().m_171514_(32, 34).m_171488_(-9.5f, -17.8f, -7.3f, 19.0f, 11.0f, 13.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)5.0f, (float)0.0f, (float)-0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("Stomach", CubeListBuilder.m_171558_().m_171514_(28, 58).m_171488_(-11.0f, -8.0f, -6.0f, 22.0f, 11.0f, 14.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)5.0f, (float)0.0f));
        root.m_171599_("ButtCover", CubeListBuilder.m_171558_().m_171514_(32, 118).m_171488_(-4.0f, 0.0f, 0.0f, 8.0f, 8.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)8.0f, (float)6.0f));
        root.m_171599_("LoinCloth", CubeListBuilder.m_171558_().m_171514_(32, 118).m_171488_(-4.0f, 0.0f, -2.0f, 8.0f, 8.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)8.0f, (float)-4.0f));
        PartDefinition rgtThigh = root.m_171599_("RgtThigh", CubeListBuilder.m_171558_().m_171514_(0, 83).m_171488_(-10.0f, 0.0f, -5.0f, 10.0f, 11.0f, 10.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-2.0f, (float)4.0f, (float)1.0f));
        PartDefinition rgtLeg = rgtThigh.m_171599_("RgtLeg", CubeListBuilder.m_171558_().m_171514_(0, 104).m_171488_(-4.0f, -1.0f, -4.0f, 8.0f, 11.0f, 8.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-5.0f, (float)10.0f, (float)0.0f));
        rgtLeg.m_171599_("RgtKnee", CubeListBuilder.m_171558_().m_171514_(0, 88).m_171488_(-2.0f, -2.0f, -0.5f, 4.0f, 4.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)2.0f, (float)-4.25f));
        rgtLeg.m_171599_("RgtToes", CubeListBuilder.m_171558_().m_171514_(0, 123).m_171488_(-2.5f, -1.0f, -3.0f, 5.0f, 2.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-1.5f, (float)9.0f, (float)-3.5f));
        rgtLeg.m_171599_("RgtBigToe", CubeListBuilder.m_171558_().m_171514_(20, 123).m_171488_(-1.5f, -1.0f, -3.0f, 3.0f, 2.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)2.5f, (float)9.0f, (float)-4.0f));
        PartDefinition lftThigh = root.m_171599_("LftThigh", CubeListBuilder.m_171558_().m_171514_(88, 83).m_171488_(0.0f, 0.0f, -5.0f, 10.0f, 11.0f, 10.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)2.0f, (float)4.0f, (float)1.0f));
        PartDefinition lftLeg = lftThigh.m_171599_("LftLeg", CubeListBuilder.m_171558_().m_171514_(96, 104).m_171488_(-4.0f, -1.0f, -4.0f, 8.0f, 11.0f, 8.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)5.0f, (float)10.0f, (float)0.0f));
        lftLeg.m_171599_("LftKnee", CubeListBuilder.m_171558_().m_171514_(118, 88).m_171488_(-2.0f, -2.0f, -0.5f, 4.0f, 4.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)2.0f, (float)-4.25f));
        lftLeg.m_171599_("LftToes", CubeListBuilder.m_171558_().m_171514_(112, 123).m_171488_(-2.5f, -1.0f, -3.0f, 5.0f, 2.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)1.5f, (float)9.0f, (float)-3.5f));
        lftLeg.m_171599_("LftBigToe", CubeListBuilder.m_171558_().m_171514_(96, 123).m_171488_(-1.5f, -1.0f, -3.0f, 3.0f, 2.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-2.5f, (float)9.0f, (float)-4.0f));
        PartDefinition lftShoulder = root.m_171599_("LftShoulder", CubeListBuilder.m_171558_().m_171514_(96, 31).m_171488_(0.0f, -3.0f, -4.0f, 8.0f, 7.0f, 8.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)7.0f, (float)-10.0f, (float)2.0f));
        PartDefinition lftArm = lftShoulder.m_171599_("LftArm", CubeListBuilder.m_171558_().m_171514_(100, 66).m_171488_(0.0f, 0.0f, -4.0f, 6.0f, 9.0f, 8.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)6.0f, (float)-1.0f, (float)1.0f));
        PartDefinition lftHand = lftArm.m_171599_("LftHand", CubeListBuilder.m_171558_().m_171514_(96, 46).m_171488_(-4.0f, 0.0f, -4.0f, 8.0f, 12.0f, 8.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)3.0f, (float)8.0f, (float)-1.0f));
        lftHand.m_171599_("LftElbow", CubeListBuilder.m_171558_().m_171514_(86, 64).m_171488_(-2.0f, -1.5f, -0.5f, 4.0f, 3.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)2.5f, (float)4.0f));
        PartDefinition lftWeaponRoot = lftHand.m_171599_("LftWeaponRoot", CubeListBuilder.m_171558_().m_171514_(24, 104).m_171488_(-1.5f, -1.5f, -4.0f, 3.0f, 3.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-0.5f, (float)8.5f, (float)-4.0f));
        PartDefinition lftWeaponEnd = lftWeaponRoot.m_171599_("LftWeaponEnd", CubeListBuilder.m_171558_().m_171514_(74, 90).m_171488_(-1.5f, -1.5f, 0.0f, 3.0f, 3.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)8.0f));
        PartDefinition lftWeaponLump = lftWeaponRoot.m_171599_("LftWeaponLump", CubeListBuilder.m_171558_().m_171514_(30, 83).m_171488_(-2.5f, -2.5f, -4.0f, 5.0f, 5.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)-4.0f));
        PartDefinition lftWeaponBetween = lftWeaponLump.m_171599_("LftWeaponBetween", CubeListBuilder.m_171558_().m_171514_(83, 42).m_171488_(-1.5f, -1.5f, -2.0f, 3.0f, 3.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)-4.0f));
        PartDefinition lftWeaponTip = lftWeaponBetween.m_171599_("LftWeaponTip", CubeListBuilder.m_171558_().m_171514_(60, 118).m_171488_(-2.5f, -2.5f, -5.0f, 5.0f, 5.0f, 5.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)-2.0f));
        lftWeaponTip.m_171599_("LftHammerNeck", CubeListBuilder.m_171558_().m_171514_(32, 39).m_171488_(-0.5f, -4.0f, -4.0f, 1.0f, 4.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)-2.5f, (float)-1.0f));
        PartDefinition lftHammerHeadSupport = lftWeaponTip.m_171599_("LftHammerHeadSupport", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-1.0f, 0.0f, -2.0f, 2.0f, 2.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)2.5f, (float)-3.0f));
        lftHammerHeadSupport.m_171599_("LftHammerHead", CubeListBuilder.m_171558_().m_171514_(32, 3).m_171488_(-2.0f, 0.0f, -2.5f, 4.0f, 3.0f, 5.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)2.0f, (float)0.0f));
        lftWeaponTip.m_171599_("LftSpike", CubeListBuilder.m_171558_().m_171514_(52, 118).m_171488_(-1.0f, -1.0f, -3.0f, 2.0f, 2.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)-5.0f));
        lftWeaponTip.m_171599_("LftSpike1", CubeListBuilder.m_171558_().m_171514_(52, 118).m_171488_(-3.0f, -1.0f, -1.0f, 3.0f, 2.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-2.5f, (float)0.0f, (float)-3.0f));
        lftWeaponTip.m_171599_("LftSpike2", CubeListBuilder.m_171558_().m_171514_(52, 118).m_171488_(3.0f, -1.0f, -1.0f, 3.0f, 2.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-0.5f, (float)0.0f, (float)-3.0f));
        lftWeaponTip.m_171599_("LftSpike3", CubeListBuilder.m_171558_().m_171514_(52, 118).m_171488_(-1.0f, 0.0f, -1.0f, 2.0f, 3.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)2.5f, (float)-3.0f));
        lftWeaponTip.m_171599_("LftSpike4", CubeListBuilder.m_171558_().m_171514_(52, 118).m_171488_(-1.0f, -3.0f, -1.0f, 2.0f, 3.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)-2.5f, (float)-3.0f));
        PartDefinition rgtShoulder = root.m_171599_("RgtShoulder", CubeListBuilder.m_171558_().m_171514_(0, 31).m_171488_(0.0f, -3.0f, -4.0f, 8.0f, 7.0f, 8.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-15.0f, (float)-10.0f, (float)2.0f));
        PartDefinition rgtArm = rgtShoulder.m_171599_("RgtArm", CubeListBuilder.m_171558_().m_171514_(0, 66).m_171488_(0.0f, 0.0f, -4.0f, 6.0f, 9.0f, 8.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-4.0f, (float)-1.0f, (float)1.0f));
        PartDefinition rgtHand = rgtArm.m_171599_("RgtHand", CubeListBuilder.m_171558_().m_171514_(0, 46).m_171488_(-4.0f, 0.0f, -4.0f, 8.0f, 12.0f, 8.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)3.0f, (float)8.0f, (float)-1.0f));
        rgtHand.m_171599_("RgtElbow", CubeListBuilder.m_171558_().m_171514_(86, 64).m_171488_(-2.0f, -1.5f, -0.5f, 4.0f, 3.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)2.5f, (float)4.0f));
        PartDefinition rgtWeaponRoot = rgtHand.m_171599_("RgtWeaponRoot", CubeListBuilder.m_171558_().m_171514_(24, 104).m_171488_(-1.5f, -1.5f, -4.0f, 3.0f, 3.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-0.5f, (float)8.5f, (float)-4.0f));
        PartDefinition rgtWeaponEnd = rgtWeaponRoot.m_171599_("RgtWeaponEnd", CubeListBuilder.m_171558_().m_171514_(74, 90).m_171488_(-1.5f, -1.5f, 0.0f, 3.0f, 3.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)8.0f));
        PartDefinition rgtWeaponLump = rgtWeaponRoot.m_171599_("RgtWeaponLump", CubeListBuilder.m_171558_().m_171514_(30, 83).m_171488_(-2.5f, -2.5f, -4.0f, 5.0f, 5.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)-4.0f));
        PartDefinition rgtWeaponBetween = rgtWeaponLump.m_171599_("RgtWeaponBetween", CubeListBuilder.m_171558_().m_171514_(83, 42).m_171488_(-1.5f, -1.5f, -2.0f, 3.0f, 3.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)-4.0f));
        PartDefinition rgtWeaponTip = rgtWeaponBetween.m_171599_("RgtWeaponTip", CubeListBuilder.m_171558_().m_171514_(60, 118).m_171488_(-2.5f, -2.5f, -5.0f, 5.0f, 5.0f, 5.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)-2.0f));
        rgtWeaponTip.m_171599_("RgtHammerNeck", CubeListBuilder.m_171558_().m_171514_(32, 39).m_171488_(-0.5f, -4.0f, -4.0f, 1.0f, 4.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)-2.5f, (float)-1.0f));
        PartDefinition rgtHammerHeadSupport = rgtWeaponTip.m_171599_("RgtHammerHeadSupport", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-1.0f, 0.0f, -2.0f, 2.0f, 2.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)2.5f, (float)-3.0f));
        rgtHammerHeadSupport.m_171599_("RgtHammerHead", CubeListBuilder.m_171558_().m_171514_(32, 3).m_171488_(-2.0f, 0.0f, -2.5f, 4.0f, 3.0f, 5.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)2.0f, (float)0.0f));
        rgtWeaponTip.m_171599_("RgtSpike", CubeListBuilder.m_171558_().m_171514_(52, 118).m_171488_(-1.0f, -1.0f, -3.0f, 2.0f, 2.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)-5.0f));
        rgtWeaponTip.m_171599_("RgtSpike1", CubeListBuilder.m_171558_().m_171514_(52, 118).m_171488_(-3.0f, -1.0f, -1.0f, 3.0f, 2.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-2.5f, (float)0.0f, (float)-3.0f));
        rgtWeaponTip.m_171599_("RgtSpike2", CubeListBuilder.m_171558_().m_171514_(52, 118).m_171488_(3.0f, -1.0f, -1.0f, 3.0f, 2.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-0.5f, (float)0.0f, (float)-3.0f));
        rgtWeaponTip.m_171599_("RgtSpike3", CubeListBuilder.m_171558_().m_171514_(52, 118).m_171488_(-1.0f, 0.0f, -1.0f, 2.0f, 3.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)2.5f, (float)-3.0f));
        rgtWeaponTip.m_171599_("RgtSpike4", CubeListBuilder.m_171558_().m_171514_(52, 118).m_171488_(-1.0f, -3.0f, -1.0f, 2.0f, 3.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)-2.5f, (float)-3.0f));
        root.m_171599_("Head3RgtEar", CubeListBuilder.m_171558_().m_171514_(110, 24).m_171488_(-8.0f, -9.0f, -1.0f, 3.0f, 5.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)7.0f, (float)-13.0f, (float)0.0f));
        root.m_171599_("Head3LftEar", CubeListBuilder.m_171558_().m_171514_(100, 24).m_171488_(5.0f, -9.0f, -1.0f, 3.0f, 5.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)7.0f, (float)-13.0f, (float)0.0f));
        root.m_171599_("Head3Eyelid", CubeListBuilder.m_171558_().m_171514_(46, 3).m_171488_(-3.0f, -8.0f, -4.5f, 6.0f, 2.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)7.0f, (float)-13.0f, (float)0.0f, (float)0.2617994f, (float)0.0f, (float)0.0f));
        root.m_171599_("Head3Nose", CubeListBuilder.m_171558_().m_171514_(60, 9).m_171488_(-1.5f, -8.5f, -3.5f, 3.0f, 2.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)7.0f, (float)-13.0f, (float)0.0f, (float)0.4886922f, (float)0.0f, (float)0.0f));
        root.m_171599_("Head3", CubeListBuilder.m_171558_().m_171514_(42, 83).m_171488_(-5.0f, -12.0f, -6.0f, 10.0f, 12.0f, 12.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)7.0f, (float)-13.0f, (float)0.0f));
        root.m_171599_("Head3Brow", CubeListBuilder.m_171558_().m_171514_(46, 0).m_171488_(-3.0f, -9.0f, -8.5f, 6.0f, 2.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)7.0f, (float)-13.0f, (float)0.0f, (float)-0.2617994f, (float)0.0f, (float)0.0f));
        root.m_171599_("Head3Hair", CubeListBuilder.m_171558_().m_171514_(80, 118).m_171488_(-2.0f, -17.0f, -5.0f, 4.0f, 6.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)7.0f, (float)-13.0f, (float)0.0f, (float)-0.6108652f, (float)0.0f, (float)0.0f));
        root.m_171599_("Head3Lip", CubeListBuilder.m_171558_().m_171514_(22, 68).m_171488_(-4.0f, -4.0f, -7.0f, 8.0f, 2.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)7.0f, (float)-13.0f, (float)0.0f, (float)0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("Head3RgtTusk", CubeListBuilder.m_171558_().m_171514_(83, 34).m_171488_(-3.5f, -6.0f, -6.5f, 1.0f, 2.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)7.0f, (float)-13.0f, (float)0.0f, (float)0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("Head3RgtTooth", CubeListBuilder.m_171558_().m_171514_(87, 34).m_171488_(-1.5f, -5.0f, -6.5f, 1.0f, 1.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)7.0f, (float)-13.0f, (float)0.0f, (float)0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("Head3LftTooth", CubeListBuilder.m_171558_().m_171514_(96, 34).m_171488_(0.5f, -5.0f, -6.5f, 1.0f, 1.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)7.0f, (float)-13.0f, (float)0.0f, (float)0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("Head3LftTusk", CubeListBuilder.m_171558_().m_171514_(100, 34).m_171488_(2.5f, -6.0f, -6.5f, 1.0f, 2.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)7.0f, (float)-13.0f, (float)0.0f, (float)0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("Head3RingHole", CubeListBuilder.m_171558_().m_171514_(26, 50).m_171488_(6.0f, -5.0f, -1.0f, 1.0f, 2.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)7.0f, (float)-13.0f, (float)0.0f));
        root.m_171599_("Head3Ring", CubeListBuilder.m_171558_().m_171514_(32, 58).m_171488_(6.0f, -6.0f, -2.0f, 1.0f, 4.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)7.0f, (float)-13.0f, (float)0.0f));
        root.m_171599_("Head2Chin", CubeListBuilder.m_171558_().m_171514_(21, 24).m_171488_(-3.0f, -5.0f, -8.0f, 6.0f, 3.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-7.0f, (float)-13.0f, (float)0.0f, (float)0.2617994f, (float)0.0f, (float)0.0f));
        root.m_171599_("Head2", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-5.0f, -12.0f, -6.0f, 10.0f, 12.0f, 12.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-7.0f, (float)-13.0f, (float)0.0f));
        root.m_171599_("Head2Lip", CubeListBuilder.m_171558_().m_171514_(0, 24).m_171488_(-4.0f, -5.0f, -8.0f, 8.0f, 2.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-7.0f, (float)-13.0f, (float)0.0f));
        root.m_171599_("Head2LftTusk", CubeListBuilder.m_171558_().m_171514_(46, 28).m_171488_(2.5f, -8.0f, -6.5f, 1.0f, 2.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-7.0f, (float)-13.0f, (float)0.0f, (float)0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("Head2RgtTusk", CubeListBuilder.m_171558_().m_171514_(39, 28).m_171488_(-3.5f, -8.0f, -6.5f, 1.0f, 2.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-7.0f, (float)-13.0f, (float)0.0f, (float)0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("Head2Nose", CubeListBuilder.m_171558_().m_171514_(116, 0).m_171488_(-2.0f, -7.0f, -7.0f, 4.0f, 2.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-7.0f, (float)-13.0f, (float)0.0f, (float)0.0872665f, (float)0.0f, (float)0.0f));
        root.m_171599_("Head2NoseBridge", CubeListBuilder.m_171558_().m_171514_(116, 4).m_171488_(-1.0f, -7.0f, -8.0f, 2.0f, 2.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-7.0f, (float)-13.0f, (float)0.0f, (float)-0.1745329f, (float)0.0f, (float)0.0f));
        root.m_171599_("Head2Brow", CubeListBuilder.m_171558_().m_171514_(80, 24).m_171488_(-4.0f, -10.5f, -8.0f, 8.0f, 3.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-7.0f, (float)-13.0f, (float)0.0f, (float)-0.0872665f, (float)0.0f, (float)0.0f));
        root.m_171599_("Head2RgtHorn", CubeListBuilder.m_171558_().m_171514_(24, 30).m_171488_(-4.0f, -8.0f, -15.0f, 2.0f, 2.0f, 5.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-7.0f, (float)-13.0f, (float)0.0f, (float)-0.5235988f, (float)0.0f, (float)0.0f));
        root.m_171599_("Head2LftHorn", CubeListBuilder.m_171558_().m_171514_(24, 30).m_171488_(2.0f, -8.0f, -15.0f, 2.0f, 2.0f, 5.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-7.0f, (float)-13.0f, (float)0.0f, (float)-0.5235988f, (float)0.0f, (float)0.0f));
        root.m_171599_("Head2DiamondHorn", CubeListBuilder.m_171558_().m_171514_(120, 46).m_171488_(-1.0f, -17.0f, -6.0f, 2.0f, 6.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-7.0f, (float)-13.0f, (float)0.0f, (float)0.0872665f, (float)0.0f, (float)0.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)128, (int)128);
    }

    public void prepareMobModel(T entity, float limbSwing, float limbSwingAmount, float partialTick) {
        this.type = ((MoCEntityMob)entity).getTypeMoC();
        this.attackCounter = ((MoCEntityOgre)entity).attackCounter;
        this.headMoving = ((MoCEntityOgre)entity).getMovingHead();
        this.armToAnimate = ((MoCEntityOgre)entity).armToAnimate;
    }

    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float hRotY = netHeadYaw / 57.29578f;
        float hRotX = headPitch / 57.29578f;
        float RLegXRot = Mth.m_14089_((float)(limbSwing * 0.6662f + (float)Math.PI)) * 0.8f * limbSwingAmount;
        float LLegXRot = Mth.m_14089_((float)(limbSwing * 0.6662f)) * 0.8f * limbSwingAmount;
        float ClothRot = Mth.m_14089_((float)(limbSwing * 0.9f)) * 0.6f * limbSwingAmount;
        float RLegXRotB = RLegXRot;
        float LLegXRotB = LLegXRot;
        float RLegXRot2 = Mth.m_14089_((float)((limbSwing + 0.1f) * 0.6662f + (float)Math.PI)) * 0.8f * limbSwingAmount;
        float LLegXRot2 = Mth.m_14089_((float)((limbSwing + 0.1f) * 0.6662f)) * 0.8f * limbSwingAmount;
        if (limbSwingAmount > 0.15f) {
            if (RLegXRot > RLegXRot2) {
                RLegXRotB = RLegXRot + 0.43633232f;
            }
            if (LLegXRot > LLegXRot2) {
                LLegXRotB = LLegXRot + 0.43633232f;
            }
        }
        this.RgtThigh.f_104203_ = RLegXRot;
        this.LftThigh.f_104203_ = LLegXRot;
        this.RgtLeg.f_104203_ = RLegXRotB;
        this.LftLeg.f_104203_ = LLegXRotB;
        this.LoinCloth.f_104203_ = ClothRot;
        this.ButtCover.f_104203_ = ClothRot;
        float armMov = -(Mth.m_14089_((float)((float)this.attackCounter * 0.18f)) * 3.0f);
        if (this.armToAnimate == 1 || this.armToAnimate == 3) {
            this.LftShoulder.f_104203_ = armMov;
            this.LftHand.f_104203_ = -0.7853981f;
        } else {
            this.LftShoulder.f_104205_ = Mth.m_14089_((float)(ageInTicks * 0.09f)) * 0.05f - 0.05f;
            this.LftShoulder.f_104203_ = RLegXRot;
            this.LftHand.f_104203_ = 0.0f;
        }
        if (this.armToAnimate == 2 || this.armToAnimate == 3) {
            this.RgtShoulder.f_104203_ = armMov;
            this.RgtHand.f_104203_ = -0.7853981f;
        } else {
            this.RgtShoulder.f_104205_ = -(Mth.m_14089_((float)(ageInTicks * 0.09f)) * 0.05f) + 0.05f;
            this.RgtShoulder.f_104203_ = LLegXRot;
            this.RgtHand.f_104203_ = 0.0f;
        }
        if (this.headMoving == 2) {
            this.Head2.f_104203_ = hRotX;
            this.Head2.f_104204_ = hRotY;
        }
        if (this.headMoving == 3) {
            this.Head3.f_104203_ = hRotX;
            this.Head3.f_104204_ = hRotY;
        }
        if (this.type == 1 || this.type == 3 || this.type == 5) {
            this.Head.f_104203_ = hRotX;
            this.Head.f_104204_ = hRotY;
            this.Brow.f_104203_ = this.Head.f_104203_;
            this.NoseBridge.f_104203_ = this.Head.f_104203_;
            this.Nose.f_104203_ = this.Head.f_104203_;
            this.RgtTusk.f_104203_ = this.Head.f_104203_;
            this.RgtTooth.f_104203_ = this.Head.f_104203_;
            this.LftTooth.f_104203_ = this.Head.f_104203_;
            this.LftTusk.f_104203_ = this.Head.f_104203_;
            this.Lip.f_104203_ = this.Head.f_104203_;
            this.RgtEar.f_104203_ = this.Head.f_104203_;
            this.RgtRing.f_104203_ = this.Head.f_104203_;
            this.RgtRingHole.f_104203_ = this.Head.f_104203_;
            this.LftEar.f_104203_ = this.Head.f_104203_;
            this.LftRing.f_104203_ = this.Head.f_104203_;
            this.LftRingHole.f_104203_ = this.Head.f_104203_;
            this.HairRope.f_104203_ = 0.6108652f + this.Head.f_104203_;
            this.Hair1.f_104203_ = 0.6108652f + this.Head.f_104203_;
            this.Hair2.f_104203_ = 0.2617994f + this.Head.f_104203_;
            this.Hair3.f_104203_ = this.Head.f_104203_;
            this.DiamondHorn.f_104203_ = 0.0872665f + this.Head.f_104203_;
            this.RgtHorn.f_104203_ = this.Head.f_104203_;
            this.RgtHornTip.f_104203_ = this.Head.f_104203_;
            this.LftHorn.f_104203_ = this.Head.f_104203_;
            this.LftHornTip.f_104203_ = this.Head.f_104203_;
            this.Brow.f_104204_ = this.Head.f_104204_;
            this.NoseBridge.f_104204_ = this.Head.f_104204_;
            this.Nose.f_104204_ = this.Head.f_104204_;
            this.RgtTusk.f_104204_ = this.Head.f_104204_;
            this.RgtTooth.f_104204_ = this.Head.f_104204_;
            this.LftTooth.f_104204_ = this.Head.f_104204_;
            this.LftTusk.f_104204_ = this.Head.f_104204_;
            this.Lip.f_104204_ = this.Head.f_104204_;
            this.RgtEar.f_104204_ = this.Head.f_104204_;
            this.RgtRing.f_104204_ = this.Head.f_104204_;
            this.RgtRingHole.f_104204_ = this.Head.f_104204_;
            this.LftEar.f_104204_ = this.Head.f_104204_;
            this.LftRing.f_104204_ = this.Head.f_104204_;
            this.LftRingHole.f_104204_ = this.Head.f_104204_;
            this.HairRope.f_104204_ = this.Head.f_104204_;
            this.Hair1.f_104204_ = this.Head.f_104204_;
            this.Hair2.f_104204_ = this.Head.f_104204_;
            this.Hair3.f_104204_ = this.Head.f_104204_;
            this.DiamondHorn.f_104204_ = this.Head.f_104204_;
            this.RgtHorn.f_104204_ = this.Head.f_104204_;
            this.RgtHornTip.f_104204_ = this.Head.f_104204_;
            this.LftHorn.f_104204_ = this.Head.f_104204_;
            this.LftHornTip.f_104204_ = this.Head.f_104204_;
        } else {
            this.Head3RgtEar.f_104203_ = this.Head3.f_104203_;
            this.Head3LftEar.f_104203_ = this.Head3.f_104203_;
            this.Head3Eyelid.f_104203_ = 0.2617994f + this.Head3.f_104203_;
            this.Head3Nose.f_104203_ = 0.4886922f + this.Head3.f_104203_;
            this.Head3Brow.f_104203_ = -0.2617994f + this.Head3.f_104203_;
            this.Head3Hair.f_104203_ = -0.6108652f + this.Head3.f_104203_;
            this.Head3Lip.f_104203_ = 0.1745329f + this.Head3.f_104203_;
            this.Head3RgtTusk.f_104203_ = 0.1745329f + this.Head3.f_104203_;
            this.Head3RgtTooth.f_104203_ = 0.1745329f + this.Head3.f_104203_;
            this.Head3LftTooth.f_104203_ = 0.1745329f + this.Head3.f_104203_;
            this.Head3LftTusk.f_104203_ = 0.1745329f + this.Head3.f_104203_;
            this.Head3RingHole.f_104203_ = this.Head3.f_104203_;
            this.Head3Ring.f_104203_ = this.Head3.f_104203_;
            this.Head3RgtEar.f_104204_ = this.Head3.f_104204_;
            this.Head3LftEar.f_104204_ = this.Head3.f_104204_;
            this.Head3Eyelid.f_104204_ = this.Head3.f_104204_;
            this.Head3Nose.f_104204_ = this.Head3.f_104204_;
            this.Head3Brow.f_104204_ = this.Head3.f_104204_;
            this.Head3Hair.f_104204_ = this.Head3.f_104204_;
            this.Head3Lip.f_104204_ = this.Head3.f_104204_;
            this.Head3RgtTusk.f_104204_ = this.Head3.f_104204_;
            this.Head3RgtTooth.f_104204_ = this.Head3.f_104204_;
            this.Head3LftTooth.f_104204_ = this.Head3.f_104204_;
            this.Head3LftTusk.f_104204_ = this.Head3.f_104204_;
            this.Head3RingHole.f_104204_ = this.Head3.f_104204_;
            this.Head3Ring.f_104204_ = this.Head3.f_104204_;
            this.Head2Chin.f_104203_ = 0.2617994f + this.Head2.f_104203_;
            this.Head2Lip.f_104203_ = this.Head2.f_104203_;
            this.Head2LftTusk.f_104203_ = 0.1745329f + this.Head2.f_104203_;
            this.Head2RgtTusk.f_104203_ = 0.1745329f + this.Head2.f_104203_;
            this.Head2Nose.f_104203_ = 0.0872665f + this.Head2.f_104203_;
            this.Head2NoseBridge.f_104203_ = -0.1745329f + this.Head2.f_104203_;
            this.Head2Brow.f_104203_ = -0.0872665f + this.Head2.f_104203_;
            this.Head2RgtHorn.f_104203_ = -0.5235988f + this.Head2.f_104203_;
            this.Head2LftHorn.f_104203_ = -0.5235988f + this.Head2.f_104203_;
            this.Head2DiamondHorn.f_104203_ = 0.0872665f + this.Head2.f_104203_;
            this.Head2Chin.f_104204_ = this.Head2.f_104204_;
            this.Head2Lip.f_104204_ = this.Head2.f_104204_;
            this.Head2LftTusk.f_104204_ = this.Head2.f_104204_;
            this.Head2RgtTusk.f_104204_ = this.Head2.f_104204_;
            this.Head2Nose.f_104204_ = this.Head2.f_104204_;
            this.Head2NoseBridge.f_104204_ = this.Head2.f_104204_;
            this.Head2Brow.f_104204_ = this.Head2.f_104204_;
            this.Head2RgtHorn.f_104204_ = this.Head2.f_104204_;
            this.Head2LftHorn.f_104204_ = this.Head2.f_104204_;
            this.Head2DiamondHorn.f_104204_ = this.Head2.f_104204_;
        }
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        if (this.type == 1) {
            this.Head.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Brow.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.NoseBridge.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Nose.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.RgtTusk.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.RgtTooth.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.LftTooth.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.LftTusk.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Lip.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.RgtEar.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.RgtRing.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.RgtRingHole.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.LftEar.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.LftRing.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.LftRingHole.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.HairRope.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Hair1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Hair2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Hair3.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.DiamondHorn.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.RgtHorn.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.RgtHornTip.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.LftHorn.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.LftHornTip.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        } else {
            this.Head3RgtEar.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Head3LftEar.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Head3Eyelid.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Head3Nose.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Head3.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Head3Brow.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Head3Hair.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Head3Lip.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Head3RgtTusk.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Head3RgtTooth.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Head3LftTooth.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Head3LftTusk.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Head3RingHole.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Head3Ring.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Head2Chin.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Head2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Head2Lip.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Head2LftTusk.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Head2RgtTusk.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Head2Nose.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Head2NoseBridge.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Head2Brow.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Head2RgtHorn.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Head2LftHorn.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Head2DiamondHorn.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        }
        this.NeckRest.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Chest.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Stomach.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.ButtCover.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LoinCloth.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RgtThigh.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LftThigh.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RgtShoulder.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LftShoulder.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}

