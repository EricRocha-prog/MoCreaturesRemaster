/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import drzhark.mocreatures.client.model.MoCModelBigCat;
import drzhark.mocreatures.entity.MoCEntityAnimal;
import drzhark.mocreatures.entity.hunter.MoCEntityBigCat;
import drzhark.mocreatures.entity.hunter.MoCEntityManticorePet;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelManticorePet<T extends MoCEntityManticorePet>
extends MoCModelBigCat<T> {
    public MoCModelManticorePet(ModelPart root) {
        super(root);
    }

    @Override
    public void prepareMobModel(T entityIn, float limbSwing, float limbSwingAmount, float partialTick) {
        super.prepareMobModel(entityIn, limbSwing, limbSwingAmount, partialTick);
        this.isFlyer = ((MoCEntityManticorePet)entityIn).isFlyer();
        this.isSaddled = ((MoCEntityBigCat)entityIn).getIsRideable();
        this.flapwings = true;
        this.floating = this.isFlyer && ((MoCEntityAnimal)entityIn).isOnAir() && !entityIn.m_20096_();
        this.isRidden = entityIn.m_20159_();
        this.hasMane = true;
        this.hasSaberTeeth = true;
        this.onAir = ((MoCEntityAnimal)entityIn).isOnAir();
        this.hasStinger = true;
        this.isMovingVertically = entityIn.m_20184_().f_82480_ != 0.0 && !entityIn.m_20096_();
        this.hasChest = false;
        this.isTamed = false;
    }

    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        super.m_6973_(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
    }
}

