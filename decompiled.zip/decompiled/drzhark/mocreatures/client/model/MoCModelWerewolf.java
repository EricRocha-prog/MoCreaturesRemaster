/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.hostile.MoCEntityWerewolf;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelWerewolf<T extends MoCEntityWerewolf>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "werewolf"), "main");
    private final ModelPart Head;
    private final ModelPart Nose;
    private final ModelPart Snout;
    private final ModelPart TeethU;
    private final ModelPart TeethL;
    private final ModelPart Mouth;
    private final ModelPart LEar;
    private final ModelPart REar;
    private final ModelPart Neck;
    private final ModelPart Neck2;
    private final ModelPart SideburnL;
    private final ModelPart SideburnR;
    private final ModelPart Chest;
    private final ModelPart Abdomen;
    private final ModelPart TailA;
    private final ModelPart TailB;
    private final ModelPart TailC;
    private final ModelPart TailD;
    private final ModelPart RLegA;
    private final ModelPart RFoot;
    private final ModelPart RLegB;
    private final ModelPart RLegC;
    private final ModelPart LLegA;
    private final ModelPart LFoot;
    private final ModelPart LLegB;
    private final ModelPart LLegC;
    private final ModelPart RArmA;
    private final ModelPart RArmB;
    private final ModelPart RArmC;
    private final ModelPart RHand;
    private final ModelPart LArmA;
    private final ModelPart LArmB;
    private final ModelPart LArmC;
    private final ModelPart LHand;
    private final ModelPart RFinger1;
    private final ModelPart RFinger2;
    private final ModelPart RFinger3;
    private final ModelPart RFinger4;
    private final ModelPart RFinger5;
    private final ModelPart LFinger1;
    private final ModelPart LFinger2;
    private final ModelPart LFinger3;
    private final ModelPart LFinger4;
    private final ModelPart LFinger5;
    public boolean hunched;

    public MoCModelWerewolf(ModelPart root) {
        this.Head = root.m_171324_("Head");
        this.Nose = root.m_171324_("Nose");
        this.Snout = root.m_171324_("Snout");
        this.TeethU = root.m_171324_("TeethU");
        this.TeethL = root.m_171324_("TeethL");
        this.Mouth = root.m_171324_("Mouth");
        this.LEar = root.m_171324_("LEar");
        this.REar = root.m_171324_("REar");
        this.Neck = root.m_171324_("Neck");
        this.Neck2 = root.m_171324_("Neck2");
        this.SideburnL = root.m_171324_("SideburnL");
        this.SideburnR = root.m_171324_("SideburnR");
        this.Chest = root.m_171324_("Chest");
        this.Abdomen = root.m_171324_("Abdomen");
        this.TailA = root.m_171324_("TailA");
        this.TailB = root.m_171324_("TailB");
        this.TailC = root.m_171324_("TailC");
        this.TailD = root.m_171324_("TailD");
        this.RLegA = root.m_171324_("RLegA");
        this.RFoot = root.m_171324_("RFoot");
        this.RLegB = root.m_171324_("RLegB");
        this.RLegC = root.m_171324_("RLegC");
        this.LLegA = root.m_171324_("LLegA");
        this.LFoot = root.m_171324_("LFoot");
        this.LLegB = root.m_171324_("LLegB");
        this.LLegC = root.m_171324_("LLegC");
        this.RArmA = root.m_171324_("RArmA");
        this.RArmB = root.m_171324_("RArmB");
        this.RArmC = root.m_171324_("RArmC");
        this.RHand = root.m_171324_("RHand");
        this.LArmA = root.m_171324_("LArmA");
        this.LArmB = root.m_171324_("LArmB");
        this.LArmC = root.m_171324_("LArmC");
        this.LHand = root.m_171324_("LHand");
        this.RFinger1 = root.m_171324_("RFinger1");
        this.RFinger2 = root.m_171324_("RFinger2");
        this.RFinger3 = root.m_171324_("RFinger3");
        this.RFinger4 = root.m_171324_("RFinger4");
        this.RFinger5 = root.m_171324_("RFinger5");
        this.LFinger1 = root.m_171324_("LFinger1");
        this.LFinger2 = root.m_171324_("LFinger2");
        this.LFinger3 = root.m_171324_("LFinger3");
        this.LFinger4 = root.m_171324_("LFinger4");
        this.LFinger5 = root.m_171324_("LFinger5");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition part = mesh.m_171576_();
        part.m_171599_("Head", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-4.0f, -3.0f, -6.0f, 8.0f, 8.0f, 6.0f), PartPose.m_171419_((float)0.0f, (float)-8.0f, (float)-6.0f));
        part.m_171599_("Nose", CubeListBuilder.m_171558_().m_171514_(44, 33).m_171481_(-1.5f, -1.7f, -12.3f, 3.0f, 2.0f, 7.0f), PartPose.m_171423_((float)0.0f, (float)-8.0f, (float)-6.0f, (float)0.2792527f, (float)0.0f, (float)0.0f));
        part.m_171599_("Snout", CubeListBuilder.m_171558_().m_171514_(0, 25).m_171481_(-2.0f, 2.0f, -12.0f, 4.0f, 2.0f, 6.0f), PartPose.m_171419_((float)0.0f, (float)-8.0f, (float)-6.0f));
        part.m_171599_("TeethU", CubeListBuilder.m_171558_().m_171514_(46, 18).m_171481_(-2.0f, 4.01f, -12.0f, 4.0f, 2.0f, 5.0f), PartPose.m_171419_((float)0.0f, (float)-8.0f, (float)-6.0f));
        part.m_171599_("TeethL", CubeListBuilder.m_171558_().m_171514_(20, 109).m_171481_(-1.5f, -12.5f, 2.01f, 3.0f, 5.0f, 2.0f), PartPose.m_171423_((float)0.0f, (float)-8.0f, (float)-6.0f, (float)2.530727f, (float)0.0f, (float)0.0f));
        part.m_171599_("Mouth", CubeListBuilder.m_171558_().m_171514_(42, 69).m_171481_(-1.5f, -12.5f, 0.0f, 3.0f, 9.0f, 2.0f), PartPose.m_171423_((float)0.0f, (float)-8.0f, (float)-6.0f, (float)2.530727f, (float)0.0f, (float)0.0f));
        part.m_171599_("LEar", CubeListBuilder.m_171558_().m_171514_(13, 14).m_171481_(0.5f, -7.5f, -1.0f, 3.0f, 5.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)-8.0f, (float)-6.0f, (float)0.0f, (float)0.0f, (float)0.1745329f));
        part.m_171599_("REar", CubeListBuilder.m_171558_().m_171514_(22, 0).m_171481_(-3.5f, -7.5f, -1.0f, 3.0f, 5.0f, 1.0f), PartPose.m_171423_((float)0.0f, (float)-8.0f, (float)-6.0f, (float)0.0f, (float)0.0f, (float)-0.1745329f));
        part.m_171599_("Neck", CubeListBuilder.m_171558_().m_171514_(28, 0).m_171481_(-3.5f, -3.0f, -7.0f, 7.0f, 8.0f, 7.0f), PartPose.m_171423_((float)0.0f, (float)-5.0f, (float)-2.0f, (float)-0.6025001f, (float)0.0f, (float)0.0f));
        part.m_171599_("Neck2", CubeListBuilder.m_171558_().m_171514_(0, 14).m_171481_(-1.5f, -2.0f, -5.0f, 3.0f, 4.0f, 7.0f), PartPose.m_171423_((float)0.0f, (float)-1.0f, (float)-6.0f, (float)-0.4537856f, (float)0.0f, (float)0.0f));
        part.m_171599_("SideburnL", CubeListBuilder.m_171558_().m_171514_(28, 33).m_171481_(3.0f, 0.0f, -2.0f, 2.0f, 6.0f, 6.0f), PartPose.m_171423_((float)0.0f, (float)-8.0f, (float)-6.0f, (float)-0.2094395f, (float)0.418879f, (float)-0.0872665f));
        part.m_171599_("SideburnR", CubeListBuilder.m_171558_().m_171514_(28, 45).m_171481_(-5.0f, 0.0f, -2.0f, 2.0f, 6.0f, 6.0f), PartPose.m_171423_((float)0.0f, (float)-8.0f, (float)-6.0f, (float)-0.2094395f, (float)-0.418879f, (float)0.0872665f));
        part.m_171599_("Chest", CubeListBuilder.m_171558_().m_171514_(20, 15).m_171481_(-4.0f, 0.0f, -7.0f, 8.0f, 8.0f, 10.0f), PartPose.m_171423_((float)0.0f, (float)-6.0f, (float)-2.5f, (float)0.641331f, (float)0.0f, (float)0.0f));
        part.m_171599_("Abdomen", CubeListBuilder.m_171558_().m_171514_(0, 40).m_171481_(-3.0f, -8.0f, -8.0f, 6.0f, 14.0f, 8.0f), PartPose.m_171423_((float)0.0f, (float)4.5f, (float)5.0f, (float)0.2695449f, (float)0.0f, (float)0.0f));
        part.m_171599_("TailA", CubeListBuilder.m_171558_().m_171514_(52, 42).m_171481_(-1.5f, -1.0f, -2.0f, 3.0f, 4.0f, 3.0f), PartPose.m_171423_((float)0.0f, (float)9.5f, (float)6.0f, (float)1.064651f, (float)0.0f, (float)0.0f));
        part.m_171599_("TailB", CubeListBuilder.m_171558_().m_171514_(48, 49).m_171481_(-2.0f, 2.0f, -2.0f, 4.0f, 6.0f, 4.0f), PartPose.m_171423_((float)0.0f, (float)9.5f, (float)6.0f, (float)0.7504916f, (float)0.0f, (float)0.0f));
        part.m_171599_("TailC", CubeListBuilder.m_171558_().m_171514_(48, 59).m_171481_(-2.0f, 6.8f, -4.6f, 4.0f, 6.0f, 4.0f), PartPose.m_171423_((float)0.0f, (float)9.5f, (float)6.0f, (float)1.099557f, (float)0.0f, (float)0.0f));
        part.m_171599_("TailD", CubeListBuilder.m_171558_().m_171514_(52, 69).m_171481_(-1.5f, 9.8f, -4.1f, 3.0f, 5.0f, 3.0f), PartPose.m_171423_((float)0.0f, (float)9.5f, (float)6.0f, (float)1.099557f, (float)0.0f, (float)0.0f));
        part.m_171599_("RLegA", CubeListBuilder.m_171558_().m_171514_(12, 64).m_171481_(-2.5f, -1.5f, -3.5f, 3.0f, 8.0f, 5.0f), PartPose.m_171423_((float)-3.0f, (float)9.5f, (float)3.0f, (float)-0.8126625f, (float)0.0f, (float)0.0f));
        part.m_171599_("RFoot", CubeListBuilder.m_171558_().m_171514_(14, 93).m_171481_(-2.506667f, 12.5f, -5.0f, 3.0f, 2.0f, 3.0f), PartPose.m_171419_((float)-3.0f, (float)9.5f, (float)3.0f));
        part.m_171599_("RLegB", CubeListBuilder.m_171558_().m_171514_(14, 76).m_171481_(-1.9f, 4.2f, 0.5f, 2.0f, 2.0f, 5.0f), PartPose.m_171423_((float)-3.0f, (float)9.5f, (float)3.0f, (float)-0.8445741f, (float)0.0f, (float)0.0f));
        part.m_171599_("RLegC", CubeListBuilder.m_171558_().m_171514_(14, 83).m_171481_(-2.0f, 6.2f, 0.5f, 2.0f, 8.0f, 2.0f), PartPose.m_171423_((float)-3.0f, (float)9.5f, (float)3.0f, (float)-0.2860688f, (float)0.0f, (float)0.0f));
        part.m_171599_("LLegB", CubeListBuilder.m_171558_().m_171514_(0, 76).m_171481_(-0.1f, 4.2f, 0.5f, 2.0f, 2.0f, 5.0f), PartPose.m_171423_((float)3.0f, (float)9.5f, (float)3.0f, (float)-0.8445741f, (float)0.0f, (float)0.0f));
        part.m_171599_("LFoot", CubeListBuilder.m_171558_().m_171514_(0, 93).m_171481_(-0.5066667f, 12.5f, -5.0f, 3.0f, 2.0f, 3.0f), PartPose.m_171419_((float)3.0f, (float)9.5f, (float)3.0f));
        part.m_171599_("LLegC", CubeListBuilder.m_171558_().m_171514_(0, 83).m_171481_(0.0f, 6.2f, 0.5f, 2.0f, 8.0f, 2.0f), PartPose.m_171423_((float)3.0f, (float)9.5f, (float)3.0f, (float)-0.2860688f, (float)0.0f, (float)0.0f));
        part.m_171599_("LLegA", CubeListBuilder.m_171558_().m_171514_(0, 64).m_171481_(-0.5f, -1.5f, -3.5f, 3.0f, 8.0f, 5.0f), PartPose.m_171423_((float)3.0f, (float)9.5f, (float)3.0f, (float)-0.8126625f, (float)0.0f, (float)0.0f));
        part.m_171599_("RArmB", CubeListBuilder.m_171558_().m_171514_(48, 77).m_171481_(-3.5f, 1.0f, -1.5f, 4.0f, 8.0f, 4.0f), PartPose.m_171423_((float)-4.0f, (float)-4.0f, (float)-2.0f, (float)0.2617994f, (float)0.0f, (float)0.3490659f));
        part.m_171599_("RArmC", CubeListBuilder.m_171558_().m_171514_(48, 112).m_171481_(-6.0f, 5.0f, 3.0f, 4.0f, 7.0f, 4.0f), PartPose.m_171423_((float)-4.0f, (float)-4.0f, (float)-2.0f, (float)-0.3490659f, (float)0.0f, (float)0.0f));
        part.m_171599_("LArmB", CubeListBuilder.m_171558_().m_171514_(48, 89).m_171481_(-0.5f, 1.0f, -1.5f, 4.0f, 8.0f, 4.0f), PartPose.m_171423_((float)4.0f, (float)-4.0f, (float)-2.0f, (float)0.2617994f, (float)0.0f, (float)-0.3490659f));
        part.m_171599_("RHand", CubeListBuilder.m_171558_().m_171514_(32, 118).m_171481_(-6.0f, 12.5f, -1.5f, 4.0f, 3.0f, 4.0f), PartPose.m_171419_((float)-4.0f, (float)-4.0f, (float)-2.0f));
        part.m_171599_("RArmA", CubeListBuilder.m_171558_().m_171514_(0, 108).m_171481_(-5.0f, -3.0f, -2.0f, 5.0f, 5.0f, 5.0f), PartPose.m_171423_((float)-4.0f, (float)-4.0f, (float)-2.0f, (float)0.6320364f, (float)0.0f, (float)0.0f));
        part.m_171599_("LArmA", CubeListBuilder.m_171558_().m_171514_(0, 98).m_171481_(0.0f, -3.0f, -2.0f, 5.0f, 5.0f, 5.0f), PartPose.m_171423_((float)4.0f, (float)-4.0f, (float)-2.0f, (float)0.6320364f, (float)0.0f, (float)0.0f));
        part.m_171599_("LArmC", CubeListBuilder.m_171558_().m_171514_(48, 101).m_171481_(2.0f, 5.0f, 3.0f, 4.0f, 7.0f, 4.0f), PartPose.m_171423_((float)4.0f, (float)-4.0f, (float)-2.0f, (float)-0.3490659f, (float)0.0f, (float)0.0f));
        part.m_171599_("LHand", CubeListBuilder.m_171558_().m_171514_(32, 111).m_171481_(2.0f, 12.5f, -1.5f, 4.0f, 3.0f, 4.0f), PartPose.m_171419_((float)4.0f, (float)-4.0f, (float)-2.0f));
        part.m_171599_("RFinger1", CubeListBuilder.m_171558_().m_171514_(8, 120).m_171481_(-3.0f, 15.5f, 1.0f, 1.0f, 3.0f, 1.0f), PartPose.m_171419_((float)-4.0f, (float)-4.0f, (float)-2.0f));
        part.m_171599_("RFinger2", CubeListBuilder.m_171558_().m_171514_(12, 124).m_171481_(-3.5f, 15.5f, -1.5f, 1.0f, 3.0f, 1.0f), PartPose.m_171419_((float)-4.0f, (float)-4.0f, (float)-2.0f));
        part.m_171599_("RFinger3", CubeListBuilder.m_171558_().m_171514_(12, 119).m_171481_(-4.8f, 15.5f, -1.5f, 1.0f, 4.0f, 1.0f), PartPose.m_171419_((float)-4.0f, (float)-4.0f, (float)-2.0f));
        part.m_171599_("RFinger4", CubeListBuilder.m_171558_().m_171514_(16, 119).m_171481_(-6.0f, 15.5f, -0.5f, 1.0f, 4.0f, 1.0f), PartPose.m_171419_((float)-4.0f, (float)-4.0f, (float)-2.0f));
        part.m_171599_("RFinger5", CubeListBuilder.m_171558_().m_171514_(16, 124).m_171481_(-6.0f, 15.5f, 1.0f, 1.0f, 3.0f, 1.0f), PartPose.m_171419_((float)-4.0f, (float)-4.0f, (float)-2.0f));
        part.m_171599_("LFinger1", CubeListBuilder.m_171558_().m_171514_(8, 124).m_171481_(2.0f, 15.5f, 1.0f, 1.0f, 3.0f, 1.0f), PartPose.m_171419_((float)4.0f, (float)-4.0f, (float)-2.0f));
        part.m_171599_("LFinger2", CubeListBuilder.m_171558_().m_171514_(0, 124).m_171481_(2.5f, 15.5f, -1.5f, 1.0f, 3.0f, 1.0f), PartPose.m_171419_((float)4.0f, (float)-4.0f, (float)-2.0f));
        part.m_171599_("LFinger3", CubeListBuilder.m_171558_().m_171514_(0, 119).m_171481_(3.8f, 15.5f, -1.5f, 1.0f, 4.0f, 1.0f), PartPose.m_171419_((float)4.0f, (float)-4.0f, (float)-2.0f));
        part.m_171599_("LFinger4", CubeListBuilder.m_171558_().m_171514_(4, 119).m_171481_(5.0f, 15.5f, -0.5f, 1.0f, 4.0f, 1.0f), PartPose.m_171419_((float)4.0f, (float)-4.0f, (float)-2.0f));
        part.m_171599_("LFinger5", CubeListBuilder.m_171558_().m_171514_(4, 124).m_171481_(5.0f, 15.5f, 1.0f, 1.0f, 3.0f, 1.0f), PartPose.m_171419_((float)4.0f, (float)-4.0f, (float)-2.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)64, (int)128);
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.Head.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Nose.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Snout.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.TeethU.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.TeethL.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Mouth.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LEar.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.REar.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Neck.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Neck2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.SideburnL.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.SideburnR.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Chest.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.Abdomen.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.TailA.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.TailB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.TailC.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.TailD.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RLegA.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RFoot.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RLegB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RLegC.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LLegA.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LFoot.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LLegB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LLegC.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RArmA.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RArmB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RArmC.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RHand.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LArmA.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LArmB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LArmC.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LHand.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RFinger1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RFinger2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RFinger3.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RFinger4.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.RFinger5.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LFinger1.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LFinger2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LFinger3.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LFinger4.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.LFinger5.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }

    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float radianF = 57.29578f;
        float RLegXRot = Mth.m_14089_((float)(limbSwing * 0.6662f + (float)Math.PI)) * 0.8f * limbSwingAmount;
        float LLegXRot = Mth.m_14089_((float)(limbSwing * 0.6662f)) * 0.8f * limbSwingAmount;
        this.Head.f_104204_ = netHeadYaw / radianF;
        if (!this.hunched) {
            this.Head.m_104227_(0.0f, -8.0f, -6.0f);
            this.Head.f_104203_ = headPitch / radianF;
            this.Neck.f_104203_ = -34.0f / radianF;
            this.Neck.m_104227_(0.0f, -5.0f, -2.0f);
            this.Neck2.m_104227_(0.0f, -1.0f, -6.0f);
            this.Chest.m_104227_(0.0f, -6.0f, -2.5f);
            this.Chest.f_104203_ = 36.0f / radianF;
            this.Abdomen.f_104203_ = 15.0f / radianF;
            this.LLegA.m_104227_(3.0f, 9.5f, 3.0f);
            this.LArmA.m_104227_(4.0f, -4.0f, -2.0f);
            this.LArmA.f_104203_ = 0.6320364f;
            this.TailA.m_104227_(0.0f, 9.5f, 6.0f);
            this.TailA.f_104203_ = 1.064651f;
        } else {
            this.Head.m_104227_(0.0f, 0.0f, -11.0f);
            this.Head.f_104203_ = (15.0f + headPitch) / radianF;
            this.Neck.f_104203_ = -10.0f / radianF;
            this.Neck.m_104227_(0.0f, 2.0f, -6.0f);
            this.Neck2.m_104227_(0.0f, 9.0f, -9.0f);
            this.Chest.m_104227_(0.0f, 1.0f, -7.5f);
            this.Chest.f_104203_ = 60.0f / radianF;
            this.Abdomen.f_104203_ = 75.0f / radianF;
            this.LLegA.m_104227_(3.0f, 9.5f, 7.0f);
            this.LArmA.m_104227_(4.0f, 4.5f, -6.0f);
            this.LArmA.f_104203_ = 0.6320364f;
            this.TailA.m_104227_(0.0f, 7.5f, 10.0f);
            this.TailA.f_104203_ = 1.064651f;
        }
        this.Nose.m_104227_(this.Head.f_104200_, this.Head.f_104201_, this.Head.f_104202_);
        this.Snout.m_104227_(this.Head.f_104200_, this.Head.f_104201_, this.Head.f_104202_);
        this.TeethU.m_104227_(this.Head.f_104200_, this.Head.f_104201_, this.Head.f_104202_);
        this.TeethL.m_104227_(this.Head.f_104200_, this.Head.f_104201_, this.Head.f_104202_);
        this.Mouth.m_104227_(this.Head.f_104200_, this.Head.f_104201_, this.Head.f_104202_);
        this.LEar.m_104227_(this.Head.f_104200_, this.Head.f_104201_, this.Head.f_104202_);
        this.REar.m_104227_(this.Head.f_104200_, this.Head.f_104201_, this.Head.f_104202_);
        this.SideburnL.m_104227_(this.Head.f_104200_, this.Head.f_104201_, this.Head.f_104202_);
        this.SideburnR.m_104227_(this.Head.f_104200_, this.Head.f_104201_, this.Head.f_104202_);
        this.Nose.f_104204_ = this.Head.f_104204_;
        this.Snout.f_104204_ = this.Head.f_104204_;
        this.TeethU.f_104204_ = this.Head.f_104204_;
        this.TeethL.f_104204_ = this.Head.f_104204_;
        this.Mouth.f_104204_ = this.Head.f_104204_;
        this.LEar.f_104204_ = this.Head.f_104204_;
        this.REar.f_104204_ = this.Head.f_104204_;
        this.Nose.f_104203_ = 0.2792527f + this.Head.f_104203_;
        this.Snout.f_104203_ = this.Head.f_104203_;
        this.TeethU.f_104203_ = this.Head.f_104203_;
        this.TeethL.f_104203_ = this.Head.f_104203_ + 2.530727f;
        this.Mouth.f_104203_ = this.Head.f_104203_ + 2.530727f;
        this.LEar.f_104203_ = this.Head.f_104203_;
        this.REar.f_104203_ = this.Head.f_104203_;
        this.SideburnL.f_104203_ = -0.2094395f + this.Head.f_104203_;
        this.SideburnL.f_104204_ = 0.418879f + this.Head.f_104204_;
        this.SideburnR.f_104203_ = -0.2094395f + this.Head.f_104203_;
        this.SideburnR.f_104204_ = -0.418879f + this.Head.f_104204_;
        this.RLegA.f_104203_ = -0.8126625f + RLegXRot;
        this.RLegB.f_104203_ = -0.8445741f + RLegXRot;
        this.RLegC.f_104203_ = -0.2860688f + RLegXRot;
        this.RFoot.f_104203_ = RLegXRot;
        this.LLegA.f_104203_ = -0.8126625f + LLegXRot;
        this.LLegB.f_104203_ = -0.8445741f + LLegXRot;
        this.LLegC.f_104203_ = -0.2860688f + LLegXRot;
        this.LFoot.f_104203_ = LLegXRot;
        float armZOsc = (float)(Math.cos(ageInTicks * 0.09f) * (double)0.05f);
        this.RArmA.f_104205_ = -armZOsc + 0.05f;
        this.LArmA.f_104205_ = armZOsc - 0.05f;
        this.RArmA.f_104203_ = LLegXRot;
        this.LArmA.f_104203_ = RLegXRot;
        this.RArmB.f_104205_ = 0.3490659f + this.RArmA.f_104205_;
        this.LArmB.f_104205_ = -0.3490659f + this.LArmA.f_104205_;
        this.RArmB.f_104203_ = 0.2617994f + this.RArmA.f_104203_;
        this.LArmB.f_104203_ = 0.2617994f + this.LArmA.f_104203_;
        this.RArmC.f_104205_ = this.RArmA.f_104205_;
        this.LArmC.f_104205_ = this.LArmA.f_104205_;
        this.RArmC.f_104203_ = -0.3490659f + this.RArmA.f_104203_;
        this.LArmC.f_104203_ = -0.3490659f + this.LArmA.f_104203_;
        this.RHand.f_104205_ = this.RArmA.f_104205_;
        this.LHand.f_104205_ = this.LArmA.f_104205_;
        this.RHand.f_104203_ = this.RArmA.f_104203_;
        this.LHand.f_104203_ = this.LArmA.f_104203_;
        for (ModelPart finger : new ModelPart[]{this.RFinger1, this.RFinger2, this.RFinger3, this.RFinger4, this.RFinger5}) {
            finger.f_104203_ = this.RArmA.f_104203_;
            finger.f_104205_ = this.RArmA.f_104205_;
            finger.m_104227_(this.RArmA.f_104200_, this.RArmA.f_104201_, this.RArmA.f_104202_);
        }
        for (ModelPart finger : new ModelPart[]{this.LFinger1, this.LFinger2, this.LFinger3, this.LFinger4, this.LFinger5}) {
            finger.f_104203_ = this.LArmA.f_104203_;
            finger.f_104205_ = this.LArmA.f_104205_;
            finger.m_104227_(this.LArmA.f_104200_, this.LArmA.f_104201_, this.LArmA.f_104202_);
        }
        this.TailB.m_104227_(this.TailA.f_104200_, this.TailA.f_104201_, this.TailA.f_104202_);
        this.TailC.m_104227_(this.TailA.f_104200_, this.TailA.f_104201_, this.TailA.f_104202_);
        this.TailD.m_104227_(this.TailA.f_104200_, this.TailA.f_104201_, this.TailA.f_104202_);
        this.RArmB.m_104227_(this.RArmA.f_104200_, this.RArmA.f_104201_, this.RArmA.f_104202_);
        this.RArmC.m_104227_(this.RArmA.f_104200_, this.RArmA.f_104201_, this.RArmA.f_104202_);
        this.RHand.m_104227_(this.RArmA.f_104200_, this.RArmA.f_104201_, this.RArmA.f_104202_);
        this.RLegB.m_104227_(this.RLegA.f_104200_, this.RLegA.f_104201_, this.RLegA.f_104202_);
        this.RLegC.m_104227_(this.RLegA.f_104200_, this.RLegA.f_104201_, this.RLegA.f_104202_);
        this.RFoot.m_104227_(this.RLegA.f_104200_, this.RLegA.f_104201_, this.RLegA.f_104202_);
        this.LArmB.m_104227_(this.LArmA.f_104200_, this.LArmA.f_104201_, this.LArmA.f_104202_);
        this.LArmC.m_104227_(this.LArmA.f_104200_, this.LArmA.f_104201_, this.LArmA.f_104202_);
        this.LHand.m_104227_(this.LArmA.f_104200_, this.LArmA.f_104201_, this.LArmA.f_104202_);
        this.LLegB.m_104227_(this.LLegA.f_104200_, this.LLegA.f_104201_, this.LLegA.f_104202_);
        this.LLegC.m_104227_(this.LLegA.f_104200_, this.LLegA.f_104201_, this.LLegA.f_104202_);
        this.LFoot.m_104227_(this.LLegA.f_104200_, this.LLegA.f_104201_, this.LLegA.f_104202_);
    }
}

