/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeDeformation
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.aquatic.MoCEntityShark;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelShark<T extends MoCEntityShark>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "shark"), "main");
    private final ModelPart body;
    private final ModelPart torso1;
    private final ModelPart neck;
    private final ModelPart head;
    private final ModelPart upper_head;
    private final ModelPart jaw_base_r1;
    private final ModelPart teeth_row_left_r1;
    private final ModelPart teeth_row_front_r1;
    private final ModelPart upper_skull_r1;
    private final ModelPart nose_bot_r1;
    private final ModelPart lower_jaw;
    private final ModelPart teeth_row_front_r2;
    private final ModelPart dorsal_fin;
    private final ModelPart dorsal_fin_d_r1;
    private final ModelPart dorsal_fin_c_r1;
    private final ModelPart dorsal_fin_b_r1;
    private final ModelPart dorsal_fin_a_r1;
    private final ModelPart pectoral_fins;
    private final ModelPart left_fin;
    private final ModelPart left_fin_d_r1;
    private final ModelPart left_fin_a_r1;
    private final ModelPart left_fin_a_r2;
    private final ModelPart right_fin;
    private final ModelPart right_fin_a_r1;
    private final ModelPart right_fin_a_r2;
    private final ModelPart right_fin_d_r1;
    private final ModelPart torso2;
    private final ModelPart pelvic_fin_right_r1;
    private final ModelPart pelvic_fin_left_r1;
    private final ModelPart tail;
    private final ModelPart caudal_fin;
    private final ModelPart caudal_fin_bot_c_r1;
    private final ModelPart caudal_fin_bot_b_r1;
    private final ModelPart caudal_fin_bot_a_r1;
    private final ModelPart caudal_fin_top_d_r1;
    private final ModelPart caudal_fin_top_c_r1;
    private final ModelPart caudal_fin_top_b_r1;
    private final ModelPart caudal_fin_top_a_r1;

    public MoCModelShark(ModelPart root) {
        this.body = root.m_171324_("body");
        this.torso1 = this.body.m_171324_("torso1");
        this.neck = this.torso1.m_171324_("neck");
        this.head = this.neck.m_171324_("head");
        this.upper_head = this.head.m_171324_("upper_head");
        this.jaw_base_r1 = this.upper_head.m_171324_("jaw_base_r1");
        this.teeth_row_left_r1 = this.upper_head.m_171324_("teeth_row_left_r1");
        this.teeth_row_front_r1 = this.upper_head.m_171324_("teeth_row_front_r1");
        this.upper_skull_r1 = this.upper_head.m_171324_("upper_skull_r1");
        this.nose_bot_r1 = this.upper_head.m_171324_("nose_bot_r1");
        this.lower_jaw = this.head.m_171324_("lower_jaw");
        this.teeth_row_front_r2 = this.lower_jaw.m_171324_("teeth_row_front_r2");
        this.dorsal_fin = this.torso1.m_171324_("dorsal_fin");
        this.dorsal_fin_d_r1 = this.dorsal_fin.m_171324_("dorsal_fin_d_r1");
        this.dorsal_fin_c_r1 = this.dorsal_fin.m_171324_("dorsal_fin_c_r1");
        this.dorsal_fin_b_r1 = this.dorsal_fin.m_171324_("dorsal_fin_b_r1");
        this.dorsal_fin_a_r1 = this.dorsal_fin.m_171324_("dorsal_fin_a_r1");
        this.pectoral_fins = this.torso1.m_171324_("pectoral_fins");
        this.left_fin = this.pectoral_fins.m_171324_("left_fin");
        this.left_fin_d_r1 = this.left_fin.m_171324_("left_fin_d_r1");
        this.left_fin_a_r1 = this.left_fin.m_171324_("left_fin_a_r1");
        this.left_fin_a_r2 = this.left_fin.m_171324_("left_fin_a_r2");
        this.right_fin = this.pectoral_fins.m_171324_("right_fin");
        this.right_fin_a_r1 = this.right_fin.m_171324_("right_fin_a_r1");
        this.right_fin_a_r2 = this.right_fin.m_171324_("right_fin_a_r2");
        this.right_fin_d_r1 = this.right_fin.m_171324_("right_fin_d_r1");
        this.torso2 = this.torso1.m_171324_("torso2");
        this.pelvic_fin_right_r1 = this.torso2.m_171324_("pelvic_fin_right_r1");
        this.pelvic_fin_left_r1 = this.torso2.m_171324_("pelvic_fin_left_r1");
        this.tail = this.torso2.m_171324_("tail");
        this.caudal_fin = this.tail.m_171324_("caudal_fin");
        this.caudal_fin_bot_c_r1 = this.caudal_fin.m_171324_("caudal_fin_bot_c_r1");
        this.caudal_fin_bot_b_r1 = this.caudal_fin.m_171324_("caudal_fin_bot_b_r1");
        this.caudal_fin_bot_a_r1 = this.caudal_fin.m_171324_("caudal_fin_bot_a_r1");
        this.caudal_fin_top_d_r1 = this.caudal_fin.m_171324_("caudal_fin_top_d_r1");
        this.caudal_fin_top_c_r1 = this.caudal_fin.m_171324_("caudal_fin_top_c_r1");
        this.caudal_fin_top_b_r1 = this.caudal_fin.m_171324_("caudal_fin_top_b_r1");
        this.caudal_fin_top_a_r1 = this.caudal_fin.m_171324_("caudal_fin_top_a_r1");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        PartDefinition body = root.m_171599_("body", CubeListBuilder.m_171558_(), PartPose.m_171419_((float)-0.5f, (float)16.0f, (float)-3.0f));
        PartDefinition torso1 = body.m_171599_("torso1", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-10.5f, -9.0f, -30.0f, 22.0f, 20.0f, 33.0f, CubeDeformation.f_171458_), PartPose.m_171419_((float)0.0f, (float)-4.0f, (float)16.0f));
        PartDefinition neck = torso1.m_171599_("neck", CubeListBuilder.m_171558_().m_171514_(56, 73).m_171488_(-9.0f, -10.0f, -14.0f, 20.0f, 18.0f, 15.0f, CubeDeformation.f_171458_), PartPose.m_171419_((float)-0.5f, (float)2.0f, (float)-30.0f));
        PartDefinition head = neck.m_171599_("head", CubeListBuilder.m_171558_(), PartPose.m_171419_((float)-1.5f, (float)0.0f, (float)-14.0f));
        PartDefinition upper_head = head.m_171599_("upper_head", CubeListBuilder.m_171558_().m_171514_(89, 24).m_171480_().m_171488_(7.451f, 4.5311f, -43.1503f, 0.0f, 4.0f, 4.0f, CubeDeformation.f_171458_).m_171555_(false).m_171514_(89, 24).m_171488_(-4.749f, 4.5311f, -43.1503f, 0.0f, 4.0f, 4.0f, CubeDeformation.f_171458_), PartPose.m_171419_((float)1.15f, (float)-5.5f, (float)30.5f));
        PartDefinition jaw_base_r1 = upper_head.m_171599_("jaw_base_r1", CubeListBuilder.m_171558_().m_171514_(160, 4).m_171488_(-7.001f, -1.9315f, -4.8207f, 14.0f, 9.0f, 8.0f, CubeDeformation.f_171458_).m_171514_(0, 0).m_171488_(-5.9794f, -10.9315f, 2.1793f, 12.0f, 20.0f, 3.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)1.351f, (float)5.5014f, (float)-37.2182f, (float)1.5708f, (float)0.0f, (float)0.0f));
        PartDefinition teeth_row_left_r1 = upper_head.m_171599_("teeth_row_left_r1", CubeListBuilder.m_171558_().m_171514_(8, 92).m_171488_(5.0f, -3.5704f, -5.5322f, 0.0f, 3.0f, 8.0f, CubeDeformation.f_171458_).m_171514_(8, 92).m_171488_(-7.0f, -3.5704f, -5.5322f, 0.0f, 3.0f, 8.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)2.351f, (float)7.5014f, (float)-41.2182f, (float)0.0f, (float)0.0f, (float)0.0f));
        PartDefinition teeth_row_front_r1 = upper_head.m_171599_("teeth_row_front_r1", CubeListBuilder.m_171558_().m_171514_(1, 80).m_171488_(5.4612f, -4.5704f, -6.072f, 0.0f, 3.0f, 12.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)1.351f, (float)8.5014f, (float)-41.2182f, (float)0.0f, (float)1.5708f, (float)0.0f));
        PartDefinition upper_skull_r1 = upper_head.m_171599_("upper_skull_r1", CubeListBuilder.m_171558_().m_171514_(78, 0).m_171488_(-7.9794f, -11.3154f, 1.1579f, 16.0f, 19.0f, 7.0f, CubeDeformation.f_171458_).m_171514_(68, 107).m_171488_(-7.9794f, -16.3154f, 5.1579f, 16.0f, 5.0f, 3.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)1.351f, (float)5.5014f, (float)-36.7182f, (float)1.7017f, (float)0.0f, (float)0.0f));
        PartDefinition nose_bot_r1 = upper_head.m_171599_("nose_bot_r1", CubeListBuilder.m_171558_().m_171514_(129, 1).m_171488_(-8.0f, 0.0207f, -0.0117f, 16.0f, 7.0f, 3.0f, new CubeDeformation(-0.02f)), PartPose.m_171423_((float)1.3716f, (float)2.5064f, (float)-53.5873f, (float)1.1083f, (float)0.0f, (float)0.0f));
        PartDefinition lower_jaw = head.m_171599_("lower_jaw", CubeListBuilder.m_171558_().m_171514_(55, 57).m_171488_(-5.9828f, -0.25f, -6.8927f, 12.0f, 3.0f, 10.0f, new CubeDeformation(0.05f)).m_171514_(10, 89).m_171488_(5.0182f, -3.25f, -5.8927f, 0.0f, 3.0f, 7.0f, CubeDeformation.f_171458_).m_171514_(10, 89).m_171488_(-4.9818f, -3.25f, -5.8927f, 0.0f, 3.0f, 7.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)2.4828f, (float)1.6811f, (float)-8.3576f, (float)0.1309f, (float)0.0f, (float)0.0f));
        PartDefinition teeth_row_front_r2 = lower_jaw.m_171599_("teeth_row_front_r2", CubeListBuilder.m_171558_().m_171514_(4, 78).m_171488_(16.0196f, -6.0052f, -4.571f, 0.0f, 3.0f, 10.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)-0.4828f, (float)2.7552f, (float)10.1978f, (float)0.0f, (float)1.5708f, (float)0.0f));
        PartDefinition dorsal_fin = torso1.m_171599_("dorsal_fin", CubeListBuilder.m_171558_(), PartPose.m_171419_((float)0.5f, (float)-20.1292f, (float)-6.2277f));
        dorsal_fin.m_171599_("dorsal_fin_d_r1", CubeListBuilder.m_171558_().m_171514_(111, 39).m_171488_(8.0f, -5.1949f, 7.2152f, 2.0f, 7.0f, 9.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)-9.0f, (float)18.324f, (float)-2.6875f, (float)1.5708f, (float)0.0f, (float)0.0f));
        dorsal_fin.m_171599_("dorsal_fin_c_r1", CubeListBuilder.m_171558_().m_171514_(170, 28).m_171488_(-1.0f, -4.0f, -1.0f, 2.0f, 4.0f, 12.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)0.0f, (float)10.7262f, (float)3.0681f, (float)1.8326f, (float)0.0f, (float)0.0f));
        dorsal_fin.m_171599_("dorsal_fin_b_r1", CubeListBuilder.m_171558_().m_171514_(161, 22).m_171488_(-1.0f, -8.0f, -1.0f, 2.0f, 4.0f, 8.0f, new CubeDeformation(-0.01f)), PartPose.m_171423_((float)0.0f, (float)7.6647f, (float)-2.5701f, (float)0.6981f, (float)0.0f, (float)0.0f));
        dorsal_fin.m_171599_("dorsal_fin_a_r1", CubeListBuilder.m_171558_().m_171514_(143, 25).m_171488_(-1.0f, -4.0f, -1.0f, 2.0f, 4.0f, 10.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)0.0f, (float)12.0248f, (float)-8.2271f, (float)1.1781f, (float)0.0f, (float)0.0f));
        PartDefinition pectoral_fins = torso1.m_171599_("pectoral_fins", CubeListBuilder.m_171558_(), PartPose.f_171404_);
        PartDefinition left_fin = pectoral_fins.m_171599_("left_fin", CubeListBuilder.m_171558_(), PartPose.m_171423_((float)11.5f, (float)7.0f, (float)-21.0f, (float)0.0f, (float)0.0f, (float)-0.7854f));
        left_fin.m_171599_("left_fin_d_r1", CubeListBuilder.m_171558_().m_171514_(225, 0).m_171488_(-1.0f, 0.3827f, -3.0761f, 2.0f, 19.0f, 5.0f, new CubeDeformation(-0.01f)), PartPose.m_171423_((float)0.3933f, (float)-2.7076f, (float)-1.1278f, (float)0.3316f, (float)0.0f, (float)0.0f));
        left_fin.m_171599_("left_fin_a_r1", CubeListBuilder.m_171558_().m_171514_(216, 24).m_171488_(-1.0f, 3.9561f, 4.8879f, 2.0f, 11.0f, 4.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)0.3933f, (float)12.7347f, (float)-9.897f, (float)0.9076f, (float)0.0f, (float)0.0f));
        left_fin.m_171599_("left_fin_a_r2", CubeListBuilder.m_171558_().m_171514_(200, 17).m_171488_(-1.0f, -1.2777f, -2.8042f, 2.0f, 14.0f, 5.0f, new CubeDeformation(0.01f)), PartPose.m_171423_((float)0.3933f, (float)-1.6235f, (float)-5.2607f, (float)0.3316f, (float)0.0f, (float)0.0f));
        PartDefinition right_fin = pectoral_fins.m_171599_("right_fin", CubeListBuilder.m_171558_(), PartPose.m_171423_((float)-10.5f, (float)6.0f, (float)-21.0f, (float)0.0f, (float)0.0f, (float)0.7854f));
        right_fin.m_171599_("right_fin_a_r1", CubeListBuilder.m_171558_().m_171514_(200, 17).m_171488_(-1.0f, -1.2777f, -2.8042f, 2.0f, 14.0f, 5.0f, new CubeDeformation(0.01f)), PartPose.m_171423_((float)0.9246f, (float)-1.4211f, (float)-5.2607f, (float)0.3316f, (float)0.0f, (float)0.0f));
        right_fin.m_171599_("right_fin_a_r2", CubeListBuilder.m_171558_().m_171514_(216, 24).m_171488_(-1.0f, 3.9561f, 4.8879f, 2.0f, 11.0f, 4.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)0.9246f, (float)12.9372f, (float)-9.897f, (float)0.9076f, (float)0.0f, (float)0.0f));
        right_fin.m_171599_("right_fin_d_r1", CubeListBuilder.m_171558_().m_171514_(225, 0).m_171555_(true).m_171488_(-1.0f, 0.3827f, -3.0761f, 2.0f, 19.0f, 5.0f, new CubeDeformation(-0.01f)).m_171555_(false), PartPose.m_171423_((float)0.9246f, (float)-2.5052f, (float)-1.1278f, (float)0.3316f, (float)0.0f, (float)0.0f));
        PartDefinition torso2 = torso1.m_171599_("torso2", CubeListBuilder.m_171558_().m_171514_(0, 54).m_171488_(-8.0f, -8.0f, 0.0f, 18.0f, 16.0f, 17.0f, CubeDeformation.f_171458_), PartPose.m_171419_((float)-0.5f, (float)0.0f, (float)2.0f));
        torso2.m_171599_("pelvic_fin_right_r1", CubeListBuilder.m_171558_().m_171514_(0, 16).m_171488_(1.5f, 0.0f, -4.5f, 0.0f, 6.0f, 9.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)-5.0f, (float)7.0f, (float)10.5f, (float)0.0f, (float)0.0f, (float)0.3927f));
        torso2.m_171599_("pelvic_fin_left_r1", CubeListBuilder.m_171558_().m_171514_(0, 16).m_171488_(-1.5f, 0.0f, -4.5f, 0.0f, 6.0f, 9.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)6.0f, (float)7.0f, (float)10.5f, (float)0.0f, (float)0.0f, (float)-0.3927f));
        PartDefinition tail = torso2.m_171599_("tail", CubeListBuilder.m_171558_().m_171514_(0, 88).m_171488_(-3.5f, -6.2608f, -4.1248f, 8.0f, 10.0f, 25.0f, CubeDeformation.f_171458_).m_171514_(78, 22).m_171488_(0.5f, -10.8811f, 0.3854f, 0.0f, 5.0f, 5.0f, CubeDeformation.f_171458_).m_171514_(10, 98).m_171488_(0.5f, 3.35f, 4.3854f, 0.0f, 7.0f, 7.0f, CubeDeformation.f_171458_), PartPose.m_171419_((float)0.5f, (float)-1.0f, (float)17.0f));
        PartDefinition caudal_fin = tail.m_171599_("caudal_fin", CubeListBuilder.m_171558_().m_171514_(148, 69).m_171488_(-2.75f, -4.1371f, -50.1669f, 6.0f, 6.0f, 9.0f, CubeDeformation.f_171458_), PartPose.m_171419_((float)0.25f, (float)0.229f, (float)69.8752f));
        caudal_fin.m_171599_("caudal_fin_bot_c_r1", CubeListBuilder.m_171558_().m_171514_(189, 49).m_171488_(-1.0f, -3.8859f, -6.906f, 2.0f, 4.0f, 15.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)0.25f, (float)5.2995f, (float)-40.2294f, (float)-1.1781f, (float)0.0f, (float)0.0f));
        caudal_fin.m_171599_("caudal_fin_bot_b_r1", CubeListBuilder.m_171558_().m_171514_(146, 45).m_171488_(-0.99f, -0.0384f, -9.3692f, 2.0f, 4.0f, 19.0f, new CubeDeformation(0.02f)), PartPose.m_171423_((float)0.25f, (float)5.2995f, (float)-40.2294f, (float)-0.7418f, (float)0.0f, (float)0.0f));
        caudal_fin.m_171599_("caudal_fin_bot_a_r1", CubeListBuilder.m_171558_().m_171514_(129, 13).m_171488_(-1.01f, 0.1241f, -8.396f, 2.0f, 4.0f, 8.0f, new CubeDeformation(-0.01f)), PartPose.m_171423_((float)0.25f, (float)5.2995f, (float)-40.2294f, (float)-1.1781f, (float)0.0f, (float)0.0f));
        caudal_fin.m_171599_("caudal_fin_top_d_r1", CubeListBuilder.m_171558_().m_171514_(113, 27).m_171488_(-2.0f, -3.5f, 3.0f, 2.0f, 3.0f, 6.0f, new CubeDeformation(0.01f)), PartPose.m_171423_((float)1.24f, (float)-7.2547f, (float)-40.024f, (float)0.9599f, (float)0.0f, (float)0.0f));
        caudal_fin.m_171599_("caudal_fin_top_c_r1", CubeListBuilder.m_171558_().m_171514_(171, 45).m_171488_(-2.0f, -3.9791f, -14.9833f, 2.0f, 4.0f, 14.0f, CubeDeformation.f_171458_), PartPose.m_171423_((float)1.25f, (float)-19.9763f, (float)-26.8568f, (float)0.9599f, (float)0.0f, (float)0.0f));
        caudal_fin.m_171599_("caudal_fin_top_b_r1", CubeListBuilder.m_171558_().m_171514_(124, 41).m_171488_(-2.02f, -2.0f, -9.0f, 2.0f, 4.0f, 18.0f, new CubeDeformation(0.03f)), PartPose.m_171423_((float)1.26f, (float)-16.7717f, (float)-35.6639f, (float)0.5236f, (float)0.0f, (float)0.0f));
        caudal_fin.m_171599_("caudal_fin_top_a_r1", CubeListBuilder.m_171558_().m_171514_(112, 65).m_171488_(-1.0f, -4.0f, -3.0f, 2.0f, 11.0f, 12.0f, new CubeDeformation(0.01f)), PartPose.m_171423_((float)0.25f, (float)-4.3334f, (float)-46.33f, (float)0.9599f, (float)0.0f, (float)0.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)256, (int)256);
    }

    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.tail.f_104204_ = Mth.m_14089_((float)(limbSwing * 0.6662f)) * limbSwingAmount * 0.25f;
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.body.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}

