/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeDeformation
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraft.world.entity.Entity
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public abstract class MoCModelAbstractBigCat<T extends Entity>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "abstract_big_cat"), "main");
    private static final float RADIAN_CONV = 57.29578f;
    private static final float INTERPOLATION_FACTOR = 0.1f;
    protected boolean hasMane;
    protected boolean isRidden;
    protected boolean isSaddled;
    protected boolean flapwings;
    protected boolean onAir;
    protected boolean isFlyer;
    protected boolean floating;
    protected boolean poisoning;
    protected boolean isTamed;
    protected boolean movingTail;
    protected int openMouthCounter;
    protected boolean hasSaberTeeth;
    protected boolean hasChest;
    protected boolean hasStinger;
    protected boolean isGhost;
    protected boolean isMovingVertically;
    protected boolean isChested;
    protected boolean diving;
    protected boolean isSitting;
    private float prevTailSwingYaw;
    private float prevMouthAngle;
    protected T bigcat;
    private final ModelPart Chest;
    private final ModelPart NeckBase;
    private final ModelPart Collar;
    private final ModelPart HeadBack;
    private final ModelPart NeckHarness;
    private final ModelPart HarnessStick;
    private final ModelPart LeftHarness;
    private final ModelPart RightHarness;
    private final ModelPart Head;
    private final ModelPart Nose;
    private final ModelPart RightUpperLip;
    private final ModelPart LeftUpperLip;
    private final ModelPart UpperTeeth;
    private final ModelPart LeftFang;
    private final ModelPart RightFang;
    private final ModelPart InsideMouth;
    private final ModelPart LowerJaw;
    private final ModelPart LowerJawTeeth;
    private final ModelPart ChinHair;
    private final ModelPart LeftChinBeard;
    private final ModelPart RightChinBeard;
    private final ModelPart ForeheadHair;
    private final ModelPart Mane;
    private final ModelPart RightEar;
    private final ModelPart LeftEar;
    private final ModelPart NeckHair;
    private final ModelPart InnerWing;
    private final ModelPart MidWing;
    private final ModelPart OuterWing;
    private final ModelPart InnerWingR;
    private final ModelPart MidWingR;
    private final ModelPart OuterWingR;
    private final ModelPart Abdomen;
    private final ModelPart Ass;
    private final ModelPart TailRoot;
    private final ModelPart Tail2;
    private final ModelPart Tail3;
    private final ModelPart Tail4;
    private final ModelPart TailTip;
    private final ModelPart TailTusk;
    private final ModelPart Saddle;
    private final ModelPart SaddleFront;
    private final ModelPart SaddleBack;
    private final ModelPart LeftFootHarness;
    private final ModelPart LeftFootRing;
    private final ModelPart RightFootHarness;
    private final ModelPart RightFootRing;
    private final ModelPart StorageChest;
    private final ModelPart STailRoot;
    private final ModelPart STail2;
    private final ModelPart STail3;
    private final ModelPart STail4;
    private final ModelPart STail5;
    private final ModelPart StingerLump;
    private final ModelPart Stinger;
    private final ModelPart LeftUpperLeg;
    private final ModelPart LeftLowerLeg;
    private final ModelPart LeftFrontFoot;
    private final ModelPart LeftClaw1;
    private final ModelPart LeftClaw2;
    private final ModelPart LeftClaw3;
    private final ModelPart RightUpperLeg;
    private final ModelPart RightLowerLeg;
    private final ModelPart RightFrontFoot;
    private final ModelPart RightClaw1;
    private final ModelPart RightClaw2;
    private final ModelPart RightClaw3;
    private final ModelPart LeftHindUpperLeg;
    private final ModelPart LeftAnkle;
    private final ModelPart LeftHindLowerLeg;
    private final ModelPart LeftHindFoot;
    private final ModelPart RightHindUpperLeg;
    private final ModelPart RightAnkle;
    private final ModelPart RightHindLowerLeg;
    private final ModelPart RightHindFoot;

    public MoCModelAbstractBigCat(ModelPart root) {
        this.Chest = root.m_171324_("Chest");
        this.NeckBase = this.Chest.m_171324_("NeckBase");
        this.Collar = this.NeckBase.m_171324_("Collar");
        this.HeadBack = this.NeckBase.m_171324_("HeadBack");
        this.NeckHarness = this.HeadBack.m_171324_("NeckHarness");
        this.HarnessStick = this.HeadBack.m_171324_("HarnessStick");
        this.LeftHarness = root.m_171324_("LeftHarness");
        this.RightHarness = root.m_171324_("RightHarness");
        this.Head = this.HeadBack.m_171324_("Head");
        this.Nose = this.Head.m_171324_("Nose");
        this.RightUpperLip = this.Head.m_171324_("RightUpperLip");
        this.LeftUpperLip = this.Head.m_171324_("LeftUpperLip");
        this.UpperTeeth = this.Head.m_171324_("UpperTeeth");
        this.LeftFang = this.Head.m_171324_("LeftFang");
        this.RightFang = this.Head.m_171324_("RightFang");
        this.InsideMouth = this.Head.m_171324_("InsideMouth");
        this.LowerJaw = this.Head.m_171324_("LowerJaw");
        this.LowerJawTeeth = this.LowerJaw.m_171324_("LowerJawTeeth");
        this.ChinHair = this.LowerJaw.m_171324_("ChinHair");
        this.LeftChinBeard = this.Head.m_171324_("LeftChinBeard");
        this.RightChinBeard = this.Head.m_171324_("RightChinBeard");
        this.ForeheadHair = this.Head.m_171324_("ForeheadHair");
        this.Mane = this.Head.m_171324_("Mane");
        this.RightEar = this.Head.m_171324_("RightEar");
        this.LeftEar = this.Head.m_171324_("LeftEar");
        this.NeckHair = this.NeckBase.m_171324_("NeckHair");
        this.InnerWing = root.m_171324_("InnerWing");
        this.MidWing = root.m_171324_("MidWing");
        this.OuterWing = root.m_171324_("OuterWing");
        this.InnerWingR = root.m_171324_("InnerWingR");
        this.MidWingR = root.m_171324_("MidWingR");
        this.OuterWingR = root.m_171324_("OuterWingR");
        this.Abdomen = this.Chest.m_171324_("Abdomen");
        this.Ass = this.Abdomen.m_171324_("Ass");
        this.TailRoot = this.Abdomen.m_171324_("TailRoot");
        this.Tail2 = this.TailRoot.m_171324_("Tail2");
        this.Tail3 = this.Tail2.m_171324_("Tail3");
        this.Tail4 = this.Tail3.m_171324_("Tail4");
        this.TailTip = this.Tail4.m_171324_("TailTip");
        this.TailTusk = this.Tail4.m_171324_("TailTusk");
        this.Saddle = this.Chest.m_171324_("Saddle");
        this.SaddleFront = this.Saddle.m_171324_("SaddleFront");
        this.SaddleBack = this.Saddle.m_171324_("SaddleBack");
        this.LeftFootHarness = this.Saddle.m_171324_("LeftFootHarness");
        this.LeftFootRing = this.LeftFootHarness.m_171324_("LeftFootRing");
        this.RightFootHarness = this.Saddle.m_171324_("RightFootHarness");
        this.RightFootRing = this.RightFootHarness.m_171324_("RightFootRing");
        this.StorageChest = this.Abdomen.m_171324_("StorageChest");
        this.STailRoot = root.m_171324_("STailRoot");
        this.STail2 = root.m_171324_("STail2");
        this.STail3 = root.m_171324_("STail3");
        this.STail4 = root.m_171324_("STail4");
        this.STail5 = root.m_171324_("STail5");
        this.StingerLump = root.m_171324_("StingerLump");
        this.Stinger = root.m_171324_("Stinger");
        this.LeftUpperLeg = this.Chest.m_171324_("LeftUpperLeg");
        this.LeftLowerLeg = this.LeftUpperLeg.m_171324_("LeftLowerLeg");
        this.LeftFrontFoot = this.LeftLowerLeg.m_171324_("LeftFrontFoot");
        this.LeftClaw1 = this.LeftFrontFoot.m_171324_("LeftClaw1");
        this.LeftClaw2 = this.LeftFrontFoot.m_171324_("LeftClaw2");
        this.LeftClaw3 = this.LeftFrontFoot.m_171324_("LeftClaw3");
        this.RightUpperLeg = this.Chest.m_171324_("RightUpperLeg");
        this.RightLowerLeg = this.RightUpperLeg.m_171324_("RightLowerLeg");
        this.RightFrontFoot = this.RightLowerLeg.m_171324_("RightFrontFoot");
        this.RightClaw1 = this.RightFrontFoot.m_171324_("RightClaw1");
        this.RightClaw2 = this.RightFrontFoot.m_171324_("RightClaw2");
        this.RightClaw3 = this.RightFrontFoot.m_171324_("RightClaw3");
        this.LeftHindUpperLeg = this.Abdomen.m_171324_("LeftHindUpperLeg");
        this.LeftAnkle = this.LeftHindUpperLeg.m_171324_("LeftAnkle");
        this.LeftHindLowerLeg = this.LeftAnkle.m_171324_("LeftHindLowerLeg");
        this.LeftHindFoot = this.LeftHindLowerLeg.m_171324_("LeftHindFoot");
        this.RightHindUpperLeg = this.Abdomen.m_171324_("RightHindUpperLeg");
        this.RightAnkle = this.RightHindUpperLeg.m_171324_("RightAnkle");
        this.RightHindLowerLeg = this.RightAnkle.m_171324_("RightHindLowerLeg");
        this.RightHindFoot = this.RightHindLowerLeg.m_171324_("RightHindFoot");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        PartDefinition chest = root.m_171599_("Chest", CubeListBuilder.m_171558_().m_171514_(0, 18).m_171488_(-3.5f, 0.0f, -8.0f, 7.0f, 8.0f, 9.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)8.0f, (float)0.0f));
        PartDefinition neckBase = chest.m_171599_("NeckBase", CubeListBuilder.m_171558_().m_171514_(0, 7).m_171488_(-2.5f, 0.0f, -2.5f, 5.0f, 6.0f, 5.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-0.5f, (float)-8.0f, (float)-0.2443461f, (float)0.0f, (float)0.0f));
        neckBase.m_171599_("Collar", CubeListBuilder.m_171558_().m_171514_(18, 0).m_171488_(-2.5f, 0.0f, 0.0f, 5.0f, 4.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)6.0f, (float)-2.0f, (float)0.34906584f, (float)0.0f, (float)0.0f));
        PartDefinition headBack = neckBase.m_171599_("HeadBack", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-2.51f, -2.5f, -1.0f, 5.0f, 5.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)2.7f, (float)-2.9f, (float)0.2443461f, (float)0.0f, (float)0.0f));
        headBack.m_171599_("NeckHarness", CubeListBuilder.m_171558_().m_171514_(85, 32).m_171488_(-3.0f, -3.0f, -2.0f, 6.0f, 6.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)0.95f));
        headBack.m_171599_("HarnessStick", CubeListBuilder.m_171558_().m_171514_(85, 42).m_171488_(-3.5f, -0.5f, -0.5f, 7.0f, 1.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-1.8f, (float)0.5f, (float)0.7853981f, (float)0.0f, (float)0.0f));
        root.m_171599_("LeftHarness", CubeListBuilder.m_171558_().m_171514_(85, 32).m_171488_(3.2f, -0.6f, 1.5f, 0.0f, 1.0f, 9.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)8.6f, (float)-13.0f, (float)0.43633232f, (float)0.0f, (float)0.0f));
        root.m_171599_("RightHarness", CubeListBuilder.m_171558_().m_171514_(85, 31).m_171488_(-3.2f, -0.6f, 1.5f, 0.0f, 1.0f, 9.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)8.6f, (float)-13.0f, (float)0.43633232f, (float)0.0f, (float)0.0f));
        PartDefinition head = headBack.m_171599_("Head", CubeListBuilder.m_171558_().m_171514_(32, 0).m_171488_(-3.5f, -3.0f, -2.0f, 7.0f, 6.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)0.2f, (float)-2.2f));
        head.m_171599_("Nose", CubeListBuilder.m_171558_().m_171514_(46, 19).m_171488_(-1.5f, -1.0f, -2.0f, 3.0f, 2.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)-3.0f, (float)0.47123888f, (float)0.0f, (float)0.0f));
        head.m_171599_("RightUpperLip", CubeListBuilder.m_171558_().m_171514_(34, 19).m_171488_(-1.0f, -1.0f, -2.0f, 2.0f, 2.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-1.25f, (float)1.0f, (float)-2.8f, (float)0.17453292f, (float)((float)Math.PI / 90), (float)-0.2617994f));
        head.m_171599_("LeftUpperLip", CubeListBuilder.m_171558_().m_171514_(34, 25).m_171488_(-1.0f, -1.0f, -2.0f, 2.0f, 2.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)1.25f, (float)1.0f, (float)-2.8f, (float)0.17453292f, (float)((float)(-Math.PI) / 90), (float)0.2617994f));
        head.m_171599_("UpperTeeth", CubeListBuilder.m_171558_().m_171514_(20, 7).m_171488_(-1.5f, -1.0f, -1.5f, 3.0f, 2.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)2.0f, (float)-2.5f, (float)0.2617994f, (float)0.0f, (float)0.0f));
        head.m_171599_("LeftFang", CubeListBuilder.m_171558_().m_171514_(44, 10).m_171488_(-0.5f, -1.5f, -0.5f, 1.0f, 3.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)1.2f, (float)2.8f, (float)-3.4f, (float)0.2617994f, (float)0.0f, (float)0.0f));
        head.m_171599_("RightFang", CubeListBuilder.m_171558_().m_171514_(48, 10).m_171488_(-0.5f, -1.5f, -0.5f, 1.0f, 3.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-1.2f, (float)2.8f, (float)-3.4f, (float)0.2617994f, (float)0.0f, (float)0.0f));
        head.m_171599_("InsideMouth", CubeListBuilder.m_171558_().m_171514_(50, 0).m_171488_(-1.5f, -1.0f, -1.0f, 3.0f, 2.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)2.0f, (float)-1.0f));
        PartDefinition lowerJaw = head.m_171599_("LowerJaw", CubeListBuilder.m_171558_().m_171514_(46, 25).m_171488_(-1.5f, -1.0f, -4.0f, 3.0f, 2.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)2.1f, (float)0.0f));
        lowerJaw.m_171599_("LowerJawTeeth", CubeListBuilder.m_171558_().m_171514_(20, 12).m_171480_().m_171488_(-1.0f, 0.0f, -1.0f, 2.0f, 1.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)-1.8f, (float)-2.7f));
        lowerJaw.m_171599_("ChinHair", CubeListBuilder.m_171558_().m_171514_(76, 7).m_171488_(-2.5f, 0.0f, -2.0f, 5.0f, 6.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)0.0f, (float)1.0f));
        head.m_171599_("LeftChinBeard", CubeListBuilder.m_171558_().m_171514_(48, 10).m_171488_(-1.0f, -2.5f, -2.0f, 2.0f, 5.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)3.6f, (float)0.0f, (float)0.25f, (float)0.0f, (float)0.5235988f, (float)0.0f));
        head.m_171599_("RightChinBeard", CubeListBuilder.m_171558_().m_171514_(36, 10).m_171488_(-1.0f, -2.5f, -2.0f, 2.0f, 5.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-3.6f, (float)0.0f, (float)0.25f, (float)0.0f, (float)-0.5235988f, (float)0.0f));
        head.m_171599_("ForeheadHair", CubeListBuilder.m_171558_().m_171514_(88, 0).m_171488_(-1.5f, -1.5f, -1.5f, 3.0f, 3.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-3.2f, (float)0.0f, (float)0.17453292f, (float)0.0f, (float)0.0f));
        head.m_171599_("Mane", CubeListBuilder.m_171558_().m_171514_(94, 0).m_171488_(-5.5f, -5.5f, -3.0f, 11.0f, 11.0f, 6.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)0.7f, (float)3.7f, (float)-0.08726646f, (float)0.0f, (float)0.0f));
        head.m_171599_("RightEar", CubeListBuilder.m_171558_().m_171514_(54, 7).m_171488_(-1.0f, -1.0f, -0.5f, 2.0f, 2.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-2.7f, (float)-3.5f, (float)1.0f, (float)0.0f, (float)0.0f, (float)-0.2617994f));
        head.m_171599_("LeftEar", CubeListBuilder.m_171558_().m_171514_(54, 4).m_171488_(-1.0f, -1.0f, -0.5f, 2.0f, 2.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)2.7f, (float)-3.5f, (float)1.0f, (float)0.0f, (float)0.0f, (float)0.2617994f));
        neckBase.m_171599_("NeckHair", CubeListBuilder.m_171558_().m_171514_(108, 17).m_171488_(-2.0f, -1.0f, -3.0f, 4.0f, 2.0f, 6.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-0.5f, (float)3.0f, (float)-0.1850049f, (float)0.0f, (float)0.0f));
        root.m_171599_("InnerWing", CubeListBuilder.m_171558_().m_171514_(26, 115).m_171488_(0.0f, 0.0f, 0.0f, 7.0f, 2.0f, 11.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)4.0f, (float)9.0f, (float)-7.0f, (float)0.0f, (float)-0.34906584f, (float)0.0f));
        root.m_171599_("MidWing", CubeListBuilder.m_171558_().m_171514_(36, 89).m_171488_(1.0f, 0.1f, 1.0f, 12.0f, 2.0f, 11.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)4.0f, (float)9.0f, (float)-7.0f, (float)0.0f, (float)0.08726646f, (float)0.0f));
        root.m_171599_("OuterWing", CubeListBuilder.m_171558_().m_171514_(62, 115).m_171488_(0.0f, 0.0f, 0.0f, 22.0f, 2.0f, 11.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)16.0f, (float)9.0f, (float)-7.0f, (float)0.0f, (float)-0.31415927f, (float)0.0f));
        root.m_171599_("InnerWingR", CubeListBuilder.m_171558_().m_171514_(26, 102).m_171488_(-7.0f, 0.0f, 0.0f, 7.0f, 2.0f, 11.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-4.0f, (float)9.0f, (float)-7.0f, (float)0.0f, (float)0.34906584f, (float)0.0f));
        root.m_171599_("MidWingR", CubeListBuilder.m_171558_().m_171514_(82, 89).m_171488_(-13.0f, 0.1f, 1.0f, 12.0f, 2.0f, 11.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-4.0f, (float)9.0f, (float)-7.0f, (float)0.0f, (float)-0.08726646f, (float)0.0f));
        root.m_171599_("OuterWingR", CubeListBuilder.m_171558_().m_171514_(62, 102).m_171488_(-22.0f, 0.0f, 0.0f, 22.0f, 2.0f, 11.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-16.0f, (float)9.0f, (float)-7.0f, (float)0.0f, (float)0.31415927f, (float)0.0f));
        PartDefinition abdomen = chest.m_171599_("Abdomen", CubeListBuilder.m_171558_().m_171514_(0, 35).m_171488_(-3.0f, 0.0f, 0.0f, 6.0f, 7.0f, 7.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)-0.0523599f, (float)0.0f, (float)0.0f));
        abdomen.m_171599_("Ass", CubeListBuilder.m_171558_().m_171514_(0, 49).m_171488_(-2.5f, 0.0f, 0.0f, 5.0f, 5.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)7.0f, (float)-0.34906584f, (float)0.0f, (float)0.0f));
        PartDefinition tailRoot = abdomen.m_171599_("TailRoot", CubeListBuilder.m_171558_().m_171514_(96, 83).m_171488_(-1.0f, 0.0f, -1.0f, 2.0f, 4.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)1.0f, (float)7.0f, (float)1.5184364f, (float)0.0f, (float)0.0f));
        PartDefinition tail2 = tailRoot.m_171599_("Tail2", CubeListBuilder.m_171558_().m_171514_(96, 75).m_171488_(-1.0f, 0.0f, -1.0f, 2.0f, 6.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-0.01f, (float)3.5f, (float)0.0f, (float)-0.5235988f, (float)0.0f, (float)0.0f));
        PartDefinition tail3 = tail2.m_171599_("Tail3", CubeListBuilder.m_171558_().m_171514_(96, 67).m_171488_(-1.0f, 0.0f, -1.0f, 2.0f, 6.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.01f, (float)5.5f, (float)0.0f, (float)-0.29670596f, (float)0.0f, (float)0.0f));
        PartDefinition tail4 = tail3.m_171599_("Tail4", CubeListBuilder.m_171558_().m_171514_(96, 61).m_171488_(-1.0f, 0.0f, -1.0f, 2.0f, 4.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-0.01f, (float)5.5f, (float)0.0f, (float)0.36651915f, (float)0.0f, (float)0.0f));
        tail4.m_171599_("TailTip", CubeListBuilder.m_171558_().m_171514_(96, 55).m_171488_(-1.0f, 0.0f, -1.0f, 2.0f, 4.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.01f, (float)3.5f, (float)0.0f, (float)0.36651915f, (float)0.0f, (float)0.0f));
        tail4.m_171599_("TailTusk", CubeListBuilder.m_171558_().m_171514_(96, 49).m_171488_(-1.5f, 0.0f, -1.5f, 3.0f, 3.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)3.5f, (float)0.0f, (float)0.36651915f, (float)0.0f, (float)0.0f));
        PartDefinition saddle = chest.m_171599_("Saddle", CubeListBuilder.m_171558_().m_171514_(79, 18).m_171488_(-4.0f, -1.0f, -3.0f, 8.0f, 2.0f, 6.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)0.5f, (float)-1.0f));
        saddle.m_171599_("SaddleFront", CubeListBuilder.m_171558_().m_171514_(101, 26).m_171488_(-2.5f, -1.0f, -1.5f, 5.0f, 2.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-1.0f, (float)-1.5f, (float)-0.1850049f, (float)0.0f, (float)0.0f));
        saddle.m_171599_("SaddleBack", CubeListBuilder.m_171558_().m_171514_(77, 26).m_171488_(-4.0f, -2.0f, -2.0f, 8.0f, 2.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)0.7f, (float)4.0f, (float)0.22305307f, (float)0.0f, (float)0.0f));
        PartDefinition leftFootHarness = saddle.m_171599_("LeftFootHarness", CubeListBuilder.m_171558_().m_171514_(81, 18).m_171488_(-0.5f, 0.0f, -0.5f, 1.0f, 5.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)4.0f, (float)0.0f, (float)0.5f));
        leftFootHarness.m_171599_("LeftFootRing", CubeListBuilder.m_171558_().m_171514_(107, 31).m_171488_(0.0f, 0.0f, 0.0f, 1.0f, 2.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-0.5f, (float)5.0f, (float)-1.0f));
        PartDefinition rightFootHarness = saddle.m_171599_("RightFootHarness", CubeListBuilder.m_171558_().m_171514_(101, 18).m_171488_(-0.5f, 0.0f, -0.5f, 1.0f, 5.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-4.0f, (float)0.0f, (float)0.5f));
        rightFootHarness.m_171599_("RightFootRing", CubeListBuilder.m_171558_().m_171514_(101, 31).m_171488_(0.0f, 0.0f, 0.0f, 1.0f, 2.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-0.5f, (float)5.0f, (float)-1.0f));
        abdomen.m_171599_("StorageChest", CubeListBuilder.m_171558_().m_171514_(32, 59).m_171488_(-5.0f, -2.0f, -2.5f, 10.0f, 4.0f, 5.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)-2.0f, (float)5.5f, (float)-1.5707963f, (float)0.0f, (float)0.0f));
        root.m_171599_("STailRoot", CubeListBuilder.m_171558_().m_171514_(104, 79).m_171480_().m_171488_(-3.0f, 4.0f, 5.0f, 6.0f, 4.0f, 6.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)8.0f, (float)0.0f, (float)0.5796765f, (float)0.0f, (float)0.0f));
        root.m_171599_("STail2", CubeListBuilder.m_171558_().m_171514_(106, 69).m_171480_().m_171488_(-2.5f, 7.5f, 7.3f, 5.0f, 4.0f, 6.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)8.0f, (float)0.0f, (float)0.9514626f, (float)0.0f, (float)0.0f));
        root.m_171599_("STail3", CubeListBuilder.m_171558_().m_171514_(108, 60).m_171480_().m_171488_(-2.0f, 13.5f, 3.3f, 4.0f, 3.0f, 6.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)8.0f, (float)0.0f, (float)1.660128f, (float)0.0f, (float)0.0f));
        root.m_171599_("STail4", CubeListBuilder.m_171558_().m_171514_(108, 51).m_171480_().m_171488_(-2.0f, 15.2f, -5.3f, 4.0f, 3.0f, 6.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)8.0f, (float)0.0f, (float)2.478058f, (float)0.0f, (float)0.0f));
        root.m_171599_("STail5", CubeListBuilder.m_171558_().m_171514_(108, 42).m_171480_().m_171488_(-2.0f, 12.9f, -9.0f, 4.0f, 3.0f, 6.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)8.0f, (float)0.0f, (float)3.035737f, (float)0.0f, (float)0.0f));
        root.m_171599_("StingerLump", CubeListBuilder.m_171558_().m_171514_(112, 34).m_171480_().m_171488_(-1.5f, 7.9f, 6.0f, 3.0f, 3.0f, 5.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)8.0f, (float)0.0f, (float)2.031914f, (float)0.0f, (float)0.0f));
        root.m_171599_("Stinger", CubeListBuilder.m_171558_().m_171514_(118, 29).m_171480_().m_171488_(-0.5f, 1.9f, 8.0f, 1.0f, 1.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)8.0f, (float)0.0f, (float)1.213985f, (float)0.0f, (float)0.0f));
        PartDefinition leftUpperLeg = chest.m_171599_("LeftUpperLeg", CubeListBuilder.m_171558_().m_171514_(0, 96).m_171488_(-1.5f, 0.0f, -2.0f, 3.0f, 7.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)3.99f, (float)3.0f, (float)-7.0f, (float)0.2617994f, (float)0.0f, (float)0.0f));
        PartDefinition leftLowerLeg = leftUpperLeg.m_171599_("LeftLowerLeg", CubeListBuilder.m_171558_().m_171514_(0, 107).m_171488_(-1.5f, 0.0f, -1.5f, 3.0f, 6.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-0.01f, (float)6.5f, (float)0.2f, (float)-0.37524578f, (float)0.0f, (float)0.0f));
        PartDefinition leftFrontFoot = leftLowerLeg.m_171599_("LeftFrontFoot", CubeListBuilder.m_171558_().m_171514_(0, 116).m_171488_(-2.0f, 0.0f, -2.0f, 4.0f, 2.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)5.0f, (float)-1.0f, (float)0.1134464f, (float)0.0f, (float)0.0f));
        leftFrontFoot.m_171599_("LeftClaw1", CubeListBuilder.m_171558_().m_171514_(16, 125).m_171488_(-0.5f, 0.0f, -0.5f, 1.0f, 1.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-1.3f, (float)1.2f, (float)-3.0f, (float)0.7853981f, (float)0.0f, (float)((float)(-Math.PI) / 180)));
        leftFrontFoot.m_171599_("LeftClaw2", CubeListBuilder.m_171558_().m_171514_(16, 125).m_171488_(-0.5f, 0.0f, -0.5f, 1.0f, 1.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)1.1f, (float)-3.0f, (float)0.7853981f, (float)0.0f, (float)0.0f));
        leftFrontFoot.m_171599_("LeftClaw3", CubeListBuilder.m_171558_().m_171514_(16, 125).m_171488_(-0.5f, 0.0f, -0.5f, 1.0f, 1.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)1.3f, (float)1.2f, (float)-3.0f, (float)0.7853981f, (float)0.0f, (float)((float)Math.PI / 180)));
        PartDefinition rightUpperLeg = chest.m_171599_("RightUpperLeg", CubeListBuilder.m_171558_().m_171514_(14, 96).m_171488_(-1.5f, 0.0f, -2.0f, 3.0f, 7.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-3.99f, (float)3.0f, (float)-7.0f, (float)0.2617994f, (float)0.0f, (float)0.0f));
        PartDefinition rightLowerLeg = rightUpperLeg.m_171599_("RightLowerLeg", CubeListBuilder.m_171558_().m_171514_(12, 107).m_171488_(-1.5f, 0.0f, -1.5f, 3.0f, 6.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.01f, (float)6.5f, (float)0.2f, (float)-0.37524578f, (float)0.0f, (float)0.0f));
        PartDefinition rightFrontFoot = rightLowerLeg.m_171599_("RightFrontFoot", CubeListBuilder.m_171558_().m_171514_(0, 122).m_171488_(-2.0f, 0.0f, -2.0f, 4.0f, 2.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)5.0f, (float)-1.0f, (float)0.1134464f, (float)0.0f, (float)0.0f));
        rightFrontFoot.m_171599_("RightClaw1", CubeListBuilder.m_171558_().m_171514_(16, 125).m_171488_(-0.5f, 0.0f, -0.5f, 1.0f, 1.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-1.3f, (float)1.2f, (float)-3.0f, (float)0.7853981f, (float)0.0f, (float)((float)(-Math.PI) / 180)));
        rightFrontFoot.m_171599_("RightClaw2", CubeListBuilder.m_171558_().m_171514_(16, 125).m_171488_(-0.5f, 0.0f, -0.5f, 1.0f, 1.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)1.1f, (float)-3.0f, (float)0.7853981f, (float)0.0f, (float)0.0f));
        rightFrontFoot.m_171599_("RightClaw3", CubeListBuilder.m_171558_().m_171514_(16, 125).m_171488_(-0.5f, 0.0f, -0.5f, 1.0f, 1.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)1.3f, (float)1.2f, (float)-3.0f, (float)0.7853981f, (float)0.0f, (float)((float)Math.PI / 180)));
        PartDefinition leftHindUpperLeg = abdomen.m_171599_("LeftHindUpperLeg", CubeListBuilder.m_171558_().m_171514_(0, 67).m_171488_(-2.0f, -1.0f, -1.5f, 3.0f, 8.0f, 5.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)3.0f, (float)3.0f, (float)6.8f, (float)-0.43633232f, (float)0.0f, (float)0.0f));
        PartDefinition leftAnkle = leftHindUpperLeg.m_171599_("LeftAnkle", CubeListBuilder.m_171558_().m_171514_(0, 80).m_171488_(-1.0f, 0.0f, -1.5f, 2.0f, 3.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-0.5f, (float)4.0f, (float)5.0f));
        PartDefinition leftHindLowerLeg = leftAnkle.m_171599_("LeftHindLowerLeg", CubeListBuilder.m_171558_().m_171514_(0, 86).m_171488_(-1.0f, 0.0f, -1.0f, 2.0f, 3.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)0.5f));
        leftHindLowerLeg.m_171599_("LeftHindFoot", CubeListBuilder.m_171558_().m_171514_(0, 91).m_171488_(-1.5f, 0.0f, -1.5f, 3.0f, 2.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)2.6f, (float)-0.8f, (float)0.47123888f, (float)0.0f, (float)0.0f));
        PartDefinition rightHindUpperLeg = abdomen.m_171599_("RightHindUpperLeg", CubeListBuilder.m_171558_().m_171514_(16, 67).m_171488_(-2.0f, -1.0f, -1.5f, 3.0f, 8.0f, 5.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)-2.0f, (float)3.0f, (float)6.8f, (float)-0.43633232f, (float)0.0f, (float)0.0f));
        PartDefinition rightAnkle = rightHindUpperLeg.m_171599_("RightAnkle", CubeListBuilder.m_171558_().m_171514_(10, 80).m_171488_(-1.0f, 0.0f, -1.5f, 2.0f, 3.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-0.5f, (float)4.0f, (float)5.0f));
        PartDefinition rightHindLowerLeg = rightAnkle.m_171599_("RightHindLowerLeg", CubeListBuilder.m_171558_().m_171514_(8, 86).m_171488_(-1.0f, 0.0f, -1.0f, 2.0f, 3.0f, 2.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)3.0f, (float)0.5f));
        rightHindLowerLeg.m_171599_("RightHindFoot", CubeListBuilder.m_171558_().m_171514_(12, 91).m_171488_(-1.5f, 0.0f, -1.5f, 3.0f, 2.0f, 3.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)2.6f, (float)-0.8f, (float)0.47123888f, (float)0.0f, (float)0.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)128, (int)128);
    }

    private void renderTeeth(boolean flag) {
        this.LeftFang.f_104207_ = flag;
        this.RightFang.f_104207_ = flag;
    }

    private void renderCollar(boolean flag) {
        this.Collar.f_104207_ = flag;
    }

    private void renderSaddle(boolean flag) {
        this.NeckHarness.f_104207_ = flag;
        this.HarnessStick.f_104207_ = flag;
        this.Saddle.f_104207_ = flag;
    }

    private void renderMane(boolean flag) {
        this.Mane.f_104207_ = flag;
        this.LeftChinBeard.f_104207_ = flag;
        this.RightChinBeard.f_104207_ = flag;
        this.ForeheadHair.f_104207_ = flag;
        this.NeckHair.f_104207_ = flag;
        this.ChinHair.f_104207_ = flag;
    }

    private void renderChest(boolean flag) {
        this.StorageChest.f_104207_ = flag;
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.renderSaddle(this.isSaddled);
        this.renderMane(this.hasMane);
        this.renderCollar(this.isTamed);
        this.renderTeeth(this.hasSaberTeeth);
        this.renderChest(this.hasChest);
        poseStack.m_85836_();
        if (this.isGhost) {
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.clearColor((float)0.8f, (float)0.8f, (float)0.8f, (float)1.0f);
        }
        this.Chest.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        if (this.isFlyer) {
            this.InnerWing.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.MidWing.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.OuterWing.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.InnerWingR.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.MidWingR.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.OuterWingR.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        }
        if (this.hasStinger) {
            this.STailRoot.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.STail2.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.STail3.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.STail4.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.STail5.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.StingerLump.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.Stinger.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        }
        if (this.isSaddled && this.isRidden) {
            this.LeftHarness.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.RightHarness.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        }
        if (this.isGhost) {
            RenderSystem.disableBlend();
            RenderSystem.clearColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        }
        poseStack.m_85849_();
    }

    public void m_6973_(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float stingZOffset;
        float stingYOffset;
        float interpolatedTailSwingYaw;
        this.bigcat = entity;
        float RLegXRot = Mth.m_14089_((float)(limbSwing * 0.8f + (float)Math.PI)) * 0.8f * limbSwingAmount;
        float LLegXRot = Mth.m_14089_((float)(limbSwing * 0.8f)) * 0.8f * limbSwingAmount;
        float gallopRLegXRot = Mth.m_14089_((float)(limbSwing * 0.6f + (float)Math.PI)) * 0.8f * limbSwingAmount;
        float gallopLLegXRot = Mth.m_14089_((float)(limbSwing * 0.6f)) * 0.8f * limbSwingAmount;
        float targetTailAngle = this.movingTail ? Mth.m_14089_((float)(ageInTicks * 0.3f)) : 0.0f;
        this.Tail2.f_104204_ = interpolatedTailSwingYaw = this.prevTailSwingYaw + (targetTailAngle - this.prevTailSwingYaw) * 0.1f;
        this.prevTailSwingYaw = interpolatedTailSwingYaw;
        if (this.isSitting) {
            stingYOffset = 17.0f;
            stingZOffset = -3.0f;
            this.Chest.f_104201_ = 14.0f;
            this.Abdomen.f_104203_ = -0.17453292f;
            this.Chest.f_104203_ = -0.7853981f;
            this.RightUpperLeg.f_104203_ = 0.61086524f;
            this.RightLowerLeg.f_104203_ = 0.08726646f;
            this.LeftUpperLeg.f_104203_ = 0.61086524f;
            this.LeftLowerLeg.f_104203_ = 0.08726646f;
            this.NeckBase.f_104203_ = 0.34906584f;
            this.RightHindUpperLeg.f_104201_ = 1.0f;
            this.RightHindUpperLeg.f_104203_ = -0.87266463f;
            this.LeftHindUpperLeg.f_104201_ = 1.0f;
            this.LeftHindUpperLeg.f_104203_ = -0.87266463f;
            this.RightHindFoot.f_104203_ = 1.5707963f;
            this.LeftHindFoot.f_104203_ = 1.5707963f;
            this.TailRoot.f_104203_ = 1.7453293f;
            this.Tail2.f_104203_ = 0.61086524f;
            this.Tail3.f_104203_ = 0.17453292f;
            this.NeckHair.f_104201_ = 2.0f;
            this.Collar.f_104203_ = 0.0f;
            this.Collar.f_104201_ = 7.0f;
            this.Collar.f_104202_ = -4.0f;
        } else {
            boolean galloping;
            stingYOffset = 8.0f;
            stingZOffset = 0.0f;
            this.Chest.f_104201_ = 8.0f;
            this.Abdomen.f_104203_ = 0.0f;
            this.Chest.f_104203_ = 0.0f;
            this.NeckBase.f_104203_ = -0.2443461f;
            this.TailRoot.f_104203_ = 1.5184364f;
            this.Tail2.f_104203_ = -0.5235988f;
            this.Tail3.f_104203_ = -0.29670596f;
            this.RightLowerLeg.f_104203_ = -0.37524578f;
            this.LeftLowerLeg.f_104203_ = -0.37524578f;
            this.RightHindUpperLeg.f_104201_ = 3.0f;
            this.LeftHindUpperLeg.f_104201_ = 3.0f;
            this.RightHindFoot.f_104203_ = 0.47123888f;
            this.LeftHindFoot.f_104203_ = 0.47123888f;
            this.Collar.f_104202_ = -2.0f;
            this.NeckHair.f_104201_ = -0.5f;
            this.Collar.f_104201_ = this.hasMane ? 9.0f : 6.0f;
            this.Collar.f_104203_ = 0.34906584f + Mth.m_14089_((float)(limbSwing * 0.8f)) * 0.5f * limbSwingAmount;
            boolean bl = galloping = limbSwingAmount >= 0.97f;
            if (this.onAir || this.isGhost) {
                if (this.isGhost || this.isFlyer && limbSwingAmount > 0.0f) {
                    float speedMov = limbSwingAmount * 0.5f;
                    this.RightUpperLeg.f_104203_ = 0.7853981f + speedMov;
                    this.LeftUpperLeg.f_104203_ = 0.7853981f + speedMov;
                    this.RightHindUpperLeg.f_104203_ = 0.17453292f + speedMov;
                    this.LeftHindUpperLeg.f_104203_ = 0.17453292f + speedMov;
                } else if (this.isMovingVertically) {
                    this.RightUpperLeg.f_104203_ = -0.61086524f;
                    this.LeftUpperLeg.f_104203_ = -0.61086524f;
                    this.RightHindUpperLeg.f_104203_ = 0.61086524f;
                    this.LeftHindUpperLeg.f_104203_ = 0.61086524f;
                }
            } else if (galloping) {
                this.RightUpperLeg.f_104203_ = 0.2617994f + gallopRLegXRot;
                this.LeftUpperLeg.f_104203_ = 0.2617994f + gallopRLegXRot;
                this.RightHindUpperLeg.f_104203_ = -0.43633232f + gallopLLegXRot;
                this.LeftHindUpperLeg.f_104203_ = -0.43633232f + gallopLLegXRot;
                this.Abdomen.f_104204_ = 0.0f;
            } else {
                this.RightUpperLeg.f_104203_ = 0.2617994f + RLegXRot;
                this.LeftHindUpperLeg.f_104203_ = -0.43633232f + RLegXRot;
                this.LeftUpperLeg.f_104203_ = 0.2617994f + LLegXRot;
                this.RightHindUpperLeg.f_104203_ = -0.43633232f + LLegXRot;
                if (!this.hasStinger) {
                    this.Abdomen.f_104204_ = Mth.m_14089_((float)(limbSwing * 0.3f)) * 0.25f * limbSwingAmount;
                }
            }
            if (this.isRidden) {
                this.LeftFootHarness.f_104203_ = -1.0471976f;
                this.RightFootHarness.f_104203_ = -1.0471976f;
            } else {
                this.LeftFootHarness.f_104203_ = RLegXRot / 3.0f;
                this.RightFootHarness.f_104203_ = RLegXRot / 3.0f;
                this.LeftFootHarness.f_104205_ = RLegXRot / 5.0f;
                this.RightFootHarness.f_104205_ = -RLegXRot / 5.0f;
            }
            float TailXRot = Mth.m_14089_((float)(limbSwing * 0.4f)) * 0.15f * limbSwingAmount;
            this.TailRoot.f_104203_ = 1.5184364f + TailXRot;
            this.Tail2.f_104203_ = -0.5235988f + TailXRot;
            this.Tail3.f_104203_ = -0.29670596f + TailXRot;
            this.Tail4.f_104203_ = 0.36651915f + TailXRot;
            this.TailTip.f_104203_ = 0.36651915f + TailXRot;
            this.TailTusk.f_104203_ = 0.36651915f + TailXRot;
        }
        float headXRot = headPitch / 57.29578f;
        this.HeadBack.f_104203_ = 0.2443461f + headXRot;
        this.HeadBack.f_104204_ = netHeadYaw / 57.29578f;
        float targetMouthAngle = this.openMouthCounter != 0 ? (this.openMouthCounter < 10 ? 22.0f + (float)this.openMouthCounter * 3.0f : (this.openMouthCounter > 20 ? 22.0f + (90.0f - (float)this.openMouthCounter * 3.0f) : 55.0f)) : 0.0f;
        float interpolatedMouthAngle = this.prevMouthAngle + (targetMouthAngle - this.prevMouthAngle) * 0.1f;
        this.LowerJaw.f_104203_ = interpolatedMouthAngle / 57.29578f;
        this.prevMouthAngle = interpolatedMouthAngle;
        if (this.isSaddled) {
            this.LeftHarness.f_104203_ = 0.43633232f + this.HeadBack.f_104203_;
            this.LeftHarness.f_104204_ = this.HeadBack.f_104204_;
            this.RightHarness.f_104203_ = 0.43633232f + this.HeadBack.f_104203_;
            this.RightHarness.f_104204_ = this.HeadBack.f_104204_;
        }
        if (this.isFlyer) {
            float wingRot = this.flapwings ? Mth.m_14089_((float)(ageInTicks * 0.3f + (float)Math.PI)) * 1.2f : Mth.m_14089_((float)(limbSwing * 0.5f)) * 0.1f;
            if (this.floating) {
                this.OuterWing.f_104204_ = -0.3228859f + wingRot / 2.0f;
                this.OuterWingR.f_104204_ = 0.3228859f - wingRot / 2.0f;
            } else {
                wingRot = 1.0471976f;
                this.OuterWing.f_104204_ = -1.5707963f;
                this.OuterWingR.f_104204_ = 1.5707963f;
            }
            this.InnerWingR.f_104201_ = this.InnerWing.f_104201_;
            this.InnerWingR.f_104202_ = this.InnerWing.f_104202_;
            this.OuterWing.f_104200_ = this.InnerWing.f_104200_ + Mth.m_14089_((float)wingRot) * 12.0f;
            this.OuterWingR.f_104200_ = this.InnerWingR.f_104200_ - Mth.m_14089_((float)wingRot) * 12.0f;
            this.MidWing.f_104201_ = this.InnerWing.f_104201_;
            this.MidWingR.f_104201_ = this.InnerWing.f_104201_;
            this.OuterWing.f_104201_ = this.InnerWing.f_104201_ + Mth.m_14031_((float)wingRot) * 12.0f;
            this.OuterWingR.f_104201_ = this.InnerWing.f_104201_ + Mth.m_14031_((float)wingRot) * 12.0f;
            this.MidWing.f_104202_ = this.InnerWing.f_104202_;
            this.MidWingR.f_104202_ = this.InnerWing.f_104202_;
            this.OuterWing.f_104202_ = this.InnerWing.f_104202_;
            this.OuterWingR.f_104202_ = this.InnerWing.f_104202_;
            this.MidWing.f_104205_ = wingRot;
            this.InnerWing.f_104205_ = wingRot;
            this.OuterWing.f_104205_ = wingRot;
            this.InnerWingR.f_104205_ = -wingRot;
            this.MidWingR.f_104205_ = -wingRot;
            this.OuterWingR.f_104205_ = -wingRot;
            if (this.hasStinger) {
                if (!this.poisoning) {
                    this.STailRoot.f_104203_ = 0.57595867f;
                    this.STailRoot.f_104201_ = stingYOffset;
                    this.STailRoot.f_104202_ = stingZOffset;
                    this.STail2.f_104203_ = 0.9512044f;
                    this.STail2.f_104201_ = stingYOffset;
                    this.STail2.f_104202_ = stingZOffset;
                    this.STail3.f_104203_ = 1.659808f;
                    this.STail3.f_104201_ = stingYOffset;
                    this.STail3.f_104202_ = stingZOffset;
                    this.STail4.f_104203_ = 2.4748769f;
                    this.STail4.f_104201_ = stingYOffset;
                    this.STail4.f_104202_ = stingZOffset;
                    this.STail5.f_104203_ = 3.0351274f;
                    this.STail5.f_104201_ = stingYOffset;
                    this.STail5.f_104202_ = stingZOffset;
                    this.StingerLump.f_104203_ = 2.0315633f;
                    this.StingerLump.f_104201_ = stingYOffset;
                    this.StingerLump.f_104202_ = stingZOffset;
                    this.Stinger.f_104203_ = 1.2130039f;
                    this.Stinger.f_104201_ = stingYOffset;
                    this.Stinger.f_104202_ = stingZOffset;
                } else if (!this.isSitting) {
                    this.STailRoot.f_104203_ = 1.6615534f;
                    this.STailRoot.f_104201_ = 14.5f;
                    this.STailRoot.f_104202_ = 2.0f;
                    this.STail2.f_104203_ = 2.242748f;
                    this.STail2.f_104201_ = 15.0f;
                    this.STail2.f_104202_ = 4.0f;
                    this.STail3.f_104203_ = 2.9496064f;
                    this.STail3.f_104201_ = 14.0f;
                    this.STail3.f_104202_ = 3.8f;
                    this.STail4.f_104203_ = 3.0892327f;
                    this.STail4.f_104201_ = 13.5f;
                    this.STail4.f_104202_ = -8.5f;
                    this.STail5.f_104203_ = 3.1415925f;
                    this.STail5.f_104201_ = 11.5f;
                    this.STail5.f_104202_ = -17.0f;
                    this.StingerLump.f_104203_ = 0.61784655f;
                    this.StingerLump.f_104201_ = -4.0f;
                    this.StingerLump.f_104202_ = -28.0f;
                    this.Stinger.f_104203_ = 0.44505894f;
                    this.Stinger.f_104201_ = 4.0f;
                    this.Stinger.f_104202_ = -29.0f;
                }
            }
        }
    }

    public float updateGhostTransparency() {
        return 1.0f;
    }
}

