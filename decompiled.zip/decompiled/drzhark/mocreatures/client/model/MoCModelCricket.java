/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.MoCEntityAmbient;
import drzhark.mocreatures.entity.ambient.MoCEntityCricket;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelCricket<T extends MoCEntityCricket>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "cricket"), "main");
    private final ModelPart head;
    private final ModelPart antenna;
    private final ModelPart antennaB;
    private final ModelPart thorax;
    private final ModelPart abdomen;
    private final ModelPart tailA;
    private final ModelPart tailB;
    private final ModelPart frontLegs;
    private final ModelPart midLegs;
    private final ModelPart thighLeft;
    private final ModelPart thighLeftB;
    private final ModelPart thighRight;
    private final ModelPart thighRightB;
    private final ModelPart legLeft;
    private final ModelPart legLeftB;
    private final ModelPart legRight;
    private final ModelPart legRightB;
    private boolean flying;

    public MoCModelCricket(ModelPart root) {
        this.head = root.m_171324_("head");
        this.antenna = root.m_171324_("antenna");
        this.antennaB = root.m_171324_("antennaB");
        this.thorax = root.m_171324_("thorax");
        this.abdomen = root.m_171324_("abdomen");
        this.tailA = root.m_171324_("tailA");
        this.tailB = root.m_171324_("tailB");
        this.frontLegs = root.m_171324_("frontLegs");
        this.midLegs = root.m_171324_("midLegs");
        this.thighLeft = root.m_171324_("thighLeft");
        this.thighLeftB = root.m_171324_("thighLeftB");
        this.thighRight = root.m_171324_("thighRight");
        this.thighRightB = root.m_171324_("thighRightB");
        this.legLeft = root.m_171324_("legLeft");
        this.legLeftB = root.m_171324_("legLeftB");
        this.legRight = root.m_171324_("legRight");
        this.legRightB = root.m_171324_("legRightB");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        root.m_171599_("head", CubeListBuilder.m_171558_().m_171514_(0, 4).m_171481_(-0.5f, 0.0f, -1.0f, 1.0f, 1.0f, 2.0f), PartPose.m_171423_((float)0.0f, (float)22.5f, (float)-2.0f, (float)-2.171231f, (float)0.0f, (float)0.0f));
        root.m_171599_("antenna", CubeListBuilder.m_171558_().m_171514_(0, 11).m_171481_(-1.0f, 0.0f, 0.0f, 2.0f, 2.0f, 0.0f), PartPose.m_171423_((float)0.0f, (float)22.5f, (float)-3.0f, (float)-2.736346f, (float)0.0f, (float)0.0f));
        root.m_171599_("antennaB", CubeListBuilder.m_171558_().m_171514_(0, 9).m_171481_(-1.0f, 0.0f, 0.0f, 2.0f, 2.0f, 0.0f), PartPose.m_171423_((float)0.0f, (float)20.7f, (float)-3.8f, (float)2.88506f, (float)0.0f, (float)0.0f));
        root.m_171599_("thorax", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-1.0f, 0.0f, -1.0f, 2.0f, 2.0f, 2.0f), PartPose.m_171423_((float)0.0f, (float)21.0f, (float)-1.0f, (float)0.0f, (float)0.0f, (float)0.0f));
        root.m_171599_("abdomen", CubeListBuilder.m_171558_().m_171514_(8, 0).m_171481_(-1.0f, 0.0f, -1.0f, 2.0f, 3.0f, 2.0f), PartPose.m_171423_((float)0.0f, (float)22.0f, (float)0.0f, (float)1.427659f, (float)0.0f, (float)0.0f));
        root.m_171599_("tailA", CubeListBuilder.m_171558_().m_171514_(4, 9).m_171481_(-1.0f, 0.0f, 0.0f, 2.0f, 3.0f, 0.0f), PartPose.m_171423_((float)0.0f, (float)22.0f, (float)2.8f, (float)1.308687f, (float)0.0f, (float)0.0f));
        root.m_171599_("tailB", CubeListBuilder.m_171558_().m_171514_(4, 7).m_171481_(-1.0f, 0.0f, 0.0f, 2.0f, 2.0f, 0.0f), PartPose.m_171423_((float)0.0f, (float)23.0f, (float)2.8f, (float)1.665602f, (float)0.0f, (float)0.0f));
        root.m_171599_("frontLegs", CubeListBuilder.m_171558_().m_171514_(0, 7).m_171481_(-1.0f, 0.0f, 0.0f, 2.0f, 2.0f, 0.0f), PartPose.m_171423_((float)0.0f, (float)23.0f, (float)-1.8f, (float)-0.8328009f, (float)0.0f, (float)0.0f));
        root.m_171599_("midLegs", CubeListBuilder.m_171558_().m_171514_(0, 13).m_171481_(-2.0f, 0.0f, 0.0f, 4.0f, 2.0f, 0.0f), PartPose.m_171423_((float)0.0f, (float)23.0f, (float)-1.2f, (float)1.070744f, (float)0.0f, (float)0.0f));
        root.m_171599_("thighLeft", CubeListBuilder.m_171558_().m_171514_(8, 5).m_171481_(0.0f, -3.0f, 0.0f, 1.0f, 3.0f, 1.0f), PartPose.m_171423_((float)0.5f, (float)23.0f, (float)0.0f, (float)-0.4886922f, (float)0.2617994f, (float)0.0f));
        root.m_171599_("thighLeftB", CubeListBuilder.m_171558_().m_171514_(8, 5).m_171481_(0.0f, -3.0f, 0.0f, 1.0f, 3.0f, 1.0f), PartPose.m_171423_((float)0.5f, (float)22.5f, (float)0.0f, (float)-1.762782f, (float)0.0f, (float)0.0f));
        root.m_171599_("thighRight", CubeListBuilder.m_171558_().m_171514_(12, 5).m_171481_(-1.0f, -3.0f, 0.0f, 1.0f, 3.0f, 1.0f), PartPose.m_171423_((float)-0.5f, (float)23.0f, (float)0.0f, (float)-0.4886922f, (float)-0.2617994f, (float)0.0f));
        root.m_171599_("thighRightB", CubeListBuilder.m_171558_().m_171514_(12, 5).m_171481_(-1.0f, -3.0f, 0.0f, 1.0f, 3.0f, 1.0f), PartPose.m_171423_((float)-0.5f, (float)22.5f, (float)0.0f, (float)-1.762782f, (float)0.0f, (float)0.0f));
        root.m_171599_("legLeft", CubeListBuilder.m_171558_().m_171514_(0, 15).m_171481_(0.0f, 0.0f, -1.0f, 0.0f, 3.0f, 2.0f), PartPose.m_171423_((float)2.0f, (float)21.0f, (float)2.5f, (float)0.0f, (float)0.0f, (float)0.0f));
        root.m_171599_("legLeftB", CubeListBuilder.m_171558_().m_171514_(4, 15).m_171481_(0.0f, 0.0f, -1.0f, 0.0f, 3.0f, 2.0f), PartPose.m_171423_((float)1.5f, (float)23.0f, (float)2.9f, (float)1.249201f, (float)0.0f, (float)0.0f));
        root.m_171599_("legRight", CubeListBuilder.m_171558_().m_171514_(4, 15).m_171481_(0.0f, 0.0f, -1.0f, 0.0f, 3.0f, 2.0f), PartPose.m_171423_((float)-2.0f, (float)21.0f, (float)2.5f, (float)0.0f, (float)0.0f, (float)0.0f));
        root.m_171599_("legRightB", CubeListBuilder.m_171558_().m_171514_(4, 15).m_171481_(0.0f, 0.0f, -1.0f, 0.0f, 3.0f, 2.0f), PartPose.m_171423_((float)-1.5f, (float)23.0f, (float)2.9f, (float)1.249201f, (float)0.0f, (float)0.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)32, (int)32);
    }

    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float legMovB;
        float legMov;
        this.flying = ((MoCEntityAmbient)entity).getIsFlying() || entity.m_20184_().f_82480_ < -0.1;
        float frontLegAdj = 0.0f;
        if (this.flying) {
            legMovB = legMov = limbSwingAmount * 1.5f;
            frontLegAdj = 1.4f;
        } else {
            legMov = Mth.m_14089_((float)(limbSwing * 1.5f + (float)Math.PI)) * 2.0f * limbSwingAmount;
            legMovB = Mth.m_14089_((float)(limbSwing * 1.5f)) * 2.0f * limbSwingAmount;
        }
        this.antennaB.f_104203_ = 2.88506f - legMov;
        this.frontLegs.f_104203_ = -0.8328009f + frontLegAdj + legMov;
        this.midLegs.f_104203_ = 1.070744f + legMovB;
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.head.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.antenna.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.antennaB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.thorax.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.abdomen.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.tailA.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.tailB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.frontLegs.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        this.midLegs.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        if (!this.flying) {
            this.thighLeft.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.thighRight.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.legLeft.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.legRight.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        } else {
            this.thighLeftB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.thighRightB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.legLeftB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            this.legRightB.m_104306_(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
            poseStack.m_85836_();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.clearColor((float)0.8f, (float)0.8f, (float)0.8f, (float)0.6f);
            RenderSystem.disableBlend();
            poseStack.m_85849_();
        }
    }
}

