/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import drzhark.mocreatures.client.model.MoCModelAbstractScorpion;
import drzhark.mocreatures.entity.MoCEntityMob;
import drzhark.mocreatures.entity.hostile.MoCEntityScorpion;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelScorpion<T extends MoCEntityScorpion>
extends MoCModelAbstractScorpion<T> {
    public MoCModelScorpion(ModelPart root) {
        super(root);
    }

    public void prepareMobModel(T entity, float limbSwing, float limbSwingAmount, float partialTick) {
        this.poisoning = ((MoCEntityScorpion)entity).swingingTail();
        this.isAdult = ((MoCEntityMob)entity).getIsAdult();
        this.isTalking = ((MoCEntityScorpion)entity).mouthCounter != 0;
        this.babies = ((MoCEntityScorpion)entity).getHasBabies();
        this.attacking = ((MoCEntityScorpion)entity).armCounter;
    }
}

