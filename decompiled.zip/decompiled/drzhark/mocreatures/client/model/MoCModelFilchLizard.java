/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeDeformation
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import drzhark.mocreatures.entity.passive.MoCEntityFilchLizard;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelFilchLizard<T extends MoCEntityFilchLizard>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "filchlizard"), "main");
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart tail;
    private final ModelPart leg1;
    private final ModelPart leg2;
    private final ModelPart leg3;
    private final ModelPart leg4;
    private final ModelPart foldHead;
    private final ModelPart foldFilch1;
    private final ModelPart foldFilch2;
    private final ModelPart filch1;
    private final ModelPart filch2;
    private final ModelPart filch3;
    private final ModelPart filch4;
    private final ModelPart filch5;
    private final ModelPart filch6;
    private boolean heldItem;

    public MoCModelFilchLizard(ModelPart root) {
        this.body = root.m_171324_("body");
        this.tail = root.m_171324_("tail");
        this.leg1 = root.m_171324_("leg1");
        this.leg2 = root.m_171324_("leg2");
        this.leg3 = root.m_171324_("leg3");
        this.leg4 = root.m_171324_("leg4");
        this.foldHead = root.m_171324_("fold_head");
        this.foldFilch1 = root.m_171324_("fold_filch1");
        this.foldFilch2 = root.m_171324_("fold_filch2");
        this.head = root.m_171324_("head");
        this.filch1 = this.head.m_171324_("filch1");
        this.filch2 = this.head.m_171324_("filch2");
        this.filch3 = this.head.m_171324_("filch3");
        this.filch4 = this.head.m_171324_("filch4");
        this.filch5 = this.head.m_171324_("filch5");
        this.filch6 = this.head.m_171324_("filch6");
    }

    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        boolean bl = this.heldItem = !entity.m_21205_().m_41619_();
        if (this.heldItem) {
            this.leg1.m_104227_(-2.0f, 13.0f, -1.0f);
            this.leg1.f_104203_ = 0.0f;
            this.leg1.f_104204_ = 1.047198f;
            this.leg1.f_104205_ = 0.6981317f;
            this.leg2.m_104227_(2.0f, 13.0f, -1.0f);
            this.leg2.f_104203_ = 0.0f;
            this.leg2.f_104204_ = -1.047198f;
            this.leg2.f_104205_ = -0.6981317f;
            this.leg3.m_104227_(2.0f, 20.0f, 5.0f);
            this.leg3.f_104203_ = 0.0f;
            this.leg3.f_104204_ = 0.0f;
            this.leg3.f_104205_ = 1.396263f;
            this.leg4.m_104227_(-2.0f, 20.0f, 5.0f);
            this.leg4.f_104203_ = 0.0f;
            this.leg4.f_104204_ = 0.0f;
            this.leg4.f_104205_ = -1.396263f;
            this.body.m_104227_(0.0f, 16.0f, 2.0f);
            this.body.f_104203_ = -0.9948377f;
            this.body.f_104204_ = 0.0f;
            this.body.f_104205_ = 0.0f;
            this.tail.m_104227_(0.0f, 20.0f, 6.0f);
            this.tail.f_104203_ = 0.6806784f;
            this.tail.f_104204_ = 0.0f;
            this.tail.f_104205_ = 0.0f;
            this.head.f_104203_ = headPitch * ((float)Math.PI / 180);
            this.head.f_104204_ = netHeadYaw * ((float)Math.PI / 180);
            this.head.f_104205_ = 0.0f;
        } else {
            this.leg1.m_104227_(2.0f, 22.0f, -4.0f);
            this.leg1.f_104203_ = 0.0f;
            this.leg1.f_104204_ = 0.0f;
            this.leg1.f_104205_ = 0.3839724f;
            this.leg2.m_104227_(-2.0f, 22.0f, -4.0f);
            this.leg2.f_104203_ = 0.0f;
            this.leg2.f_104204_ = 0.0f;
            this.leg2.f_104205_ = -0.3839724f;
            this.leg3.m_104227_(2.0f, 22.0f, 5.0f);
            this.leg3.f_104203_ = 0.0f;
            this.leg3.f_104204_ = 0.0f;
            this.leg3.f_104205_ = 0.3839724f;
            this.leg4.m_104227_(-2.0f, 22.0f, 5.0f);
            this.leg4.f_104203_ = 0.0f;
            this.leg4.f_104204_ = 0.0f;
            this.leg4.f_104205_ = -0.3839724f;
            this.body.m_104227_(0.0f, 21.0f, 0.0f);
            this.body.f_104203_ = 0.0f;
            this.body.f_104204_ = 0.0f;
            this.body.f_104205_ = 0.0f;
            this.tail.m_104227_(0.0f, 21.0f, 6.0f);
            this.tail.f_104203_ = 0.0f;
            this.tail.f_104204_ = 0.0f;
            this.tail.f_104205_ = 0.0f;
            this.leg1.f_104204_ = Mth.m_14089_((float)(limbSwing * 0.6662f * 2.0f + (float)Math.PI)) * 0.6f * limbSwingAmount;
            this.leg2.f_104204_ = -Mth.m_14089_((float)(limbSwing * 0.6662f * 2.0f + (float)Math.PI)) * 0.6f * limbSwingAmount;
            this.foldHead.f_104203_ = headPitch * ((float)Math.PI / 180);
            this.foldHead.f_104204_ = netHeadYaw * ((float)Math.PI / 180);
            this.foldHead.f_104205_ = 0.0f;
        }
        this.leg3.f_104204_ = Mth.m_14089_((float)(limbSwing * 0.6662f * 2.0f + (float)Math.PI)) * 0.6f * limbSwingAmount;
        this.leg4.f_104204_ = Mth.m_14089_((float)(limbSwing * 0.6662f * 2.0f + (float)Math.PI)) * 0.6f * limbSwingAmount;
        this.tail.f_104204_ = -Mth.m_14089_((float)(limbSwing * 0.6662f * 2.0f + (float)Math.PI)) * 0.2f * limbSwingAmount;
    }

    public void m_7695_(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        if (this.heldItem) {
            this.head.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        } else {
            this.foldHead.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
            this.foldFilch1.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
            this.foldFilch2.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        }
        this.body.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.tail.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg1.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg2.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg3.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leg4.m_104306_(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        root.m_171599_("body", CubeListBuilder.m_171558_().m_171514_(0, 6).m_171488_(-2.0f, -1.5f, -6.0f, 4.0f, 3.0f, 12.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)21.0f, (float)0.0f));
        root.m_171599_("tail", CubeListBuilder.m_171558_().m_171514_(32, 9).m_171488_(-1.0f, -0.5f, 0.0f, 2.0f, 2.0f, 10.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)21.0f, (float)6.0f));
        root.m_171599_("leg1", CubeListBuilder.m_171558_().m_171514_(16, 0).m_171488_(0.0f, -0.5f, -0.5f, 4.0f, 1.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)2.0f, (float)22.0f, (float)-4.0f));
        root.m_171599_("leg2", CubeListBuilder.m_171558_().m_171514_(16, 3).m_171488_(-4.0f, -0.5f, -0.5f, 4.0f, 1.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-2.0f, (float)22.0f, (float)-4.0f));
        root.m_171599_("leg3", CubeListBuilder.m_171558_().m_171514_(16, 0).m_171488_(0.0f, -0.5f, -0.5f, 4.0f, 1.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)2.0f, (float)22.0f, (float)5.0f));
        root.m_171599_("leg4", CubeListBuilder.m_171558_().m_171514_(16, 3).m_171488_(-4.0f, -0.5f, -0.5f, 4.0f, 1.0f, 1.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)-2.0f, (float)22.0f, (float)5.0f));
        root.m_171599_("fold_filch1", CubeListBuilder.m_171558_().m_171514_(0, 22).m_171488_(1.0f, -1.5f, 0.0f, 1.0f, 3.0f, 6.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)21.0f, (float)-6.0f, (float)0.0f, (float)0.0349066f, (float)0.0f));
        root.m_171599_("fold_filch2", CubeListBuilder.m_171558_().m_171514_(14, 22).m_171488_(-2.0f, -1.5f, 0.0f, 1.0f, 3.0f, 6.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)21.0f, (float)-6.0f, (float)0.0f, (float)-0.0349066f, (float)0.0f));
        root.m_171599_("fold_head", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-2.0f, -0.5f, -4.0f, 4.0f, 2.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)21.0f, (float)-6.0f));
        PartDefinition headPart = root.m_171599_("head", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171488_(-2.0f, -2.5f, -4.0f, 4.0f, 2.0f, 4.0f, new CubeDeformation(0.0f)), PartPose.m_171419_((float)0.0f, (float)12.0f, (float)-1.0f));
        headPart.m_171599_("filch1", CubeListBuilder.m_171558_().m_171514_(0, 22).m_171488_(0.0f, -2.5f, 2.5f, 1.0f, 3.0f, 6.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)0.3665191f, (float)1.570796f, (float)-0.296706f));
        headPart.m_171599_("filch2", CubeListBuilder.m_171558_().m_171514_(14, 22).m_171488_(-1.0f, -2.5f, 2.5f, 1.0f, 3.0f, 6.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)0.3665191f, (float)-1.570796f, (float)0.296706f));
        headPart.m_171599_("filch3", CubeListBuilder.m_171558_().m_171514_(0, 22).m_171488_(-0.5f, -2.5f, 2.0f, 1.0f, 3.0f, 6.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)1.570796f, (float)-0.2617994f));
        headPart.m_171599_("filch4", CubeListBuilder.m_171558_().m_171514_(14, 22).m_171488_(-0.5f, -2.5f, 2.0f, 1.0f, 3.0f, 6.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-1.570796f, (float)0.2617994f));
        headPart.m_171599_("filch5", CubeListBuilder.m_171558_().m_171514_(0, 22).m_171488_(-1.0f, -2.5f, 1.5f, 1.0f, 3.0f, 6.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)-0.3839724f, (float)1.570796f, (float)-0.2617994f));
        headPart.m_171599_("filch6", CubeListBuilder.m_171558_().m_171514_(14, 22).m_171488_(0.0f, -2.5f, 1.5f, 1.0f, 3.0f, 6.0f, new CubeDeformation(0.0f)), PartPose.m_171423_((float)0.0f, (float)0.0f, (float)0.0f, (float)-0.4014257f, (float)-1.570796f, (float)0.2617994f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)64, (int)32);
    }
}

