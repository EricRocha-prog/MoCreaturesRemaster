/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager$DestFactor
 *  com.mojang.blaze3d.platform.GlStateManager$SourceFactor
 *  com.mojang.blaze3d.systems.RenderSystem
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  com.mojang.math.Axis
 *  net.minecraft.client.model.EntityModel
 *  net.minecraft.client.model.geom.ModelLayerLocation
 *  net.minecraft.client.model.geom.ModelPart
 *  net.minecraft.client.model.geom.PartPose
 *  net.minecraft.client.model.geom.builders.CubeListBuilder
 *  net.minecraft.client.model.geom.builders.LayerDefinition
 *  net.minecraft.client.model.geom.builders.MeshDefinition
 *  net.minecraft.client.model.geom.builders.PartDefinition
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.client.model;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import drzhark.mocreatures.entity.aquatic.MoCEntityJellyFish;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(value=Dist.CLIENT)
public class MoCModelJellyFish<T extends MoCEntityJellyFish>
extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("mocreatures", "jellyfish"), "main");
    protected final ModelPart Top;
    protected final ModelPart Head;
    protected final ModelPart HeadSmall;
    protected final ModelPart Body;
    protected final ModelPart BodyCenter;
    protected final ModelPart BodyBottom;
    protected final ModelPart Side1;
    protected final ModelPart Side2;
    protected final ModelPart Side3;
    protected final ModelPart Side4;
    protected final ModelPart LegSmall1;
    protected final ModelPart LegC1;
    protected final ModelPart LegC2;
    protected final ModelPart LegC3;
    protected final ModelPart Leg1;
    protected final ModelPart Leg2;
    protected final ModelPart Leg3;
    protected final ModelPart Leg4;
    protected final ModelPart Leg5;
    protected final ModelPart Leg6;
    protected final ModelPart Leg7;
    protected final ModelPart Leg8;
    protected final ModelPart Leg9;
    private boolean glowing;
    private boolean outOfWater;
    private float limbSwingAmount;

    public MoCModelJellyFish(ModelPart root) {
        this.Top = root.m_171324_("Top");
        this.Head = root.m_171324_("Head");
        this.HeadSmall = root.m_171324_("HeadSmall");
        this.Body = root.m_171324_("Body");
        this.BodyCenter = root.m_171324_("BodyCenter");
        this.BodyBottom = root.m_171324_("BodyBottom");
        this.Side1 = root.m_171324_("Side1");
        this.Side2 = root.m_171324_("Side2");
        this.Side3 = root.m_171324_("Side3");
        this.Side4 = root.m_171324_("Side4");
        this.LegSmall1 = root.m_171324_("LegSmall1");
        this.LegC1 = root.m_171324_("LegC1");
        this.LegC2 = root.m_171324_("LegC2");
        this.LegC3 = root.m_171324_("LegC3");
        this.Leg1 = root.m_171324_("Leg1");
        this.Leg2 = root.m_171324_("Leg2");
        this.Leg3 = root.m_171324_("Leg3");
        this.Leg4 = root.m_171324_("Leg4");
        this.Leg5 = root.m_171324_("Leg5");
        this.Leg6 = root.m_171324_("Leg6");
        this.Leg7 = root.m_171324_("Leg7");
        this.Leg8 = root.m_171324_("Leg8");
        this.Leg9 = root.m_171324_("Leg9");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.m_171576_();
        root.m_171599_("Top", CubeListBuilder.m_171558_().m_171514_(0, 10).m_171481_(-2.5f, 0.0f, -2.5f, 5.0f, 1.0f, 5.0f), PartPose.m_171419_((float)0.0f, (float)11.0f, (float)0.0f));
        root.m_171599_("Head", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-4.0f, 0.0f, -4.0f, 8.0f, 2.0f, 8.0f), PartPose.m_171419_((float)0.0f, (float)12.0f, (float)0.0f));
        root.m_171599_("HeadSmall", CubeListBuilder.m_171558_().m_171514_(24, 0).m_171481_(-2.0f, 0.0f, -2.0f, 4.0f, 3.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)12.5f, (float)0.0f));
        root.m_171599_("Body", CubeListBuilder.m_171558_().m_171514_(36, 0).m_171481_(-3.5f, 0.0f, -3.5f, 7.0f, 7.0f, 7.0f), PartPose.m_171419_((float)0.0f, (float)13.8f, (float)0.0f));
        root.m_171599_("BodyCenter", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-1.0f, 0.0f, -1.0f, 2.0f, 3.0f, 2.0f), PartPose.m_171419_((float)0.0f, (float)15.5f, (float)0.0f));
        root.m_171599_("BodyBottom", CubeListBuilder.m_171558_().m_171514_(20, 10).m_171481_(-2.0f, 0.0f, -2.0f, 4.0f, 2.0f, 4.0f), PartPose.m_171419_((float)0.0f, (float)18.3f, (float)0.0f));
        root.m_171599_("Side1", CubeListBuilder.m_171558_().m_171514_(20, 10).m_171481_(-2.0f, 5.0f, 0.0f, 4.0f, 2.0f, 4.0f), PartPose.m_171423_((float)0.0f, (float)12.5f, (float)0.0f, (float)-0.7679449f, (float)0.0f, (float)0.0f));
        root.m_171599_("Side2", CubeListBuilder.m_171558_().m_171514_(20, 10).m_171481_(-4.0f, 5.0f, -2.0f, 4.0f, 2.0f, 4.0f), PartPose.m_171423_((float)0.0f, (float)12.5f, (float)0.0f, (float)0.0f, (float)0.0f, (float)-0.7679449f));
        root.m_171599_("Side3", CubeListBuilder.m_171558_().m_171514_(20, 10).m_171481_(0.0f, 5.0f, -2.0f, 4.0f, 2.0f, 4.0f), PartPose.m_171423_((float)0.0f, (float)12.5f, (float)0.0f, (float)0.0f, (float)0.0f, (float)0.7679449f));
        root.m_171599_("Side4", CubeListBuilder.m_171558_().m_171514_(20, 10).m_171481_(-2.0f, 5.0f, -4.0f, 4.0f, 2.0f, 4.0f), PartPose.m_171423_((float)0.0f, (float)12.5f, (float)0.0f, (float)0.7679449f, (float)0.0f, (float)0.0f));
        root.m_171599_("LegSmall1", CubeListBuilder.m_171558_().m_171514_(60, 2).m_171481_(-1.0f, 0.0f, -1.0f, 1.0f, 3.0f, 1.0f), PartPose.m_171419_((float)0.0f, (float)18.5f, (float)0.0f));
        root.m_171599_("LegC1", CubeListBuilder.m_171558_().m_171514_(15, 10).m_171481_(-1.0f, 0.0f, -1.0f, 1.0f, 4.0f, 1.0f), PartPose.m_171423_((float)-0.5f, (float)15.5f, (float)-0.5f, (float)-0.2602503f, (float)0.0f, (float)0.1487144f));
        root.m_171599_("LegC2", CubeListBuilder.m_171558_().m_171514_(15, 10).m_171481_(-1.0f, 0.0f, 0.0f, 1.0f, 4.0f, 1.0f), PartPose.m_171423_((float)0.5f, (float)15.5f, (float)-0.5f, (float)0.1487144f, (float)1.747395f, (float)0.0f));
        root.m_171599_("LegC3", CubeListBuilder.m_171558_().m_171514_(15, 10).m_171481_(-1.0f, 0.0f, 0.0f, 1.0f, 4.0f, 1.0f), PartPose.m_171423_((float)-0.5f, (float)15.5f, (float)0.5f, (float)0.1115358f, (float)0.3717861f, (float)0.2230717f));
        root.m_171599_("Leg1", CubeListBuilder.m_171558_().m_171514_(0, 10).m_171481_(-0.5f, 0.0f, -0.5f, 1.0f, 4.0f, 1.0f), PartPose.m_171419_((float)0.0f, (float)20.0f, (float)2.5f));
        root.m_171599_("Leg2", CubeListBuilder.m_171558_().m_171514_(0, 10).m_171481_(-0.5f, 0.0f, -0.5f, 1.0f, 4.0f, 1.0f), PartPose.m_171419_((float)0.0f, (float)20.0f, (float)-2.5f));
        root.m_171599_("Leg3", CubeListBuilder.m_171558_().m_171514_(0, 10).m_171481_(-0.5f, 0.0f, -0.5f, 1.0f, 4.0f, 1.0f), PartPose.m_171419_((float)2.5f, (float)20.0f, (float)0.0f));
        root.m_171599_("Leg4", CubeListBuilder.m_171558_().m_171514_(0, 10).m_171481_(-0.5f, 0.0f, -0.5f, 1.0f, 4.0f, 1.0f), PartPose.m_171419_((float)-2.5f, (float)20.0f, (float)0.0f));
        root.m_171599_("Leg5", CubeListBuilder.m_171558_().m_171514_(0, 10).m_171481_(-0.5f, 0.0f, -0.5f, 1.0f, 4.0f, 1.0f), PartPose.m_171423_((float)2.0f, (float)20.0f, (float)2.0f, (float)0.0f, (float)0.7853982f, (float)0.0f));
        root.m_171599_("Leg6", CubeListBuilder.m_171558_().m_171514_(0, 10).m_171481_(-0.5f, 0.0f, -0.5f, 1.0f, 4.0f, 1.0f), PartPose.m_171423_((float)2.0f, (float)20.0f, (float)-2.0f, (float)0.0f, (float)0.7853982f, (float)0.0f));
        root.m_171599_("Leg7", CubeListBuilder.m_171558_().m_171514_(0, 10).m_171481_(-0.5f, 0.0f, -0.5f, 1.0f, 4.0f, 1.0f), PartPose.m_171423_((float)-2.0f, (float)20.0f, (float)-2.0f, (float)0.0f, (float)0.7853982f, (float)0.0f));
        root.m_171599_("Leg8", CubeListBuilder.m_171558_().m_171514_(60, 0).m_171481_(0.0f, 0.0f, 0.0f, 1.0f, 5.0f, 1.0f), PartPose.m_171419_((float)0.0f, (float)18.5f, (float)0.0f));
        root.m_171599_("Leg9", CubeListBuilder.m_171558_().m_171514_(0, 10).m_171481_(-0.5f, 0.0f, -0.5f, 1.0f, 4.0f, 1.0f), PartPose.m_171423_((float)-2.0f, (float)20.0f, (float)2.0f, (float)0.0f, (float)0.7853982f, (float)0.0f));
        return LayerDefinition.m_171565_((MeshDefinition)mesh, (int)64, (int)16);
    }

    public void setupAnim(T entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.glowing = ((MoCEntityJellyFish)entityIn).isGlowing();
        this.outOfWater = !entityIn.m_20069_();
        this.limbSwingAmount = limbSwingAmount;
    }

    public void m_7695_(PoseStack matrixStackIn, VertexConsumer bufferIn, int packedLightIn, int packedOverlayIn, float red, float green, float blue, float alpha) {
        matrixStackIn.m_85836_();
        if (this.outOfWater) {
            matrixStackIn.m_252880_(0.0f, 0.6f, -0.3f);
        } else {
            matrixStackIn.m_252880_(0.0f, 0.2f, 0.0f);
            matrixStackIn.m_252781_(Axis.f_252529_.m_252977_(this.limbSwingAmount * -60.0f));
        }
        RenderSystem.enableBlend();
        if (!this.glowing || this.outOfWater) {
            float transparency = 0.7f;
            RenderSystem.defaultBlendFunc();
            RenderSystem.clearColor((float)0.8f, (float)0.8f, (float)0.8f, (float)transparency);
        } else {
            RenderSystem.blendFunc((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE);
        }
        this.Top.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        this.Head.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        this.HeadSmall.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        this.Body.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        this.BodyCenter.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        this.BodyBottom.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        this.Side1.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        this.Side2.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        this.Side3.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        this.Side4.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        this.LegSmall1.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        this.LegC1.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        this.LegC2.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        this.LegC3.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        this.Leg1.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        this.Leg2.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        this.Leg3.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        this.Leg4.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        this.Leg5.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        this.Leg6.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        this.Leg7.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        this.Leg8.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        this.Leg9.m_104306_(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        RenderSystem.disableBlend();
        matrixStackIn.m_85849_();
    }
}

