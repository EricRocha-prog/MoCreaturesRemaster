/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.Mob
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraftforge.common.ForgeSpawnEggItem
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber$Bus
 *  net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent
 *  net.minecraftforge.registries.DeferredRegister
 *  net.minecraftforge.registries.ForgeRegistries
 *  net.minecraftforge.registries.IForgeRegistry
 *  net.minecraftforge.registries.RegistryObject
 */
package drzhark.mocreatures.init;

import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.init.MoCEntities;
import java.util.function.Supplier;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.RegistryObject;

@Mod.EventBusSubscriber(modid="mocreatures", bus=Mod.EventBusSubscriber.Bus.MOD)
public class MoCSpawnEggs {
    public static final DeferredRegister<Item> SPAWN_EGGS = DeferredRegister.create((IForgeRegistry)ForgeRegistries.ITEMS, (String)"mocreatures");
    public static final RegistryObject<Item> BIRD_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("bird", () -> (EntityType)MoCEntities.BIRD.get(), 37109, 4609629);
    public static final RegistryObject<Item> BLACK_BEAR_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("blackbear", () -> (EntityType)MoCEntities.BLACK_BEAR.get(), 986897, 8609347);
    public static final RegistryObject<Item> BOAR_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("boar", () -> (EntityType)MoCEntities.BOAR.get(), 2037783, 4995892);
    public static final RegistryObject<Item> BUNNY_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("bunny", () -> (EntityType)MoCEntities.BUNNY.get(), 8741934, 14527570);
    public static final RegistryObject<Item> CROCODILE_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("crocodile", () -> (EntityType)MoCEntities.CROCODILE.get(), 2698525, 10720356);
    public static final RegistryObject<Item> DUCK_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("duck", () -> (EntityType)MoCEntities.DUCK.get(), 3161353, 14011565);
    public static final RegistryObject<Item> DEER_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("deer", () -> (EntityType)MoCEntities.DEER.get(), 11572843, 13752020);
    public static final RegistryObject<Item> ELEPHANT_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("elephant", () -> (EntityType)MoCEntities.ELEPHANT.get(), 4274216, 9337176);
    public static final RegistryObject<Item> ENT_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("ent", () -> (EntityType)MoCEntities.ENT.get(), 9794886, 5800509);
    public static final RegistryObject<Item> FILCHLIZARD_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("filchlizard", () -> (EntityType)MoCEntities.FILCH_LIZARD.get(), 9930060, 5580310);
    public static final RegistryObject<Item> FOX_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("fox", () -> (EntityType)MoCEntities.FOX.get(), 15966491, 4009236);
    public static final RegistryObject<Item> GOAT_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("goat", () -> (EntityType)MoCEntities.GOAT.get(), 15262682, 4404517);
    public static final RegistryObject<Item> GRIZZLYBEAR_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("grizzlybear", () -> (EntityType)MoCEntities.GRIZZLY_BEAR.get(), 3547151, 11371099);
    public static final RegistryObject<Item> KITTY_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("kitty", () -> (EntityType)MoCEntities.KITTY.get(), 16707009, 14861419);
    public static final RegistryObject<Item> KOMODODRAGON_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("komododragon", () -> (EntityType)MoCEntities.KOMODO_DRAGON.get(), 8615512, 3025185);
    public static final RegistryObject<Item> LEOGER_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("leoger", () -> (EntityType)MoCEntities.LEOGER.get(), 13274957, 6638124);
    public static final RegistryObject<Item> LEOPARD_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("leopard", () -> (EntityType)MoCEntities.LEOPARD.get(), 13478009, 3682085);
    public static final RegistryObject<Item> LIARD_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("liard", () -> (EntityType)MoCEntities.LIARD.get(), 11965543, 8215850);
    public static final RegistryObject<Item> LION_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("lion", () -> (EntityType)MoCEntities.LION.get(), 11503958, 2234383);
    public static final RegistryObject<Item> LIGER_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("liger", () -> (EntityType)MoCEntities.LIGER.get(), 13347170, 9068088);
    public static final RegistryObject<Item> LITHER_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("lither", () -> (EntityType)MoCEntities.LITHER.get(), 0x221A11, 7821878);
    public static final RegistryObject<Item> MOLE_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("mole", () -> (EntityType)MoCEntities.MOLE.get(), 263173, 10646113);
    public static final RegistryObject<Item> MOUSE_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("mouse", () -> (EntityType)MoCEntities.MOUSE.get(), 7428164, 0xECAAAA);
    public static final RegistryObject<Item> OSTRICH_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("ostrich", () -> (EntityType)MoCEntities.OSTRICH.get(), 12884106, 10646377);
    public static final RegistryObject<Item> PANDABEAR_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("pandabear", () -> (EntityType)MoCEntities.PANDA_BEAR.get(), 13354393, 789516);
    public static final RegistryObject<Item> PANTHARD_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("panthard", () -> (EntityType)MoCEntities.PANTHARD.get(), 591108, 9005068);
    public static final RegistryObject<Item> PANTHER_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("panther", () -> (EntityType)MoCEntities.PANTHER.get(), 1709584, 16768078);
    public static final RegistryObject<Item> PANTHGER_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("panthger", () -> (EntityType)MoCEntities.PANTHGER.get(), 2826517, 14348086);
    public static final RegistryObject<Item> WILDPOLARBEAR_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("wildpolarbear", () -> (EntityType)MoCEntities.POLAR_BEAR.get(), 15131867, 11380879);
    public static final RegistryObject<Item> RACCOON_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("raccoon", () -> (EntityType)MoCEntities.RACCOON.get(), 6115913, 0x181411);
    public static final RegistryObject<Item> SNAKE_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("snake", () -> (EntityType)MoCEntities.SNAKE.get(), 670976, 11309312);
    public static final RegistryObject<Item> TIGER_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("tiger", () -> (EntityType)MoCEntities.TIGER.get(), 12476160, 2956299);
    public static final RegistryObject<Item> TURTLE_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("turtle", () -> (EntityType)MoCEntities.TURTLE.get(), 6505237, 10524955);
    public static final RegistryObject<Item> TURKEY_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("turkey", () -> (EntityType)MoCEntities.TURKEY.get(), 12268098, 0x6AADDA);
    public static final RegistryObject<Item> WILDHORSE_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("wildhorse", () -> (EntityType)MoCEntities.WILDHORSE.get(), 9204829, 11379712);
    public static final RegistryObject<Item> WYVERN_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("wyvern", () -> (EntityType)MoCEntities.WYVERN.get(), 11440923, 15526339);
    public static final RegistryObject<Item> CAVEOGRE_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("caveogre", () -> (EntityType)MoCEntities.CAVE_OGRE.get(), 5079480, 0xBFFAFF);
    public static final RegistryObject<Item> FIREOGRE_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("fireogre", () -> (EntityType)MoCEntities.FIRE_OGRE.get(), 0x900C00, 14336256);
    public static final RegistryObject<Item> FLAMEWRAITH_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("flamewraith", () -> (EntityType)MoCEntities.FLAME_WRAITH.get(), 0x1000000, 16744064);
    public static final RegistryObject<Item> BIGGOLEM_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("biggolem", () -> (EntityType)MoCEntities.BIG_GOLEM.get(), 0x4A4A4A, 52411);
    public static final RegistryObject<Item> GREENOGRE_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("greenogre", () -> (EntityType)MoCEntities.GREEN_OGRE.get(), 0x333333, 6553856);
    public static final RegistryObject<Item> HORSEMOB_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("horsemob", () -> (EntityType)MoCEntities.HORSE_MOB.get(), 0x2A2A2A, 10579012);
    public static final RegistryObject<Item> HELLRAT_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("hellrat", () -> (EntityType)MoCEntities.HELL_RAT.get(), 5064201, 10354944);
    public static final RegistryObject<Item> DARKMANTICORE_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("darkmanticore", () -> (EntityType)MoCEntities.DARK_MANTICORE.get(), 0x323232, 657930);
    public static final RegistryObject<Item> FIREMANTICORE_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("firemanticore", () -> (EntityType)MoCEntities.FIRE_MANTICORE.get(), 7148552, 2819585);
    public static final RegistryObject<Item> FROSTMANTICORE_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("frostmanticore", () -> (EntityType)MoCEntities.FROST_MANTICORE.get(), 3559006, 2041389);
    public static final RegistryObject<Item> PLAINMANTICORE_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("plainmanticore", () -> (EntityType)MoCEntities.PLAIN_MANTICORE.get(), 7623465, 5510656);
    public static final RegistryObject<Item> TOXICMANTICORE_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("toxicmanticore", () -> (EntityType)MoCEntities.TOXIC_MANTICORE.get(), 6252034, 3365689);
    public static final RegistryObject<Item> MINIGOLEM_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("minigolem", () -> (EntityType)MoCEntities.MINI_GOLEM.get(), 4734789, 0xC2C2C2);
    public static final RegistryObject<Item> RAT_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("rat", () -> (EntityType)MoCEntities.RAT.get(), 3685435, 15838633);
    public static final RegistryObject<Item> CAVESCORPION_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("cavescorpion", () -> (EntityType)MoCEntities.CAVE_SCORPION.get(), 0x323232, 855309);
    public static final RegistryObject<Item> DIRTSCORPION_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("dirtscorpion", () -> (EntityType)MoCEntities.DIRT_SCORPION.get(), 6838816, 855309);
    public static final RegistryObject<Item> FIRESCORPION_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("firescorpion", () -> (EntityType)MoCEntities.FIRE_SCORPION.get(), 0xFF0000, 855309);
    public static final RegistryObject<Item> FROSTSCORPION_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("frostscorpion", () -> (EntityType)MoCEntities.FROST_SCORPION.get(), 0xC0C0C0, 855309);
    public static final RegistryObject<Item> UNDEADSCORPION_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("undeadscorpion", () -> (EntityType)MoCEntities.UNDEAD_SCORPION.get(), 0x1A1A1A, 855309);
    public static final RegistryObject<Item> SILVERSKELETON_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("silverskeleton", () -> (EntityType)MoCEntities.SILVER_SKELETON.get(), 0xD3D3D3, 0xEEEEEE);
    public static final RegistryObject<Item> WEREWOLF_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("werewolf", () -> (EntityType)MoCEntities.WEREWOLF.get(), 7631459, 0xDBDBDB);
    public static final RegistryObject<Item> WRAITH_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("wraith", () -> (EntityType)MoCEntities.WRAITH.get(), 2764582, 0xB0B0B0);
    public static final RegistryObject<Item> WWOLF_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("wwolf", () -> (EntityType)MoCEntities.WWOLF.get(), 0x4A4A4A, 9996056);
    public static final RegistryObject<Item> ANCHOVY_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("anchovy", () -> (EntityType)MoCEntities.ANCHOVY.get(), 7039838, 12763545);
    public static final RegistryObject<Item> ANGELFISH_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("angelfish", () -> (EntityType)MoCEntities.ANGELFISH.get(), 0xB7B7B7, 15970609);
    public static final RegistryObject<Item> ANGLER_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("angler", () -> (EntityType)MoCEntities.ANGLER.get(), 2961195, 11972077);
    public static final RegistryObject<Item> CLOWNFISH_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("clownfish", () -> (EntityType)MoCEntities.CLOWNFISH.get(), 16439491, 15425029);
    public static final RegistryObject<Item> GOLDFISH_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("goldfish", () -> (EntityType)MoCEntities.GOLDFISH.get(), 0xFF9900, 0xFFFF00);
    public static final RegistryObject<Item> HIPPOTANG_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("hippotang", () -> (EntityType)MoCEntities.HIPPOTANG.get(), 4280267, 12893441);
    public static final RegistryObject<Item> MANDERIN_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("manderin", () -> (EntityType)MoCEntities.MANDERIN.get(), 14764801, 5935359);
    public static final RegistryObject<Item> BASS_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("bass", () -> (EntityType)MoCEntities.BASS.get(), 5854242, 0x999901);
    public static final RegistryObject<Item> COD_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("cod", () -> (EntityType)MoCEntities.COD.get(), 8355712, 0xB9B000);
    public static final RegistryObject<Item> SALMON_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("salmon", () -> (EntityType)MoCEntities.SALMON.get(), 10489616, 951424);
    public static final RegistryObject<Item> DOLPHIN_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("dolphin", () -> (EntityType)MoCEntities.DOLPHIN.get(), 4086148, 11251396);
    public static final RegistryObject<Item> MANTARAY_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("mantaray", () -> (EntityType)MoCEntities.MANTA_RAY.get(), 592137, 0x252525);
    public static final RegistryObject<Item> SHARK_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("shark", () -> (EntityType)MoCEntities.SHARK.get(), 3817558, 11580358);
    public static final RegistryObject<Item> STINGRAY_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("stingray", () -> (EntityType)MoCEntities.STING_RAY.get(), 6770509, 13947080);
    public static final RegistryObject<Item> FISHY_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("fishy", () -> (EntityType)MoCEntities.FISHY.get(), 16684800, 0xCC3300);
    public static final RegistryObject<Item> JELLYFISH_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("jellyfish", () -> (EntityType)MoCEntities.JELLYFISH.get(), 0x373737, 0x999901);
    public static final RegistryObject<Item> PIRANHA_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("piranha", () -> (EntityType)MoCEntities.PIRANHA.get(), 16684800, 0xC80000);
    public static final RegistryObject<Item> ANT_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("ant", () -> (EntityType)MoCEntities.ANT.get(), 5915945, 2693905);
    public static final RegistryObject<Item> BEE_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("bee", () -> (EntityType)MoCEntities.BEE.get(), 15912747, 526604);
    public static final RegistryObject<Item> BUTTERFLY_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("butterfly", () -> (EntityType)MoCEntities.BUTTERFLY.get(), 15912747, 526604);
    public static final RegistryObject<Item> CRAB_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("crab", () -> (EntityType)MoCEntities.CRAB.get(), 11880978, 15514213);
    public static final RegistryObject<Item> CRICKET_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("cricket", () -> (EntityType)MoCEntities.CRICKET.get(), 0x191919, 0x636363);
    public static final RegistryObject<Item> DRAGONFLY_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("dragonfly", () -> (EntityType)MoCEntities.DRAGONFLY.get(), 0x232323, 0x7D7D7D);
    public static final RegistryObject<Item> FIREFLY_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("firefly", () -> (EntityType)MoCEntities.FIREFLY.get(), 0xF2F000, 0x141400);
    public static final RegistryObject<Item> FLY_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("fly", () -> (EntityType)MoCEntities.FLY.get(), 0x191919, 0x636363);
    public static final RegistryObject<Item> GRASSHOPPER_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("grasshopper", () -> (EntityType)MoCEntities.GRASSHOPPER.get(), 7830593, 3747075);
    public static final RegistryObject<Item> MAGGOT_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("maggot", () -> (EntityType)MoCEntities.MAGGOT.get(), 0xE0E0E0, 0xFFFFFF);
    public static final RegistryObject<Item> ROACH_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("roach", () -> (EntityType)MoCEntities.ROACH.get(), 0x191919, 0x636363);
    public static final RegistryObject<Item> SNAIL_SPAWN_EGG = MoCSpawnEggs.registerSpawnEgg("snail", () -> (EntityType)MoCEntities.SNAIL.get(), 0x838383, 0xEEEEEE);

    private static RegistryObject<Item> registerSpawnEgg(String entityName, Supplier<EntityType<? extends Mob>> entityTypeSupplier, int primaryColor, int secondaryColor) {
        return SPAWN_EGGS.register(entityName + "_spawn_egg", () -> new ForgeSpawnEggItem(entityTypeSupplier, primaryColor, secondaryColor, new Item.Properties()));
    }

    @SubscribeEvent
    public static void onCommonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(() -> MoCreatures.LOGGER.info("Setting up Mo'Creatures spawn eggs"));
    }
}

