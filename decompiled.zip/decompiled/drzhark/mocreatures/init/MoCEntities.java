/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.EntityType$Builder
 *  net.minecraft.world.entity.EntityType$EntityFactory
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.MobCategory
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraftforge.event.entity.EntityAttributeCreationEvent
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber$Bus
 *  net.minecraftforge.registries.DeferredRegister
 *  net.minecraftforge.registries.ForgeRegistries
 *  net.minecraftforge.registries.IForgeRegistry
 *  net.minecraftforge.registries.RegistryObject
 */
package drzhark.mocreatures.init;

import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.entity.MoCEntityAnimal;
import drzhark.mocreatures.entity.MoCEntityAquatic;
import drzhark.mocreatures.entity.ambient.MoCEntityAnt;
import drzhark.mocreatures.entity.ambient.MoCEntityBee;
import drzhark.mocreatures.entity.ambient.MoCEntityButterfly;
import drzhark.mocreatures.entity.ambient.MoCEntityCrab;
import drzhark.mocreatures.entity.ambient.MoCEntityCricket;
import drzhark.mocreatures.entity.ambient.MoCEntityDragonfly;
import drzhark.mocreatures.entity.ambient.MoCEntityFirefly;
import drzhark.mocreatures.entity.ambient.MoCEntityFly;
import drzhark.mocreatures.entity.ambient.MoCEntityGrasshopper;
import drzhark.mocreatures.entity.ambient.MoCEntityMaggot;
import drzhark.mocreatures.entity.ambient.MoCEntityRoach;
import drzhark.mocreatures.entity.ambient.MoCEntitySnail;
import drzhark.mocreatures.entity.aquatic.MoCEntityAnchovy;
import drzhark.mocreatures.entity.aquatic.MoCEntityAngelFish;
import drzhark.mocreatures.entity.aquatic.MoCEntityAngler;
import drzhark.mocreatures.entity.aquatic.MoCEntityBass;
import drzhark.mocreatures.entity.aquatic.MoCEntityClownFish;
import drzhark.mocreatures.entity.aquatic.MoCEntityCod;
import drzhark.mocreatures.entity.aquatic.MoCEntityDolphin;
import drzhark.mocreatures.entity.aquatic.MoCEntityFishy;
import drzhark.mocreatures.entity.aquatic.MoCEntityGoldFish;
import drzhark.mocreatures.entity.aquatic.MoCEntityHippoTang;
import drzhark.mocreatures.entity.aquatic.MoCEntityJellyFish;
import drzhark.mocreatures.entity.aquatic.MoCEntityManderin;
import drzhark.mocreatures.entity.aquatic.MoCEntityMantaRay;
import drzhark.mocreatures.entity.aquatic.MoCEntityMediumFish;
import drzhark.mocreatures.entity.aquatic.MoCEntityPiranha;
import drzhark.mocreatures.entity.aquatic.MoCEntityRay;
import drzhark.mocreatures.entity.aquatic.MoCEntitySalmon;
import drzhark.mocreatures.entity.aquatic.MoCEntityShark;
import drzhark.mocreatures.entity.aquatic.MoCEntitySmallFish;
import drzhark.mocreatures.entity.aquatic.MoCEntityStingRay;
import drzhark.mocreatures.entity.hostile.MoCEntityCaveOgre;
import drzhark.mocreatures.entity.hostile.MoCEntityCaveScorpion;
import drzhark.mocreatures.entity.hostile.MoCEntityDarkManticore;
import drzhark.mocreatures.entity.hostile.MoCEntityDirtScorpion;
import drzhark.mocreatures.entity.hostile.MoCEntityFireManticore;
import drzhark.mocreatures.entity.hostile.MoCEntityFireOgre;
import drzhark.mocreatures.entity.hostile.MoCEntityFireScorpion;
import drzhark.mocreatures.entity.hostile.MoCEntityFlameWraith;
import drzhark.mocreatures.entity.hostile.MoCEntityFrostManticore;
import drzhark.mocreatures.entity.hostile.MoCEntityFrostScorpion;
import drzhark.mocreatures.entity.hostile.MoCEntityGolem;
import drzhark.mocreatures.entity.hostile.MoCEntityGreenOgre;
import drzhark.mocreatures.entity.hostile.MoCEntityHellRat;
import drzhark.mocreatures.entity.hostile.MoCEntityHorseMob;
import drzhark.mocreatures.entity.hostile.MoCEntityManticore;
import drzhark.mocreatures.entity.hostile.MoCEntityMiniGolem;
import drzhark.mocreatures.entity.hostile.MoCEntityOgre;
import drzhark.mocreatures.entity.hostile.MoCEntityPlainManticore;
import drzhark.mocreatures.entity.hostile.MoCEntityRat;
import drzhark.mocreatures.entity.hostile.MoCEntitySilverSkeleton;
import drzhark.mocreatures.entity.hostile.MoCEntityToxicManticore;
import drzhark.mocreatures.entity.hostile.MoCEntityUndeadScorpion;
import drzhark.mocreatures.entity.hostile.MoCEntityWWolf;
import drzhark.mocreatures.entity.hostile.MoCEntityWerewolf;
import drzhark.mocreatures.entity.hostile.MoCEntityWraith;
import drzhark.mocreatures.entity.hunter.MoCEntityBlackBear;
import drzhark.mocreatures.entity.hunter.MoCEntityCrocodile;
import drzhark.mocreatures.entity.hunter.MoCEntityFox;
import drzhark.mocreatures.entity.hunter.MoCEntityGrizzlyBear;
import drzhark.mocreatures.entity.hunter.MoCEntityKomodo;
import drzhark.mocreatures.entity.hunter.MoCEntityLeoger;
import drzhark.mocreatures.entity.hunter.MoCEntityLeopard;
import drzhark.mocreatures.entity.hunter.MoCEntityLiard;
import drzhark.mocreatures.entity.hunter.MoCEntityLiger;
import drzhark.mocreatures.entity.hunter.MoCEntityLion;
import drzhark.mocreatures.entity.hunter.MoCEntityLither;
import drzhark.mocreatures.entity.hunter.MoCEntityManticorePet;
import drzhark.mocreatures.entity.hunter.MoCEntityPanthard;
import drzhark.mocreatures.entity.hunter.MoCEntityPanther;
import drzhark.mocreatures.entity.hunter.MoCEntityPanthger;
import drzhark.mocreatures.entity.hunter.MoCEntityPetScorpion;
import drzhark.mocreatures.entity.hunter.MoCEntityPolarBear;
import drzhark.mocreatures.entity.hunter.MoCEntityRaccoon;
import drzhark.mocreatures.entity.hunter.MoCEntitySnake;
import drzhark.mocreatures.entity.hunter.MoCEntityTiger;
import drzhark.mocreatures.entity.item.MoCEntityEgg;
import drzhark.mocreatures.entity.item.MoCEntityKittyBed;
import drzhark.mocreatures.entity.item.MoCEntityLitterBox;
import drzhark.mocreatures.entity.item.MoCEntityThrowableRock;
import drzhark.mocreatures.entity.neutral.MoCEntityBoar;
import drzhark.mocreatures.entity.neutral.MoCEntityElephant;
import drzhark.mocreatures.entity.neutral.MoCEntityEnt;
import drzhark.mocreatures.entity.neutral.MoCEntityGoat;
import drzhark.mocreatures.entity.neutral.MoCEntityKitty;
import drzhark.mocreatures.entity.neutral.MoCEntityOstrich;
import drzhark.mocreatures.entity.neutral.MoCEntityPandaBear;
import drzhark.mocreatures.entity.neutral.MoCEntityWyvern;
import drzhark.mocreatures.entity.passive.MoCEntityBird;
import drzhark.mocreatures.entity.passive.MoCEntityBunny;
import drzhark.mocreatures.entity.passive.MoCEntityDeer;
import drzhark.mocreatures.entity.passive.MoCEntityDuck;
import drzhark.mocreatures.entity.passive.MoCEntityFilchLizard;
import drzhark.mocreatures.entity.passive.MoCEntityHorse;
import drzhark.mocreatures.entity.passive.MoCEntityMole;
import drzhark.mocreatures.entity.passive.MoCEntityMouse;
import drzhark.mocreatures.entity.passive.MoCEntityTurkey;
import drzhark.mocreatures.entity.passive.MoCEntityTurtle;
import drzhark.mocreatures.entity.tameable.MoCEntityTameableAnimal;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.RegistryObject;

@Mod.EventBusSubscriber(modid="mocreatures", bus=Mod.EventBusSubscriber.Bus.MOD)
public class MoCEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = DeferredRegister.create((IForgeRegistry)ForgeRegistries.ENTITY_TYPES, (String)"mocreatures");
    private static final Map<RegistryObject<? extends EntityType<? extends LivingEntity>>, Supplier<AttributeSupplier.Builder>> ENTITY_ATTRIBUTES = new HashMap<RegistryObject<? extends EntityType<? extends LivingEntity>>, Supplier<AttributeSupplier.Builder>>();
    public static final RegistryObject<EntityType<MoCEntityBird>> BIRD = MoCEntities.registerEntity("bird", MoCEntityBird::new, MobCategory.CREATURE, 0.5f, 0.9f, MoCEntityTameableAnimal::createAttributes, 37109, 4609629);
    public static final RegistryObject<EntityType<MoCEntityBlackBear>> BLACK_BEAR = MoCEntities.registerEntity("blackbear", MoCEntityBlackBear::new, MobCategory.CREATURE, 0.85f, 1.175f, MoCEntityBlackBear::createAttributes, 986897, 8609347);
    public static final RegistryObject<EntityType<MoCEntityBoar>> BOAR = MoCEntities.registerEntity("boar", MoCEntityBoar::new, MobCategory.CREATURE, 0.9f, 0.9f, MoCEntityBoar::createAttributes, 2037783, 4995892);
    public static final RegistryObject<EntityType<MoCEntityBunny>> BUNNY = MoCEntities.registerEntity("bunny", MoCEntityBunny::new, MobCategory.CREATURE, 0.5f, 0.5f, MoCEntityTameableAnimal::createAttributes, 8741934, 14527570);
    public static final RegistryObject<EntityType<MoCEntityCrocodile>> CROCODILE = MoCEntities.registerEntity("crocodile", MoCEntityCrocodile::new, MobCategory.CREATURE, 0.9f, 0.5f, MoCEntityCrocodile::createAttributes, 2698525, 10720356);
    public static final RegistryObject<EntityType<MoCEntityDuck>> DUCK = MoCEntities.registerEntity("duck", MoCEntityDuck::new, MobCategory.CREATURE, 0.4f, 0.7f, MoCEntityAnimal::createAttributes, 3161353, 14011565);
    public static final RegistryObject<EntityType<MoCEntityDeer>> DEER = MoCEntities.registerEntity("deer", MoCEntityDeer::new, MobCategory.CREATURE, 0.9f, 1.425f, MoCEntityTameableAnimal::createAttributes, 11572843, 13752020);
    public static final RegistryObject<EntityType<MoCEntityElephant>> ELEPHANT = MoCEntities.registerEntity("elephant", MoCEntityElephant::new, MobCategory.CREATURE, 1.1f, 3.0f, MoCEntityElephant::createAttributes, 4274216, 9337176);
    public static final RegistryObject<EntityType<MoCEntityEnt>> ENT = MoCEntities.registerEntity("ent", MoCEntityEnt::new, MobCategory.CREATURE, 1.4f, 7.0f, MoCEntityEnt::createAttributes, 9794886, 5800509);
    public static final RegistryObject<EntityType<MoCEntityFilchLizard>> FILCH_LIZARD = MoCEntities.registerEntity("filchlizard", MoCEntityFilchLizard::new, MobCategory.CREATURE, 0.6f, 0.5f, MoCEntityAnimal::createAttributes, 9930060, 5580310);
    public static final RegistryObject<EntityType<MoCEntityFox>> FOX = MoCEntities.registerEntity("fox", MoCEntityFox::new, MobCategory.CREATURE, 0.7f, 0.85f, MoCEntityFox::createAttributes, 15966491, 4009236);
    public static final RegistryObject<EntityType<MoCEntityGoat>> GOAT = MoCEntities.registerEntity("goat", MoCEntityGoat::new, MobCategory.CREATURE, 0.8f, 0.9f, MoCEntityGoat::createAttributes, 15262682, 4404517);
    public static final RegistryObject<EntityType<MoCEntityGrizzlyBear>> GRIZZLY_BEAR = MoCEntities.registerEntity("grizzlybear", MoCEntityGrizzlyBear::new, MobCategory.CREATURE, 1.125f, 1.57f, MoCEntityGrizzlyBear::createAttributes, 3547151, 11371099);
    public static final RegistryObject<EntityType<MoCEntityKitty>> KITTY = MoCEntities.registerEntity("kitty", MoCEntityKitty::new, MobCategory.CREATURE, 0.8f, 0.8f, MoCEntityKitty::createAttributes, 16707009, 14861419);
    public static final RegistryObject<EntityType<MoCEntityKomodo>> KOMODO_DRAGON = MoCEntities.registerEntity("komododragon", MoCEntityKomodo::new, MobCategory.CREATURE, 1.25f, 0.9f, MoCEntityKomodo::createAttributes, 8615512, 3025185);
    public static final RegistryObject<EntityType<MoCEntityLeoger>> LEOGER = MoCEntities.registerEntity("leoger", MoCEntityLeoger::new, MobCategory.CREATURE, 1.3f, 1.3815f, MoCEntityLeoger::createAttributes, 13274957, 6638124);
    public static final RegistryObject<EntityType<MoCEntityLeopard>> LEOPARD = MoCEntities.registerEntity("leopard", MoCEntityLeopard::new, MobCategory.CREATURE, 1.165f, 1.01f, MoCEntityLeopard::createAttributes, 13478009, 3682085);
    public static final RegistryObject<EntityType<MoCEntityLiard>> LIARD = MoCEntities.registerEntity("liard", MoCEntityLiard::new, MobCategory.CREATURE, 1.175f, 1.065f, MoCEntityLiard::createAttributes, 11965543, 8215850);
    public static final RegistryObject<EntityType<MoCEntityLion>> LION = MoCEntities.registerEntity("lion", MoCEntityLion::new, MobCategory.CREATURE, 1.25f, 1.275f, MoCEntityLion::createAttributes, 11503958, 2234383);
    public static final RegistryObject<EntityType<MoCEntityLiger>> LIGER = MoCEntities.registerEntity("liger", MoCEntityLiger::new, MobCategory.CREATURE, 1.35f, 1.43525f, MoCEntityLiger::createAttributes, 13347170, 9068088);
    public static final RegistryObject<EntityType<MoCEntityLither>> LITHER = MoCEntities.registerEntity("lither", MoCEntityLither::new, MobCategory.CREATURE, 1.175f, 1.17f, MoCEntityLither::createAttributes, 0x221A11, 7821878);
    public static final RegistryObject<EntityType<MoCEntityManticorePet>> MANTICORE_PET = MoCEntities.registerEntity("manticorepet", MoCEntityManticorePet::new, MobCategory.CREATURE, 1.4f, 1.3f, MoCEntityManticorePet::createAttributes);
    public static final RegistryObject<EntityType<MoCEntityMole>> MOLE = MoCEntities.registerEntity("mole", MoCEntityMole::new, MobCategory.CREATURE, 1.0f, 0.5f, MoCEntityTameableAnimal::createAttributes, 263173, 10646113);
    public static final RegistryObject<EntityType<MoCEntityMouse>> MOUSE = MoCEntities.registerEntity("mouse", MoCEntityMouse::new, MobCategory.CREATURE, 0.45f, 0.3f, MoCEntityAnimal::createAttributes, 7428164, 0xECAAAA);
    public static final RegistryObject<EntityType<MoCEntityOstrich>> OSTRICH = MoCEntities.registerEntity("ostrich", MoCEntityOstrich::new, MobCategory.CREATURE, 0.8f, 2.225f, MoCEntityOstrich::createAttributes, 12884106, 10646377);
    public static final RegistryObject<EntityType<MoCEntityPandaBear>> PANDA_BEAR = MoCEntities.registerEntity("pandabear", MoCEntityPandaBear::new, MobCategory.CREATURE, 0.8f, 1.05f, MoCEntityPandaBear::createAttributes, 13354393, 789516);
    public static final RegistryObject<EntityType<MoCEntityPanthard>> PANTHARD = MoCEntities.registerEntity("panthard", MoCEntityPanthard::new, MobCategory.CREATURE, 1.14f, 1.063175f, MoCEntityPanthard::createAttributes, 591108, 9005068);
    public static final RegistryObject<EntityType<MoCEntityPanther>> PANTHER = MoCEntities.registerEntity("panther", MoCEntityPanther::new, MobCategory.CREATURE, 1.175f, 1.065f, MoCEntityPanther::createAttributes, 1709584, 16768078);
    public static final RegistryObject<EntityType<MoCEntityPanthger>> PANTHGER = MoCEntities.registerEntity("panthger", MoCEntityPanthger::new, MobCategory.CREATURE, 1.225f, 1.2225f, MoCEntityPanthger::createAttributes, 2826517, 14348086);
    public static final RegistryObject<EntityType<MoCEntityPetScorpion>> PET_SCORPION = MoCEntities.registerEntity("petscorpion", MoCEntityPetScorpion::new, MobCategory.CREATURE, 1.4f, 0.9f, MoCEntityPetScorpion::createAttributes);
    public static final RegistryObject<EntityType<MoCEntityPolarBear>> POLAR_BEAR = MoCEntities.registerEntity("wildpolarbear", MoCEntityPolarBear::new, MobCategory.CREATURE, 1.5f, 1.834f, MoCEntityPolarBear::createAttributes, 15131867, 11380879);
    public static final RegistryObject<EntityType<MoCEntityRaccoon>> RACCOON = MoCEntities.registerEntity("raccoon", MoCEntityRaccoon::new, MobCategory.CREATURE, 0.6f, 0.525f, MoCEntityRaccoon::createAttributes, 6115913, 0x181411);
    public static final RegistryObject<EntityType<MoCEntitySnake>> SNAKE = MoCEntities.registerEntity("snake", MoCEntitySnake::new, MobCategory.CREATURE, 1.4f, 0.5f, MoCEntitySnake::createAttributes, 670976, 11309312);
    public static final RegistryObject<EntityType<MoCEntityTiger>> TIGER = MoCEntities.registerEntity("tiger", MoCEntityTiger::new, MobCategory.CREATURE, 1.25f, 1.275f, MoCEntityTiger::createAttributes, 12476160, 2956299);
    public static final RegistryObject<EntityType<MoCEntityTurtle>> TURTLE = MoCEntities.registerEntity("turtle", MoCEntityTurtle::new, MobCategory.CREATURE, 0.6f, 0.425f, MoCEntityTameableAnimal::createAttributes, 6505237, 10524955);
    public static final RegistryObject<EntityType<MoCEntityTurkey>> TURKEY = MoCEntities.registerEntity("turkey", MoCEntityTurkey::new, MobCategory.CREATURE, 0.6f, 0.9f, MoCEntityTameableAnimal::createAttributes, 12268098, 0x6AADDA);
    public static final RegistryObject<EntityType<MoCEntityHorse>> WILDHORSE = MoCEntities.registerEntity("wildhorse", MoCEntityHorse::new, MobCategory.CREATURE, 1.3964844f, 1.6f, MoCEntityTameableAnimal::createAttributes, 9204829, 11379712);
    public static final RegistryObject<EntityType<MoCEntityWyvern>> WYVERN = MoCEntities.registerEntity("wyvern", MoCEntityWyvern::new, MobCategory.CREATURE, 1.45f, 1.55f, MoCEntityWyvern::registerAttributes, 11440923, 15526339);
    public static final RegistryObject<EntityType<MoCEntityCaveOgre>> CAVE_OGRE = MoCEntities.registerEntity("caveogre", MoCEntityCaveOgre::new, MobCategory.MONSTER, 1.8f, 3.05f, MoCEntityCaveOgre::createAttributes, 5079480, 0xBFFAFF);
    public static final RegistryObject<EntityType<MoCEntityFireOgre>> FIRE_OGRE = MoCEntities.registerEntity("fireogre", MoCEntityFireOgre::new, MobCategory.MONSTER, 1.8f, 3.05f, MoCEntityFireOgre::createAttributes, 0x900C00, 14336256);
    public static final RegistryObject<EntityType<MoCEntityFlameWraith>> FLAME_WRAITH = MoCEntities.registerEntity("flamewraith", MoCEntityFlameWraith::new, MobCategory.MONSTER, 0.6f, 1.3f, MoCEntityFlameWraith::createAttributes, 0x1000000, 16744064);
    public static final RegistryObject<EntityType<MoCEntityGolem>> BIG_GOLEM = MoCEntities.registerEntity("biggolem", MoCEntityGolem::new, MobCategory.MONSTER, 1.8f, 4.3f, MoCEntityGolem::createAttributes, 0x4A4A4A, 52411);
    public static final RegistryObject<EntityType<MoCEntityGreenOgre>> GREEN_OGRE = MoCEntities.registerEntity("greenogre", MoCEntityGreenOgre::new, MobCategory.MONSTER, 1.8f, 3.05f, MoCEntityGreenOgre::createAttributes, 0x333333, 6553856);
    public static final RegistryObject<EntityType<MoCEntityHorseMob>> HORSE_MOB = MoCEntities.registerEntity("horsemob", MoCEntityHorseMob::new, MobCategory.MONSTER, 1.3964844f, 1.6f, MoCEntityHorseMob::createAttributes, 0x2A2A2A, 10579012);
    public static final RegistryObject<EntityType<MoCEntityHellRat>> HELL_RAT = MoCEntities.registerEntity("hellrat", MoCEntityHellRat::new, MobCategory.MONSTER, 0.7f, 0.65f, MoCEntityHellRat::createAttributes, 5064201, 10354944);
    public static final RegistryObject<EntityType<MoCEntityManticore>> MANTICORE = MoCEntities.registerEntity("manticore", MoCEntityManticore::new, MobCategory.MONSTER, 1.4f, 1.3f, MoCEntityManticore::createAttributes, 7954176, 0x333333);
    public static final RegistryObject<EntityType<MoCEntityDarkManticore>> DARK_MANTICORE = MoCEntities.registerEntity("darkmanticore", MoCEntityDarkManticore::new, MobCategory.MONSTER, 1.35f, 1.45f, MoCEntityDarkManticore::createAttributes, 0x323232, 657930);
    public static final RegistryObject<EntityType<MoCEntityFireManticore>> FIRE_MANTICORE = MoCEntities.registerEntity("firemanticore", MoCEntityFireManticore::new, MobCategory.MONSTER, 1.35f, 1.45f, MoCEntityFireManticore::createAttributes, 7148552, 2819585);
    public static final RegistryObject<EntityType<MoCEntityFrostManticore>> FROST_MANTICORE = MoCEntities.registerEntity("frostmanticore", MoCEntityFrostManticore::new, MobCategory.MONSTER, 1.35f, 1.45f, MoCEntityFrostManticore::createAttributes, 3559006, 2041389);
    public static final RegistryObject<EntityType<MoCEntityPlainManticore>> PLAIN_MANTICORE = MoCEntities.registerEntity("plainmanticore", MoCEntityPlainManticore::new, MobCategory.MONSTER, 1.35f, 1.45f, MoCEntityPlainManticore::createAttributes, 7623465, 5510656);
    public static final RegistryObject<EntityType<MoCEntityToxicManticore>> TOXIC_MANTICORE = MoCEntities.registerEntity("toxicmanticore", MoCEntityToxicManticore::new, MobCategory.MONSTER, 1.35f, 1.45f, MoCEntityToxicManticore::createAttributes, 6252034, 3365689);
    public static final RegistryObject<EntityType<MoCEntityMiniGolem>> MINI_GOLEM = MoCEntities.registerEntity("minigolem", MoCEntityMiniGolem::new, MobCategory.MONSTER, 0.6f, 1.3f, MoCEntityMiniGolem::createAttributes, 4734789, 0xC2C2C2);
    public static final RegistryObject<EntityType<MoCEntityOgre>> OGRE = MoCEntities.registerEntity("ogre", MoCEntityOgre::new, MobCategory.MONSTER, 1.8f, 3.05f, MoCEntityOgre::createAttributes, 9204851, 0x636363);
    public static final RegistryObject<EntityType<MoCEntityRat>> RAT = MoCEntities.registerEntity("rat", MoCEntityRat::new, MobCategory.MONSTER, 0.58f, 0.455f, MoCEntityRat::createAttributes, 3685435, 15838633);
    public static final RegistryObject<EntityType<MoCEntityCaveScorpion>> CAVE_SCORPION = MoCEntities.registerEntity("cavescorpion", MoCEntityCaveScorpion::new, MobCategory.MONSTER, 1.4f, 0.9f, MoCEntityCaveScorpion::createAttributes, 0x323232, 855309);
    public static final RegistryObject<EntityType<MoCEntityDirtScorpion>> DIRT_SCORPION = MoCEntities.registerEntity("dirtscorpion", MoCEntityDirtScorpion::new, MobCategory.MONSTER, 1.4f, 0.9f, MoCEntityDirtScorpion::createAttributes, 6838816, 855309);
    public static final RegistryObject<EntityType<MoCEntityFireScorpion>> FIRE_SCORPION = MoCEntities.registerEntity("firescorpion", MoCEntityFireScorpion::new, MobCategory.MONSTER, 1.4f, 0.9f, MoCEntityFireScorpion::createAttributes, 0xFF0000, 855309);
    public static final RegistryObject<EntityType<MoCEntityFrostScorpion>> FROST_SCORPION = MoCEntities.registerEntity("frostscorpion", MoCEntityFrostScorpion::new, MobCategory.MONSTER, 1.4f, 0.9f, MoCEntityFrostScorpion::createAttributes, 0xC0C0C0, 855309);
    public static final RegistryObject<EntityType<MoCEntityUndeadScorpion>> UNDEAD_SCORPION = MoCEntities.registerEntity("undeadscorpion", MoCEntityUndeadScorpion::new, MobCategory.MONSTER, 1.4f, 0.9f, MoCEntityUndeadScorpion::createAttributes, 0x1A1A1A, 855309);
    public static final RegistryObject<EntityType<MoCEntitySilverSkeleton>> SILVER_SKELETON = MoCEntities.registerEntity("silverskeleton", MoCEntitySilverSkeleton::new, MobCategory.MONSTER, 0.6f, 1.95f, MoCEntitySilverSkeleton::createAttributes, 0xD3D3D3, 0xEEEEEE);
    public static final RegistryObject<EntityType<MoCEntityWerewolf>> WEREWOLF = MoCEntities.registerEntity("werewolf", MoCEntityWerewolf::new, MobCategory.MONSTER, 0.6f, 1.8f, MoCEntityWerewolf::createAttributes, 7631459, 0xDBDBDB);
    public static final RegistryObject<EntityType<MoCEntityWraith>> WRAITH = MoCEntities.registerEntity("wraith", MoCEntityWraith::new, MobCategory.MONSTER, 0.6f, 1.3f, MoCEntityWraith::createAttributes, 2764582, 0xB0B0B0);
    public static final RegistryObject<EntityType<MoCEntityWWolf>> WWOLF = MoCEntities.registerEntity("wwolf", MoCEntityWWolf::new, MobCategory.MONSTER, 0.8f, 0.8f, MoCEntityWWolf::createAttributes, 0x4A4A4A, 9996056);
    public static final RegistryObject<EntityType<MoCEntityAnchovy>> ANCHOVY = MoCEntities.registerEntity("anchovy", MoCEntityAnchovy::new, MobCategory.WATER_CREATURE, 0.5f, 0.3f, MoCEntityAquatic::createAttributes, 7039838, 12763545);
    public static final RegistryObject<EntityType<MoCEntityAngelFish>> ANGELFISH = MoCEntities.registerEntity("angelfish", MoCEntityAngelFish::new, MobCategory.WATER_CREATURE, 0.5f, 0.3f, MoCEntityAquatic::createAttributes, 0xB7B7B7, 15970609);
    public static final RegistryObject<EntityType<MoCEntityAngler>> ANGLER = MoCEntities.registerEntity("angler", MoCEntityAngler::new, MobCategory.WATER_CREATURE, 0.5f, 1.5f, MoCEntityAquatic::createAttributes, 2961195, 11972077);
    public static final RegistryObject<EntityType<MoCEntityClownFish>> CLOWNFISH = MoCEntities.registerEntity("clownfish", MoCEntityClownFish::new, MobCategory.WATER_CREATURE, 0.5f, 0.3f, MoCEntityAquatic::createAttributes, 16439491, 15425029);
    public static final RegistryObject<EntityType<MoCEntityGoldFish>> GOLDFISH = MoCEntities.registerEntity("goldfish", MoCEntityGoldFish::new, MobCategory.WATER_CREATURE, 0.3f, 0.2f, MoCEntityAquatic::createAttributes, 0xFF9900, 0xFFFF00);
    public static final RegistryObject<EntityType<MoCEntityHippoTang>> HIPPOTANG = MoCEntities.registerEntity("hippotang", MoCEntityHippoTang::new, MobCategory.WATER_CREATURE, 0.5f, 0.3f, MoCEntityAquatic::createAttributes, 4280267, 12893441);
    public static final RegistryObject<EntityType<MoCEntityManderin>> MANDERIN = MoCEntities.registerEntity("manderin", MoCEntityManderin::new, MobCategory.WATER_CREATURE, 0.5f, 0.3f, MoCEntityAquatic::createAttributes, 14764801, 5935359);
    public static final RegistryObject<EntityType<MoCEntityBass>> BASS = MoCEntities.registerEntity("bass", MoCEntityBass::new, MobCategory.WATER_CREATURE, 0.7f, 0.3f, MoCEntityAquatic::createAttributes, 5854242, 0x999901);
    public static final RegistryObject<EntityType<MoCEntityCod>> COD = MoCEntities.registerEntity("cod", MoCEntityCod::new, MobCategory.WATER_CREATURE, 0.5f, 0.3f, MoCEntityAquatic::createAttributes, 8355712, 0xB9B000);
    public static final RegistryObject<EntityType<MoCEntitySalmon>> SALMON = MoCEntities.registerEntity("salmon", MoCEntitySalmon::new, MobCategory.WATER_CREATURE, 0.7f, 0.4f, MoCEntityAquatic::createAttributes, 10489616, 951424);
    public static final RegistryObject<EntityType<MoCEntityDolphin>> DOLPHIN = MoCEntities.registerEntity("dolphin", MoCEntityDolphin::new, MobCategory.WATER_CREATURE, 1.3f, 0.605f, MoCEntityAquatic::createAttributes, 4086148, 11251396);
    public static final RegistryObject<EntityType<MoCEntityMantaRay>> MANTA_RAY = MoCEntities.registerEntity("mantaray", MoCEntityMantaRay::new, MobCategory.WATER_CREATURE, 2.0f, 0.5f, MoCEntityAquatic::createAttributes, 592137, 0x252525);
    public static final RegistryObject<EntityType<MoCEntityRay>> RAY = MoCEntities.registerEntity("ray", MoCEntityRay::new, MobCategory.WATER_CREATURE, 1.45f, 0.4f, MoCEntityAquatic::createAttributes, 6770509, 13947080);
    public static final RegistryObject<EntityType<MoCEntityShark>> SHARK = MoCEntities.registerEntity("shark", MoCEntityShark::new, MobCategory.WATER_CREATURE, 1.65f, 0.9f, MoCEntityAquatic::createAttributes, 3817558, 11580358);
    public static final RegistryObject<EntityType<MoCEntityStingRay>> STING_RAY = MoCEntities.registerEntity("stingray", MoCEntityStingRay::new, MobCategory.WATER_CREATURE, 1.2f, 0.3f, MoCEntityAquatic::createAttributes, 6770509, 13947080);
    public static final RegistryObject<EntityType<MoCEntityFishy>> FISHY = MoCEntities.registerEntity("fishy", MoCEntityFishy::new, MobCategory.WATER_CREATURE, 0.3f, 0.3f, MoCEntityAquatic::createAttributes, 16684800, 0xCC3300);
    public static final RegistryObject<EntityType<MoCEntityJellyFish>> JELLYFISH = MoCEntities.registerEntity("jellyfish", MoCEntityJellyFish::new, MobCategory.WATER_CREATURE, 0.9f, 0.9f, MoCEntityAquatic::createAttributes, 0x373737, 0x999901);
    public static final RegistryObject<EntityType<MoCEntityMediumFish>> MEDIUM_FISH = MoCEntities.registerEntity("mediumfish", MoCEntityMediumFish::new, MobCategory.WATER_CREATURE, 0.5f, 0.3f, MoCEntityAquatic::createAttributes, 8355712, 0xB9B000);
    public static final RegistryObject<EntityType<MoCEntityPiranha>> PIRANHA = MoCEntities.registerEntity("piranha", MoCEntityPiranha::new, MobCategory.WATER_CREATURE, 0.3f, 0.3f, MoCEntityAquatic::createAttributes, 16684800, 0xC80000);
    public static final RegistryObject<EntityType<MoCEntitySmallFish>> SMALL_FISH = MoCEntities.registerEntity("smallfish", MoCEntitySmallFish::new, MobCategory.WATER_CREATURE, 0.3f, 0.3f, MoCEntityAquatic::createAttributes, 16684800, 0xCC3300);
    public static final RegistryObject<EntityType<MoCEntityAnt>> ANT = MoCEntities.registerEntity("ant", MoCEntityAnt::new, MobCategory.AMBIENT, 0.3f, 0.2f, MoCEntityAnt::createAttributes, 5915945, 2693905);
    public static final RegistryObject<EntityType<MoCEntityBee>> BEE = MoCEntities.registerEntity("bee", MoCEntityBee::new, MobCategory.AMBIENT, 0.4f, 0.3f, MoCEntityBee::createAttributes, 15912747, 526604);
    public static final RegistryObject<EntityType<MoCEntityButterfly>> BUTTERFLY = MoCEntities.registerEntity("butterfly", MoCEntityButterfly::new, MobCategory.AMBIENT, 0.5f, 0.3f, MoCEntityButterfly::createAttributes, 15912747, 526604);
    public static final RegistryObject<EntityType<MoCEntityCrab>> CRAB = MoCEntities.registerEntity("crab", MoCEntityCrab::new, MobCategory.AMBIENT, 0.45f, 0.3f, MoCEntityCrab::registerAttributes, 11880978, 15514213);
    public static final RegistryObject<EntityType<MoCEntityCricket>> CRICKET = MoCEntities.registerEntity("cricket", MoCEntityCricket::new, MobCategory.AMBIENT, 0.3f, 0.3f, MoCEntityCricket::createAttributes, 0x191919, 0x636363);
    public static final RegistryObject<EntityType<MoCEntityDragonfly>> DRAGONFLY = MoCEntities.registerEntity("dragonfly", MoCEntityDragonfly::new, MobCategory.AMBIENT, 0.5f, 0.3f, MoCEntityDragonfly::createAttributes, 0x232323, 0x7D7D7D);
    public static final RegistryObject<EntityType<MoCEntityFirefly>> FIREFLY = MoCEntities.registerEntity("firefly", MoCEntityFirefly::new, MobCategory.AMBIENT, 0.3f, 0.3f, MoCEntityFirefly::createAttributes, 0xF2F000, 0x141400);
    public static final RegistryObject<EntityType<MoCEntityFly>> FLY = MoCEntities.registerEntity("fly", MoCEntityFly::new, MobCategory.AMBIENT, 0.2f, 0.2f, MoCEntityFly::createAttributes, 0x191919, 0x636363);
    public static final RegistryObject<EntityType<MoCEntityGrasshopper>> GRASSHOPPER = MoCEntities.registerEntity("grasshopper", MoCEntityGrasshopper::new, MobCategory.AMBIENT, 0.4f, 0.3f, MoCEntityGrasshopper::createAttributes, 7830593, 3747075);
    public static final RegistryObject<EntityType<MoCEntityMaggot>> MAGGOT = MoCEntities.registerEntity("maggot", MoCEntityMaggot::new, MobCategory.AMBIENT, 0.3f, 0.3f, MoCEntityMaggot::createAttributes, 0xE0E0E0, 0xFFFFFF);
    public static final RegistryObject<EntityType<MoCEntityRoach>> ROACH = MoCEntities.registerEntity("roach", MoCEntityRoach::new, MobCategory.AMBIENT, 0.3f, 0.3f, MoCEntityRoach::createAttributes, 0x191919, 0x636363);
    public static final RegistryObject<EntityType<MoCEntitySnail>> SNAIL = MoCEntities.registerEntity("snail", MoCEntitySnail::new, MobCategory.AMBIENT, 0.3f, 0.3f, MoCEntitySnail::createAttributes, 0x838383, 0xEEEEEE);
    public static final RegistryObject<EntityType<MoCEntityEgg>> EGG = ENTITY_TYPES.register("egg", () -> EntityType.Builder.m_20704_(MoCEntityEgg::new, (MobCategory)MobCategory.MISC).m_20699_(0.25f, 0.25f).m_20702_(64).m_20717_(10).m_20712_(new ResourceLocation("mocreatures", "egg").toString()));
    public static final RegistryObject<EntityType<MoCEntityKittyBed>> KITTY_BED;
    public static final RegistryObject<EntityType<MoCEntityLitterBox>> LITTERBOX;
    public static final RegistryObject<EntityType<MoCEntityThrowableRock>> TROCK;

    private static <T extends LivingEntity> RegistryObject<EntityType<T>> registerEntity(String name, EntityType.EntityFactory<T> factory, MobCategory category, float width, float height, Supplier<AttributeSupplier.Builder> attributes, int primaryColor, int secondaryColor) {
        RegistryObject entityType = ENTITY_TYPES.register(name.toLowerCase(), () -> EntityType.Builder.m_20704_((EntityType.EntityFactory)factory, (MobCategory)category).m_20699_(width, height).m_20702_(80).m_20717_(3).m_20712_(new ResourceLocation("mocreatures", name.toLowerCase()).toString()));
        ENTITY_ATTRIBUTES.put((RegistryObject<? extends EntityType<? extends LivingEntity>>)entityType, attributes);
        return entityType;
    }

    private static <T extends LivingEntity> RegistryObject<EntityType<T>> registerEntity(String name, EntityType.EntityFactory<T> factory, MobCategory category, float width, float height, Supplier<AttributeSupplier.Builder> attributes) {
        RegistryObject entityType = ENTITY_TYPES.register(name.toLowerCase(), () -> EntityType.Builder.m_20704_((EntityType.EntityFactory)factory, (MobCategory)category).m_20699_(width, height).m_20702_(80).m_20717_(3).m_20712_(new ResourceLocation("mocreatures", name.toLowerCase()).toString()));
        ENTITY_ATTRIBUTES.put((RegistryObject<? extends EntityType<? extends LivingEntity>>)entityType, attributes);
        return entityType;
    }

    @SubscribeEvent
    public static void registerEntityAttributes(EntityAttributeCreationEvent event) {
        ENTITY_ATTRIBUTES.put(KITTY_BED, MoCEntityKittyBed::createAttributes);
        ENTITY_ATTRIBUTES.put(LITTERBOX, MoCEntityLitterBox::createAttributes);
        ENTITY_ATTRIBUTES.forEach((entityType, attributeSupplier) -> {
            try {
                if (entityType.isPresent()) {
                    AttributeSupplier attributes = ((AttributeSupplier.Builder)attributeSupplier.get()).m_22265_();
                    event.put((EntityType)entityType.get(), attributes);
                    if (entityType.equals(WYVERN)) {
                        MoCreatures.LOGGER.info("Registered Wyvern attributes: {}", (Object)attributes);
                    }
                } else {
                    MoCreatures.LOGGER.warn("Skipping attributes for entity that's not present: {}", (Object)entityType.getId());
                }
            }
            catch (Exception e) {
                MoCreatures.LOGGER.error("Error registering attributes for entity: {}", (Object)entityType.getId(), (Object)e);
            }
        });
        MoCreatures.LOGGER.info("Registered entity attributes for {} entities", (Object)ENTITY_ATTRIBUTES.size());
    }

    static {
        ENTITY_ATTRIBUTES.put(EGG, MoCEntityEgg::createAttributes);
        KITTY_BED = ENTITY_TYPES.register("kittybed", () -> EntityType.Builder.m_20704_(MoCEntityKittyBed::new, (MobCategory)MobCategory.MISC).m_20699_(1.0f, 0.15f).m_20702_(64).m_20717_(10).m_20712_(new ResourceLocation("mocreatures", "kittybed").toString()));
        LITTERBOX = ENTITY_TYPES.register("litterbox", () -> EntityType.Builder.m_20704_(MoCEntityLitterBox::new, (MobCategory)MobCategory.MISC).m_20699_(1.0f, 0.15f).m_20702_(64).m_20717_(10).m_20712_(new ResourceLocation("mocreatures", "litterbox").toString()));
        TROCK = ENTITY_TYPES.register("trock", () -> EntityType.Builder.m_20704_(MoCEntityThrowableRock::new, (MobCategory)MobCategory.MISC).m_20699_(1.0f, 1.0f).m_20702_(64).m_20717_(10).m_20712_(new ResourceLocation("mocreatures", "trock").toString()));
    }
}

