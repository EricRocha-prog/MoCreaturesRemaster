/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 */
package drzhark.mocreatures.init;

import net.minecraft.resources.ResourceLocation;

public class MoCLootTables {
    public static final ResourceLocation ANT = new ResourceLocation("mocreatures", "entities/ambient/ant");
    public static final ResourceLocation BEE = new ResourceLocation("mocreatures", "entities/ambient/bee");
    public static final ResourceLocation BUTTERFLY = new ResourceLocation("mocreatures", "entities/ambient/butterfly");
    public static final ResourceLocation CRICKET = new ResourceLocation("mocreatures", "entities/ambient/cricket");
    public static final ResourceLocation DRAGONFLY = new ResourceLocation("mocreatures", "entities/ambient/dragonfly");
    public static final ResourceLocation FIREFLY = new ResourceLocation("mocreatures", "entities/ambient/firefly");
    public static final ResourceLocation FLY = new ResourceLocation("mocreatures", "entities/ambient/fly");
    public static final ResourceLocation GRASSHOPPER = new ResourceLocation("mocreatures", "entities/ambient/grasshopper");
    public static final ResourceLocation MAGGOT = new ResourceLocation("mocreatures", "entities/ambient/maggot");
    public static final ResourceLocation ROACH = new ResourceLocation("mocreatures", "entities/ambient/roach");
    public static final ResourceLocation SNAIL = new ResourceLocation("mocreatures", "entities/ambient/snail");
    public static final ResourceLocation BIRD = new ResourceLocation("mocreatures", "entities/bird");
    public static final ResourceLocation BOAR = new ResourceLocation("mocreatures", "entities/boar");
    public static final ResourceLocation BUNNY = new ResourceLocation("mocreatures", "entities/bunny");
    public static final ResourceLocation CROCODILE = new ResourceLocation("mocreatures", "entities/crocodile");
    public static final ResourceLocation DEER = new ResourceLocation("mocreatures", "entities/deer");
    public static final ResourceLocation DUCK = new ResourceLocation("mocreatures", "entities/duck");
    public static final ResourceLocation FOX = new ResourceLocation("mocreatures", "entities/fox");
    public static final ResourceLocation GOAT = new ResourceLocation("mocreatures", "entities/goat");
    public static final ResourceLocation KITTY = new ResourceLocation("mocreatures", "entities/kitty");
    public static final ResourceLocation KOMODO_DRAGON = new ResourceLocation("mocreatures", "entities/komodo_dragon");
    public static final ResourceLocation MOLE = new ResourceLocation("mocreatures", "entities/mole");
    public static final ResourceLocation OSTRICH = new ResourceLocation("mocreatures", "entities/ostrich");
    public static final ResourceLocation RACCOON = new ResourceLocation("mocreatures", "entities/raccoon");
    public static final ResourceLocation TURKEY = new ResourceLocation("mocreatures", "entities/turkey");
    public static final ResourceLocation TURTLE = new ResourceLocation("mocreatures", "entities/turtle");
    public static final ResourceLocation WILD_WOLF = new ResourceLocation("mocreatures", "entities/wild_wolf");
    public static final ResourceLocation BLACK_BEAR = new ResourceLocation("mocreatures", "entities/black_bear");
    public static final ResourceLocation GRIZZLY_BEAR = new ResourceLocation("mocreatures", "entities/grizzly_bear");
    public static final ResourceLocation PANDA_BEAR = new ResourceLocation("mocreatures", "entities/panda_bear");
    public static final ResourceLocation POLAR_BEAR = new ResourceLocation("mocreatures", "entities/polar_bear");
    public static final ResourceLocation LEOGER = new ResourceLocation("mocreatures", "entities/leoger");
    public static final ResourceLocation LEOPARD = new ResourceLocation("mocreatures", "entities/leopard");
    public static final ResourceLocation LIARD = new ResourceLocation("mocreatures", "entities/liard");
    public static final ResourceLocation LIGER = new ResourceLocation("mocreatures", "entities/liger");
    public static final ResourceLocation LION = new ResourceLocation("mocreatures", "entities/lion");
    public static final ResourceLocation LITHER = new ResourceLocation("mocreatures", "entities/lither");
    public static final ResourceLocation PANTHARD = new ResourceLocation("mocreatures", "entities/panthard");
    public static final ResourceLocation PANTHER = new ResourceLocation("mocreatures", "entities/panther");
    public static final ResourceLocation PANTHGER = new ResourceLocation("mocreatures", "entities/panthger");
    public static final ResourceLocation TIGER = new ResourceLocation("mocreatures", "entities/tiger");
    public static final ResourceLocation WYVERN = new ResourceLocation("mocreatures", "entities/wyvern");
    public static final ResourceLocation FILCH_LIZARD = new ResourceLocation("mocreatures", "entities/filch_lizard/filch_lizard");
    public static final ResourceLocation FILCH_LIZARD_SPAWN = new ResourceLocation("mocreatures", "entities/filch_lizard/filch_lizard_spawn");
    public static final ResourceLocation FILCH_LIZARD_STEAL = new ResourceLocation("mocreatures", "entities/filch_lizard/filch_lizard_steal");
    public static final ResourceLocation BIG_GOLEM = new ResourceLocation("mocreatures", "entities/big_golem");
    public static final ResourceLocation MINI_GOLEM = new ResourceLocation("mocreatures", "entities/mini_golem");
    public static final ResourceLocation DARK_MANTICORE = new ResourceLocation("mocreatures", "entities/dark_manticore");
    public static final ResourceLocation FIRE_MANTICORE = new ResourceLocation("mocreatures", "entities/fire_manticore");
    public static final ResourceLocation FROST_MANTICORE = new ResourceLocation("mocreatures", "entities/frost_manticore");
    public static final ResourceLocation PLAIN_MANTICORE = new ResourceLocation("mocreatures", "entities/plain_manticore");
    public static final ResourceLocation TOXIC_MANTICORE = new ResourceLocation("mocreatures", "entities/toxic_manticore");
    public static final ResourceLocation CAVE_OGRE = new ResourceLocation("mocreatures", "entities/cave_ogre");
    public static final ResourceLocation FIRE_OGRE = new ResourceLocation("mocreatures", "entities/fire_ogre");
    public static final ResourceLocation GREEN_OGRE = new ResourceLocation("mocreatures", "entities/green_ogre");
    public static final ResourceLocation HELL_RAT = new ResourceLocation("mocreatures", "entities/hell_rat");
    public static final ResourceLocation MOUSE = new ResourceLocation("mocreatures", "entities/mouse");
    public static final ResourceLocation RAT = new ResourceLocation("mocreatures", "entities/rat");
    public static final ResourceLocation ANCHOVY = new ResourceLocation("mocreatures", "entities/aquatic/anchovy");
    public static final ResourceLocation ANGELFISH = new ResourceLocation("mocreatures", "entities/aquatic/angelfish");
    public static final ResourceLocation ANGLERFISH = new ResourceLocation("mocreatures", "entities/aquatic/anglerfish");
    public static final ResourceLocation BASS = new ResourceLocation("mocreatures", "entities/aquatic/bass");
    public static final ResourceLocation CLOWNFISH = new ResourceLocation("mocreatures", "entities/aquatic/clownfish");
    public static final ResourceLocation COD = new ResourceLocation("mocreatures", "entities/aquatic/cod");
    public static final ResourceLocation CRAB = new ResourceLocation("mocreatures", "entities/aquatic/crab");
    public static final ResourceLocation DOLPHIN = new ResourceLocation("mocreatures", "entities/aquatic/dolphin");
    public static final ResourceLocation FISHY = new ResourceLocation("mocreatures", "entities/aquatic/fishy");
    public static final ResourceLocation GOLDFISH = new ResourceLocation("mocreatures", "entities/aquatic/goldfish");
    public static final ResourceLocation HIPPO_TANG = new ResourceLocation("mocreatures", "entities/aquatic/hippo_tang");
    public static final ResourceLocation JELLYFISH = new ResourceLocation("mocreatures", "entities/aquatic/jellyfish");
    public static final ResourceLocation MANDARINFISH = new ResourceLocation("mocreatures", "entities/aquatic/mandarinfish");
    public static final ResourceLocation MANTA_RAY = new ResourceLocation("mocreatures", "entities/aquatic/manta_ray");
    public static final ResourceLocation PIRANHA = new ResourceLocation("mocreatures", "entities/aquatic/piranha");
    public static final ResourceLocation SALMON = new ResourceLocation("mocreatures", "entities/aquatic/salmon");
    public static final ResourceLocation SHARK = new ResourceLocation("mocreatures", "entities/aquatic/shark");
    public static final ResourceLocation STINGRAY = new ResourceLocation("mocreatures", "entities/aquatic/stingray");
    public static final ResourceLocation CAVE_SCORPION = new ResourceLocation("mocreatures", "entities/cave_scorpion");
    public static final ResourceLocation DIRT_SCORPION = new ResourceLocation("mocreatures", "entities/dirt_scorpion");
    public static final ResourceLocation FIRE_SCORPION = new ResourceLocation("mocreatures", "entities/fire_scorpion");
    public static final ResourceLocation FROST_SCORPION = new ResourceLocation("mocreatures", "entities/frost_scorpion");
    public static final ResourceLocation UNDEAD_SCORPION = new ResourceLocation("mocreatures", "entities/undead_scorpion");
    public static final ResourceLocation FLAME_WRAITH = new ResourceLocation("mocreatures", "entities/flame_wraith");
    public static final ResourceLocation SILVER_SKELETON = new ResourceLocation("mocreatures", "entities/silver_skeleton");
    public static final ResourceLocation WRAITH = new ResourceLocation("mocreatures", "entities/wraith");
    public static final ResourceLocation WEREHUMAN = new ResourceLocation("mocreatures", "entities/werehuman");
    public static final ResourceLocation WEREWOLF = new ResourceLocation("mocreatures", "entities/werewolf");
}

