/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  net.minecraft.world.level.levelgen.feature.Feature
 *  net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration
 *  net.minecraftforge.eventbus.api.IEventBus
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber$Bus
 *  net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent
 *  net.minecraftforge.registries.DeferredRegister
 *  net.minecraftforge.registries.ForgeRegistries
 *  net.minecraftforge.registries.IForgeRegistry
 *  net.minecraftforge.registries.RegistryObject
 */
package drzhark.mocreatures.init;

import com.mojang.serialization.Codec;
import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.worldgen.feature.FirestoneClusterFeature;
import drzhark.mocreatures.worldgen.feature.WyvernNestFeature;
import drzhark.mocreatures.worldgen.structure.WyvernIslandFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.RegistryObject;

@Mod.EventBusSubscriber(modid="mocreatures", bus=Mod.EventBusSubscriber.Bus.MOD)
public class MoCFeatures {
    public static final DeferredRegister<Feature<?>> FEATURES = DeferredRegister.create((IForgeRegistry)ForgeRegistries.FEATURES, (String)"mocreatures");
    public static final RegistryObject<Feature<NoneFeatureConfiguration>> FIRESTONE_CLUSTER = FEATURES.register("firestone_cluster", () -> new FirestoneClusterFeature((Codec<NoneFeatureConfiguration>)NoneFeatureConfiguration.f_67815_));
    public static final RegistryObject<Feature<NoneFeatureConfiguration>> WYVERN_ISLAND = FEATURES.register("wyvern_island", () -> new WyvernIslandFeature((Codec<NoneFeatureConfiguration>)NoneFeatureConfiguration.f_67815_));
    public static final RegistryObject<Feature<NoneFeatureConfiguration>> WYVERN_NEST = FEATURES.register("wyvern_nest", () -> new WyvernNestFeature((Codec<NoneFeatureConfiguration>)NoneFeatureConfiguration.f_67815_));

    public static void register(IEventBus eventBus) {
        MoCreatures.LOGGER.info("Registering MoCreatures features");
        FEATURES.register(eventBus);
    }

    @SubscribeEvent
    public static void onCommonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(() -> {
            MoCreatures.LOGGER.info("MoCreatures features initialized");
            MoCreatures.LOGGER.info("Registered features: " + FEATURES.getEntries().size());
        });
    }
}

