/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.ints.Int2ObjectMap
 *  net.minecraft.world.entity.npc.VillagerProfession
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.Items
 *  net.minecraft.world.item.trading.MerchantOffer
 *  net.minecraft.world.level.ItemLike
 *  net.minecraftforge.event.village.VillagerTradesEvent
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 */
package drzhark.mocreatures.init;

import drzhark.mocreatures.init.MoCItems;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import java.util.List;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.level.ItemLike;
import net.minecraftforge.event.village.VillagerTradesEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid="mocreatures")
public class MoCVillagerTrades {
    @SubscribeEvent
    public static void registerTrades(VillagerTradesEvent event) {
        Int2ObjectMap trades = event.getTrades();
        if (VillagerProfession.f_35587_.equals((Object)event.getType())) {
            ((List)trades.get(1)).add((e, r) -> MoCVillagerTrades.offer(new ItemStack((ItemLike)MoCItems.DUCK_RAW.get(), 14 + r.m_188503_(5)), new ItemStack((ItemLike)Items.f_42616_), 10, 2, 0.05f));
            ((List)trades.get(1)).add((e, r) -> MoCVillagerTrades.offer(new ItemStack((ItemLike)MoCItems.OSTRICH_RAW.get(), 10 + r.m_188503_(3)), new ItemStack((ItemLike)Items.f_42616_), 10, 2, 0.05f));
            ((List)trades.get(2)).add((e, r) -> MoCVillagerTrades.offer(new ItemStack((ItemLike)Items.f_42616_), new ItemStack((ItemLike)MoCItems.DUCK_COOKED.get(), 6 + r.m_188503_(3)), 10, 5, 0.05f));
            ((List)trades.get(2)).add((e, r) -> MoCVillagerTrades.offer(new ItemStack((ItemLike)Items.f_42616_), new ItemStack((ItemLike)MoCItems.OSTRICH_COOKED.get(), 5 + r.m_188503_(3)), 10, 5, 0.05f));
        }
        if (VillagerProfession.f_35589_.equals((Object)event.getType())) {
            ((List)trades.get(1)).add((e, r) -> MoCVillagerTrades.offer(new ItemStack((ItemLike)MoCItems.ANCIENTSILVERSCRAP.get(), 4 + r.m_188503_(3)), new ItemStack((ItemLike)Items.f_42616_), 10, 2, 0.05f));
            ((List)trades.get(4)).add((e, r) -> MoCVillagerTrades.offer(new ItemStack((ItemLike)Items.f_42616_), new ItemStack((ItemLike)MoCItems.MYSTIC_PEAR.get(), 2 + r.m_188503_(2)), 3, 15, 0.1f));
        }
        if (VillagerProfession.f_35591_.equals((Object)event.getType())) {
            ((List)trades.get(1)).add((e, r) -> MoCVillagerTrades.offer(new ItemStack((ItemLike)Items.f_42616_, 2 + r.m_188503_(3)), new ItemStack((ItemLike)MoCItems.FISH_NET.get()), 10, 5, 0.05f));
            ((List)trades.get(2)).add((e, r) -> MoCVillagerTrades.offer(new ItemStack((ItemLike)Items.f_42616_), new ItemStack((ItemLike)MoCItems.CRAB_COOKED.get(), 6 + r.m_188503_(3)), 10, 5, 0.05f));
        }
        if (VillagerProfession.f_35593_.equals((Object)event.getType())) {
            ((List)trades.get(1)).add((e, r) -> MoCVillagerTrades.offer(new ItemStack((ItemLike)MoCItems.FUR.get(), 9 + r.m_188503_(4)), new ItemStack((ItemLike)Items.f_42616_), 10, 2, 0.05f));
            ((List)trades.get(1)).add((e, r) -> MoCVillagerTrades.offer(new ItemStack((ItemLike)MoCItems.ANIMALHIDE.get(), 6 + r.m_188503_(4)), new ItemStack((ItemLike)Items.f_42616_), 10, 2, 0.05f));
        }
        if (VillagerProfession.f_35594_.equals((Object)event.getType())) {
            ((List)trades.get(1)).add((e, r) -> new MerchantOffer(new ItemStack((ItemLike)Items.f_42516_), new ItemStack((ItemLike)Items.f_42402_), new ItemStack((ItemLike)MoCItems.SCROLLFREEDOM.get()), 12, 10, 0.1f));
        }
        if (VillagerProfession.f_35598_.equals((Object)event.getType()) || VillagerProfession.f_35599_.equals((Object)event.getType()) || VillagerProfession.f_35586_.equals((Object)event.getType())) {
            ((List)trades.get(2)).add((e, r) -> MoCVillagerTrades.offer(new ItemStack((ItemLike)Items.f_42616_, 4 + r.m_188503_(3)), new ItemStack((ItemLike)MoCItems.ANCIENTSILVERINGOT.get()), 10, 5, 0.05f));
            ((List)trades.get(2)).add((e, r) -> MoCVillagerTrades.offer(new ItemStack((ItemLike)MoCItems.ANCIENTSILVERINGOT.get(), 3 + r.m_188503_(2)), new ItemStack((ItemLike)Items.f_42616_), 10, 5, 0.05f));
        }
    }

    private static MerchantOffer offer(ItemStack in, ItemStack out, int maxUses, int xp, float priceMult) {
        return new MerchantOffer(in, out, maxUses, xp, priceMult);
    }
}

