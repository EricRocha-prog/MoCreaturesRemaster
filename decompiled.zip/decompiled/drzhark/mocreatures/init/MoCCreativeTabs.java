/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.network.chat.Component
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.world.item.CreativeModeTab
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.ItemLike
 *  net.minecraftforge.eventbus.api.IEventBus
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber$Bus
 *  net.minecraftforge.registries.DeferredRegister
 *  net.minecraftforge.registries.RegistryObject
 */
package drzhark.mocreatures.init;

import drzhark.mocreatures.init.MoCBlocks;
import drzhark.mocreatures.init.MoCItems;
import drzhark.mocreatures.item.MoCItemEgg;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

@Mod.EventBusSubscriber(modid="mocreatures", bus=Mod.EventBusSubscriber.Bus.MOD)
public class MoCCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS = DeferredRegister.create((ResourceKey)Registries.f_279569_, (String)"mocreatures");
    public static final RegistryObject<CreativeModeTab> MOC_TAB = CREATIVE_MODE_TABS.register("mocreatures_tab", () -> CreativeModeTab.builder().m_257941_((Component)Component.m_237115_((String)"itemGroup.mocreatures_tab")).m_257737_(() -> MoCItems.AMULET_FAIRY_FULL.get() != null ? new ItemStack((ItemLike)MoCItems.AMULET_FAIRY_FULL.get()) : ItemStack.f_41583_).m_257501_((params, output) -> {
        for (RegistryObject blockEntry : MoCBlocks.BLOCKS.getEntries()) {
            try {
                if (!blockEntry.isPresent()) continue;
                String blockPath = blockEntry.getId().m_135815_();
                MoCBlocks.ITEMS.getEntries().stream().filter(itemObj -> itemObj.getId().m_135815_().equals(blockPath)).findFirst().ifPresent(itemObj -> output.m_246326_((ItemLike)itemObj.get()));
            }
            catch (Exception blockPath) {}
        }
        for (RegistryObject itemEntry : MoCItems.ITEMS.getEntries()) {
            try {
                if (!itemEntry.isPresent()) continue;
                Item item = (Item)itemEntry.get();
                if (item instanceof MoCItemEgg) {
                    MoCItemEgg eggItem = (MoCItemEgg)item;
                    eggItem.fillItemCategory(output);
                    continue;
                }
                output.m_246326_((ItemLike)item);
            }
            catch (Exception exception) {}
        }
    }).m_257652_());

    public static void register(IEventBus modEventBus) {
        CREATIVE_MODE_TABS.register(modEventBus);
    }
}

