/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.SpawnPlacements
 *  net.minecraft.world.entity.SpawnPlacements$Type
 *  net.minecraft.world.entity.animal.Animal
 *  net.minecraft.world.item.CreativeModeTabs
 *  net.minecraft.world.level.ItemLike
 *  net.minecraft.world.level.levelgen.Heightmap$Types
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.event.BuildCreativeModeTabContentsEvent
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber$Bus
 *  net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent
 *  net.minecraftforge.fml.loading.FMLEnvironment
 */
package drzhark.mocreatures.init;

import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.init.MoCEntities;
import drzhark.mocreatures.init.MoCSpawnEggs;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.loading.FMLEnvironment;

@Mod.EventBusSubscriber(modid="mocreatures", bus=Mod.EventBusSubscriber.Bus.MOD)
public class MoCRegistration {
    @SubscribeEvent
    public static void onCommonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(() -> {
            MoCRegistration.registerSpawnPlacements();
            MoCreatures.LOGGER.info("Mo'Creatures common setup complete");
        });
    }

    private static void registerSpawnPlacements() {
        SpawnPlacements.m_21754_((EntityType)((EntityType)MoCEntities.BIRD.get()), (SpawnPlacements.Type)SpawnPlacements.Type.NO_RESTRICTIONS, (Heightmap.Types)Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Animal::m_218104_);
        SpawnPlacements.m_21754_((EntityType)((EntityType)MoCEntities.BLACK_BEAR.get()), (SpawnPlacements.Type)SpawnPlacements.Type.ON_GROUND, (Heightmap.Types)Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Animal::m_218104_);
        MoCreatures.LOGGER.info("Registered spawn placements for Mo' Creatures entities");
    }

    @SubscribeEvent
    public static void buildCreativeModeTabContents(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.f_256731_) {
            MoCSpawnEggs.SPAWN_EGGS.getEntries().forEach(egg -> event.m_246326_((ItemLike)egg.get()));
        }
    }

    public static void clientSetup() {
        if (FMLEnvironment.dist == Dist.CLIENT) {
            MoCreatures.LOGGER.info("Mo'Creatures client setup complete");
        }
    }
}

