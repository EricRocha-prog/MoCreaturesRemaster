/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.level.block.Block
 *  net.minecraftforge.event.furnace.FurnaceFuelBurnTimeEvent
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 */
package drzhark.mocreatures.init;

import drzhark.mocreatures.init.MoCBlocks;
import drzhark.mocreatures.init.MoCItems;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.event.furnace.FurnaceFuelBurnTimeEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid="mocreatures")
public class MoCRecipes {
    @SubscribeEvent
    public static void registerFuels(FurnaceFuelBurnTimeEvent event) {
        Item item = event.getItemStack().m_41720_();
        if (item == ((Block)MoCBlocks.wyvwoodSapling.get()).m_5456_()) {
            event.setBurnTime(100);
        } else if (item == MoCItems.FIRESTONECHUNK.get()) {
            event.setBurnTime(2400);
        } else if (item == MoCItems.HEARTFIRE.get()) {
            event.setBurnTime(3200);
        } else if (item == MoCItems.SHARKAXE.get() || item == MoCItems.SHARKSWORD.get()) {
            event.setBurnTime(200);
        }
    }
}

