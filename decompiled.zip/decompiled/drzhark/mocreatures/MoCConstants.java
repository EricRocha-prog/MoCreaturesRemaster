/*
 * Decompiled with CFR 0.152.
 */
package drzhark.mocreatures;

public class MoCConstants {
    public static final String MOD_ID = "mocreatures";
    public static final String MOD_PREFIX = "mocreatures:";
    public static final String MOD_NAME = "Mo' Creatures: Nostalgia Edition";
    public static final String MOD_VERSION = "12.4.0";
    public static final Integer DATAFIXER_VERSION = 1;
}

