/*
 * Decompiled with CFR 0.152.
 */
package drzhark.mocreatures.compat.industrialforegoing;

public class IndustrialForegoingIntegration {
    public static void generateLatexEntries() {
    }
}

