/*
 * Decompiled with CFR 0.152.
 */
package drzhark.mocreatures.compat.jer;

public class JERIntegration {
    public static void init() {
    }
}

