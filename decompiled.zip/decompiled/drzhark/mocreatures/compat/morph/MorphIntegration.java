/*
 * Decompiled with CFR 0.152.
 */
package drzhark.mocreatures.compat.morph;

public class MorphIntegration {
    public static void mapAbilities() {
    }
}

