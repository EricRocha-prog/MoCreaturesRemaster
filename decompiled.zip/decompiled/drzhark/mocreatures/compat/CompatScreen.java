/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiGraphics
 *  net.minecraft.client.gui.components.Button
 *  net.minecraft.client.gui.components.events.GuiEventListener
 *  net.minecraft.client.gui.screens.Screen
 *  net.minecraft.client.gui.screens.worldselection.SelectWorldScreen
 *  net.minecraft.network.chat.Component
 */
package drzhark.mocreatures.compat;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.network.chat.Component;

public class CompatScreen
extends Screen {
    public static boolean showScreen = true;
    private final List<Component> messages = new ArrayList<Component>();
    private int textHeight;

    public CompatScreen() {
        super((Component)Component.m_237119_());
        this.messages.add((Component)Component.m_237115_((String)"msg.mocreatures.compat.cms"));
        this.messages.add((Component)Component.m_237119_());
        this.messages.add((Component)Component.m_237119_());
        this.messages.add((Component)Component.m_237115_((String)"msg.mocreatures.compat.cms1"));
        this.messages.add((Component)Component.m_237119_());
        this.messages.add((Component)Component.m_237115_((String)"msg.mocreatures.compat.cms2"));
        this.messages.add((Component)Component.m_237119_());
    }

    protected void m_7856_() {
        this.m_169413_();
        int n = this.messages.size();
        Objects.requireNonNull(this.f_96547_);
        this.textHeight = n * 9;
        int n2 = this.f_96544_ / 2 + this.textHeight / 2;
        Objects.requireNonNull(this.f_96547_);
        int buttonY = Math.min(n2 + 9, this.f_96544_ - 30);
        this.m_142416_((GuiEventListener)Button.m_253074_((Component)Component.m_237115_((String)"gui.done"), btn -> this.f_96541_.m_91152_((Screen)new SelectWorldScreen((Screen)this))).m_252987_(this.f_96543_ / 2 - 100, buttonY, 200, 20).m_253136_());
    }

    public void m_88315_(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
        this.m_280273_(graphics);
        int i = this.f_96544_ / 2 - this.textHeight / 2;
        for (Component line : this.messages) {
            graphics.m_280653_(this.f_96547_, line, this.f_96543_ / 2, i, 0xFFFFFF);
            Objects.requireNonNull(this.f_96547_);
            i += 9;
        }
        super.m_88315_(graphics, mouseX, mouseY, partialTicks);
    }
}

