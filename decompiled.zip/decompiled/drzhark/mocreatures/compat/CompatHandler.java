/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraftforge.fml.ModList
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber$Bus
 */
package drzhark.mocreatures.compat;

import drzhark.mocreatures.compat.industrialforegoing.IndustrialForegoingIntegration;
import drzhark.mocreatures.compat.jer.JERIntegration;
import drzhark.mocreatures.compat.morph.MorphIntegration;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid="mocreatures", bus=Mod.EventBusSubscriber.Bus.MOD)
public class CompatHandler {
    public static void preInit() {
    }

    public static void init() {
        if (ModList.get().isLoaded("industrialforegoing")) {
            IndustrialForegoingIntegration.generateLatexEntries();
        }
        if (ModList.get().isLoaded("jeresources")) {
            JERIntegration.init();
        }
    }

    public static void postInit() {
        if (ModList.get().isLoaded("morph")) {
            MorphIntegration.mapAbilities();
        }
    }

    static {
        try {
            String line;
            BufferedWriter bw;
            BufferedReader br;
            File tempFile;
            File file = new File(Minecraft.m_91087_().f_91069_, "config" + File.separator + "mia" + File.separator + "mocreatures.cfg");
            if (Files.exists(file.toPath(), new LinkOption[0])) {
                tempFile = new File(Minecraft.m_91087_().f_91069_, "config" + File.separator + "mia" + File.separator + "mocreatures_temp.cfg");
                ArrayList<String> configEntries = new ArrayList<String>();
                configEntries.add("Enable Hatchery integration");
                configEntries.add("Enable Ice and Fire additions");
                configEntries.add("Enable Industrial Foregoing integration");
                configEntries.add("Enable JER integration");
                configEntries.add("Enable Thermal Expansion integration");
                configEntries.add("Increase damage to werewolves from other mod silver weapons");
                configEntries.add("Replace cod and clownfish drops with their corresponding item");
                br = new BufferedReader(new FileReader(file));
                try {
                    bw = new BufferedWriter(new FileWriter(tempFile));
                    try {
                        while ((line = br.readLine()) != null) {
                            for (String targetConfigEntry : configEntries) {
                                if (!line.contains(targetConfigEntry)) continue;
                                line = line.replace("=true", "=false");
                            }
                            bw.write(line + "\n");
                        }
                    }
                    finally {
                        bw.close();
                    }
                }
                finally {
                    br.close();
                }
                file.delete();
                tempFile.renameTo(file);
            }
            if (Files.exists((file = new File(Minecraft.m_91087_().f_91069_, "config" + File.separator + "mia" + File.separator + "base.cfg")).toPath(), new LinkOption[0])) {
                tempFile = new File(Minecraft.m_91087_().f_91069_, "config" + File.separator + "mia" + File.separator + "base_temp.cfg");
                String targetConfigEntry = "Replaces all raw meat drops with cooked ones";
                br = new BufferedReader(new FileReader(file));
                try {
                    bw = new BufferedWriter(new FileWriter(tempFile));
                    try {
                        while ((line = br.readLine()) != null) {
                            if (line.contains(targetConfigEntry)) {
                                line = line.replace("=true", "=false");
                            }
                            bw.write(line + "\n");
                        }
                    }
                    finally {
                        bw.close();
                    }
                }
                finally {
                    br.close();
                }
                file.delete();
                tempFile.renameTo(file);
            }
            System.out.println("MIA config files modified successfully!");
        }
        catch (Exception exception) {
            // empty catch block
        }
    }
}

