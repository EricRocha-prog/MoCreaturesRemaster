/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.common.MinecraftForge
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.registries.ForgeRegistries
 *  net.minecraftforge.registries.MissingMappingsEvent
 */
package drzhark.mocreatures.compat.datafixes;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.MissingMappingsEvent;

public class EntityIDFixer {
    public EntityIDFixer() {
        MinecraftForge.EVENT_BUS.register((Object)this);
    }

    public CompoundTag fixTagCompound(CompoundTag compound) {
        int entityType;
        String entityId = compound.m_128461_("id");
        if (entityId.equals("mocreatures:scorpion")) {
            entityType = compound.m_128451_("TypeInt");
            switch (entityType) {
                case 2: {
                    compound.m_128359_("id", "mocreatures:cavescorpion");
                    break;
                }
                case 3: {
                    compound.m_128359_("id", "mocreatures:firescorpion");
                    break;
                }
                case 4: {
                    compound.m_128359_("id", "mocreatures:frostscorpion");
                    break;
                }
                default: {
                    compound.m_128359_("id", "mocreatures:dirtscorpion");
                }
            }
            compound.m_128405_("TypeInt", 1);
        }
        if (entityId.equals("mocreatures:manticore")) {
            entityType = compound.m_128451_("TypeInt");
            switch (entityType) {
                case 2: {
                    compound.m_128359_("id", "mocreatures:darkmanticore");
                    break;
                }
                case 3: {
                    compound.m_128359_("id", "mocreatures:frostmanticore");
                    break;
                }
                case 4: {
                    compound.m_128359_("id", "mocreatures:toxicmanticore");
                    break;
                }
                default: {
                    compound.m_128359_("id", "mocreatures:firemanticore");
                }
            }
            compound.m_128405_("TypeInt", 1);
        }
        return compound;
    }

    @SubscribeEvent
    public void onMissingEntityMappings(MissingMappingsEvent event) {
        ResourceLocation scorpion = new ResourceLocation("mocreatures", "scorpion");
        ResourceLocation manticore = new ResourceLocation("mocreatures", "manticore");
        event.getMappings(ForgeRegistries.ENTITY_TYPES.getRegistryKey(), "mocreatures").forEach(mapping -> {
            if (mapping.getKey().equals((Object)scorpion) || mapping.getKey().equals((Object)manticore)) {
                mapping.ignore();
            }
        });
    }
}

