/*
 * Decompiled with CFR 0.152.
 */
package drzhark.mocreatures.compat.thermalexpansion;

public class ThermalExpansionIntegration {
    public static void addRecipes() {
    }
}

