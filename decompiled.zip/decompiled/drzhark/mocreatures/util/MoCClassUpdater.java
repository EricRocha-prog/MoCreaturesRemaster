/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.util;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;

public class MoCClassUpdater {
    public static Level getLevel(Entity entity) {
        return entity.m_9236_();
    }
}

