/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.LazyLoadedValue
 *  net.minecraft.world.item.Tier
 *  net.minecraft.world.item.crafting.Ingredient
 *  net.minecraft.world.level.ItemLike
 */
package drzhark.mocreatures.util;

import drzhark.mocreatures.init.MoCItems;
import java.util.function.Supplier;
import net.minecraft.util.LazyLoadedValue;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.ItemLike;

public enum MoCItemTier implements Tier
{
    SHARK(1, 161, 7.0f, 2.5f, 15, () -> Ingredient.m_43929_((ItemLike[])new ItemLike[]{(ItemLike)MoCItems.SHARK_TEETH.get()})),
    SILVER(2, 304, 9.5f, 3.0f, 19, Ingredient::m_151265_),
    SCORPC(2, 371, 7.5f, 2.5f, 16, () -> Ingredient.m_43929_((ItemLike[])new ItemLike[]{(ItemLike)MoCItems.CHITINCAVE.get()})),
    SCORPF(2, 371, 7.5f, 2.5f, 16, () -> Ingredient.m_43929_((ItemLike[])new ItemLike[]{(ItemLike)MoCItems.CHITINFROST.get()})),
    SCORPN(2, 371, 7.5f, 2.5f, 16, () -> Ingredient.m_43929_((ItemLike[])new ItemLike[]{(ItemLike)MoCItems.CHITINNETHER.get()})),
    SCORPD(2, 371, 7.5f, 2.5f, 16, () -> Ingredient.m_43929_((ItemLike[])new ItemLike[]{(ItemLike)MoCItems.CHITIN.get()})),
    SCORPU(2, 371, 7.5f, 2.5f, 16, () -> Ingredient.m_43929_((ItemLike[])new ItemLike[]{(ItemLike)MoCItems.CHITINUNDEAD.get()})),
    STING(0, 8, 6.0f, 0.0f, 5, Ingredient::m_151265_);

    private final int level;
    private final int uses;
    private final float speed;
    private final float damage;
    private final int enchantmentValue;
    private final LazyLoadedValue<Ingredient> repairIngredient;

    private MoCItemTier(int level, int uses, float speed, float damage, int enchantmentValue, Supplier<Ingredient> repairIngredient) {
        this.level = level;
        this.uses = uses;
        this.speed = speed;
        this.damage = damage;
        this.enchantmentValue = enchantmentValue;
        this.repairIngredient = new LazyLoadedValue(repairIngredient);
    }

    public int m_6609_() {
        return this.uses;
    }

    public float m_6624_() {
        return this.speed;
    }

    public float m_6631_() {
        return this.damage;
    }

    public int m_6604_() {
        return this.level;
    }

    public int m_6601_() {
        return this.enchantmentValue;
    }

    public Ingredient m_6282_() {
        return (Ingredient)this.repairIngredient.m_13971_();
    }
}

