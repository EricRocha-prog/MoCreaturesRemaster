/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.level.BlockGetter
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraft.world.level.block.SoundType
 *  net.minecraft.world.level.block.state.BlockBehaviour$Properties
 *  net.minecraft.world.level.block.state.BlockState
 */
package drzhark.mocreatures.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;

public class MoCBlockNest
extends Block {
    public MoCBlockNest(BlockBehaviour.Properties properties) {
        super(properties.m_60978_(0.5f).m_60918_(SoundType.f_56740_));
    }

    public void m_142072_(Level level, BlockState state, BlockPos pos, Entity entity, float distance) {
        entity.m_142535_(distance, 0.2f, level.m_269111_().m_268989_());
    }

    public int getFlammability(BlockState state, BlockGetter getter, BlockPos pos, Direction direction) {
        return Blocks.f_50335_.getFlammability(state, getter, pos, direction);
    }
}

