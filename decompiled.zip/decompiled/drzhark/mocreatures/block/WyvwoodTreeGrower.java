/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.RandomSource
 *  net.minecraft.world.level.block.grower.AbstractTreeGrower
 *  net.minecraft.world.level.levelgen.feature.ConfiguredFeature
 */
package drzhark.mocreatures.block;

import javax.annotation.Nullable;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.grower.AbstractTreeGrower;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;

public class WyvwoodTreeGrower
extends AbstractTreeGrower {
    private static final ResourceKey<ConfiguredFeature<?, ?>> WYVWOOD_DARK_OAK = ResourceKey.m_135785_((ResourceKey)Registries.f_256911_, (ResourceLocation)new ResourceLocation("mocreatures:wyvwood_dark_oak"));
    private static final ResourceKey<ConfiguredFeature<?, ?>> WYVWOOD_LARGE_DARK_OAK = ResourceKey.m_135785_((ResourceKey)Registries.f_256911_, (ResourceLocation)new ResourceLocation("mocreatures:wyvwood_large_dark_oak"));
    private static final ResourceKey<ConfiguredFeature<?, ?>> WYVWOOD_SPRUCE = ResourceKey.m_135785_((ResourceKey)Registries.f_256911_, (ResourceLocation)new ResourceLocation("mocreatures:wyvwood_spruce"));
    private static final ResourceKey<ConfiguredFeature<?, ?>> WYVWOOD_LARGE_SPRUCE = ResourceKey.m_135785_((ResourceKey)Registries.f_256911_, (ResourceLocation)new ResourceLocation("mocreatures:wyvwood_large_spruce"));

    @Nullable
    protected ResourceKey<ConfiguredFeature<?, ?>> m_213888_(RandomSource random, boolean hasFlowers) {
        if (random.m_188503_(10) == 0) {
            return random.m_188499_() ? WYVWOOD_LARGE_DARK_OAK : WYVWOOD_LARGE_SPRUCE;
        }
        return random.m_188499_() ? WYVWOOD_DARK_OAK : WYVWOOD_SPRUCE;
    }
}

