/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.tags.BlockTags
 *  net.minecraft.world.level.BlockGetter
 *  net.minecraft.world.level.LevelReader
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.SaplingBlock
 *  net.minecraft.world.level.block.SoundType
 *  net.minecraft.world.level.block.grower.AbstractTreeGrower
 *  net.minecraft.world.level.block.state.BlockBehaviour$Properties
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.material.PushReaction
 */
package drzhark.mocreatures.block;

import drzhark.mocreatures.block.WyvwoodTreeGrower;
import drzhark.mocreatures.init.MoCBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SaplingBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.grower.AbstractTreeGrower;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.PushReaction;

public class MoCBlockSapling
extends SaplingBlock {
    public MoCBlockSapling(BlockBehaviour.Properties properties) {
        super((AbstractTreeGrower)new WyvwoodTreeGrower(), properties.m_60910_().m_60977_().m_60978_(0.0f).m_60918_(SoundType.f_56740_).m_278166_(PushReaction.DESTROY));
    }

    public boolean m_7898_(BlockState state, LevelReader level, BlockPos pos) {
        BlockPos blockpos = pos.m_7495_();
        BlockState blockstate = level.m_8055_(blockpos);
        if (blockstate.m_60713_((Block)MoCBlocks.wyvgrass.get()) || blockstate.m_60713_((Block)MoCBlocks.wyvdirt.get())) {
            return true;
        }
        return blockstate.m_204336_(BlockTags.f_144274_) || super.m_7898_(state, level, pos);
    }

    protected boolean m_6266_(BlockState state, BlockGetter level, BlockPos pos) {
        return state.m_60713_((Block)MoCBlocks.wyvgrass.get()) || state.m_60713_((Block)MoCBlocks.wyvdirt.get()) || state.m_204336_(BlockTags.f_144274_);
    }
}

