/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.level.block.GlassBlock
 *  net.minecraft.world.level.block.SoundType
 *  net.minecraft.world.level.block.state.BlockBehaviour$Properties
 *  net.minecraft.world.level.material.MapColor
 */
package drzhark.mocreatures.block;

import net.minecraft.world.level.block.GlassBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;

public class MoCBlockGlass
extends GlassBlock {
    public MoCBlockGlass(BlockBehaviour.Properties properties) {
        super(properties.m_284180_(MapColor.f_283808_).m_60978_(0.3f).m_60955_().m_60918_(SoundType.f_56744_).m_60922_((state, getter, pos, entityType) -> false).m_60960_((state, getter, pos) -> false).m_60971_((state, getter, pos) -> false));
    }
}

