/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.util.Mth
 *  net.minecraft.util.RandomSource
 *  net.minecraft.world.level.LevelReader
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.SoundType
 *  net.minecraft.world.level.block.state.BlockBehaviour$Properties
 *  net.minecraft.world.level.block.state.BlockState
 */
package drzhark.mocreatures.block;

import drzhark.mocreatures.init.MoCBlocks;
import java.util.Random;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;

public class MoCBlockOre
extends Block {
    public MoCBlockOre(BlockBehaviour.Properties properties) {
        super(properties.m_60913_(3.0f, 3.0f).m_60918_(SoundType.f_56742_));
    }

    public int getExpDrop(BlockState state, LevelReader level, RandomSource randomSource, BlockPos pos, int fortuneLevel, int silkTouchLevel) {
        return silkTouchLevel == 0 ? this.getExperience(new Random()) : 0;
    }

    private int getExperience(Random rand) {
        if (this == MoCBlocks.ancientOre.get()) {
            return Mth.m_216271_((RandomSource)((RandomSource)rand), (int)2, (int)5);
        }
        if (this == MoCBlocks.wyvernDiamondOre.get()) {
            return Mth.m_216271_((RandomSource)((RandomSource)rand), (int)4, (int)8);
        }
        if (this == MoCBlocks.wyvernEmeraldOre.get()) {
            return Mth.m_216271_((RandomSource)((RandomSource)rand), (int)4, (int)8);
        }
        if (this == MoCBlocks.wyvernLapisOre.get()) {
            return Mth.m_216271_((RandomSource)((RandomSource)rand), (int)3, (int)6);
        }
        return 0;
    }
}

