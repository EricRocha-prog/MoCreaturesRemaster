/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.SoundType
 *  net.minecraft.world.level.block.state.BlockBehaviour$Properties
 */
package drzhark.mocreatures.block;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;

public class MoCBlockPlanks
extends Block {
    public MoCBlockPlanks(BlockBehaviour.Properties properties) {
        super(properties.m_60913_(2.0f, 3.0f).m_60918_(SoundType.f_56736_));
    }
}

