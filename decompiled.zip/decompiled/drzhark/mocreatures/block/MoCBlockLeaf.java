/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.server.level.ServerLevel
 *  net.minecraft.tags.BlockTags
 *  net.minecraft.util.RandomSource
 *  net.minecraft.world.level.LevelAccessor
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.LeavesBlock
 *  net.minecraft.world.level.block.SoundType
 *  net.minecraft.world.level.block.state.BlockBehaviour$Properties
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.StateDefinition$Builder
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.level.material.MapColor
 */
package drzhark.mocreatures.block;

import drzhark.mocreatures.init.MoCBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.material.MapColor;

public class MoCBlockLeaf
extends LeavesBlock {
    private static final int MAX_DISTANCE = 6;

    public MoCBlockLeaf(BlockBehaviour.Properties properties) {
        super(properties.m_284180_(MapColor.f_283915_).m_60978_(0.2f).m_60977_().m_60918_(SoundType.f_56740_).m_60955_().m_60960_((s, g, p) -> false).m_60971_((s, g, p) -> false));
        this.m_49959_((BlockState)((BlockState)((BlockState)this.f_49792_.m_61090_()).m_61124_((Property)f_54418_, (Comparable)Integer.valueOf(6))).m_61124_((Property)f_54419_, (Comparable)Boolean.FALSE));
    }

    public BlockState m_7417_(BlockState state, Direction direction, BlockState neighborState, LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        int distance = 6;
        boolean foundLog = false;
        for (Direction dir : Direction.values()) {
            BlockState adjacent = level.m_8055_(pos.m_121945_(dir));
            if (adjacent.m_60734_() == MoCBlocks.wyvwoodLog.get() || adjacent.m_204336_(BlockTags.f_13106_)) {
                return (BlockState)((BlockState)state.m_61124_((Property)f_54419_, (Comparable)Boolean.valueOf(true))).m_61124_((Property)f_54418_, (Comparable)Integer.valueOf(1));
            }
            if (!(adjacent.m_60734_() instanceof LeavesBlock)) continue;
            if (((Boolean)adjacent.m_61143_((Property)f_54419_)).booleanValue()) {
                return (BlockState)((BlockState)state.m_61124_((Property)f_54419_, (Comparable)Boolean.valueOf(true))).m_61124_((Property)f_54418_, (Comparable)Integer.valueOf(1));
            }
            distance = Math.min(distance, (Integer)adjacent.m_61143_((Property)f_54418_) + 1);
        }
        if (distance < 6) {
            return (BlockState)state.m_61124_((Property)f_54418_, (Comparable)Integer.valueOf(distance));
        }
        level.m_186460_(pos, (Block)this, 1);
        return state;
    }

    public void m_213897_(BlockState state, ServerLevel level, BlockPos pos, RandomSource rand) {
        if (((Boolean)state.m_61143_((Property)f_54419_)).booleanValue()) {
            return;
        }
        int currentDistance = (Integer)state.m_61143_((Property)f_54418_);
        if (currentDistance >= 6) {
            level.m_7471_(pos, false);
            return;
        }
        BlockState newState = this.m_54435_(state, (LevelAccessor)level, pos);
        if (newState != state) {
            level.m_7731_(pos, newState, 3);
        }
    }

    private BlockState m_54435_(BlockState state, LevelAccessor level, BlockPos pos) {
        int distance = 6;
        for (Direction dir : Direction.values()) {
            BlockPos neighborPos = pos.m_121945_(dir);
            BlockState neighborState = level.m_8055_(neighborPos);
            if (neighborState.m_60734_() == MoCBlocks.wyvwoodLog.get() || neighborState.m_204336_(BlockTags.f_13106_)) {
                return (BlockState)((BlockState)state.m_61124_((Property)f_54419_, (Comparable)Boolean.valueOf(true))).m_61124_((Property)f_54418_, (Comparable)Integer.valueOf(1));
            }
            if (!(neighborState.m_60734_() instanceof LeavesBlock)) continue;
            if (((Boolean)neighborState.m_61143_((Property)f_54419_)).booleanValue()) {
                return (BlockState)((BlockState)state.m_61124_((Property)f_54419_, (Comparable)Boolean.valueOf(true))).m_61124_((Property)f_54418_, (Comparable)Integer.valueOf(1));
            }
            distance = Math.min(distance, (Integer)neighborState.m_61143_((Property)f_54418_) + 1);
        }
        return (BlockState)state.m_61124_((Property)f_54418_, (Comparable)Integer.valueOf(distance));
    }

    protected void m_7926_(StateDefinition.Builder<Block, BlockState> builder) {
        super.m_7926_(builder);
    }
}

