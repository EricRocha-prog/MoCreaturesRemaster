/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.server.level.ServerLevel
 *  net.minecraft.util.RandomSource
 *  net.minecraft.world.level.BlockGetter
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.LevelReader
 *  net.minecraft.world.level.WorldGenLevel
 *  net.minecraft.world.level.biome.Biome
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraft.world.level.block.BonemealableBlock
 *  net.minecraft.world.level.block.GrassBlock
 *  net.minecraft.world.level.block.MushroomBlock
 *  net.minecraft.world.level.block.SoundType
 *  net.minecraft.world.level.block.state.BlockBehaviour$Properties
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.levelgen.feature.ConfiguredFeature
 *  net.minecraft.world.level.material.MapColor
 *  net.minecraftforge.common.IPlantable
 */
package drzhark.mocreatures.block;

import drzhark.mocreatures.block.MoCBlockTallGrass;
import drzhark.mocreatures.init.MoCBlocks;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.BonemealableBlock;
import net.minecraft.world.level.block.GrassBlock;
import net.minecraft.world.level.block.MushroomBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.common.IPlantable;

public class MoCBlockGrass
extends GrassBlock
implements BonemealableBlock {
    public MoCBlockGrass(BlockBehaviour.Properties properties) {
        super(properties.m_284180_(MapColor.f_283824_).m_60977_().m_60978_(0.6f).m_60918_(SoundType.f_56740_));
    }

    public void m_213898_(BlockState state, ServerLevel world, BlockPos pos, RandomSource random) {
        if (!world.isAreaLoaded(pos, 3)) {
            return;
        }
        if (world.m_46803_(pos.m_7494_()) < 4 && world.m_8055_(pos.m_7494_()).m_60739_((BlockGetter)world, pos.m_7494_()) > 2) {
            if (this == MoCBlocks.wyvgrass.get()) {
                world.m_46597_(pos, ((Block)MoCBlocks.wyvdirt.get()).m_49966_());
            }
        } else if (world.m_46803_(pos.m_7494_()) >= 9) {
            for (int i = 0; i < 4; ++i) {
                BlockPos blockpos = pos.m_7918_(random.m_188503_(3) - 1, random.m_188503_(5) - 3, random.m_188503_(3) - 1);
                if (!world.m_46749_(blockpos)) continue;
                BlockState stateAbove = world.m_8055_(blockpos.m_7494_());
                BlockState targetState = world.m_8055_(blockpos);
                if (!targetState.m_60713_((Block)MoCBlocks.wyvdirt.get()) || world.m_46803_(blockpos.m_7494_()) < 4 || stateAbove.m_60739_((BlockGetter)world, blockpos.m_7494_()) > 2) continue;
                world.m_46597_(blockpos, ((Block)MoCBlocks.wyvgrass.get()).m_49966_());
            }
        }
    }

    public boolean m_7370_(LevelReader world, BlockPos pos, BlockState state, boolean isClient) {
        return true;
    }

    public boolean m_214167_(Level world, RandomSource random, BlockPos pos, BlockState state) {
        return true;
    }

    public void m_214148_(ServerLevel world, RandomSource random, BlockPos pos, BlockState state) {
        BlockPos above = pos.m_7494_();
        if (this == MoCBlocks.wyvgrass.get()) {
            for (int i = 0; i < 128; ++i) {
                BlockPos spawnPos = above;
                for (int j = 0; j < i / 16 && world.m_8055_((spawnPos = spawnPos.m_7918_(random.m_188503_(3) - 1, (random.m_188503_(3) - 1) * random.m_188503_(3) / 2, random.m_188503_(3) - 1)).m_7495_()).m_60713_((Block)MoCBlocks.wyvgrass.get()) && !world.m_8055_(spawnPos).m_60838_((BlockGetter)world, spawnPos); ++j) {
                }
                if (!world.m_8055_(spawnPos).m_60795_()) continue;
                if (random.m_188503_(24) == 0) {
                    if (random.m_188499_()) {
                        world.m_7731_(spawnPos, Blocks.f_50072_.m_49966_(), 3);
                        continue;
                    }
                    world.m_7731_(spawnPos, Blocks.f_50073_.m_49966_(), 3);
                    continue;
                }
                if (random.m_188503_(8) == 0) {
                    List flowers = ((Biome)world.m_204166_(spawnPos).m_203334_()).m_47536_().m_47815_();
                    if (flowers.isEmpty()) continue;
                    ConfiguredFeature feature = (ConfiguredFeature)flowers.get(0);
                    BlockState beforeState = world.m_8055_(spawnPos);
                    feature.m_224953_((WorldGenLevel)world, world.m_7726_().m_8481_(), random, spawnPos);
                    BlockState afterState = world.m_8055_(spawnPos);
                    if (!afterState.m_60713_(Blocks.f_50034_) && !afterState.m_60713_(Blocks.f_50359_)) continue;
                    world.m_7731_(spawnPos, ((Block)MoCBlocks.tallWyvgrass.get()).m_49966_(), 3);
                    continue;
                }
                BlockState tallState = ((Block)MoCBlocks.tallWyvgrass.get()).m_49966_();
                if (!((MoCBlockTallGrass)((Object)MoCBlocks.tallWyvgrass.get())).m_7898_(tallState, (LevelReader)world, spawnPos)) continue;
                world.m_7731_(spawnPos, tallState, 3);
            }
        }
    }

    public boolean canSustainPlant(BlockState state, BlockGetter world, BlockPos pos, Direction facing, IPlantable plantable) {
        BlockState plantState = plantable.getPlant(world, pos.m_121945_(facing));
        if (plantState.m_60734_() instanceof MushroomBlock) {
            return true;
        }
        return super.canSustainPlant(state, world, pos, facing, plantable);
    }
}

