/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.level.block.RotatedPillarBlock
 *  net.minecraft.world.level.block.SoundType
 *  net.minecraft.world.level.block.state.BlockBehaviour$Properties
 *  net.minecraft.world.level.material.MapColor
 */
package drzhark.mocreatures.block;

import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;

public class MoCBlockLog
extends RotatedPillarBlock {
    public MoCBlockLog(BlockBehaviour.Properties properties) {
        super(properties.m_284180_(MapColor.f_283825_).m_60978_(2.0f).m_60918_(SoundType.f_56736_));
    }
}

