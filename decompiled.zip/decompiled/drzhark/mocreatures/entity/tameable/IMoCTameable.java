/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.Entity$RemovalReason
 */
package drzhark.mocreatures.entity.tameable;

import drzhark.mocreatures.entity.IMoCEntity;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.Entity;

public interface IMoCTameable
extends IMoCEntity {
    public boolean isRiderDisconnecting();

    public void setRiderDisconnecting(boolean var1);

    public void playTameEffect(boolean var1);

    public void setTamed(boolean var1);

    public void m_142687_(Entity.RemovalReason var1);

    public void m_7380_(CompoundTag var1);

    public void m_7378_(CompoundTag var1);

    public void setOwnerId(@Nullable UUID var1);

    public float getPetHealth();

    public void spawnHeart();

    public boolean readytoBreed();

    public String getOffspringClazz(IMoCTameable var1);

    public int getOffspringTypeInt(IMoCTameable var1);

    public boolean compatibleMate(Entity var1);

    public boolean getHasEaten();

    public void setHasEaten(boolean var1);

    public int getGestationTime();

    public void setGestationTime(int var1);
}

