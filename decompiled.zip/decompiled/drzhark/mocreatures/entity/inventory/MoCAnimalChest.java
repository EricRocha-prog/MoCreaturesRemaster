/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.network.chat.Component
 *  net.minecraft.world.LockCode
 *  net.minecraft.world.SimpleContainer
 */
package drzhark.mocreatures.entity.inventory;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.LockCode;
import net.minecraft.world.SimpleContainer;

public class MoCAnimalChest
extends SimpleContainer {
    private LockCode lockCode = LockCode.f_19102_;
    private Component name;
    private Size size;

    public MoCAnimalChest(String name, Size size) {
        super(size.numSlots);
        this.name = Component.m_237113_((String)name);
        this.size = size;
    }

    public Component getName() {
        return this.name;
    }

    public void write(CompoundTag nbttagcompound) {
        this.lockCode.m_19109_(nbttagcompound);
    }

    public void read(CompoundTag nbttagcompound) {
        this.lockCode = LockCode.m_19111_((CompoundTag)nbttagcompound);
    }

    public Size getSize() {
        return this.size;
    }

    public static enum Size {
        tiny(9, 1),
        small(18, 2),
        medium(27, 3),
        large(36, 4),
        huge(45, 5),
        gigantic(54, 6);

        private final int numSlots;
        private final int rows;

        private Size(int numSlots, int rows) {
            this.numSlots = numSlots;
            this.rows = rows;
        }

        public int getNumSlots() {
            return this.numSlots;
        }

        public int getRows() {
            return this.rows;
        }
    }
}

