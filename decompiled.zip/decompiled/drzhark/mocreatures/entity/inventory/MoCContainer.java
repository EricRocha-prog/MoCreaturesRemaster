/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.network.chat.Component
 *  net.minecraft.world.Container
 *  net.minecraft.world.LockCode
 *  net.minecraft.world.SimpleMenuProvider
 *  net.minecraft.world.entity.player.Inventory
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.inventory.AbstractContainerMenu
 *  net.minecraft.world.inventory.ChestMenu
 */
package drzhark.mocreatures.entity.inventory;

import drzhark.mocreatures.entity.inventory.MoCAnimalChest;
import javax.annotation.Nullable;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.LockCode;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ChestMenu;

public class MoCContainer {
    private LockCode lockCode = LockCode.f_19102_;
    private Component name;
    private MoCAnimalChest.Size size;
    private Container inventory;

    public MoCContainer(String name, MoCAnimalChest.Size size, Container inventory) {
        this.name = Component.m_237113_((String)name);
        this.size = size;
        this.inventory = inventory;
    }

    public Component getDisplayName() {
        return this.name;
    }

    public SimpleMenuProvider createMenuProvider() {
        return new SimpleMenuProvider((id, playerInventory, player) -> this.createMenu(id, playerInventory, player), this.name);
    }

    @Nullable
    public AbstractContainerMenu createMenu(int id, Inventory playerInventory, Player playerIn) {
        return switch (this.size.getRows()) {
            case 1 -> ChestMenu.m_39234_((int)id, (Inventory)playerInventory);
            case 2 -> ChestMenu.m_39243_((int)id, (Inventory)playerInventory);
            case 3 -> ChestMenu.m_39255_((int)id, (Inventory)playerInventory);
            case 4 -> ChestMenu.m_39258_((int)id, (Inventory)playerInventory);
            case 5 -> ChestMenu.m_39262_((int)id, (Inventory)playerInventory);
            case 6 -> ChestMenu.m_39266_((int)id, (Inventory)playerInventory);
            default -> ChestMenu.m_39255_((int)id, (Inventory)playerInventory);
        };
    }
}

