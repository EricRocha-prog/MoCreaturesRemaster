/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.particles.ParticleOptions
 *  net.minecraft.core.particles.ParticleTypes
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityDimensions
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.Pose
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.entity.hostile;

import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.entity.hostile.MoCEntityRat;
import drzhark.mocreatures.init.MoCLootTables;
import drzhark.mocreatures.init.MoCSoundEvents;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

public class MoCEntityHellRat
extends MoCEntityRat {
    private int textCounter;

    public MoCEntityHellRat(EntityType<? extends MoCEntityHellRat> type, Level world) {
        super((EntityType<? extends MoCEntityRat>)type, world);
        this.f_21364_ = 7;
    }

    public boolean m_5825_() {
        return true;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return MoCEntityRat.createAttributes().m_22268_(Attributes.f_22276_, 40.0).m_22268_(Attributes.f_22279_, 0.325).m_22268_(Attributes.f_22281_, 4.5).m_22268_(Attributes.f_22284_, 7.0);
    }

    @Override
    public void selectType() {
        this.setTypeMoC(4);
    }

    @Override
    public ResourceLocation getTexture() {
        if (this.f_19796_.m_188503_(2) == 0) {
            ++this.textCounter;
        }
        if (this.textCounter < 10) {
            this.textCounter = 10;
        }
        if (this.textCounter > 29) {
            this.textCounter = 10;
        }
        String textNumber = String.valueOf(this.textCounter);
        textNumber = textNumber.substring(0, 1);
        return MoCreatures.proxy.getModelTexture("hell_rat" + textNumber + ".png");
    }

    @Override
    protected SoundEvent m_5592_() {
        return (SoundEvent)MoCSoundEvents.ENTITY_HELL_RAT_DEATH.get();
    }

    @Override
    protected SoundEvent m_7975_(DamageSource source) {
        return (SoundEvent)MoCSoundEvents.ENTITY_HELL_RAT_HURT.get();
    }

    @Override
    protected SoundEvent m_7515_() {
        return (SoundEvent)MoCSoundEvents.ENTITY_HELL_RAT_AMBIENT.get();
    }

    @Override
    protected ResourceLocation m_7582_() {
        return MoCLootTables.HELL_RAT;
    }

    @Override
    public boolean m_7327_(Entity entityIn) {
        boolean flag = super.m_7327_(entityIn);
        if (flag && entityIn instanceof LivingEntity) {
            entityIn.m_20254_(5);
        }
        return flag;
    }

    @Override
    public void m_8107_() {
        if (this.m_9236_().m_5776_()) {
            for (int i = 0; i < 2; ++i) {
                this.m_9236_().m_7106_((ParticleOptions)ParticleTypes.f_123744_, this.m_20185_() + (this.f_19796_.m_188500_() - 0.5) * (double)this.m_20205_(), this.m_20186_() + this.f_19796_.m_188500_() * (double)this.m_20206_(), this.m_20189_() + (this.f_19796_.m_188500_() - 0.5) * (double)this.m_20205_(), 0.0, 0.0, 0.0);
            }
        }
        super.m_8107_();
    }

    @Override
    protected float m_6431_(Pose poseIn, EntityDimensions sizeIn) {
        return this.m_20206_() * 0.485f;
    }
}

