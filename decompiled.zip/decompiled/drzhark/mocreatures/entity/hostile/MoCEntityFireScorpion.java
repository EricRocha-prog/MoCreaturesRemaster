/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.entity.hostile;

import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.entity.hostile.MoCEntityScorpion;
import drzhark.mocreatures.init.MoCLootTables;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

public class MoCEntityFireScorpion
extends MoCEntityScorpion {
    public MoCEntityFireScorpion(EntityType<? extends MoCEntityFireScorpion> type, Level world) {
        super(type, world, 3);
        this.f_21364_ = 7;
    }

    public boolean m_5825_() {
        return true;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return MoCEntityScorpion.createAttributes().m_22268_(Attributes.f_22277_, 24.0).m_22268_(Attributes.f_22276_, 30.0).m_22268_(Attributes.f_22279_, 0.34).m_22268_(Attributes.f_22281_, 4.0).m_22268_(Attributes.f_22284_, 5.0);
    }

    @Override
    public ResourceLocation getTexture() {
        return MoCreatures.proxy.getModelTexture("scorpion_fire.png");
    }

    public void m_19970_(LivingEntity attacker, Entity target) {
        if (!this.getIsPoisoning() && this.f_19796_.m_188503_(5) == 0 && target instanceof LivingEntity) {
            this.setPoisoning(true);
            target.m_20254_(15);
        } else {
            this.swingArm();
        }
        super.m_19970_(attacker, target);
    }

    protected ResourceLocation m_7582_() {
        return MoCLootTables.FIRE_SCORPION;
    }
}

