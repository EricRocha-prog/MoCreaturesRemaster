/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.entity.hostile;

import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.entity.hostile.MoCEntityOgre;
import drzhark.mocreatures.init.MoCLootTables;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

public class MoCEntityFireOgre
extends MoCEntityOgre {
    public MoCEntityFireOgre(EntityType<? extends MoCEntityFireOgre> type, Level world) {
        super((EntityType<? extends MoCEntityOgre>)type, world);
    }

    public boolean m_5825_() {
        return true;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return MoCEntityOgre.createAttributes().m_22268_(Attributes.f_22276_, 65.0).m_22268_(Attributes.f_22284_, 9.0).m_22268_(Attributes.f_22281_, 7.5);
    }

    @Override
    public ResourceLocation getTexture() {
        return MoCreatures.proxy.getModelTexture("ogre_fire.png");
    }

    @Override
    public boolean isFireStarter() {
        return true;
    }

    @Override
    public float getDestroyForce() {
        return MoCreatures.proxy.ogreFireStrength;
    }

    @Override
    public void m_8107_() {
        super.m_8107_();
        if (this.m_20071_()) {
            this.m_6469_(this.m_269291_().m_269063_(), 1.0f);
        }
    }

    protected ResourceLocation m_7582_() {
        return MoCLootTables.FIRE_OGRE;
    }
}

