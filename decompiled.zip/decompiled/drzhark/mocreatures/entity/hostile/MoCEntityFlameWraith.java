/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.particles.ParticleOptions
 *  net.minecraft.core.particles.ParticleTypes
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.util.Mth
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.entity.monster.Enemy
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.entity.hostile;

import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.entity.hostile.MoCEntityWraith;
import drzhark.mocreatures.init.MoCLootTables;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.Level;

public class MoCEntityFlameWraith
extends MoCEntityWraith
implements Enemy {
    protected int burningTime;

    public MoCEntityFlameWraith(EntityType<? extends MoCEntityFlameWraith> type, Level world) {
        super((EntityType<? extends MoCEntityWraith>)type, world);
        this.texture = MoCreatures.proxy.alphaWraithEyes ? "wraith_flame_alpha.png" : "wraith_flame.png";
        this.burningTime = 30;
        this.f_21364_ = 7;
    }

    public boolean m_5825_() {
        return true;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return MoCEntityWraith.createAttributes().m_22268_(Attributes.f_22276_, 25.0).m_22268_(Attributes.f_22281_, 4.0);
    }

    @Override
    protected ResourceLocation m_7582_() {
        return MoCLootTables.FLAME_WRAITH;
    }

    @Override
    public void m_8107_() {
        if (!this.m_9236_().m_5776_()) {
            float f;
            if (this.m_9236_().m_46461_() && (f = this.m_213856_()) > 0.5f && this.m_9236_().m_45527_(new BlockPos(Mth.m_14107_((double)this.m_20185_()), Mth.m_14107_((double)this.m_20186_()), Mth.m_14107_((double)this.m_20189_()))) && this.f_19796_.m_188501_() * 30.0f < (f - 0.4f) * 2.0f) {
                this.m_21153_(this.m_21223_() - 2.0f);
            }
        } else {
            for (int i = 0; i < 2; ++i) {
                this.m_9236_().m_7106_((ParticleOptions)ParticleTypes.f_123744_, this.m_20185_() + (this.f_19796_.m_188500_() - 0.5) * (double)this.m_20205_(), this.m_20186_() + this.f_19796_.m_188500_() * (double)this.m_20206_(), this.m_20189_() + (this.f_19796_.m_188500_() - 0.5) * (double)this.m_20205_(), 0.0, 0.0, 0.0);
            }
        }
        super.m_8107_();
    }

    public void m_19970_(LivingEntity attacker, Entity target) {
        if (!this.m_9236_().m_5776_() && !this.m_9236_().m_6042_().f_63857_()) {
            target.m_20254_(this.burningTime);
        }
        super.m_19970_(attacker, target);
    }
}

