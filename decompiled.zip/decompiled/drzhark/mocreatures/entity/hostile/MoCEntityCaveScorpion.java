/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.server.level.ServerLevel
 *  net.minecraft.world.effect.MobEffectInstance
 *  net.minecraft.world.effect.MobEffects
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.MobSpawnType
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.entity.hostile;

import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.entity.MoCEntityMob;
import drzhark.mocreatures.entity.hostile.MoCEntityScorpion;
import drzhark.mocreatures.init.MoCLootTables;
import java.util.Random;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

public class MoCEntityCaveScorpion
extends MoCEntityScorpion {
    public MoCEntityCaveScorpion(EntityType<? extends MoCEntityCaveScorpion> type, Level world) {
        super(type, world, 2);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return MoCEntityScorpion.createAttributes().m_22268_(Attributes.f_22277_, 24.0).m_22268_(Attributes.f_22276_, 20.0).m_22268_(Attributes.f_22279_, 0.325).m_22268_(Attributes.f_22281_, 3.5).m_22268_(Attributes.f_22284_, 4.0);
    }

    @Override
    public ResourceLocation getTexture() {
        return MoCreatures.proxy.getModelTexture("scorpion_cave.png");
    }

    public void m_19970_(LivingEntity attacker, Entity target) {
        if (!this.getIsPoisoning() && this.f_19796_.m_188503_(5) == 0 && target instanceof LivingEntity) {
            LivingEntity livingTarget = (LivingEntity)target;
            this.setPoisoning(true);
            livingTarget.m_7292_(new MobEffectInstance(MobEffects.f_19604_, 300, 0));
            livingTarget.m_7292_(new MobEffectInstance(MobEffects.f_19613_, 300, 0));
        } else {
            this.swingArm();
        }
        super.m_19970_(attacker, target);
    }

    public static boolean getCanSpawnHere(EntityType<? extends MoCEntityMob> type, ServerLevel world, MobSpawnType reason, BlockPos pos, Random randomIn) {
        return MoCEntityScorpion.getCanSpawnHere(type, world, reason, pos, randomIn) && !world.m_45527_(pos) && (double)pos.m_123342_() < 50.0;
    }

    protected ResourceLocation m_7582_() {
        return MoCLootTables.CAVE_SCORPION;
    }
}

