/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.chat.Component
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityDimensions
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.Mob
 *  net.minecraft.world.entity.MobType
 *  net.minecraft.world.entity.PathfinderMob
 *  net.minecraft.world.entity.Pose
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.entity.ai.goal.Goal
 *  net.minecraft.world.entity.ai.goal.LookAtPlayerGoal
 *  net.minecraft.world.entity.ai.goal.MeleeAttackGoal
 *  net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal
 *  net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal
 *  net.minecraft.world.entity.animal.IronGolem
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.level.Level
 *  net.minecraftforge.network.PacketDistributor
 *  net.minecraftforge.network.PacketDistributor$TargetPoint
 */
package drzhark.mocreatures.entity.hostile;

import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.entity.MoCEntityMob;
import drzhark.mocreatures.init.MoCLootTables;
import drzhark.mocreatures.init.MoCSoundEvents;
import drzhark.mocreatures.network.MoCMessageHandler;
import drzhark.mocreatures.network.message.MoCMessageAnimation;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.PacketDistributor;

public class MoCEntityWraith
extends MoCEntityMob {
    public int attackCounter;

    public MoCEntityWraith(EntityType<? extends MoCEntityWraith> type, Level world) {
        super(type, world);
        this.f_19863_ = false;
        this.f_21364_ = 5;
    }

    protected void m_8099_() {
        this.f_21345_.m_25352_(2, (Goal)new MeleeAttackGoal((PathfinderMob)this, 1.0, true));
        this.f_21345_.m_25352_(8, (Goal)new LookAtPlayerGoal((Mob)this, Player.class, 8.0f));
        this.f_21346_.m_25352_(1, (Goal)new HurtByTargetGoal((PathfinderMob)this, new Class[0]));
        this.f_21346_.m_25352_(2, (Goal)new NearestAttackableTargetGoal((Mob)this, Player.class, true));
        this.f_21346_.m_25352_(3, (Goal)new NearestAttackableTargetGoal((Mob)this, IronGolem.class, true));
    }

    public static AttributeSupplier.Builder createAttributes() {
        return MoCEntityMob.createAttributes().m_22268_(Attributes.f_22281_, 3.0).m_22268_(Attributes.f_22276_, 20.0).m_22268_(Attributes.f_22279_, 0.25);
    }

    @Override
    public void selectType() {
        if (this.getTypeMoC() == 0) {
            int i = this.f_19796_.m_188503_(100);
            if (i < 5 && MoCreatures.proxy.easterEggs) {
                this.setTypeMoC(2);
                this.m_6593_((Component)Component.m_237113_((String)"Scratch"));
            } else {
                this.setTypeMoC(1);
            }
        }
    }

    @Override
    public ResourceLocation getTexture() {
        if (this.getTypeMoC() == 2) {
            return MoCreatures.proxy.getModelTexture("wraith_scratch.png");
        }
        return MoCreatures.proxy.getModelTexture(MoCreatures.proxy.alphaWraithEyes ? "wraith_alpha.png" : "wraith.png");
    }

    protected SoundEvent m_5592_() {
        return MoCreatures.proxy.legacyWraithSounds ? (SoundEvent)MoCSoundEvents.ENTITY_WRAITH_DEATH_LEGACY.get() : (SoundEvent)MoCSoundEvents.ENTITY_WRAITH_DEATH.get();
    }

    protected SoundEvent m_7975_(DamageSource source) {
        return MoCreatures.proxy.legacyWraithSounds ? (SoundEvent)MoCSoundEvents.ENTITY_WRAITH_HURT_LEGACY.get() : (SoundEvent)MoCSoundEvents.ENTITY_WRAITH_HURT.get();
    }

    protected SoundEvent m_7515_() {
        return MoCreatures.proxy.legacyWraithSounds ? (SoundEvent)MoCSoundEvents.ENTITY_WRAITH_AMBIENT_LEGACY.get() : (SoundEvent)MoCSoundEvents.ENTITY_WRAITH_AMBIENT.get();
    }

    protected ResourceLocation m_7582_() {
        return MoCLootTables.WRAITH;
    }

    public MobType m_6336_() {
        return MobType.f_21641_;
    }

    @Override
    public boolean isFlyer() {
        return true;
    }

    public boolean m_6094_() {
        return false;
    }

    protected void m_7324_(Entity entity) {
    }

    @Override
    public boolean m_142535_(float distance, float damageMultiplier, DamageSource source) {
        return false;
    }

    @Override
    public int maxFlyingHeight() {
        return 10;
    }

    @Override
    public int minFlyingHeight() {
        return 3;
    }

    @Override
    public boolean m_7327_(Entity entityIn) {
        this.startArmSwingAttack();
        return super.m_7327_(entityIn);
    }

    private void startArmSwingAttack() {
        if (!this.m_9236_().m_5776_()) {
            this.attackCounter = 1;
            MoCMessageHandler.INSTANCE.send(PacketDistributor.NEAR.with(() -> new PacketDistributor.TargetPoint(this.m_20185_(), this.m_20186_(), this.m_20189_(), 64.0, this.m_9236_().m_46472_())), (Object)new MoCMessageAnimation(this.m_19879_(), 1));
        }
    }

    public void m_8107_() {
        if (this.attackCounter > 0) {
            this.attackCounter += 2;
            if (this.attackCounter > 10) {
                this.attackCounter = 0;
            }
        }
        super.m_8107_();
    }

    @Override
    public void performAnimation(int animationType) {
        if (animationType == 1) {
            this.attackCounter = 1;
        }
    }

    @Override
    protected boolean isDaylightSensitive() {
        return true;
    }

    protected float m_6431_(Pose poseIn, EntityDimensions sizeIn) {
        return this.m_20206_() * 0.86f;
    }
}

