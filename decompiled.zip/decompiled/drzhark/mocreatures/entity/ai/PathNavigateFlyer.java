/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Mob
 *  net.minecraft.world.entity.ai.navigation.FlyingPathNavigation
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.entity.ai;

import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.level.Level;

public class PathNavigateFlyer
extends FlyingPathNavigation {
    public PathNavigateFlyer(Mob mob, Level level) {
        super(mob, level);
        this.m_26440_(false);
        this.m_7008_(true);
        this.m_26443_(true);
    }

    protected boolean m_7632_() {
        return true;
    }
}

