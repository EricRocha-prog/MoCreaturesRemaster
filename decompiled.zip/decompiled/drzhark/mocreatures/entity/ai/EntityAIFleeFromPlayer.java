/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.Vec3i
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.PathfinderMob
 *  net.minecraft.world.entity.ai.goal.Goal
 *  net.minecraft.world.entity.ai.goal.Goal$Flag
 *  net.minecraft.world.entity.ai.util.DefaultRandomPos
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.phys.Vec3
 */
package drzhark.mocreatures.entity.ai;

import drzhark.mocreatures.entity.IMoCEntity;
import java.util.EnumSet;
import net.minecraft.core.Vec3i;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

public class EntityAIFleeFromPlayer
extends Goal {
    private final PathfinderMob mob;
    protected double speed;
    protected double distance;
    private double randPosX;
    private double randPosY;
    private double randPosZ;

    public EntityAIFleeFromPlayer(PathfinderMob creature, double speedIn, double distanceToCheck) {
        this.mob = creature;
        this.distance = distanceToCheck;
        this.speed = speedIn;
        this.m_7021_(EnumSet.of(Goal.Flag.MOVE));
    }

    public boolean m_8036_() {
        if (this.mob instanceof IMoCEntity && ((IMoCEntity)this.mob).isNotScared()) {
            return false;
        }
        if (!this.IsNearPlayer(this.distance)) {
            return false;
        }
        Vec3 vec3 = DefaultRandomPos.m_148407_((PathfinderMob)this.mob, (int)5, (int)4, (Vec3)Vec3.m_82539_((Vec3i)this.mob.m_20183_()));
        if (vec3 == null) {
            return false;
        }
        this.randPosX = vec3.f_82479_;
        this.randPosY = vec3.f_82480_;
        this.randPosZ = vec3.f_82481_;
        return true;
    }

    protected boolean IsNearPlayer(double d) {
        Player player = this.mob.m_9236_().m_45930_((Entity)this.mob, d);
        return player != null;
    }

    public void m_8056_() {
        this.mob.m_21573_().m_26519_(this.randPosX, this.randPosY, this.randPosZ, this.speed);
    }

    public boolean m_8045_() {
        return !this.mob.m_21573_().m_26571_();
    }
}

