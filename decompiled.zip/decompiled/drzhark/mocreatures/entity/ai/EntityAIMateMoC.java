/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.advancements.CriteriaTriggers
 *  net.minecraft.core.particles.ParticleOptions
 *  net.minecraft.core.particles.ParticleTypes
 *  net.minecraft.server.level.ServerLevel
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraft.stats.Stats
 *  net.minecraft.util.RandomSource
 *  net.minecraft.world.entity.AgeableMob
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.ExperienceOrb
 *  net.minecraft.world.entity.ai.goal.Goal
 *  net.minecraft.world.entity.ai.goal.Goal$Flag
 *  net.minecraft.world.entity.animal.Animal
 *  net.minecraft.world.level.GameRules
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.entity.ai;

import drzhark.mocreatures.entity.passive.MoCEntityTurkey;
import drzhark.mocreatures.entity.tameable.MoCEntityTameableAnimal;
import java.util.EnumSet;
import java.util.List;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.stats.Stats;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;

public class EntityAIMateMoC
extends Goal {
    private final MoCEntityTameableAnimal animal;
    private final Class<? extends MoCEntityTameableAnimal> mateClass;
    Level level;
    int spawnBabyDelay;
    double moveSpeed;
    private MoCEntityTameableAnimal targetMate;

    public EntityAIMateMoC(MoCEntityTameableAnimal animal, double speedIn) {
        this(animal, speedIn, animal.getClass());
    }

    public EntityAIMateMoC(MoCEntityTameableAnimal p_i47306_1_, double p_i47306_2_, Class<? extends MoCEntityTameableAnimal> p_i47306_4_) {
        this.animal = p_i47306_1_;
        this.level = p_i47306_1_.m_9236_();
        this.mateClass = p_i47306_4_;
        this.moveSpeed = p_i47306_2_;
        this.m_7021_(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
    }

    public boolean m_8036_() {
        if (!this.animal.m_27593_()) {
            return false;
        }
        this.targetMate = this.getNearbyMate();
        return this.targetMate != null;
    }

    public boolean m_8045_() {
        return this.targetMate.m_6084_() && this.targetMate.m_27593_() && this.spawnBabyDelay < 60;
    }

    public void m_8041_() {
        this.targetMate = null;
        this.spawnBabyDelay = 0;
    }

    public void m_8037_() {
        this.animal.m_21563_().m_24960_((Entity)this.targetMate, 10.0f, (float)this.animal.m_8132_());
        this.animal.m_21573_().m_5624_((Entity)this.targetMate, this.moveSpeed);
        ++this.spawnBabyDelay;
        if (this.spawnBabyDelay >= 60 && this.animal.m_20280_((Entity)this.targetMate) < 9.0) {
            this.spawnBaby();
        }
    }

    private MoCEntityTameableAnimal getNearbyMate() {
        List list = this.level.m_45976_(this.mateClass, this.animal.m_20191_().m_82400_(8.0));
        double d0 = Double.MAX_VALUE;
        MoCEntityTameableAnimal entityanimal = null;
        for (MoCEntityTameableAnimal entityanimal1 : list) {
            if (this.animal.getClass() != entityanimal1.getClass() || !(this.animal.m_20280_((Entity)entityanimal1) < d0)) continue;
            entityanimal = entityanimal1;
            d0 = this.animal.m_20280_((Entity)entityanimal1);
        }
        return entityanimal;
    }

    private void spawnBaby() {
        AgeableMob entityageable = this.animal.m_142606_((ServerLevel)this.level, (AgeableMob)this.targetMate);
        if (entityageable != null) {
            ServerPlayer entityplayermp = this.animal.m_27592_();
            if (entityplayermp == null && this.targetMate.m_27592_() != null) {
                entityplayermp = this.targetMate.m_27592_();
            }
            if (entityplayermp != null) {
                entityplayermp.m_36220_(Stats.f_12937_);
                CriteriaTriggers.f_10581_.m_147278_(entityplayermp, (Animal)this.animal, (Animal)this.targetMate, entityageable);
            }
            if (this.animal.getTypeMoC() != 1) {
                this.animal.setMoCAge(6000);
                this.animal.m_27594_();
            }
            if (this.targetMate.getTypeMoC() != 1) {
                this.targetMate.setMoCAge(6000);
                this.targetMate.m_27594_();
            }
            entityageable.m_146762_(-24000);
            entityageable.m_7678_(this.animal.m_20185_(), this.animal.m_20186_(), this.animal.m_20189_(), 0.0f, 0.0f);
            if (entityageable instanceof MoCEntityTurkey) {
                ((MoCEntityTurkey)entityageable).selectType();
            }
            this.level.m_7967_((Entity)entityageable);
            RandomSource random = this.animal.m_217043_();
            for (int i = 0; i < 7; ++i) {
                double d0 = random.m_188583_() * 0.02;
                double d1 = random.m_188583_() * 0.02;
                double d2 = random.m_188583_() * 0.02;
                double d3 = random.m_188500_() * (double)this.animal.m_20205_() * 2.0 - (double)this.animal.m_20205_();
                double d4 = 0.5 + random.m_188500_() * (double)this.animal.m_20206_();
                double d5 = random.m_188500_() * (double)this.animal.m_20205_() * 2.0 - (double)this.animal.m_20205_();
                this.level.m_7106_((ParticleOptions)ParticleTypes.f_123750_, this.animal.m_20185_() + d3, this.animal.m_20186_() + d4, this.animal.m_20189_() + d5, d0, d1, d2);
            }
            if (this.level.m_46469_().m_46207_(GameRules.f_46135_)) {
                this.level.m_7967_((Entity)new ExperienceOrb(this.level, this.animal.m_20185_(), this.animal.m_20186_(), this.animal.m_20189_(), random.m_188503_(7) + 1));
            }
        }
    }
}

