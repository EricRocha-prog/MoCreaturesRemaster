/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.Mob
 *  net.minecraft.world.entity.ai.goal.Goal
 *  net.minecraft.world.entity.ai.goal.Goal$Flag
 *  net.minecraft.world.phys.AABB
 */
package drzhark.mocreatures.entity.ai;

import drzhark.mocreatures.entity.IMoCEntity;
import java.util.EnumSet;
import java.util.List;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.AABB;

public class EntityAIFollowHerd
extends Goal {
    Mob theAnimal;
    Mob herdAnimal;
    double moveSpeed;
    double maxRange;
    double minRange;
    private int delayCounter;
    private int executionChance;

    public EntityAIFollowHerd(Mob animal, double speed, double minRangeIn, double maxRangeIn, int chance) {
        this.theAnimal = animal;
        this.moveSpeed = speed;
        this.minRange = minRangeIn;
        this.maxRange = maxRangeIn;
        this.executionChance = chance;
        this.m_7021_(EnumSet.of(Goal.Flag.MOVE));
    }

    public EntityAIFollowHerd(Mob animal, double speed) {
        this(animal, speed, 4.0, 20.0, 120);
    }

    public boolean m_8036_() {
        if (this.theAnimal.m_217043_().m_188503_(this.executionChance) != 0) {
            return false;
        }
        AABB searchBox = this.theAnimal.m_20191_().m_82377_(this.maxRange, 4.0, this.maxRange);
        List list = this.theAnimal.m_9236_().m_45976_(this.theAnimal.getClass(), searchBox);
        Mob entityliving = null;
        double d0 = Double.MAX_VALUE;
        for (Object entity : list) {
            Mob entityliving1;
            double d1;
            if (!(entity instanceof Mob) || !((d1 = this.theAnimal.m_20280_((Entity)(entityliving1 = (Mob)entity))) >= this.minRange) || this.theAnimal == entityliving1) continue;
            d0 = d1;
            entityliving = entityliving1;
        }
        if (entityliving == null) {
            return false;
        }
        if (d0 < this.maxRange) {
            return false;
        }
        this.herdAnimal = entityliving;
        return true;
    }

    public boolean m_8045_() {
        if (this.theAnimal instanceof IMoCEntity && ((IMoCEntity)this.theAnimal).isMovementCeased()) {
            return false;
        }
        if (!this.herdAnimal.m_6084_()) {
            return false;
        }
        double d0 = this.theAnimal.m_20280_((Entity)this.herdAnimal);
        return d0 >= this.minRange && d0 <= this.maxRange;
    }

    public void m_8056_() {
        this.delayCounter = 0;
    }

    public void m_8041_() {
        this.herdAnimal = null;
    }

    public void m_8037_() {
        if (--this.delayCounter <= 0) {
            this.delayCounter = 20;
            this.theAnimal.m_21573_().m_5624_((Entity)this.herdAnimal, this.moveSpeed);
        }
    }

    public void setExecutionChance(int newchance) {
        this.executionChance = newchance;
    }
}

