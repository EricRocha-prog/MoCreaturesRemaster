/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.Mob
 *  net.minecraft.world.entity.PathfinderMob
 *  net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal
 */
package drzhark.mocreatures.entity.ai;

import drzhark.mocreatures.entity.tameable.IMoCTameable;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;

public class EntityAITargetNonTamedMoC<T extends LivingEntity>
extends NearestAttackableTargetGoal<T> {
    private final PathfinderMob tameable;

    public EntityAITargetNonTamedMoC(PathfinderMob creature, Class<T> classTarget, boolean checkSight) {
        super((Mob)creature, classTarget, checkSight);
        this.tameable = creature;
    }

    public boolean m_8036_() {
        return this.tameable instanceof IMoCTameable && !((IMoCTameable)this.tameable).getIsTamed() && super.m_8036_();
    }
}

