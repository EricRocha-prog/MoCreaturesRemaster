/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.Mob
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.entity.ai;

import drzhark.mocreatures.entity.tameable.IMoCTameable;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class EntityAITools {
    protected static boolean IsNearPlayer(Mob entityliving, double d) {
        Player entityplayer1 = entityliving.m_9236_().m_45930_((Entity)entityliving, d);
        return entityplayer1 != null;
    }

    protected static Player getIMoCTameableOwner(IMoCTameable pet) {
        if (pet.getOwnerId() == null) {
            return null;
        }
        Mob mobEntity = (Mob)pet;
        Level level = mobEntity.m_9236_();
        for (int i = 0; i < level.m_6907_().size(); ++i) {
            Player entityplayer = (Player)level.m_6907_().get(i);
            if (!pet.getOwnerId().equals(entityplayer.m_20148_())) continue;
            return entityplayer;
        }
        return null;
    }
}

