/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.core.BlockPos
 *  net.minecraft.util.Mth
 *  net.minecraft.util.RandomSource
 *  net.minecraft.world.entity.PathfinderMob
 *  net.minecraft.world.entity.ai.navigation.PathNavigation
 *  net.minecraft.world.phys.Vec3
 */
package drzhark.mocreatures.entity.ai;

import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.phys.Vec3;

public class RandomPositionGeneratorMoCFlyer {
    private static Vec3 staticVector = Vec3.f_82478_;

    @Nullable
    public static Vec3 findRandomTarget(PathfinderMob entitycreatureIn, int xz, int y) {
        return RandomPositionGeneratorMoCFlyer.findRandomTargetBlock(entitycreatureIn, xz, y, null);
    }

    @Nullable
    public static Vec3 findRandomTargetBlockTowards(PathfinderMob entitycreatureIn, int xz, int y, Vec3 targetVec3) {
        staticVector = targetVec3.m_82492_(entitycreatureIn.m_20185_(), entitycreatureIn.m_20186_(), entitycreatureIn.m_20189_());
        return RandomPositionGeneratorMoCFlyer.findRandomTargetBlock(entitycreatureIn, xz, y, staticVector);
    }

    @Nullable
    public static Vec3 findRandomTargetBlockAwayFrom(PathfinderMob entitycreatureIn, int xz, int y, Vec3 targetVec3) {
        staticVector = new Vec3(entitycreatureIn.m_20185_(), entitycreatureIn.m_20186_(), entitycreatureIn.m_20189_()).m_82546_(targetVec3);
        return RandomPositionGeneratorMoCFlyer.findRandomTargetBlock(entitycreatureIn, xz, y, staticVector);
    }

    @Nullable
    private static Vec3 findRandomTargetBlock(PathfinderMob entitycreatureIn, int xz, int y, @Nullable Vec3 targetVec3) {
        double d1;
        double d0;
        PathNavigation pathnavigate = entitycreatureIn.m_21573_();
        RandomSource random = entitycreatureIn.m_217043_();
        boolean flag = false;
        int i = 0;
        int j = 0;
        int k = 0;
        float f = -99999.0f;
        boolean flag1 = entitycreatureIn.m_21536_() ? (d0 = entitycreatureIn.m_21534_().m_203198_((double)Mth.m_14107_((double)entitycreatureIn.m_20185_()), (double)Mth.m_14107_((double)entitycreatureIn.m_20186_()), (double)Mth.m_14107_((double)entitycreatureIn.m_20189_())) + 4.0) < (d1 = (double)(entitycreatureIn.m_21535_() + (float)xz)) * d1 : false;
        for (int j1 = 0; j1 < 10; ++j1) {
            float f1;
            int l = random.m_188503_(2 * xz + 1) - xz;
            int k1 = random.m_188503_(2 * y + 1) - y;
            int i1 = random.m_188503_(2 * xz + 1) - xz;
            if (targetVec3 != null && !((double)l * targetVec3.f_82479_ + (double)i1 * targetVec3.f_82481_ >= 0.0)) continue;
            if (entitycreatureIn.m_21536_() && xz > 1) {
                BlockPos blockpos = entitycreatureIn.m_21534_();
                l = entitycreatureIn.m_20185_() > (double)blockpos.m_123341_() ? (l -= random.m_188503_(xz / 2)) : (l += random.m_188503_(xz / 2));
                i1 = entitycreatureIn.m_20189_() > (double)blockpos.m_123343_() ? (i1 -= random.m_188503_(xz / 2)) : (i1 += random.m_188503_(xz / 2));
            }
            BlockPos blockpos1 = new BlockPos((int)((double)l + entitycreatureIn.m_20185_()), (int)((double)k1 + entitycreatureIn.m_20186_()), (int)((double)i1 + entitycreatureIn.m_20189_()));
            if (flag1 && !entitycreatureIn.m_21444_(blockpos1) || !((f1 = entitycreatureIn.m_21692_(blockpos1)) > f)) continue;
            f = f1;
            i = l;
            j = k1;
            k = i1;
            flag = true;
        }
        if (flag) {
            return new Vec3((double)i + entitycreatureIn.m_20185_(), (double)j + entitycreatureIn.m_20186_(), (double)k + entitycreatureIn.m_20189_());
        }
        return null;
    }
}

