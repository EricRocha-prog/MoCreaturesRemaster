/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.Mob
 *  net.minecraft.world.entity.ai.goal.Goal
 *  net.minecraft.world.entity.ai.goal.Goal$Flag
 *  net.minecraft.world.phys.AABB
 */
package drzhark.mocreatures.entity.ai;

import drzhark.mocreatures.entity.IMoCEntity;
import java.util.EnumSet;
import java.util.List;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.AABB;

public class EntityAIFollowAdult
extends Goal {
    Mob childAnimal;
    Mob parentAnimal;
    double moveSpeed;
    private int delayCounter;

    public EntityAIFollowAdult(Mob animal, double speed) {
        this.childAnimal = animal;
        this.moveSpeed = speed;
        this.m_7021_(EnumSet.of(Goal.Flag.MOVE));
    }

    public boolean m_8036_() {
        if (((IMoCEntity)this.childAnimal).getIsSitting()) {
            return false;
        }
        if (!(this.childAnimal instanceof IMoCEntity) || ((IMoCEntity)this.childAnimal).getIsAdult()) {
            return false;
        }
        AABB searchBox = this.childAnimal.m_20191_().m_82377_(8.0, 4.0, 8.0);
        List list = this.childAnimal.m_9236_().m_45976_(this.childAnimal.getClass(), searchBox);
        Mob entityliving = null;
        double d0 = Double.MAX_VALUE;
        for (Object entity : list) {
            double d1;
            Mob entityliving1;
            if (!(entity instanceof Mob) || !(entity instanceof IMoCEntity) || !((IMoCEntity)(entityliving1 = (Mob)entity)).getIsAdult() || !((d1 = this.childAnimal.m_20280_((Entity)entityliving1)) <= d0)) continue;
            d0 = d1;
            entityliving = entityliving1;
        }
        if (entityliving == null) {
            return false;
        }
        if (d0 < 9.0) {
            return false;
        }
        this.parentAnimal = entityliving;
        return true;
    }

    public boolean m_8045_() {
        if (((IMoCEntity)this.childAnimal).getIsSitting()) {
            return false;
        }
        if (((IMoCEntity)this.childAnimal).getIsAdult()) {
            return false;
        }
        if (!this.parentAnimal.m_6084_()) {
            return false;
        }
        double d0 = this.childAnimal.m_20280_((Entity)this.parentAnimal);
        return d0 >= 9.0 && d0 <= 256.0;
    }

    public void m_8056_() {
        this.delayCounter = 0;
    }

    public void m_8041_() {
        this.parentAnimal = null;
    }

    public void m_8037_() {
        if (--this.delayCounter <= 0) {
            this.delayCounter = 10;
            this.childAnimal.m_21573_().m_5624_((Entity)this.parentAnimal, this.moveSpeed);
        }
    }
}

