/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.LivingEntity
 */
package drzhark.mocreatures.entity;

import java.util.UUID;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;

public interface IMoCEntity {
    public void selectType();

    public String getPetName();

    public void setPetName(String var1);

    public int getOwnerPetId();

    public void setOwnerPetId(int var1);

    public UUID getOwnerId();

    public boolean getIsTamed();

    public boolean getIsAdult();

    public boolean getIsGhost();

    public void setAdult(boolean var1);

    public boolean checkSpawningBiome();

    public void performAnimation(int var1);

    public boolean renderName();

    public int nameYOffset();

    public void makeEntityJump();

    public void makeEntityDive();

    public float getSizeFactor();

    public float getAdjustedYOffset();

    public void setArmorType(int var1);

    public int getTypeMoC();

    public void setTypeMoC(int var1);

    public float rollRotationOffset();

    public float pitchRotationOffset();

    public int getMoCAge();

    public void setMoCAge(int var1);

    public float yawRotationOffset();

    public float getAdjustedZOffset();

    public float getAdjustedXOffset();

    public ResourceLocation getTexture();

    public boolean canAttackTarget(LivingEntity var1);

    public boolean getIsSitting();

    public boolean isNotScared();

    public boolean isMovementCeased();

    public boolean shouldAttackPlayers();

    public double getDivingDepth();

    public boolean isDiving();

    public void forceEntityJump();

    public int maxFlyingHeight();

    public int minFlyingHeight();

    public boolean isFlyer();

    public boolean getIsFlying();
}

