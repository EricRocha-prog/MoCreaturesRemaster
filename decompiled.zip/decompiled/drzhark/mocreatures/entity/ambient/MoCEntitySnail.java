/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.network.syncher.EntityDataAccessor
 *  net.minecraft.network.syncher.EntityDataSerializer
 *  net.minecraft.network.syncher.EntityDataSerializers
 *  net.minecraft.network.syncher.SynchedEntityData
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.sounds.SoundEvents
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.entity.ai.goal.Goal
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.entity.ambient;

import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.entity.MoCEntityAmbient;
import drzhark.mocreatures.entity.ai.EntityAIWanderMoC2;
import drzhark.mocreatures.init.MoCLootTables;
import javax.annotation.Nullable;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializer;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.Level;

public class MoCEntitySnail
extends MoCEntityAmbient {
    private static final EntityDataAccessor<Boolean> IS_HIDING = SynchedEntityData.m_135353_(MoCEntitySnail.class, (EntityDataSerializer)EntityDataSerializers.f_135035_);

    public MoCEntitySnail(EntityType<? extends MoCEntitySnail> type, Level world) {
        super(type, world);
    }

    protected void m_8099_() {
        this.f_21345_.m_25352_(1, (Goal)new EntityAIWanderMoC2(this, 0.8));
    }

    @Override
    protected void m_8097_() {
        super.m_8097_();
        this.f_19804_.m_135372_(IS_HIDING, (Object)Boolean.FALSE);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return MoCEntityAmbient.createAttributes().m_22268_(Attributes.f_22276_, 4.0).m_22268_(Attributes.f_22284_, 2.0).m_22268_(Attributes.f_22279_, 0.1);
    }

    @Override
    public boolean isMovementCeased() {
        return this.getIsHiding();
    }

    @Override
    public void selectType() {
        if (this.getTypeMoC() == 0) {
            this.setTypeMoC(this.f_19796_.m_188503_(6) + 1);
        }
    }

    @Override
    public ResourceLocation getTexture() {
        switch (this.getTypeMoC()) {
            case 2: {
                return MoCreatures.proxy.getModelTexture("snail_green.png");
            }
            case 3: {
                return MoCreatures.proxy.getModelTexture("snail_yellow.png");
            }
            case 4: {
                return MoCreatures.proxy.getModelTexture("snail_red.png");
            }
            case 5: {
                return MoCreatures.proxy.getModelTexture("slug_golden.png");
            }
            case 6: {
                return MoCreatures.proxy.getModelTexture("slug_black.png");
            }
        }
        return MoCreatures.proxy.getModelTexture("snail_brown.png");
    }

    public boolean getIsHiding() {
        return (Boolean)this.f_19804_.m_135370_(IS_HIDING);
    }

    public void setIsHiding(boolean flag) {
        this.f_19804_.m_135381_(IS_HIDING, (Object)flag);
    }

    public void m_8107_() {
        super.m_8107_();
        if (!this.m_9236_().m_5776_()) {
            LivingEntity entityliving = this.getBoogey(3.0);
            if (entityliving != null && entityliving.m_20192_() > 0.5f && entityliving.m_20205_() > 0.5f && this.m_142582_((Entity)entityliving)) {
                if (!this.getIsHiding()) {
                    this.setIsHiding(true);
                }
                this.m_21573_().m_26573_();
            } else {
                this.setIsHiding(false);
            }
            if (this.getIsHiding() && this.getTypeMoC() > 4) {
                this.setIsHiding(false);
            }
        }
    }

    @Override
    public void m_8119_() {
        super.m_8119_();
        if (this.getIsHiding()) {
            this.f_20884_ = this.f_20883_ = this.m_146908_();
            this.f_19859_ = this.m_146908_();
        }
    }

    protected SoundEvent m_5592_() {
        return SoundEvents.f_12422_;
    }

    protected SoundEvent m_7975_(DamageSource source) {
        return SoundEvents.f_12422_;
    }

    @Nullable
    protected ResourceLocation m_7582_() {
        return MoCLootTables.SNAIL;
    }

    public boolean m_6147_() {
        return this.f_19862_;
    }

    public boolean climbing() {
        return !this.m_20096_() && this.m_6147_();
    }

    protected void m_6135_() {
    }
}

