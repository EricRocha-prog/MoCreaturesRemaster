/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityDimensions
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.Pose
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.entity.ambient;

import drzhark.mocreatures.MoCTools;
import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.entity.MoCEntityInsect;
import drzhark.mocreatures.init.MoCLootTables;
import drzhark.mocreatures.init.MoCSoundEvents;
import javax.annotation.Nullable;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class MoCEntityGrasshopper
extends MoCEntityInsect {
    private int jumpCounter;
    private int soundCounter;

    public MoCEntityGrasshopper(EntityType<? extends MoCEntityGrasshopper> type, Level world) {
        super((EntityType<? extends MoCEntityInsect>)type, world);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return MoCEntityInsect.createAttributes().m_22268_(Attributes.f_22284_, 1.0).m_22268_(Attributes.f_22280_, 0.25);
    }

    @Override
    public void selectType() {
        if (this.getTypeMoC() == 0) {
            int i = this.f_19796_.m_188503_(100);
            if (i <= 50) {
                this.setTypeMoC(1);
            } else {
                this.setTypeMoC(2);
            }
        }
    }

    @Override
    public ResourceLocation getTexture() {
        if (this.getTypeMoC() == 1) {
            return MoCreatures.proxy.getModelTexture("grasshopper_bright_green.png");
        }
        return MoCreatures.proxy.getModelTexture("grasshopper_olive_green.png");
    }

    public void m_8107_() {
        super.m_8107_();
        if (!this.m_9236_().m_5776_()) {
            Player ep;
            if ((this.getIsFlying() || !this.m_20096_()) && (ep = this.m_9236_().m_45930_((Entity)this, 5.0)) != null && --this.soundCounter == -1) {
                MoCTools.playCustomSound((Entity)this, (SoundEvent)MoCSoundEvents.ENTITY_GRASSHOPPER_FLY.get());
                this.soundCounter = 10;
            }
            if (this.jumpCounter > 0 && ++this.jumpCounter > 30) {
                this.jumpCounter = 0;
            }
        }
    }

    @Override
    public void m_8119_() {
        super.m_8119_();
        if (!this.m_9236_().m_5776_() && this.m_20096_() && (this.m_20184_().f_82479_ > 0.05 || this.m_20184_().f_82481_ > 0.05 || this.m_20184_().f_82479_ < -0.05 || this.m_20184_().f_82481_ < -0.05) && this.jumpCounter == 0) {
            this.m_20334_(this.m_20184_().f_82479_ * 5.0, 0.45, this.m_20184_().f_82481_ * 5.0);
            this.jumpCounter = 1;
        }
    }

    protected SoundEvent m_7515_() {
        if (this.m_9236_().m_46461_()) {
            return this.m_9236_().m_213780_().m_188500_() <= 0.1 ? (SoundEvent)MoCSoundEvents.ENTITY_GRASSHOPPER_CHIRP.get() : null;
        }
        return this.m_9236_().m_213780_().m_188500_() <= 0.1 ? (SoundEvent)MoCSoundEvents.ENTITY_GRASSHOPPER_CHIRP.get() : null;
    }

    protected SoundEvent m_5592_() {
        return (SoundEvent)MoCSoundEvents.ENTITY_GRASSHOPPER_HURT.get();
    }

    protected SoundEvent m_7975_(DamageSource source) {
        return (SoundEvent)MoCSoundEvents.ENTITY_GRASSHOPPER_HURT.get();
    }

    @Nullable
    protected ResourceLocation m_7582_() {
        return MoCLootTables.GRASSHOPPER;
    }

    @Override
    public boolean isFlyer() {
        return true;
    }

    public float m_6113_() {
        if (this.getIsFlying()) {
            return 0.12f;
        }
        return 0.15f;
    }

    @Override
    public float m_6431_(Pose poseIn, EntityDimensions sizeIn) {
        return 0.15f;
    }
}

