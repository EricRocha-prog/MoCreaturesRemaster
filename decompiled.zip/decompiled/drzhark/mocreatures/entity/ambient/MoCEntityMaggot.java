/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.sounds.SoundEvents
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.entity.EntityDimensions
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.Pose
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.entity.ai.goal.Goal
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.entity.ambient;

import drzhark.mocreatures.entity.MoCEntityAmbient;
import drzhark.mocreatures.entity.ai.EntityAIWanderMoC2;
import drzhark.mocreatures.init.MoCLootTables;
import javax.annotation.Nullable;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.Level;

public class MoCEntityMaggot
extends MoCEntityAmbient {
    public MoCEntityMaggot(EntityType<? extends MoCEntityMaggot> type, Level world) {
        super(type, world);
        this.texture = "maggot.png";
    }

    protected void m_8099_() {
        this.f_21345_.m_25352_(1, (Goal)new EntityAIWanderMoC2(this, 0.8));
    }

    public static AttributeSupplier.Builder createAttributes() {
        return MoCEntityAmbient.createAttributes().m_22268_(Attributes.f_22276_, 4.0).m_22268_(Attributes.f_22279_, 0.1);
    }

    protected SoundEvent m_5592_() {
        return SoundEvents.f_12422_;
    }

    protected SoundEvent m_7975_(DamageSource source) {
        return SoundEvents.f_12422_;
    }

    @Nullable
    protected ResourceLocation m_7582_() {
        return MoCLootTables.MAGGOT;
    }

    public boolean m_6147_() {
        return this.f_19862_;
    }

    public boolean climbing() {
        return !this.m_20096_() && this.m_6147_();
    }

    public void m_6135_() {
    }

    public float m_6431_(Pose poseIn, EntityDimensions sizeIn) {
        return this.m_20206_() * 0.45f;
    }
}

