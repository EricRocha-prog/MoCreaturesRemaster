/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.Mob
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.Items
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.entity.ambient;

import drzhark.mocreatures.MoCTools;
import drzhark.mocreatures.entity.MoCEntityInsect;
import drzhark.mocreatures.init.MoCLootTables;
import drzhark.mocreatures.init.MoCSoundEvents;
import javax.annotation.Nullable;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

public class MoCEntityFly
extends MoCEntityInsect {
    private int soundCount;

    public MoCEntityFly(EntityType<? extends MoCEntityFly> type, Level world) {
        super((EntityType<? extends MoCEntityInsect>)type, world);
        this.texture = "fly.png";
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.m_21552_().m_22268_(Attributes.f_22276_, 10.0).m_22268_(Attributes.f_22279_, 0.25).m_22268_(Attributes.f_22280_, 0.25);
    }

    @Override
    public boolean isAttractedToLight() {
        return true;
    }

    public void m_8107_() {
        Player player;
        super.m_8107_();
        if (!this.m_9236_().m_5776_() && this.getIsFlying() && --this.soundCount == -1 && (player = this.m_9236_().m_45930_((Entity)this, 5.0)) != null) {
            MoCTools.playCustomSound((Entity)this, (SoundEvent)MoCSoundEvents.ENTITY_FLY_AMBIENT.get());
            this.soundCount = 55;
        }
    }

    protected SoundEvent m_5592_() {
        return (SoundEvent)MoCSoundEvents.ENTITY_FLY_HURT.get();
    }

    protected SoundEvent m_7975_(DamageSource source) {
        return (SoundEvent)MoCSoundEvents.ENTITY_FLY_HURT.get();
    }

    @Nullable
    protected ResourceLocation m_7582_() {
        return MoCLootTables.FLY;
    }

    @Override
    public boolean isMyFavoriteFood(ItemStack stack) {
        return !stack.m_41619_() && stack.m_41720_() == Items.f_42583_;
    }

    @Override
    public boolean isFlyer() {
        return true;
    }

    public float m_6113_() {
        if (this.getIsFlying()) {
            return 0.2f;
        }
        return 0.12f;
    }
}

