/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.tags.ItemTags
 *  net.minecraft.util.Mth
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.entity.EntityDimensions
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.Pose
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.entity.ambient;

import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.entity.MoCEntityInsect;
import drzhark.mocreatures.init.MoCLootTables;
import javax.annotation.Nullable;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class MoCEntityButterfly
extends MoCEntityInsect {
    private int fCounter;

    public MoCEntityButterfly(EntityType<? extends MoCEntityButterfly> type, Level world) {
        super((EntityType<? extends MoCEntityInsect>)type, world);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return MoCEntityInsect.registerAttributes().m_22268_(Attributes.f_22279_, 0.12);
    }

    public void m_8107_() {
        super.m_8107_();
    }

    @Override
    public void selectType() {
        if (this.getTypeMoC() == 0) {
            this.setTypeMoC(this.f_19796_.m_188503_(10) + 1);
        }
    }

    @Override
    public ResourceLocation getTexture() {
        switch (this.getTypeMoC()) {
            case 1: {
                return MoCreatures.proxy.getModelTexture("butterfly_agalais_urticae.png");
            }
            case 2: {
                return MoCreatures.proxy.getModelTexture("butterfly_argyreus_hyperbius.png");
            }
            case 3: {
                return MoCreatures.proxy.getModelTexture("butterfly_athyma_nefte.png");
            }
            case 4: {
                return MoCreatures.proxy.getModelTexture("butterfly_catopsilia_pomona.png");
            }
            case 5: {
                return MoCreatures.proxy.getModelTexture("butterfly_morpho_peleides.png");
            }
            case 6: {
                return MoCreatures.proxy.getModelTexture("butterfly_vanessa_atalanta.png");
            }
            case 8: {
                return MoCreatures.proxy.getModelTexture("moth_camptogramma_bilineata.png");
            }
            case 9: {
                return MoCreatures.proxy.getModelTexture("moth_idia_aemula.png");
            }
            case 10: {
                return MoCreatures.proxy.getModelTexture("moth_thyatira_batis.png");
            }
        }
        return MoCreatures.proxy.getModelTexture("butterfly_pieris_rapae.png");
    }

    public float tFloat() {
        if (!this.getIsFlying()) {
            return 0.0f;
        }
        if (++this.fCounter > 1000) {
            this.fCounter = 0;
        }
        return Mth.m_14089_((float)((float)this.fCounter * 0.1f)) * 0.2f;
    }

    @Override
    public float getSizeFactor() {
        if (this.getTypeMoC() < 8) {
            return 0.7f;
        }
        return 1.0f;
    }

    @Override
    public boolean isMyFavoriteFood(ItemStack stack) {
        return !stack.m_41619_() && stack.m_204117_(ItemTags.f_13149_);
    }

    @Override
    public boolean isAttractedToLight() {
        return this.getTypeMoC() > 7;
    }

    @Override
    public boolean isFlyer() {
        return true;
    }

    public float m_6113_() {
        if (this.getIsFlying()) {
            return 0.13f;
        }
        return 0.1f;
    }

    protected SoundEvent m_5592_() {
        return null;
    }

    protected SoundEvent m_7975_(DamageSource source) {
        return null;
    }

    @Nullable
    protected ResourceLocation m_7582_() {
        return MoCLootTables.BUTTERFLY;
    }

    @Override
    public float m_6431_(Pose poseIn, EntityDimensions sizeIn) {
        return 0.1f;
    }
}

