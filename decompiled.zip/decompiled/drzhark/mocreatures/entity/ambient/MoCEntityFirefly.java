/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityDimensions
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.Pose
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.entity.ambient;

import drzhark.mocreatures.MoCTools;
import drzhark.mocreatures.entity.MoCEntityInsect;
import drzhark.mocreatures.init.MoCLootTables;
import drzhark.mocreatures.init.MoCSoundEvents;
import javax.annotation.Nullable;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class MoCEntityFirefly
extends MoCEntityInsect {
    private int soundCount;

    public MoCEntityFirefly(EntityType<? extends MoCEntityFirefly> type, Level world) {
        super((EntityType<? extends MoCEntityInsect>)type, world);
        this.texture = "firefly.png";
    }

    public static AttributeSupplier.Builder createAttributes() {
        return MoCEntityInsect.registerAttributes().m_22268_(Attributes.f_22284_, 1.0);
    }

    public void m_8107_() {
        Player player;
        super.m_8107_();
        if (!this.m_9236_().m_5776_() && (player = this.m_9236_().m_45930_((Entity)this, 5.0)) != null && this.getIsFlying() && --this.soundCount == -1) {
            MoCTools.playCustomSound((Entity)this, (SoundEvent)MoCSoundEvents.ENTITY_GRASSHOPPER_FLY.get());
            this.soundCount = 20;
        }
    }

    protected SoundEvent m_5592_() {
        return (SoundEvent)MoCSoundEvents.ENTITY_GRASSHOPPER_HURT.get();
    }

    protected SoundEvent m_7975_(DamageSource source) {
        return (SoundEvent)MoCSoundEvents.ENTITY_GRASSHOPPER_HURT.get();
    }

    @Nullable
    protected ResourceLocation m_7582_() {
        return MoCLootTables.FIREFLY;
    }

    @Override
    public boolean isFlyer() {
        return true;
    }

    public float m_6113_() {
        if (this.getIsFlying()) {
            return 0.12f;
        }
        return 0.1f;
    }

    @Override
    public float m_6431_(Pose poseIn, EntityDimensions sizeIn) {
        return 0.15f;
    }
}

