/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.world.Difficulty
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.Mob
 *  net.minecraft.world.entity.MobType
 *  net.minecraft.world.entity.PathfinderMob
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.entity.ai.goal.Goal
 *  net.minecraft.world.entity.ai.goal.LookAtPlayerGoal
 *  net.minecraft.world.entity.ai.goal.MeleeAttackGoal
 *  net.minecraft.world.entity.ai.goal.RandomLookAroundGoal
 *  net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.level.Level
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.entity.ambient;

import drzhark.mocreatures.MoCTools;
import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.entity.ai.EntityAIFollowOwnerPlayer;
import drzhark.mocreatures.entity.ai.EntityAIWanderMoC2;
import drzhark.mocreatures.entity.tameable.MoCEntityTameableAnimal;
import drzhark.mocreatures.init.MoCLootTables;
import drzhark.mocreatures.init.MoCSoundEvents;
import javax.annotation.Nullable;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.Difficulty;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class MoCEntityCrab
extends MoCEntityTameableAnimal {
    public MoCEntityCrab(EntityType<? extends MoCEntityCrab> type, Level world) {
        super((EntityType<? extends MoCEntityTameableAnimal>)type, world);
        this.setMoCAge(50 + this.f_19796_.m_188503_(50));
    }

    protected void m_8099_() {
        this.f_21345_.m_25352_(1, (Goal)new EntityAIFollowOwnerPlayer((Mob)this, 0.8, 6.0f, 5.0f));
        this.f_21345_.m_25352_(4, (Goal)new EntityAIWanderMoC2((PathfinderMob)this, 1.0));
        this.f_21345_.m_25352_(5, (Goal)new MeleeAttackGoal((PathfinderMob)this, 1.0, true));
        this.f_21345_.m_25352_(6, (Goal)new LookAtPlayerGoal((Mob)this, Player.class, 8.0f));
        this.f_21345_.m_25352_(6, (Goal)new RandomLookAroundGoal((Mob)this));
        this.f_21346_.m_25352_(1, (Goal)new HurtByTargetGoal((PathfinderMob)this, new Class[0]));
    }

    public static AttributeSupplier.Builder registerAttributes() {
        return MoCEntityTameableAnimal.createAttributes().m_22268_(Attributes.f_22277_, 12.0).m_22268_(Attributes.f_22276_, 6.0).m_22268_(Attributes.f_22284_, 2.0).m_22268_(Attributes.f_22279_, 0.3).m_22268_(Attributes.f_22281_, 1.5);
    }

    @Override
    public void selectType() {
        if (this.getTypeMoC() == 0) {
            this.setTypeMoC(this.f_19796_.m_188503_(5) + 1);
        }
    }

    @Override
    public ResourceLocation getTexture() {
        switch (this.getTypeMoC()) {
            case 2: {
                return MoCreatures.proxy.getModelTexture("crab_blue.png");
            }
            case 3: {
                return MoCreatures.proxy.getModelTexture("crab_spotted.png");
            }
            case 4: {
                return MoCreatures.proxy.getModelTexture("crab_green.png");
            }
            case 5: {
                return MoCreatures.proxy.getModelTexture("crab_russet.png");
            }
        }
        return MoCreatures.proxy.getModelTexture("crab_red.png");
    }

    public int m_213860_() {
        return 1 + this.m_9236_().m_213780_().m_188503_(3);
    }

    @Nullable
    protected ResourceLocation m_7582_() {
        return MoCLootTables.CRAB;
    }

    public boolean m_6147_() {
        return this.f_19862_;
    }

    public boolean climbing() {
        return !this.m_20096_() && this.m_6147_();
    }

    @Override
    public void m_6135_() {
    }

    protected void m_7324_(Entity entity) {
        if (entity instanceof Player && this.m_5448_() == null && entity.m_9236_().m_46791_() != Difficulty.PEACEFUL) {
            entity.m_6469_(this.m_269291_().m_269333_((LivingEntity)this), 1.5f);
        }
        super.m_7324_(entity);
    }

    @Override
    public boolean m_7327_(Entity entity) {
        this.m_5496_((SoundEvent)MoCSoundEvents.ENTITY_GOAT_SMACK.get(), 1.0f, 2.0f);
        return super.m_7327_(entity);
    }

    @Override
    @OnlyIn(value=Dist.CLIENT)
    public float getSizeFactor() {
        return 0.7f * (float)this.getMoCAge() * 0.01f;
    }

    @Override
    public boolean m_6040_() {
        return true;
    }

    @OnlyIn(value=Dist.CLIENT)
    public boolean isFleeing() {
        return MoCTools.getMyMovementSpeed((Entity)this) > 0.09f;
    }

    public MobType m_6336_() {
        return MobType.f_21642_;
    }

    @Override
    protected boolean canBeTrappedInNet() {
        return true;
    }

    @Override
    public int nameYOffset() {
        return -20;
    }

    @Override
    public boolean isReadyToFollowOwnerPlayer() {
        return !this.isMovementCeased();
    }

    protected SoundEvent m_5592_() {
        return null;
    }

    protected SoundEvent m_7975_(DamageSource source) {
        return null;
    }
}

