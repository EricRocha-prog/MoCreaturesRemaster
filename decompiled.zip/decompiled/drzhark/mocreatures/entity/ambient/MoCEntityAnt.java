/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.network.syncher.EntityDataAccessor
 *  net.minecraft.network.syncher.EntityDataSerializer
 *  net.minecraft.network.syncher.EntityDataSerializers
 *  net.minecraft.network.syncher.SynchedEntityData
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.util.Mth
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityDimensions
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.Pose
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.entity.ai.goal.Goal
 *  net.minecraft.world.entity.item.ItemEntity
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.entity.ambient;

import drzhark.mocreatures.MoCTools;
import drzhark.mocreatures.entity.MoCEntityAmbient;
import drzhark.mocreatures.entity.ai.EntityAIWanderMoC2;
import drzhark.mocreatures.init.MoCLootTables;
import javax.annotation.Nullable;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializer;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class MoCEntityAnt
extends MoCEntityAmbient {
    private static final EntityDataAccessor<Boolean> FOUND_FOOD = SynchedEntityData.m_135353_(MoCEntityAnt.class, (EntityDataSerializer)EntityDataSerializers.f_135035_);

    public MoCEntityAnt(EntityType<? extends MoCEntityAnt> type, Level world) {
        super(type, world);
        this.texture = "ant.png";
    }

    protected void m_8099_() {
        this.f_21345_.m_25352_(1, (Goal)new EntityAIWanderMoC2(this, 1.2));
    }

    @Override
    protected void m_8097_() {
        super.m_8097_();
        this.f_19804_.m_135372_(FOUND_FOOD, (Object)Boolean.FALSE);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return MoCEntityAmbient.createAttributes().m_22268_(Attributes.f_22276_, 3.0).m_22268_(Attributes.f_22284_, 1.0).m_22268_(Attributes.f_22279_, 0.28);
    }

    public boolean getHasFood() {
        return (Boolean)this.f_19804_.m_135370_(FOUND_FOOD);
    }

    public void setHasFood(boolean flag) {
        this.f_19804_.m_135381_(FOUND_FOOD, (Object)flag);
    }

    public void m_8107_() {
        ItemEntity entityitem;
        super.m_8107_();
        if (this.m_20069_()) {
            this.m_20256_(this.m_20184_().m_82542_(1.0, 0.6, 1.0));
        }
        if (!this.m_9236_().m_5776_() && !this.getHasFood()) {
            entityitem = MoCTools.getClosestFood((Entity)this, 8.0);
            if (entityitem == null || entityitem.m_213877_()) {
                return;
            }
            if (entityitem.m_20202_() == null) {
                float f = entityitem.m_20270_((Entity)this);
                if (f > 1.0f) {
                    int i = Mth.m_14107_((double)entityitem.m_20185_());
                    int j = Mth.m_14107_((double)entityitem.m_20186_());
                    int k = Mth.m_14107_((double)entityitem.m_20189_());
                    this.faceLocation(i, j, k, 30.0f);
                    this.getMyOwnPath((Entity)entityitem, f);
                    return;
                }
                if (f < 1.0f) {
                    this.exchangeItem(entityitem);
                    this.setHasFood(true);
                    return;
                }
            }
        }
        if (this.getHasFood() && !this.m_20159_()) {
            entityitem = MoCTools.getClosestFood((Entity)this, 2.0);
            if (entityitem != null && entityitem.m_20202_() == null) {
                entityitem.m_20329_((Entity)this);
                return;
            }
            if (!this.m_20159_()) {
                this.setHasFood(false);
            }
        }
    }

    private void exchangeItem(ItemEntity entityitem) {
        ItemEntity cargo = new ItemEntity(this.m_9236_(), this.m_20185_(), this.m_20186_() + 0.2, this.m_20189_(), entityitem.m_32055_());
        entityitem.m_146870_();
        if (!this.m_9236_().m_5776_()) {
            this.m_9236_().m_7967_((Entity)cargo);
        }
    }

    @Override
    public boolean isMyFavoriteFood(ItemStack stack) {
        return !stack.m_41619_() && MoCTools.isItemEdible(stack.m_41720_());
    }

    public float m_6113_() {
        if (this.getHasFood()) {
            return 0.1f;
        }
        return 0.15f;
    }

    protected SoundEvent m_5592_() {
        return null;
    }

    protected SoundEvent m_7975_(DamageSource source) {
        return null;
    }

    @Nullable
    protected ResourceLocation m_7582_() {
        return MoCLootTables.ANT;
    }

    protected float m_6431_(Pose poseIn, EntityDimensions sizeIn) {
        return 0.1f;
    }
}

