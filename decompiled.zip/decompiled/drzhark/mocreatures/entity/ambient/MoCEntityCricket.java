/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.entity.EntityDimensions
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.Pose
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.entity.ai.goal.Goal
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.entity.ambient;

import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.entity.MoCEntityAmbient;
import drzhark.mocreatures.entity.ai.EntityAIWanderMoC2;
import drzhark.mocreatures.init.MoCLootTables;
import drzhark.mocreatures.init.MoCSoundEvents;
import javax.annotation.Nullable;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.Level;

public class MoCEntityCricket
extends MoCEntityAmbient {
    private int jumpCounter;
    private int soundCounter;

    public MoCEntityCricket(EntityType<? extends MoCEntityCricket> type, Level world) {
        super(type, world);
    }

    protected void m_8099_() {
        this.f_21345_.m_25352_(1, (Goal)new EntityAIWanderMoC2(this, 1.2));
    }

    public static AttributeSupplier.Builder createAttributes() {
        return MoCEntityAmbient.createAttributes().m_22268_(Attributes.f_22276_, 4.0).m_22268_(Attributes.f_22279_, 0.25).m_22268_(Attributes.f_22284_, 1.0);
    }

    @Override
    public void selectType() {
        if (this.getTypeMoC() == 0) {
            int i = this.f_19796_.m_188503_(100);
            if (i <= 50) {
                this.setTypeMoC(1);
            } else {
                this.setTypeMoC(2);
            }
        }
    }

    @Override
    public ResourceLocation getTexture() {
        if (this.getTypeMoC() == 1) {
            return MoCreatures.proxy.getModelTexture("cricket_light_brown.png");
        }
        return MoCreatures.proxy.getModelTexture("cricket_brown.png");
    }

    public void m_8107_() {
        super.m_8107_();
        if (this.m_20069_()) {
            this.m_20256_(this.m_20184_().m_82542_(1.0, 0.6, 1.0));
        }
        if (!this.m_9236_().m_5776_() && this.jumpCounter > 0 && ++this.jumpCounter > 30) {
            this.jumpCounter = 0;
        }
    }

    @Override
    public void m_8119_() {
        super.m_8119_();
        if (!this.m_9236_().m_5776_() && this.m_20096_() && (this.m_20184_().f_82479_ > 0.05 || this.m_20184_().f_82481_ > 0.05 || this.m_20184_().f_82479_ < -0.05 || this.m_20184_().f_82481_ < -0.05) && this.jumpCounter == 0) {
            this.m_20334_(this.m_20184_().f_82479_ * 5.0, 0.45, this.m_20184_().f_82481_ * 5.0);
            this.jumpCounter = 1;
        }
    }

    protected SoundEvent m_7515_() {
        if (!this.m_9236_().m_46461_()) {
            return this.m_9236_().m_213780_().m_188500_() <= 0.1 ? (SoundEvent)MoCSoundEvents.ENTITY_CRICKET_AMBIENT.get() : null;
        }
        return this.m_9236_().m_213780_().m_188500_() <= 0.1 ? (SoundEvent)MoCSoundEvents.ENTITY_CRICKET_CHIRP.get() : null;
    }

    protected SoundEvent m_5592_() {
        return (SoundEvent)MoCSoundEvents.ENTITY_CRICKET_HURT.get();
    }

    protected SoundEvent m_7975_(DamageSource source) {
        return (SoundEvent)MoCSoundEvents.ENTITY_CRICKET_HURT.get();
    }

    @Nullable
    protected ResourceLocation m_7582_() {
        return MoCLootTables.CRICKET;
    }

    public float m_6113_() {
        if (this.getIsFlying()) {
            return 0.12f;
        }
        return 0.15f;
    }

    protected float m_6431_(Pose poseIn, EntityDimensions sizeIn) {
        return 0.15f;
    }
}

