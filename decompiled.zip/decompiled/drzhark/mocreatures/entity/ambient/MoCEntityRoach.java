/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityDimensions
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.Mob
 *  net.minecraft.world.entity.Pose
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.entity.ai.goal.Goal
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.Items
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.entity.ambient;

import drzhark.mocreatures.entity.MoCEntityInsect;
import drzhark.mocreatures.entity.ai.EntityAIFleeFromEntityMoC;
import drzhark.mocreatures.entity.ambient.MoCEntityCrab;
import drzhark.mocreatures.init.MoCLootTables;
import drzhark.mocreatures.init.MoCSoundEvents;
import javax.annotation.Nullable;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

public class MoCEntityRoach
extends MoCEntityInsect {
    public MoCEntityRoach(EntityType<? extends MoCEntityRoach> type, Level world) {
        super((EntityType<? extends MoCEntityInsect>)type, world);
        this.texture = "roach.png";
    }

    @Override
    protected void m_8099_() {
        super.m_8099_();
        this.f_21345_.m_25352_(0, (Goal)new EntityAIFleeFromEntityMoC((Mob)this, entity -> !(entity instanceof MoCEntityCrab) && (entity.m_20192_() > 0.3f || entity.m_20205_() > 0.3f), 6.0f, 0.8, 1.3));
    }

    public static AttributeSupplier.Builder createAttributes() {
        return MoCEntityInsect.createAttributes().m_22268_(Attributes.f_22284_, 1.0).m_22268_(Attributes.f_22280_, 0.25);
    }

    public void m_8107_() {
        super.m_8107_();
    }

    @Override
    public boolean entitiesToInclude(Entity entity) {
        return !(entity instanceof MoCEntityInsect) && super.entitiesToInclude(entity);
    }

    @Override
    public boolean isFlyer() {
        return true;
    }

    @Override
    public boolean isMyFavoriteFood(ItemStack stack) {
        return !stack.m_41619_() && stack.m_41720_() == Items.f_42583_;
    }

    public float m_6113_() {
        if (this.getIsFlying()) {
            return 0.1f;
        }
        return 0.25f;
    }

    @Override
    public boolean isNotScared() {
        return this.getIsFlying();
    }

    @Override
    public float m_6431_(Pose poseIn, EntityDimensions sizeIn) {
        return 0.1f;
    }

    protected SoundEvent m_5592_() {
        return (SoundEvent)MoCSoundEvents.ENTITY_GRASSHOPPER_HURT.get();
    }

    protected SoundEvent m_7975_(DamageSource source) {
        return (SoundEvent)MoCSoundEvents.ENTITY_GRASSHOPPER_HURT.get();
    }

    @Nullable
    protected ResourceLocation m_7582_() {
        return MoCLootTables.ROACH;
    }
}

