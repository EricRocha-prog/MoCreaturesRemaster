/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityDimensions
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.Mob
 *  net.minecraft.world.entity.MobType
 *  net.minecraft.world.entity.PathfinderMob
 *  net.minecraft.world.entity.Pose
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.entity.ai.control.FlyingMoveControl
 *  net.minecraft.world.entity.ai.goal.Goal
 *  net.minecraft.world.entity.ai.goal.WaterAvoidingRandomFlyingGoal
 *  net.minecraft.world.entity.ai.navigation.FlyingPathNavigation
 *  net.minecraft.world.entity.ai.navigation.PathNavigation
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraft.world.level.block.state.BlockState
 */
package drzhark.mocreatures.entity;

import drzhark.mocreatures.MoCTools;
import drzhark.mocreatures.entity.MoCEntityAmbient;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomFlyingGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public abstract class MoCEntityInsect
extends MoCEntityAmbient {
    private int climbCounter;

    protected MoCEntityInsect(EntityType<? extends MoCEntityInsect> type, Level world) {
        super(type, world);
        this.f_21342_ = new FlyingMoveControl((Mob)this, 10, false);
    }

    public static AttributeSupplier.Builder registerAttributes() {
        return MoCEntityAmbient.createAttributes().m_22268_(Attributes.f_22276_, 4.0).m_22268_(Attributes.f_22279_, 0.25).m_22268_(Attributes.f_22280_, 0.6);
    }

    protected PathNavigation m_6037_(Level worldIn) {
        FlyingPathNavigation nav = new FlyingPathNavigation((Mob)this, worldIn);
        nav.m_26443_(true);
        nav.m_7008_(true);
        return nav;
    }

    @Override
    protected void m_8097_() {
        super.m_8097_();
    }

    protected void m_8099_() {
        super.m_8099_();
        this.f_21345_.m_25352_(0, (Goal)new WaterAvoidingRandomFlyingGoal((PathfinderMob)this, 0.8));
    }

    public float m_6431_(Pose poseIn, EntityDimensions sizeIn) {
        return 0.2f;
    }

    @Override
    public boolean getIsFlying() {
        return this.isOnAir() && !this.m_6147_();
    }

    @Override
    public void m_8119_() {
        super.m_8119_();
        if (this.m_20069_()) {
            this.m_20256_(this.m_20184_().m_82520_(1.0, 0.6, 1.0));
        }
        if (!this.m_9236_().f_46443_) {
            int[] ai;
            if (this.f_19796_.m_188503_(50) == 0 && (ai = MoCTools.returnNearestBlockCoord((Entity)this, this.isAttractedToLight() ? Blocks.f_50081_ : Blocks.f_50359_, 8.0))[0] > -1000) {
                this.m_21573_().m_26519_((double)ai[0], (double)ai[1], (double)ai[2], 1.0);
            }
        } else if (this.climbCounter > 0 && ++this.climbCounter > 8) {
            this.climbCounter = 0;
        }
    }

    public boolean isAttractedToLight() {
        return false;
    }

    @Override
    public void performAnimation(int animationType) {
        if (animationType == 1) {
            this.climbCounter = 1;
        }
    }

    public boolean m_6147_() {
        return this.f_19862_;
    }

    public boolean climbing() {
        return this.climbCounter != 0;
    }

    protected void m_7840_(double y, boolean onGroundIn, BlockState state, BlockPos pos) {
    }

    public boolean m_6090_() {
        return true;
    }

    public MobType m_6336_() {
        return MobType.f_21642_;
    }
}

