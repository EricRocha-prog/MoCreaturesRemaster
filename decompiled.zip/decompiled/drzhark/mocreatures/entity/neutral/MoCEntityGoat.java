/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.network.syncher.EntityDataAccessor
 *  net.minecraft.network.syncher.EntityDataSerializer
 *  net.minecraft.network.syncher.EntityDataSerializers
 *  net.minecraft.network.syncher.SynchedEntityData
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.sounds.SoundEvents
 *  net.minecraft.util.Mth
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.InteractionResult
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.effect.MobEffects
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.Entity$RemovalReason
 *  net.minecraft.world.entity.EntityDimensions
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.Mob
 *  net.minecraft.world.entity.PathfinderMob
 *  net.minecraft.world.entity.Pose
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.entity.ai.goal.FloatGoal
 *  net.minecraft.world.entity.ai.goal.Goal
 *  net.minecraft.world.entity.ai.goal.LookAtPlayerGoal
 *  net.minecraft.world.entity.ai.goal.MeleeAttackGoal
 *  net.minecraft.world.entity.item.ItemEntity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.Items
 *  net.minecraft.world.level.ItemLike
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.block.state.BlockState
 */
package drzhark.mocreatures.entity.neutral;

import drzhark.mocreatures.MoCTools;
import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.entity.ai.EntityAIFollowAdult;
import drzhark.mocreatures.entity.ai.EntityAIPanicMoC;
import drzhark.mocreatures.entity.ai.EntityAIWanderMoC2;
import drzhark.mocreatures.entity.tameable.MoCEntityTameableAnimal;
import drzhark.mocreatures.init.MoCLootTables;
import drzhark.mocreatures.init.MoCSoundEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializer;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

public class MoCEntityGoat
extends MoCEntityTameableAnimal {
    private static final EntityDataAccessor<Boolean> IS_CHARGING = SynchedEntityData.m_135353_(MoCEntityGoat.class, (EntityDataSerializer)EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Boolean> IS_UPSET = SynchedEntityData.m_135353_(MoCEntityGoat.class, (EntityDataSerializer)EntityDataSerializers.f_135035_);
    public int movecount;
    private boolean hungry;
    private boolean swingLeg;
    private boolean swingEar;
    private boolean swingTail;
    private boolean bleat;
    private boolean eating;
    private int bleatcount;
    private int attacking;
    private int chargecount;
    private int tailcount;
    private int earcount;
    private int eatcount;

    public MoCEntityGoat(EntityType<? extends MoCEntityGoat> type, Level world) {
        super((EntityType<? extends MoCEntityTameableAnimal>)type, world);
        this.setAdult(true);
        this.setMoCAge(70);
    }

    protected void m_8099_() {
        this.f_21345_.m_25352_(1, (Goal)new FloatGoal((Mob)this));
        this.f_21345_.m_25352_(2, (Goal)new EntityAIPanicMoC((PathfinderMob)this, 1.0));
        this.f_21345_.m_25352_(4, (Goal)new EntityAIFollowAdult((Mob)this, 1.0));
        this.f_21345_.m_25352_(5, (Goal)new MeleeAttackGoal((PathfinderMob)this, 1.0, false));
        this.f_21345_.m_25352_(6, (Goal)new EntityAIWanderMoC2((PathfinderMob)this, 1.0));
        this.f_21345_.m_25352_(7, (Goal)new LookAtPlayerGoal((Mob)this, Player.class, 8.0f));
    }

    public static AttributeSupplier.Builder createAttributes() {
        return MoCEntityTameableAnimal.createAttributes().m_22268_(Attributes.f_22277_, 24.0).m_22268_(Attributes.f_22276_, 10.0).m_22268_(Attributes.f_22284_, 1.0).m_22268_(Attributes.f_22281_, 2.5).m_22268_(Attributes.f_22279_, 0.25);
    }

    @Override
    protected void m_8097_() {
        super.m_8097_();
        this.f_19804_.m_135372_(IS_CHARGING, (Object)Boolean.FALSE);
        this.f_19804_.m_135372_(IS_UPSET, (Object)Boolean.FALSE);
    }

    public boolean getUpset() {
        return (Boolean)this.f_19804_.m_135370_(IS_UPSET);
    }

    public void setUpset(boolean flag) {
        this.f_19804_.m_135381_(IS_UPSET, (Object)flag);
    }

    public boolean getCharging() {
        return (Boolean)this.f_19804_.m_135370_(IS_CHARGING);
    }

    public void setCharging(boolean flag) {
        this.f_19804_.m_135381_(IS_CHARGING, (Object)flag);
    }

    @Override
    public void selectType() {
        if (this.getTypeMoC() == 0) {
            int i = this.f_19796_.m_188503_(100);
            if (i <= 15) {
                this.setTypeMoC(1);
                this.setMoCAge(50);
            } else if (i <= 30) {
                this.setTypeMoC(2);
                this.setMoCAge(70);
            } else if (i <= 45) {
                this.setTypeMoC(3);
                this.setMoCAge(70);
            } else if (i <= 60) {
                this.setTypeMoC(4);
                this.setMoCAge(70);
            } else if (i <= 75) {
                this.setTypeMoC(5);
                this.setMoCAge(90);
            } else if (i <= 90) {
                this.setTypeMoC(6);
                this.setMoCAge(90);
            } else {
                this.setTypeMoC(7);
                this.setMoCAge(90);
            }
        }
    }

    @Override
    public ResourceLocation getTexture() {
        switch (this.getTypeMoC()) {
            case 2: {
                return MoCreatures.proxy.getModelTexture("goat_brown_light.png");
            }
            case 3: {
                return MoCreatures.proxy.getModelTexture("goat_brown_spotted.png");
            }
            case 4: {
                return MoCreatures.proxy.getModelTexture("goat_gray_spotted.png");
            }
            case 5: {
                return MoCreatures.proxy.getModelTexture("goat_gray.png");
            }
            case 6: {
                return MoCreatures.proxy.getModelTexture("goat_brown.png");
            }
        }
        return MoCreatures.proxy.getModelTexture("goat_white.png");
    }

    public void calm() {
        this.m_6710_(null);
        this.setUpset(false);
        this.setCharging(false);
        this.attacking = 0;
        this.chargecount = 0;
    }

    @Override
    public void m_6135_() {
        if (this.getTypeMoC() == 1) {
            this.m_20334_(this.m_20184_().f_82479_, 0.41, this.m_20184_().f_82481_);
        } else if (this.getTypeMoC() < 5) {
            this.m_20334_(this.m_20184_().f_82479_, 0.45, this.m_20184_().f_82481_);
        } else {
            this.m_20334_(this.m_20184_().f_82479_, 0.5, this.m_20184_().f_82481_);
        }
        if (this.m_21023_(MobEffects.f_19603_)) {
            this.m_20256_(this.m_20184_().m_82520_(0.0, (double)((float)(this.m_21124_(MobEffects.f_19603_).m_19564_() + 1) * 0.1f), 0.0));
        }
        if (this.m_20142_()) {
            float f = this.m_146908_() * 0.01745329f;
            this.m_20256_(this.m_20184_().m_82520_((double)(Mth.m_14031_((float)f) * -0.2f), 0.0, (double)(Mth.m_14089_((float)f) * 0.2f)));
        }
        this.f_19812_ = true;
    }

    @Override
    public void m_8119_() {
        super.m_8119_();
        if (this.getBleating()) {
            ++this.bleatcount;
            if (this.bleatcount > 15) {
                this.bleatcount = 0;
                this.setBleating(false);
            }
        }
        if (this.getSwingLeg()) {
            this.movecount += 5;
            if (this.movecount == 30) {
                MoCTools.playCustomSound((Entity)this, (SoundEvent)MoCSoundEvents.ENTITY_GOAT_DIGG.get());
            }
            if (this.movecount > 100) {
                this.setSwingLeg(false);
                this.movecount = 0;
            }
        }
        if (this.getSwingEar()) {
            this.earcount += 5;
            if (this.earcount > 40) {
                this.setSwingEar(false);
                this.earcount = 0;
            }
        }
        if (this.getSwingTail()) {
            this.tailcount += 15;
            if (this.tailcount > 135) {
                this.setSwingTail(false);
                this.tailcount = 0;
            }
        }
        if (this.getEating()) {
            Player entityplayer1;
            ++this.eatcount;
            if (this.eatcount == 2 && (entityplayer1 = this.m_9236_().m_45930_((Entity)this, 3.0)) != null) {
                MoCTools.playCustomSound((Entity)this, (SoundEvent)MoCSoundEvents.ENTITY_GOAT_EATING.get());
            }
            if (this.eatcount > 25) {
                this.setEating(false);
                this.eatcount = 0;
            }
        }
    }

    public void m_8107_() {
        Player player;
        super.m_8107_();
        if (this.m_9236_().m_5776_()) {
            if (this.f_19796_.m_188503_(100) == 0) {
                this.setSwingEar(true);
            }
            if (this.f_19796_.m_188503_(80) == 0) {
                this.setSwingTail(true);
            }
            if (this.f_19796_.m_188503_(50) == 0) {
                this.setEating(true);
            }
        }
        if (this.hungry && this.f_19796_.m_188503_(20) == 0) {
            this.hungry = false;
        }
        if (!this.m_9236_().m_5776_() && (this.getMoCAge() < 90 || this.getTypeMoC() > 4 && this.getMoCAge() < 100) && this.f_19796_.m_188503_(500) == 0) {
            this.setMoCAge(this.getMoCAge() + 1);
            if (this.getTypeMoC() == 1 && this.getMoCAge() > 70) {
                int i = this.f_19796_.m_188503_(6) + 2;
                this.setTypeMoC(i);
            }
        }
        if (this.getUpset()) {
            this.attacking += this.f_19796_.m_188503_(4) + 2;
            if (this.attacking > 75) {
                this.attacking = 75;
            }
            if (this.f_19796_.m_188503_(200) == 0 || this.m_5448_() == null) {
                this.calm();
            }
            if (!this.getCharging() && this.f_19796_.m_188503_(35) == 0) {
                this.swingLeg();
            }
            if (!this.getCharging()) {
                this.m_21573_().m_26573_();
            }
            if (this.m_5448_() != null) {
                this.m_21391_((Entity)this.m_5448_(), 10.0f, 10.0f);
                if (this.f_19796_.m_188503_(80) == 0) {
                    this.setCharging(true);
                }
            }
        }
        if (this.getCharging()) {
            ++this.chargecount;
            if (this.chargecount > 120) {
                this.chargecount = 0;
            }
            if (this.m_5448_() == null) {
                this.calm();
            }
        }
        if (!this.getUpset() && !this.getCharging() && (player = this.m_9236_().m_45930_((Entity)this, 24.0)) != null) {
            MoCEntityGoat entitytarget;
            ItemEntity entityitem = this.getClosestEntityItem((Entity)this, 10.0);
            if (entityitem != null) {
                float f = entityitem.m_20270_((Entity)this);
                if (f > 2.0f) {
                    int i = Mth.m_14107_((double)entityitem.m_20185_());
                    int j = Mth.m_14107_((double)entityitem.m_20186_());
                    int k = Mth.m_14107_((double)entityitem.m_20189_());
                    this.faceLocation(i, j, k, 30.0f);
                    this.setPathToEntity((Entity)entityitem, f);
                    return;
                }
                if (f < 2.0f && this.f_20919_ == 0 && this.f_19796_.m_188503_(50) == 0) {
                    MoCTools.playCustomSound((Entity)this, (SoundEvent)MoCSoundEvents.ENTITY_GOAT_EATING.get());
                    this.setEating(true);
                    entityitem.m_142687_(Entity.RemovalReason.DISCARDED);
                    return;
                }
            }
            if (this.getTypeMoC() > 4 && this.f_19796_.m_188503_(200) == 0 && (entitytarget = (MoCEntityGoat)this.getClosestEntityLiving((Entity)this, 14.0)) != null) {
                this.setUpset(true);
                this.m_6710_((LivingEntity)entitytarget);
                entitytarget.setUpset(true);
                entitytarget.m_6710_((LivingEntity)this);
            }
        }
    }

    @Override
    public boolean isMyFavoriteFood(ItemStack stack) {
        return !stack.m_41619_() && MoCTools.isItemEdible(stack.m_41720_());
    }

    public int m_8100_() {
        if (this.hungry) {
            return 80;
        }
        return 200;
    }

    @Override
    public boolean entitiesToIgnore(Entity entity) {
        return !(entity instanceof MoCEntityGoat) || ((MoCEntityGoat)entity).getTypeMoC() < 5;
    }

    @Override
    public boolean isMovementCeased() {
        return this.getUpset() && !this.getCharging();
    }

    @Override
    public boolean m_7327_(Entity entityIn) {
        this.attacking = 30;
        if (entityIn instanceof MoCEntityGoat) {
            MoCTools.bigSmack((Entity)this, entityIn, 0.4f);
            MoCTools.playCustomSound((Entity)this, (SoundEvent)MoCSoundEvents.ENTITY_GOAT_SMACK.get());
            if (this.f_19796_.m_188503_(3) == 0) {
                this.calm();
                ((MoCEntityGoat)entityIn).calm();
            }
            return false;
        }
        MoCTools.bigSmack((Entity)this, entityIn, 0.8f);
        if (this.f_19796_.m_188503_(3) == 0) {
            this.calm();
        }
        return super.m_7327_(entityIn);
    }

    @Override
    public boolean isNotScared() {
        return this.getTypeMoC() > 4;
    }

    private void swingLeg() {
        if (!this.getSwingLeg()) {
            this.setSwingLeg(true);
            this.movecount = 0;
        }
    }

    public boolean getSwingLeg() {
        return this.swingLeg;
    }

    public void setSwingLeg(boolean flag) {
        this.swingLeg = flag;
    }

    public boolean getSwingEar() {
        return this.swingEar;
    }

    public void setSwingEar(boolean flag) {
        this.swingEar = flag;
    }

    public boolean getSwingTail() {
        return this.swingTail;
    }

    public void setSwingTail(boolean flag) {
        this.swingTail = flag;
    }

    public boolean getEating() {
        return this.eating;
    }

    public void setEating(boolean flag) {
        this.eating = flag;
    }

    @Override
    public boolean m_6469_(DamageSource damagesource, float i) {
        if (super.m_6469_(damagesource, i)) {
            Entity entity = damagesource.m_7639_();
            if (entity != this && entity instanceof LivingEntity && super.shouldAttackPlayers() && this.getTypeMoC() > 4) {
                this.m_6710_((LivingEntity)entity);
                this.setUpset(true);
            }
            return true;
        }
        return false;
    }

    public int legMovement() {
        if (!this.getSwingLeg()) {
            return 0;
        }
        if (this.movecount < 21) {
            return this.movecount * -1;
        }
        if (this.movecount < 70) {
            return this.movecount - 40;
        }
        return -this.movecount + 100;
    }

    public int earMovement() {
        if (!this.getSwingEar()) {
            return 0;
        }
        if (this.earcount < 11) {
            return this.earcount + 30;
        }
        if (this.earcount < 31) {
            return -this.earcount + 50;
        }
        return this.earcount - 10;
    }

    public int tailMovement() {
        if (!this.getSwingTail()) {
            return 90;
        }
        return this.tailcount - 45;
    }

    public int mouthMovement() {
        if (!this.getEating()) {
            return 0;
        }
        if (this.eatcount < 6) {
            return this.eatcount;
        }
        if (this.eatcount < 16) {
            return -this.eatcount + 10;
        }
        return this.eatcount - 20;
    }

    public boolean m_142535_(float distance, float damageMultiplier, DamageSource source) {
        return false;
    }

    @Override
    public InteractionResult m_6071_(Player player, InteractionHand hand) {
        InteractionResult tameResult = this.processTameInteract(player, hand);
        if (tameResult != null) {
            return tameResult;
        }
        ItemStack stack = player.m_21120_(hand);
        if (!stack.m_41619_() && stack.m_150930_(Items.f_42446_)) {
            if (this.getTypeMoC() > 4) {
                this.setUpset(true);
                this.m_6710_((LivingEntity)player);
                return InteractionResult.FAIL;
            }
            if (this.getTypeMoC() == 1) {
                return InteractionResult.FAIL;
            }
            if (!player.m_150110_().f_35937_) {
                stack.m_41774_(1);
            }
            player.m_150109_().m_36054_(new ItemStack((ItemLike)Items.f_42455_));
            return InteractionResult.SUCCESS;
        }
        if (this.getIsTamed() && !stack.m_41619_() && MoCTools.isItemEdible(stack.m_41720_())) {
            if (!player.m_150110_().f_35937_) {
                stack.m_41774_(1);
            }
            this.m_21153_(this.m_21233_());
            MoCTools.playCustomSound((Entity)this, (SoundEvent)MoCSoundEvents.ENTITY_GOAT_EATING.get());
            return InteractionResult.SUCCESS;
        }
        if (!this.getIsTamed() && !stack.m_41619_() && MoCTools.isItemEdible(stack.m_41720_())) {
            if (!this.m_9236_().m_5776_()) {
                MoCTools.tameWithName(player, this);
            }
            return InteractionResult.SUCCESS;
        }
        return super.m_6071_(player, hand);
    }

    public boolean getBleating() {
        return this.bleat && this.getAttacking() == 0;
    }

    public void setBleating(boolean flag) {
        this.bleat = flag;
    }

    public int getAttacking() {
        return this.attacking;
    }

    public void setAttacking(int flag) {
        this.attacking = flag;
    }

    protected SoundEvent m_7975_(DamageSource source) {
        return (SoundEvent)MoCSoundEvents.ENTITY_GOAT_HURT.get();
    }

    protected SoundEvent m_7515_() {
        this.setBleating(true);
        if (this.getTypeMoC() == 1) {
            return (SoundEvent)MoCSoundEvents.ENTITY_GOAT_AMBIENT_BABY.get();
        }
        if (this.getTypeMoC() > 2 && this.getTypeMoC() < 5) {
            return (SoundEvent)MoCSoundEvents.ENTITY_GOAT_AMBIENT_FEMALE.get();
        }
        return (SoundEvent)MoCSoundEvents.ENTITY_GOAT_AMBIENT.get();
    }

    protected SoundEvent m_5592_() {
        return (SoundEvent)MoCSoundEvents.ENTITY_GOAT_DEATH.get();
    }

    protected void m_7355_(BlockPos pos, BlockState block) {
        this.m_5496_(SoundEvents.f_12345_, 0.15f, 1.0f);
    }

    protected ResourceLocation m_7582_() {
        return MoCLootTables.GOAT;
    }

    @Override
    public int getMoCMaxAge() {
        return 50;
    }

    public float m_6113_() {
        return 0.15f;
    }

    public float m_6431_(Pose poseIn, EntityDimensions sizeIn) {
        return this.m_20206_() * 0.945f;
    }
}

