/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Vec3i
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.network.syncher.EntityDataAccessor
 *  net.minecraft.network.syncher.EntityDataSerializer
 *  net.minecraft.network.syncher.EntityDataSerializers
 *  net.minecraft.network.syncher.SynchedEntityData
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.server.level.ServerLevel
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.sounds.SoundEvents
 *  net.minecraft.tags.BlockTags
 *  net.minecraft.tags.ItemTags
 *  net.minecraft.tags.StructureTags
 *  net.minecraft.world.Difficulty
 *  net.minecraft.world.DifficultyInstance
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.InteractionResult
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.Entity$RemovalReason
 *  net.minecraft.world.entity.EntityDimensions
 *  net.minecraft.world.entity.EntitySelector
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.Mob
 *  net.minecraft.world.entity.MobSpawnType
 *  net.minecraft.world.entity.PathfinderMob
 *  net.minecraft.world.entity.Pose
 *  net.minecraft.world.entity.SpawnGroupData
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.entity.ai.goal.FloatGoal
 *  net.minecraft.world.entity.ai.goal.Goal
 *  net.minecraft.world.entity.ai.goal.LookAtPlayerGoal
 *  net.minecraft.world.entity.ai.goal.MeleeAttackGoal
 *  net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal
 *  net.minecraft.world.entity.item.ItemEntity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.Items
 *  net.minecraft.world.item.crafting.Ingredient
 *  net.minecraft.world.level.BlockGetter
 *  net.minecraft.world.level.ItemLike
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.LevelAccessor
 *  net.minecraft.world.level.ServerLevelAccessor
 *  net.minecraft.world.level.pathfinder.Path
 *  net.minecraftforge.network.PacketDistributor
 *  net.minecraftforge.network.PacketDistributor$TargetPoint
 */
package drzhark.mocreatures.entity.neutral;

import drzhark.mocreatures.MoCTools;
import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.entity.MoCEntityAnimal;
import drzhark.mocreatures.entity.ai.EntityAIFollowAdult;
import drzhark.mocreatures.entity.ai.EntityAIPanicMoC;
import drzhark.mocreatures.entity.item.MoCEntityKittyBed;
import drzhark.mocreatures.entity.item.MoCEntityLitterBox;
import drzhark.mocreatures.entity.tameable.MoCEntityTameableAnimal;
import drzhark.mocreatures.init.MoCEntities;
import drzhark.mocreatures.init.MoCItems;
import drzhark.mocreatures.init.MoCLootTables;
import drzhark.mocreatures.init.MoCSoundEvents;
import drzhark.mocreatures.network.MoCMessageHandler;
import drzhark.mocreatures.network.message.MoCMessageAnimation;
import drzhark.mocreatures.util.MoCTags;
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializer;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.StructureTags;
import net.minecraft.world.Difficulty;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraftforge.network.PacketDistributor;

public class MoCEntityKitty
extends MoCEntityTameableAnimal {
    private static final EntityDataAccessor<Boolean> SITTING = SynchedEntityData.m_135353_(MoCEntityKitty.class, (EntityDataSerializer)EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Boolean> HUNGRY = SynchedEntityData.m_135353_(MoCEntityKitty.class, (EntityDataSerializer)EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Boolean> EMO = SynchedEntityData.m_135353_(MoCEntityKitty.class, (EntityDataSerializer)EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Boolean> CLIMBING = SynchedEntityData.m_135353_(MoCEntityKitty.class, (EntityDataSerializer)EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Integer> KITTY_STATE = SynchedEntityData.m_135353_(MoCEntityKitty.class, (EntityDataSerializer)EntityDataSerializers.f_135028_);
    private static final EntityDataAccessor<Integer> TEMPER = SynchedEntityData.m_135353_(MoCEntityKitty.class, (EntityDataSerializer)EntityDataSerializers.f_135028_);
    private final int[] treeCoord = new int[]{-1, -1, -1};
    private int kittyTimer;
    private int madTimer;
    private boolean foundTree;
    private boolean isSwinging;
    private boolean onTree;
    private ItemEntity itemAttackTarget;

    public MoCEntityKitty(EntityType<? extends MoCEntityKitty> type, Level world) {
        super((EntityType<? extends MoCEntityTameableAnimal>)type, world);
        this.setAdult(true);
        this.setMoCAge(40);
        this.setKittyState(1);
        this.kittyTimer = 0;
        this.madTimer = this.f_19796_.m_188503_(5);
        this.foundTree = false;
    }

    protected void m_8099_() {
        this.f_21345_.m_25352_(1, (Goal)new FloatGoal((Mob)this));
        this.f_21345_.m_25352_(2, (Goal)new EntityAIPanicMoC((PathfinderMob)this, 1.0));
        this.f_21345_.m_25352_(4, (Goal)new EntityAIFollowAdult((Mob)this, 1.0));
        this.f_21345_.m_25352_(5, (Goal)new MeleeAttackGoal((PathfinderMob)this, 1.0, false));
        this.f_21345_.m_25352_(6, (Goal)new WaterAvoidingRandomStrollGoal((PathfinderMob)this, 1.0));
        this.f_21345_.m_25352_(7, (Goal)new LookAtPlayerGoal((Mob)this, Player.class, 8.0f));
    }

    public static AttributeSupplier.Builder createAttributes() {
        return MoCEntityTameableAnimal.createAttributes().m_22268_(Attributes.f_22277_, 12.0).m_22268_(Attributes.f_22276_, 10.0).m_22268_(Attributes.f_22281_, 2.0).m_22268_(Attributes.f_22279_, 0.25);
    }

    @Override
    public void selectType() {
        if (this.getTypeMoC() == 0) {
            this.setTypeMoC(this.f_19796_.m_188503_(11) + 1);
        }
    }

    @Override
    public ResourceLocation getTexture() {
        switch (this.getTypeMoC()) {
            case 2: {
                return MoCreatures.proxy.getModelTexture("kitty_gray.png");
            }
            case 3: {
                return MoCreatures.proxy.getModelTexture("kitty_black.png");
            }
            case 4: {
                return MoCreatures.proxy.getModelTexture("kitty_calico.png");
            }
            case 5: {
                return MoCreatures.proxy.getModelTexture("kitty_tuxedo.png");
            }
            case 6: {
                return MoCreatures.proxy.getModelTexture("kitty_white_black.png");
            }
            case 7: {
                return MoCreatures.proxy.getModelTexture("kitty_white.png");
            }
            case 8: {
                return MoCreatures.proxy.getModelTexture("kitty_orange_tabby.png");
            }
            case 9: {
                return MoCreatures.proxy.getModelTexture("kitty_cream_dark.png");
            }
            case 10: {
                return MoCreatures.proxy.getModelTexture("kitty_gray_tabby.png");
            }
            case 11: {
                return MoCreatures.proxy.getModelTexture("kitty_yellow_tabby.png");
            }
        }
        return MoCreatures.proxy.getModelTexture("kitty_cream.png");
    }

    @Override
    protected void m_8097_() {
        super.m_8097_();
        this.f_19804_.m_135372_(SITTING, (Object)Boolean.FALSE);
        this.f_19804_.m_135372_(HUNGRY, (Object)Boolean.FALSE);
        this.f_19804_.m_135372_(EMO, (Object)Boolean.FALSE);
        this.f_19804_.m_135372_(CLIMBING, (Object)Boolean.FALSE);
        this.f_19804_.m_135372_(KITTY_STATE, (Object)0);
        this.f_19804_.m_135372_(TEMPER, (Object)0);
    }

    @Override
    public SpawnGroupData m_6518_(ServerLevelAccessor worldIn, DifficultyInstance difficultyIn, MobSpawnType reason, @Nullable SpawnGroupData spawnDataIn, @Nullable CompoundTag dataTag) {
        switch (this.m_9236_().f_46441_.m_188503_(3)) {
            case 0: {
                this.setTemper(0);
                break;
            }
            case 1: {
                this.setTemper(1);
                break;
            }
            case 2: {
                this.setTemper(2);
            }
        }
        return super.m_6518_(worldIn, difficultyIn, reason, spawnDataIn, dataTag);
    }

    public int getKittyState() {
        return (Integer)this.f_19804_.m_135370_(KITTY_STATE);
    }

    public void setKittyState(int i) {
        this.f_19804_.m_135381_(KITTY_STATE, (Object)i);
    }

    @Override
    public int getTemper() {
        return (Integer)this.f_19804_.m_135370_(TEMPER);
    }

    @Override
    public void setTemper(int i) {
        this.f_19804_.m_135381_(TEMPER, (Object)i);
    }

    @Override
    public boolean getIsSitting() {
        return (Boolean)this.f_19804_.m_135370_(SITTING);
    }

    public boolean getIsHungry() {
        return (Boolean)this.f_19804_.m_135370_(HUNGRY);
    }

    public boolean getShowEmoteIcon() {
        return (Boolean)this.f_19804_.m_135370_(EMO);
    }

    public void setShowEmoteIcon(boolean flag) {
        this.f_19804_.m_135381_(EMO, (Object)flag);
    }

    public boolean getIsSwinging() {
        return this.isSwinging;
    }

    public boolean getOnTree() {
        return this.onTree;
    }

    public void setOnTree(boolean var1) {
        this.onTree = var1;
    }

    public void setSitting(boolean flag) {
        this.f_19804_.m_135381_(SITTING, (Object)flag);
    }

    public void setHungry(boolean flag) {
        this.f_19804_.m_135381_(HUNGRY, (Object)flag);
    }

    public void setSwinging(boolean var1) {
        this.isSwinging = var1;
    }

    protected float m_6431_(Pose poseIn, EntityDimensions sizeIn) {
        return sizeIn.f_20378_ * 0.8f;
    }

    @Override
    public boolean m_7327_(Entity entityIn) {
        if (this.getKittyState() != 18 && this.getKittyState() != 10) {
            this.swingArm();
        }
        if (this.getKittyState() == 13 && entityIn instanceof Player || this.getKittyState() == 8 && entityIn instanceof ItemEntity || this.getKittyState() == 18 && entityIn instanceof MoCEntityKitty || this.getKittyState() == 10) {
            return false;
        }
        return super.m_7327_(entityIn);
    }

    @Override
    public boolean m_6469_(DamageSource damagesource, float i) {
        if (super.m_6469_(damagesource, i)) {
            Entity entity = damagesource.m_7639_();
            if (entity != this && entity instanceof LivingEntity) {
                LivingEntity entity1 = (LivingEntity)entity;
                if (this.getKittyState() == 10) {
                    List list = this.m_9236_().m_45976_(MoCEntityKitty.class, this.m_20191_().m_82377_(16.0, 6.0, 16.0));
                    for (MoCEntityKitty entity2 : list) {
                        if (entity2.getKittyState() != 21) continue;
                        entity2.m_6710_(entity1);
                        return true;
                    }
                    return true;
                }
                if (entity1 instanceof Player && super.shouldAttackPlayers() && (this.getTemper() == 2 || this.getTemper() == 0 && this.f_19796_.m_188503_(2) < 1)) {
                    if (this.getKittyState() < 2) {
                        this.m_6710_(entity1);
                    } else if (this.getKittyState() == 19 || this.getKittyState() == 20 || this.getKittyState() == 21) {
                        this.m_6710_(entity1);
                        this.setSitting(false);
                    } else if (this.getKittyState() > 1 && this.getKittyState() != 10 && this.getKittyState() != 19 && this.getKittyState() != 20 && this.getKittyState() != 21) {
                        this.setKittyState(13);
                        this.setSitting(false);
                    }
                    return true;
                }
                this.m_6710_(entity1);
            }
            return true;
        }
        return false;
    }

    public void changeKittyState(int i) {
        this.setKittyState(i);
        this.setSitting(false);
        this.kittyTimer = 0;
        this.setOnTree(false);
        this.foundTree = false;
        this.m_6710_(null);
        this.itemAttackTarget = null;
    }

    public boolean climbingTree() {
        return this.getKittyState() == 16 && this.m_6147_();
    }

    public boolean m_142535_(float distance, float damageMultiplier, DamageSource source) {
        return false;
    }

    @Override
    protected Entity findPlayerToAttack() {
        if (this.m_9236_().m_46791_().m_19028_() > Difficulty.NORMAL.m_19028_() && this.getKittyState() != 8 && this.getKittyState() != 10 && this.getKittyState() != 15 && this.getKittyState() != 18 && this.getKittyState() != 19 && !this.isMovementCeased() && this.getIsHungry()) {
            return this.getClosestTarget((Entity)this, 10.0);
        }
        return null;
    }

    public ResourceLocation getEmoteIcon() {
        switch (this.getKittyState()) {
            case -1: {
                return MoCreatures.proxy.getMiscTexture("emoticon_blank.png");
            }
            case 3: {
                return MoCreatures.proxy.getMiscTexture("emoticon_3.png");
            }
            case 4: {
                return MoCreatures.proxy.getMiscTexture("emoticon_4.png");
            }
            case 5: {
                return MoCreatures.proxy.getMiscTexture("emoticon_5.png");
            }
            case 7: {
                return MoCreatures.proxy.getMiscTexture("emoticon_7.png");
            }
            case 8: {
                return MoCreatures.proxy.getMiscTexture("emoticon_8.png");
            }
            case 9: 
            case 18: {
                return MoCreatures.proxy.getMiscTexture("emoticon_9.png");
            }
            case 10: 
            case 21: {
                return MoCreatures.proxy.getMiscTexture("emoticon_10.png");
            }
            case 11: {
                return MoCreatures.proxy.getMiscTexture("emoticon_11.png");
            }
            case 12: {
                return MoCreatures.proxy.getMiscTexture("emoticon_12.png");
            }
            case 13: {
                return MoCreatures.proxy.getMiscTexture("emoticon_13.png");
            }
            case 16: {
                return MoCreatures.proxy.getMiscTexture("emoticon_16.png");
            }
            case 17: {
                return MoCreatures.proxy.getMiscTexture("emoticon_17.png");
            }
            case 19: 
            case 20: {
                return MoCreatures.proxy.getMiscTexture("emoticon_19.png");
            }
        }
        return MoCreatures.proxy.getMiscTexture("emoticon_1.png");
    }

    protected SoundEvent m_5592_() {
        return this.getKittyState() == 10 ? (SoundEvent)MoCSoundEvents.ENTITY_KITTY_DEATH_BABY.get() : (SoundEvent)MoCSoundEvents.ENTITY_KITTY_DEATH.get();
    }

    protected SoundEvent m_7975_(DamageSource source) {
        return this.getKittyState() == 10 ? (SoundEvent)MoCSoundEvents.ENTITY_KITTY_HURT_BABY.get() : (SoundEvent)MoCSoundEvents.ENTITY_KITTY_HURT.get();
    }

    public ResourceLocation m_7582_() {
        return this.getIsAdult() ? MoCLootTables.KITTY : null;
    }

    protected SoundEvent m_7515_() {
        switch (this.getKittyState()) {
            case 3: {
                return (SoundEvent)MoCSoundEvents.ENTITY_KITTY_HUNGRY.get();
            }
            case 4: {
                if (this.m_20202_() != null) {
                    MoCEntityKittyBed kittyBed = (MoCEntityKittyBed)this.m_20202_();
                    if (kittyBed != null && !kittyBed.getHasMilk()) {
                        return (SoundEvent)MoCSoundEvents.ENTITY_KITTY_DRINKING.get();
                    }
                    if (kittyBed != null && !kittyBed.getHasFood()) {
                        return (SoundEvent)MoCSoundEvents.ENTITY_KITTY_EATING.get();
                    }
                }
                return null;
            }
            case 6: {
                return (SoundEvent)MoCSoundEvents.ENTITY_KITTY_LITTER.get();
            }
            case 10: {
                return (SoundEvent)MoCSoundEvents.ENTITY_KITTY_AMBIENT_BABY.get();
            }
            case 12: 
            case 18: {
                return (SoundEvent)MoCSoundEvents.ENTITY_KITTY_PURR.get();
            }
            case 13: {
                return (SoundEvent)MoCSoundEvents.ENTITY_KITTY_ANGRY.get();
            }
            case 17: {
                return (SoundEvent)MoCSoundEvents.ENTITY_KITTY_TRAPPED.get();
            }
        }
        return (SoundEvent)MoCSoundEvents.ENTITY_KITTY_AMBIENT.get();
    }

    public Mob getKittyStuff(Entity entity, double d, boolean flag) {
        double d1 = -1.0;
        Mob obj = null;
        List list = flag ? this.m_9236_().m_45976_(MoCEntityLitterBox.class, this.m_20191_().m_82400_(d)) : this.m_9236_().m_45976_(MoCEntityKittyBed.class, this.m_20191_().m_82400_(d));
        for (Entity entity1 : list) {
            if (flag) {
                MoCEntityLitterBox entitylitterbox;
                if (!(entity1 instanceof MoCEntityLitterBox) || (entitylitterbox = (MoCEntityLitterBox)entity1).getUsedLitter()) continue;
                double d2 = entity1.m_20275_(entity.m_20185_(), entity.m_20186_(), entity.m_20189_());
                if (!(d < 0.0) && !(d2 < d * d) || d1 != -1.0 && !(d2 < d1) || !entitylitterbox.m_142582_(entity)) continue;
                d1 = d2;
                obj = entitylitterbox;
                continue;
            }
            if (!(entity1 instanceof MoCEntityKittyBed)) continue;
            MoCEntityKittyBed kittyBed = (MoCEntityKittyBed)entity1;
            double d3 = entity1.m_20275_(entity.m_20185_(), entity.m_20186_(), entity.m_20189_());
            if (!(d < 0.0) && !(d3 < d * d) || d1 != -1.0 && !(d3 < d1) || !kittyBed.m_142582_(entity)) continue;
            d1 = d3;
            obj = kittyBed;
        }
        return obj;
    }

    public double m_6048_() {
        if (this.m_20202_() instanceof Player && this.m_9236_().m_5776_()) {
            if (this.getKittyState() == 10) {
                return super.m_6048_() + (double)0.4f;
            }
            if (this.upsideDown()) {
                return super.m_6048_() - (double)0.1f;
            }
            if (this.onMaBack()) {
                return super.m_6048_() + (double)0.1f;
            }
        }
        return super.m_6048_();
    }

    @Override
    public InteractionResult m_6071_(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) {
            return InteractionResult.FAIL;
        }
        InteractionResult tameResult = this.processTameInteract(player, hand);
        if (tameResult != null) {
            return tameResult;
        }
        ItemStack stack = player.m_21120_(hand);
        if (this.getKittyState() == 2 && !stack.m_41619_() && stack.m_41720_() == MoCItems.MEDALLION.get()) {
            if (!this.m_9236_().m_5776_()) {
                MoCTools.tameWithName(player, this);
            }
            if (this.getIsTamed()) {
                if (!player.m_7500_()) {
                    stack.m_41774_(1);
                }
                this.changeKittyState(3);
                this.m_21153_(this.m_21233_());
                return InteractionResult.SUCCESS;
            }
            return InteractionResult.FAIL;
        }
        if (this.getKittyState() == 7 && !stack.m_41619_() && (stack.m_41720_() == Items.f_42502_ || stack.m_204117_(ItemTags.f_13156_))) {
            if (!player.m_7500_()) {
                stack.m_41774_(1);
            }
            MoCTools.playCustomSound((Entity)this, (SoundEvent)MoCSoundEvents.ENTITY_KITTY_EATING.get());
            this.m_21153_(this.m_21233_());
            this.changeKittyState(9);
            return InteractionResult.SUCCESS;
        }
        if (this.getKittyState() == 11 && !stack.m_41619_() && stack.m_41720_() == MoCItems.WOOL_BALL.get()) {
            if (!player.m_7500_()) {
                stack.m_41774_(1);
            }
            this.setKittyState(8);
            if (!this.m_9236_().m_5776_()) {
                ItemEntity entityitem = new ItemEntity(this.m_9236_(), this.m_20185_(), this.m_20186_() + 1.0, this.m_20189_(), new ItemStack((ItemLike)MoCItems.WOOL_BALL.get(), 1));
                entityitem.m_32010_(30);
                entityitem.m_32061_();
                this.m_9236_().m_7967_((Entity)entityitem);
                entityitem.m_20256_(entityitem.m_20184_().m_82520_((double)((this.f_19796_.m_188501_() - this.f_19796_.m_188501_()) * 0.3f), (double)(this.f_19796_.m_188501_() * 0.05f), (double)((this.f_19796_.m_188501_() - this.f_19796_.m_188501_()) * 0.3f)));
                this.itemAttackTarget = entityitem;
            }
            return InteractionResult.SUCCESS;
        }
        if (this.getKittyState() == 13 && !stack.m_41619_() && stack.m_204117_(ItemTags.f_13156_)) {
            if (!player.m_7500_()) {
                stack.m_41774_(1);
            }
            MoCTools.playCustomSound((Entity)this, (SoundEvent)MoCSoundEvents.ENTITY_KITTY_EATING.get());
            this.m_21153_(this.m_21233_());
            this.changeKittyState(7);
            return InteractionResult.SUCCESS;
        }
        if (!stack.m_41619_() && this.getKittyState() > 2 && stack.m_41720_() == MoCItems.MEDALLION.get() || stack.m_41720_() == Items.f_42517_) {
            if (!this.m_9236_().m_5776_()) {
                MoCTools.tameWithName(player, this);
            }
            return InteractionResult.SUCCESS;
        }
        if (!stack.m_41619_() && this.getKittyState() > 2 && this.pickable() && stack.m_41720_() == Items.f_42655_) {
            if (this.m_20329_((Entity)player)) {
                this.changeKittyState(14);
            }
            return InteractionResult.SUCCESS;
        }
        if (!stack.m_41619_() && this.getKittyState() > 2 && this.whipable() && stack.m_41720_() == MoCItems.WHIP.get()) {
            this.setSitting(!this.getIsSitting());
            this.setIsJumping(false);
            this.m_21573_().m_26573_();
            this.m_6710_(null);
            return InteractionResult.SUCCESS;
        }
        if (stack.m_41619_() && this.getKittyState() > 2 && this.pickable()) {
            if (this.m_20329_((Entity)player)) {
                this.changeKittyState(15);
            }
            return InteractionResult.SUCCESS;
        }
        if (stack.m_41619_() && this.getKittyState() == 15) {
            this.changeKittyState(7);
            return InteractionResult.SUCCESS;
        }
        if (this.getKittyState() == 14 && this.m_20202_() != null) {
            this.changeKittyState(7);
            return InteractionResult.SUCCESS;
        }
        return super.m_6071_(player, hand);
    }

    @Override
    public boolean isMovementCeased() {
        return this.getIsSitting() || this.getKittyState() == 6 || this.getKittyState() == 16 && this.getOnTree() || this.getKittyState() == 12 || this.getKittyState() == 17 || this.getKittyState() == 14 || this.getKittyState() == 20 || this.getKittyState() == 23;
    }

    public boolean m_6147_() {
        return this.isBesideClimbableBlock();
    }

    public boolean isBesideClimbableBlock() {
        return (Boolean)this.f_19804_.m_135370_(CLIMBING);
    }

    public void setBesideClimbableBlock(boolean climbing) {
        this.f_19804_.m_135381_(CLIMBING, (Object)climbing);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void m_8107_() {
        block132: {
            block133: {
                if (this.m_9236_().m_5776_()) break block133;
                if (!this.getIsAdult() && this.getKittyState() != 10) {
                    this.setKittyState(10);
                }
                if (this.getKittyState() != 12) {
                    super.m_8107_();
                }
                if (this.f_19796_.m_188503_(200) < 1) {
                    this.setShowEmoteIcon(!this.getShowEmoteIcon());
                }
                if (!this.getIsAdult() && this.f_19796_.m_188503_(200) < 1) {
                    this.m_146762_(this.m_146764_() + 1);
                    if (this.m_146764_() >= 100) {
                        this.setAdult(true);
                    }
                }
                if (!this.getIsHungry() && !this.getIsSitting() && this.f_19796_.m_188503_(100) < 1) {
                    this.setHungry(true);
                }
                switch (this.getKittyState()) {
                    case -1: 
                    case 23: {
                        break;
                    }
                    case 0: {
                        this.changeKittyState(1);
                        break;
                    }
                    case 1: {
                        if (this.f_19796_.m_188503_(20) < 1) {
                            this.changeKittyState(2);
                            break;
                        }
                        if (this.getIsHungry()) {
                            if (this.f_19796_.m_188503_(10) != 0) break;
                            ItemEntity entityItem = this.getClosestItem((Entity)this, 10.0, Ingredient.m_204132_(MoCTags.Items.COOKED_FISHES), Ingredient.m_204132_(MoCTags.Items.COOKED_FISHES));
                            if (entityItem != null) {
                                float f = this.m_20270_((Entity)entityItem);
                                if (f > 2.0f) {
                                    this.setPathToEntity((Entity)entityItem, f);
                                }
                                if (f < 2.0f && this.f_20919_ < 1) {
                                    entityItem.m_146870_();
                                    MoCTools.playCustomSound((Entity)this, (SoundEvent)MoCSoundEvents.ENTITY_KITTY_EATING.get());
                                    this.setHungry(false);
                                    break;
                                }
                            }
                        }
                        break block132;
                    }
                    case 2: {
                        LivingEntity living1 = this.getBoogey(6.0);
                        if (living1 != null) {
                            MoCTools.runLikeHell((Mob)this, (Entity)living1);
                        }
                        if (this.f_19796_.m_188503_(200) < 1) {
                            this.changeKittyState(1);
                            break;
                        }
                        break block132;
                    }
                    case 3: {
                        MoCEntityKittyBed kittyBed;
                        ++this.kittyTimer;
                        if (this.kittyTimer > 500) {
                            if (this.f_19796_.m_188503_(200) < 1) {
                                this.changeKittyState(13);
                                break;
                            }
                            if (this.f_19796_.m_188503_(500) < 1) {
                                this.changeKittyState(7);
                                break;
                            }
                        }
                        if (this.f_19796_.m_188503_(20) != 0 || (kittyBed = (MoCEntityKittyBed)this.getKittyStuff((Entity)this, 18.0, false)) == null || kittyBed.m_20160_() || !kittyBed.getHasMilk() && !kittyBed.getHasFood()) break;
                        float f5 = this.m_20270_((Entity)kittyBed);
                        if (f5 > 2.0f) {
                            this.setPathToEntity((Entity)kittyBed, f5);
                        }
                        if (f5 < 2.0f && this.m_20329_((Entity)kittyBed)) {
                            this.changeKittyState(4);
                            this.setSitting(true);
                            break;
                        }
                        break block132;
                    }
                    case 4: {
                        if (this.m_20202_() != null) {
                            MoCEntityKittyBed kittyBed1 = (MoCEntityKittyBed)this.m_20202_();
                            if (kittyBed1 != null && !kittyBed1.getHasMilk() && !kittyBed1.getHasFood()) {
                                this.m_21153_(this.m_21233_());
                                this.m_8127_();
                                this.changeKittyState(5);
                            }
                        } else {
                            this.m_21153_(this.m_21233_());
                            this.m_8127_();
                            this.changeKittyState(5);
                        }
                        if (this.f_19796_.m_188503_(2500) < 1) {
                            this.m_21153_(this.m_21233_());
                            this.m_8127_();
                            this.changeKittyState(7);
                            break;
                        }
                        break block132;
                    }
                    case 5: {
                        ++this.kittyTimer;
                        if (this.kittyTimer > 2000 && this.f_19796_.m_188503_(1000) < 1) {
                            this.changeKittyState(13);
                            break;
                        }
                        if (this.f_19796_.m_188503_(20) != 0) break;
                        MoCEntityLitterBox litterBox = (MoCEntityLitterBox)this.getKittyStuff((Entity)this, 18.0, true);
                        if (litterBox != null && !litterBox.m_20160_()) {
                            if (litterBox.getUsedLitter()) break;
                            float f6 = this.m_20270_((Entity)litterBox);
                            if (f6 > 2.0f) {
                                this.setPathToEntity((Entity)litterBox, f6);
                            }
                            if (f6 < 2.0f && this.m_20329_((Entity)litterBox)) {
                                this.changeKittyState(6);
                                break;
                            }
                        }
                        break block132;
                    }
                    case 6: {
                        ++this.kittyTimer;
                        if (this.kittyTimer <= 300) {
                            if (this.f_19796_.m_188503_(40) < 1) {
                                MoCTools.playCustomSound((Entity)this, SoundEvents.f_12331_);
                                break;
                            }
                            break block132;
                        } else {
                            MoCTools.playCustomSound((Entity)this, SoundEvents.f_12389_);
                            MoCEntityLitterBox litterBox1 = (MoCEntityLitterBox)this.m_20202_();
                            if (litterBox1 != null) {
                                litterBox1.setUsedLitter(true);
                                litterBox1.litterTime = 0;
                            }
                            this.m_8127_();
                            this.changeKittyState(7);
                            break;
                        }
                    }
                    case 7: {
                        ItemStack stack;
                        Player player;
                        if (this.getIsSitting()) break;
                        if (this.f_19796_.m_188503_(20) < 1 && (player = this.m_9236_().m_45930_((Entity)this, 12.0)) != null && !(stack = player.m_150109_().m_36056_()).m_41619_() && stack.m_41720_() == MoCItems.WOOL_BALL.get()) {
                            this.changeKittyState(11);
                            break;
                        }
                        if (this.m_20072_() && this.f_19796_.m_188503_(500) < 1) {
                            this.changeKittyState(13);
                            break;
                        }
                        if (!this.m_9236_().m_46461_() && this.f_19796_.m_188503_(500) < 1) {
                            MoCEntityKittyBed kittyBed1 = (MoCEntityKittyBed)this.getKittyStuff((Entity)this, 18.0, false);
                            if (kittyBed1 == null || kittyBed1.m_20160_()) {
                                this.changeKittyState(12);
                                break;
                            }
                            float f9 = this.m_20270_((Entity)kittyBed1);
                            if (f9 > 2.0f) {
                                this.setPathToEntity((Entity)kittyBed1, f9);
                                break;
                            }
                            if (this.m_20329_((Entity)kittyBed1)) {
                                this.changeKittyState(12);
                                break;
                            }
                            break block132;
                        } else {
                            if (this.m_21223_() < this.m_21233_() || this.f_19796_.m_188503_(3000) < 1) {
                                this.changeKittyState(3);
                                break;
                            }
                            if (this.m_9236_().m_45527_(this.m_20183_()) && this.f_19796_.m_188503_(4000) < 1) {
                                this.changeKittyState(16);
                                break;
                            }
                        }
                        break block132;
                    }
                    case 8: {
                        if (this.f_19796_.m_188503_(this.getTemper() == 2 ? 300 : 200) < 1) {
                            if (this.m_20072_()) {
                                this.changeKittyState(13);
                                break;
                            }
                            this.changeKittyState(7);
                            break;
                        }
                        if (this.itemAttackTarget != null) {
                            float f1 = this.m_20270_((Entity)this.itemAttackTarget);
                            if (f1 < 1.5f) {
                                this.swingArm();
                                if (this.f_19796_.m_188503_(10) < 1) {
                                    float force = 0.2f;
                                    if (this.getTemper() == 2) {
                                        force = 0.3f;
                                    }
                                    if (this.getTypeMoC() == 10) {
                                        force = 0.1f;
                                    }
                                    MoCTools.bigSmack((Entity)this, (Entity)this.itemAttackTarget, force);
                                    break;
                                }
                                break block132;
                            } else {
                                this.setPathToEntity((Entity)this.itemAttackTarget, f1);
                                break;
                            }
                        }
                        break block132;
                    }
                    case 9: {
                        ++this.kittyTimer;
                        if (this.f_19796_.m_188503_(50) < 1) {
                            List list = this.m_9236_().m_6443_(Entity.class, this.m_20191_().m_82377_(16.0, 6.0, 16.0), EntitySelector.f_20408_.and(e -> e != this));
                            for (int j = 0; j < list.size(); ++j) {
                                Entity entity = (Entity)list.get(j);
                                if (!(entity instanceof MoCEntityKitty) || ((MoCEntityKitty)entity).getKittyState() != 9) continue;
                                this.changeKittyState(18);
                                this.m_6710_((LivingEntity)entity);
                                ((MoCEntityKitty)entity).changeKittyState(18);
                                ((MoCEntityKitty)entity).m_6710_((LivingEntity)this);
                                break;
                            }
                        }
                        if (this.kittyTimer > 2000) {
                            this.changeKittyState(7);
                            break;
                        }
                        break block132;
                    }
                    case 10: {
                        float f3;
                        float f2;
                        if (this.getIsAdult()) {
                            this.changeKittyState(7);
                            break;
                        }
                        if (this.f_19796_.m_188503_(50) < 1) {
                            List list1 = this.m_9236_().m_6443_(Entity.class, this.m_20191_().m_82377_(16.0, 6.0, 16.0), EntitySelector.f_20408_.and(e -> e != this));
                            for (Entity entity1 : list1) {
                                float f9;
                                if (!(entity1 instanceof MoCEntityKitty) || ((MoCEntityKitty)entity1).getKittyState() != 21 || !((f9 = this.m_20270_(entity1)) > 12.0f)) continue;
                                this.m_6710_((LivingEntity)entity1);
                            }
                        }
                        if ((this.itemAttackTarget == null || this.m_5448_() == null) && this.f_19796_.m_188503_(100) < 1) {
                            int i = this.f_19796_.m_188503_(10);
                            if (i < 7) {
                                this.itemAttackTarget = this.getClosestItem((Entity)this, 10.0, new Ingredient[0]);
                            } else {
                                this.m_6710_((LivingEntity)this.m_9236_().m_45930_((Entity)this, 18.0));
                            }
                        }
                        if ((this.m_5448_() != null || this.itemAttackTarget != null) && this.f_19796_.m_188503_(400) < 1) {
                            this.m_6710_(null);
                            this.itemAttackTarget = null;
                        }
                        if (this.itemAttackTarget != null && (f2 = this.m_20270_((Entity)this.itemAttackTarget)) < 1.5f) {
                            this.swingArm();
                            if (this.f_19796_.m_188503_(10) < 1) {
                                MoCTools.bigSmack((Entity)this, (Entity)this.itemAttackTarget, 0.2f);
                            }
                        }
                        if (this.m_5448_() instanceof MoCEntityKitty && this.f_19796_.m_188503_(20) < 1 && (f3 = this.m_20270_((Entity)this.m_5448_())) < 2.0f) {
                            this.swingArm();
                            this.m_21573_().m_26573_();
                        }
                        if (!(this.m_5448_() instanceof Player)) break;
                        float f4 = this.m_20270_((Entity)this.m_5448_());
                        if (f4 < 2.0f && this.f_19796_.m_188503_(20) < 1) {
                            this.swingArm();
                            break;
                        }
                        break block132;
                    }
                    case 11: {
                        Player player1 = this.m_9236_().m_45930_((Entity)this, 18.0);
                        if (player1 != null) {
                            if (this.f_19796_.m_188503_(10) != 0) break;
                            ItemStack stack1 = player1.m_150109_().m_36056_();
                            if (stack1.m_41720_() != MoCItems.WOOL_BALL.get()) {
                                this.changeKittyState(7);
                                break;
                            }
                            float f8 = this.m_20270_((Entity)player1);
                            if (f8 > 5.0f) {
                                this.getPathOrWalkableBlock((Entity)player1, f8);
                                break;
                            }
                        }
                        break block132;
                    }
                    case 12: {
                        ++this.kittyTimer;
                        if (this.m_9236_().m_46461_() || this.kittyTimer > 500 && this.f_19796_.m_188503_(500) < 1) {
                            this.m_8127_();
                            this.changeKittyState(7);
                            break;
                        }
                        this.setSitting(true);
                        if (this.f_19796_.m_188503_(100) < 1 || !this.m_20096_()) {
                            super.m_8107_();
                            break;
                        }
                        break block132;
                    }
                    case 13: {
                        if (this.getTemper() == 1 || this.getTemper() == 0 && this.f_19796_.m_188503_(2) < 1) {
                            this.changeKittyState(7);
                        }
                        this.setHungry(false);
                        this.m_6710_((LivingEntity)this.m_9236_().m_45930_((Entity)this, 18.0));
                        if (this.m_5448_() != null) {
                            float f7 = this.m_20270_((Entity)this.m_5448_());
                            if (f7 < 1.5f) {
                                this.swingArm();
                                if (this.f_19796_.m_188503_(20) < 1) {
                                    --this.madTimer;
                                    this.m_5448_().m_6469_(this.m_9236_().m_269111_().m_269333_((LivingEntity)this), 1.0f);
                                    if (this.madTimer < 1) {
                                        this.changeKittyState(7);
                                        this.madTimer = this.f_19796_.m_188503_(5);
                                    }
                                }
                            }
                            if (this.f_19796_.m_188503_(500) < 1) {
                                this.changeKittyState(7);
                                break;
                            }
                            break block132;
                        } else {
                            this.changeKittyState(7);
                            break;
                        }
                    }
                    case 14: {
                        if (this.m_20096_()) {
                            this.changeKittyState(13);
                            break;
                        }
                        if (this.f_19796_.m_188503_(50) < 1) {
                            this.swingArm();
                        }
                        if (this.m_20202_() == null) break;
                        this.m_146922_(this.m_20202_().m_146908_() + 90.0f);
                        Player player2 = (Player)this.m_20202_();
                        if (player2 == null) {
                            this.changeKittyState(13);
                            break;
                        }
                        ItemStack stack2 = player2.m_150109_().m_36056_();
                        if (stack2.m_41720_() != Items.f_42655_) {
                            this.changeKittyState(13);
                            break;
                        }
                        break block132;
                    }
                    case 15: {
                        if (this.m_20096_()) {
                            this.changeKittyState(7);
                        }
                        if (this.m_20202_() != null) {
                            this.m_146922_(this.m_20202_().m_146908_() + 90.0f);
                            break;
                        }
                        break block132;
                    }
                    case 16: {
                        ++this.kittyTimer;
                        if (this.kittyTimer > 500) {
                            if (!this.getOnTree()) {
                                this.changeKittyState(7);
                            } else {
                                this.setKittyState(17);
                            }
                        }
                        if (!this.getOnTree()) {
                            Path pathEntity;
                            BlockPos treeTop;
                            if (!this.foundTree && this.f_19796_.m_188503_(50) < 1 && (treeTop = MoCTools.getTreeTop(this.m_9236_(), (Entity)this, 18)) != null) {
                                this.treeCoord[0] = treeTop.m_123341_();
                                this.treeCoord[1] = treeTop.m_123342_();
                                this.treeCoord[2] = treeTop.m_123343_();
                                this.foundTree = true;
                            }
                            if ((pathEntity = this.m_21573_().m_26524_((double)this.treeCoord[0], (double)this.treeCoord[1], (double)this.treeCoord[2], 0)) != null) {
                                this.m_21573_().m_26536_(pathEntity, 1.5);
                            }
                            double dX = (double)this.treeCoord[0] + 0.5 - this.m_20185_();
                            double dY = (double)this.treeCoord[1] + 0.5 - (this.m_20186_() + (double)this.m_20192_());
                            double dZ = (double)this.treeCoord[2] + 0.5 - this.m_20189_();
                            double distance = Math.sqrt(dX * dX + dY * dY + dZ * dZ);
                            this.m_20334_(dX / distance * 0.05, this.m_20184_().f_82480_, dZ / distance * 0.05);
                            if (!this.m_20096_() && this.f_19862_) {
                                this.f_19794_ = this.m_9236_().m_8055_(this.m_20183_()).m_204336_(BlockTags.f_13035_) || this.m_9236_().m_8055_(this.m_20183_().m_7494_()).m_204336_(BlockTags.f_13035_);
                                break;
                            }
                            if (!this.m_9236_().m_8055_(this.m_20183_()).m_60828_((BlockGetter)this.m_9236_(), this.m_20183_())) {
                                this.f_19794_ = false;
                                this.m_6138_();
                                BlockPos posBelow = this.m_20183_().m_7495_();
                                if (this.m_9236_().m_8055_(posBelow).m_204336_(BlockTags.f_13035_)) {
                                    this.setOnTree(true);
                                    break;
                                }
                            }
                        }
                        break block132;
                    }
                    case 17: {
                        Player player3;
                        if (this.getTemper() == 2 || this.getTemper() == 0 && this.f_19796_.m_188503_(2) < 1) {
                            this.changeKittyState(7);
                        }
                        if ((player3 = this.m_9236_().m_45930_((Entity)this, 2.0)) != null) {
                            this.changeKittyState(7);
                            break;
                        }
                        break block132;
                    }
                    case 18: {
                        if (!(this.m_5448_() instanceof MoCEntityKitty)) {
                            this.changeKittyState(9);
                            break;
                        }
                        MoCEntityKitty kitty = (MoCEntityKitty)this.m_5448_();
                        if (kitty != null && kitty.getKittyState() == 18) {
                            float f10;
                            if (this.f_19796_.m_188503_(50) < 1) {
                                this.swingArm();
                            }
                            if ((f10 = this.m_20270_((Entity)kitty)) < 5.0f) {
                                ++this.kittyTimer;
                            }
                            if (this.kittyTimer > 500 && this.f_19796_.m_188503_(50) < 1) {
                                ((MoCEntityKitty)this.m_5448_()).changeKittyState(7);
                                this.changeKittyState(19);
                                break;
                            }
                            break block132;
                        } else {
                            this.changeKittyState(9);
                            break;
                        }
                    }
                    case 19: {
                        if (this.f_19796_.m_188503_(20) != 0) break;
                        MoCEntityKittyBed kittyBed2 = (MoCEntityKittyBed)this.getKittyStuff((Entity)this, 18.0, false);
                        if (kittyBed2 != null) {
                            if (kittyBed2.m_20160_()) break;
                            float f11 = this.m_20270_((Entity)kittyBed2);
                            if (f11 > 2.0f) {
                                this.setPathToEntity((Entity)kittyBed2, f11);
                            }
                            if (f11 < 2.0f && this.m_20329_((Entity)kittyBed2)) {
                                this.changeKittyState(20);
                                break;
                            }
                        }
                        break block132;
                    }
                    case 20: {
                        if (this.m_20202_() == null) {
                            this.changeKittyState(19);
                            break;
                        }
                        this.m_146922_(180.0f);
                        ++this.kittyTimer;
                        if (this.kittyTimer <= 1000) break;
                        int i2 = this.f_19796_.m_188503_(3) + 1;
                        for (int l2 = 0; l2 < i2; ++l2) {
                            MoCEntityKitty kitty1 = (MoCEntityKitty)((EntityType)MoCEntities.KITTY.get()).m_20615_(this.m_9236_());
                            int babyType = this.getTypeMoC();
                            if (this.f_19796_.m_188503_(2) < 1) {
                                babyType = this.f_19796_.m_188503_(8) + 1;
                            }
                            kitty1.setTypeMoC(babyType);
                            kitty1.m_6034_(this.m_20185_(), this.m_20186_(), this.m_20189_());
                            this.m_9236_().m_7967_((Entity)kitty1);
                            MoCTools.playCustomSound((Entity)this, SoundEvents.f_11752_);
                            kitty1.setAdult(false);
                            kitty1.changeKittyState(10);
                        }
                        this.m_8127_();
                        this.changeKittyState(21);
                        break;
                    }
                    case 21: {
                        ++this.kittyTimer;
                        if (this.kittyTimer > 2000) {
                            List list2 = this.m_9236_().m_6443_(Entity.class, this.m_20191_().m_82377_(24.0, 8.0, 24.0), EntitySelector.f_20408_.and(e -> e != this));
                            int i3 = 0;
                            for (Entity entity2 : list2) {
                                if (!(entity2 instanceof MoCEntityKitty) || ((MoCEntityKitty)entity2).getKittyState() != 10) continue;
                                ++i3;
                            }
                            if (i3 < 1) {
                                this.changeKittyState(7);
                                break;
                            }
                            this.kittyTimer = 1000;
                        }
                        if (this.m_5448_() instanceof Player && this.f_19796_.m_188503_(300) < 1) {
                            this.m_6710_(null);
                            break;
                        }
                        break block132;
                    }
                    default: {
                        this.changeKittyState(7);
                        break;
                    }
                }
                break block132;
            }
            super.m_8107_();
        }
        if (this.m_20159_()) {
            MoCTools.dismountSneakingPlayer((Mob)this);
        }
    }

    public boolean onMaBack() {
        return this.getKittyState() == 15;
    }

    @Override
    public void m_8119_() {
        super.m_8119_();
        if (this.getIsSwinging()) {
            this.f_20921_ += 0.2f;
            if (this.f_20921_ > 2.0f) {
                this.setSwinging(false);
                this.f_20921_ = 0.0f;
            }
        }
        if (!this.m_9236_().m_5776_() && this.getKittyState() == 16) {
            this.setBesideClimbableBlock(this.f_19862_);
        }
    }

    private boolean pickable() {
        return this.getKittyState() != 13 && this.getKittyState() != 14 && this.getKittyState() != 15 && this.getKittyState() != 19 && this.getKittyState() != 20 && this.getKittyState() != 21;
    }

    @Override
    public boolean renderName() {
        return this.getKittyState() != 14 && this.getKittyState() != 15 && this.getKittyState() > 1 && super.renderName();
    }

    @Override
    public void m_142687_(Entity.RemovalReason reason) {
        if (reason == Entity.RemovalReason.DISCARDED) {
            super.m_142687_(reason);
            return;
        }
        if (this.m_9236_().m_5776_() || this.getKittyState() <= 2 || this.m_21223_() <= 0.0f) {
            super.m_142687_(reason);
        }
    }

    public void swingArm() {
        if (!this.m_9236_().m_5776_()) {
            MoCMessageHandler.INSTANCE.send(PacketDistributor.NEAR.with(() -> new PacketDistributor.TargetPoint(this.m_20185_(), this.m_20186_(), this.m_20189_(), 64.0, this.m_9236_().m_46472_())), (Object)new MoCMessageAnimation(this.m_19879_(), 0));
        }
        if (!this.getIsSwinging()) {
            this.setSwinging(true);
            this.f_20921_ = 0.0f;
        }
    }

    @Override
    public void performAnimation(int i) {
        this.swingArm();
    }

    public boolean upsideDown() {
        return this.getKittyState() == 14;
    }

    public boolean whipable() {
        return this.getKittyState() != 13;
    }

    public static boolean getCanSpawnHere(EntityType<MoCEntityAnimal> type, ServerLevel world, MobSpawnType reason, BlockPos pos, Random randomIn) {
        if (MoCreatures.proxy.kittyVillageChance <= 0) {
            return MoCEntityAnimal.getCanSpawnHere(type, (LevelAccessor)world, reason, pos, randomIn);
        }
        BlockPos villagePos = world.m_215011_(StructureTags.f_215889_, pos, 100, true);
        if (villagePos != null && pos.m_123331_((Vec3i)villagePos) <= 16384.0) {
            return MoCEntityAnimal.getCanSpawnHere(type, (LevelAccessor)world, reason, pos, randomIn);
        }
        return false;
    }

    @Override
    public void m_7380_(CompoundTag tag) {
        super.m_7380_(tag);
        tag.m_128379_("Sitting", this.getIsSitting());
        tag.m_128405_("KittyState", this.getKittyState());
        tag.m_128405_("Temper", this.getTemper());
    }

    @Override
    public void m_7378_(CompoundTag tag) {
        super.m_7378_(tag);
        this.setSitting(tag.m_128471_("Sitting"));
        this.setKittyState(tag.m_128451_("KittyState"));
        this.setTemper(tag.m_128451_("Temper"));
    }

    @Override
    public void dropMyStuff() {
        if (!this.m_9236_().m_5776_() && this.getIsTamed()) {
            MoCTools.dropCustomItem((Entity)this, this.m_9236_(), new ItemStack((ItemLike)MoCItems.MEDALLION.get(), 1));
        }
    }

    @Override
    public void m_6667_(DamageSource damagesource) {
        this.dropMyStuff();
        super.m_6667_(damagesource);
    }

    @Override
    public boolean swimmerEntity() {
        return true;
    }

    @Override
    public int nameYOffset() {
        if (this.getIsSitting()) {
            return -30;
        }
        return -40;
    }
}

