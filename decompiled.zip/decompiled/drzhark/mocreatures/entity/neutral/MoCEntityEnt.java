/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  net.minecraft.core.BlockPos
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.server.level.ServerLevel
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.util.Mth
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityDimensions
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.Mob
 *  net.minecraft.world.entity.PathfinderMob
 *  net.minecraft.world.entity.Pose
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.entity.ai.goal.FloatGoal
 *  net.minecraft.world.entity.ai.goal.Goal
 *  net.minecraft.world.entity.ai.goal.LookAtPlayerGoal
 *  net.minecraft.world.entity.ai.goal.MeleeAttackGoal
 *  net.minecraft.world.entity.animal.Animal
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.AxeItem
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.Items
 *  net.minecraft.world.level.ItemLike
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraft.world.level.block.SaplingBlock
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraftforge.common.util.FakePlayerFactory
 *  net.minecraftforge.event.level.BlockEvent$BreakEvent
 */
package drzhark.mocreatures.entity.neutral;

import com.mojang.authlib.GameProfile;
import drzhark.mocreatures.MoCTools;
import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.entity.MoCEntityAnimal;
import drzhark.mocreatures.entity.ai.EntityAIWanderMoC2;
import drzhark.mocreatures.init.MoCSoundEvents;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SaplingBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.util.FakePlayerFactory;
import net.minecraftforge.event.level.BlockEvent;

public class MoCEntityEnt
extends MoCEntityAnimal {
    private static final Block[] tallgrass = new Block[]{Blocks.f_50034_, Blocks.f_50035_};
    private static final Block[] double_plant = new Block[]{Blocks.f_50355_, Blocks.f_50356_, Blocks.f_50357_, Blocks.f_50358_, Blocks.f_50359_, Blocks.f_50360_};
    private static final Block[] red_flower = new Block[]{Blocks.f_50112_, Blocks.f_50113_, Blocks.f_50114_, Blocks.f_50115_, Blocks.f_50116_, Blocks.f_50117_, Blocks.f_50118_, Blocks.f_50119_, Blocks.f_50120_};

    public MoCEntityEnt(EntityType<? extends MoCEntityEnt> type, Level world) {
        super(type, world);
        this.m_274367_(2.0f);
        this.f_21364_ = 10;
    }

    protected void m_8099_() {
        this.f_21345_.m_25352_(1, (Goal)new FloatGoal((Mob)this));
        this.f_21345_.m_25352_(5, (Goal)new MeleeAttackGoal((PathfinderMob)this, 1.0, false));
        this.f_21345_.m_25352_(6, (Goal)new EntityAIWanderMoC2((PathfinderMob)this, 1.0));
        this.f_21345_.m_25352_(7, (Goal)new LookAtPlayerGoal((Mob)this, Player.class, 8.0f));
    }

    public static AttributeSupplier.Builder createAttributes() {
        return MoCEntityAnimal.createAttributes().m_22268_(Attributes.f_22276_, 60.0).m_22268_(Attributes.f_22284_, 7.0).m_22268_(Attributes.f_22281_, 7.5).m_22268_(Attributes.f_22279_, 0.25).m_22268_(Attributes.f_22278_, 1.0);
    }

    @Override
    public void selectType() {
        if (this.getTypeMoC() == 0) {
            this.setTypeMoC(this.f_19796_.m_188503_(2) + 1);
        }
    }

    @Override
    public ResourceLocation getTexture() {
        if (this.getTypeMoC() == 2) {
            return MoCreatures.proxy.getModelTexture("ent_birch.png");
        }
        return MoCreatures.proxy.getModelTexture("ent_oak.png");
    }

    public int m_213860_() {
        return 10;
    }

    @Override
    public boolean m_6469_(DamageSource damagesource, float i) {
        Player ep;
        ItemStack currentItem;
        Item itemheld;
        if (damagesource.m_7639_() != null && damagesource.m_7639_() instanceof Player && (itemheld = (currentItem = (ep = (Player)damagesource.m_7639_()).m_150109_().m_36056_()).m_41720_()) instanceof AxeItem) {
            this.m_9236_().m_46791_();
            if (super.shouldAttackPlayers()) {
                this.m_6710_((LivingEntity)ep);
            }
            return super.m_6469_(damagesource, i);
        }
        if (damagesource == this.m_269291_().m_269387_() || damagesource == this.m_269291_().m_269549_() || damagesource == this.m_269291_().m_269233_()) {
            return super.m_6469_(damagesource, i);
        }
        return false;
    }

    protected void m_7472_(DamageSource source, int looting, boolean recentlyHitIn) {
        int i = this.f_19796_.m_188503_(3);
        int qty = this.f_19796_.m_188503_(12) + 4;
        if (this.getTypeMoC() == 2) {
            if (i == 0) {
                this.m_5552_(new ItemStack((ItemLike)Blocks.f_50001_, qty), 0.0f);
                return;
            }
            if (i == 1) {
                this.m_5552_(new ItemStack((ItemLike)Items.f_42398_, qty), 0.0f);
                return;
            }
            this.m_5552_(new ItemStack((ItemLike)Blocks.f_50748_, qty), 0.0f);
        } else {
            if (i == 0) {
                this.m_5552_(new ItemStack((ItemLike)Blocks.f_49999_, qty), 0.0f);
                return;
            }
            if (i == 1) {
                this.m_5552_(new ItemStack((ItemLike)Items.f_42398_, qty), 0.0f);
                return;
            }
            this.m_5552_(new ItemStack((ItemLike)Blocks.f_50746_, qty), 0.0f);
        }
    }

    protected SoundEvent m_5592_() {
        return (SoundEvent)MoCSoundEvents.ENTITY_ENT_DEATH.get();
    }

    protected SoundEvent m_7975_(DamageSource source) {
        return (SoundEvent)MoCSoundEvents.ENTITY_ENT_HURT.get();
    }

    protected SoundEvent m_7515_() {
        return (SoundEvent)MoCSoundEvents.ENTITY_ENT_AMBIENT.get();
    }

    public void m_8107_() {
        super.m_8107_();
        if (!this.m_9236_().m_5776_()) {
            if (this.m_5448_() == null && this.f_19796_.m_188503_(500) == 0) {
                this.plantOnFertileGround();
            }
            if (this.f_19796_.m_188503_(100) == 0) {
                this.attractCritter();
            }
        }
    }

    private void attractCritter() {
        List list = this.m_9236_().m_45933_((Entity)this, this.m_20191_().m_82377_(8.0, 3.0, 8.0));
        int n = this.f_19796_.m_188503_(3) + 1;
        int j = 0;
        for (Entity entity : list) {
            Animal entityanimal;
            if (!(entity instanceof Animal) || !(entity.m_20205_() < 0.6f) || !(entity.m_20206_() < 0.6f) || (entityanimal = (Animal)entity).m_5448_() != null || MoCTools.isTamed((Entity)entityanimal)) continue;
            entityanimal.m_6710_((LivingEntity)this);
            entityanimal.m_21573_().m_5624_((Entity)this, 1.0);
            if (++j <= n) continue;
            return;
        }
    }

    private void plantOnFertileGround() {
        BlockPos pos = new BlockPos(Mth.m_14107_((double)this.m_20185_()), Mth.m_14107_((double)this.m_20186_()), Mth.m_14107_((double)this.m_20189_()));
        Block blockUnderFeet = this.m_9236_().m_8055_(pos.m_7495_()).m_60734_();
        Block blockOnFeet = this.m_9236_().m_8055_(pos).m_60734_();
        if (Blocks.f_50493_.m_49966_().m_60713_(blockUnderFeet)) {
            Block block = Blocks.f_50440_;
            BlockEvent.BreakEvent event = null;
            if (!this.m_9236_().m_5776_()) {
                event = new BlockEvent.BreakEvent(this.m_9236_(), pos, block.m_49966_(), (Player)FakePlayerFactory.get((ServerLevel)((ServerLevel)this.m_9236_()), (GameProfile)MoCreatures.MOCFAKEPLAYER));
            }
            if (event != null && !event.isCanceled()) {
                this.m_9236_().m_7731_(pos.m_7495_(), block.m_49966_(), 3);
                return;
            }
            return;
        }
        if (Blocks.f_50440_.m_49966_().m_60713_(blockUnderFeet) && blockOnFeet == Blocks.f_50016_) {
            BlockState iblockstate = this.getBlockStateToBePlanted();
            int plantChance = 3;
            if (iblockstate.m_60734_() instanceof SaplingBlock) {
                plantChance = 10;
            }
            for (int x = -1; x < 2; ++x) {
                for (int z = -1; z < 2; ++z) {
                    BlockPos pos1 = new BlockPos(Mth.m_14107_((double)(this.m_20185_() + (double)x)), Mth.m_14107_((double)this.m_20186_()), Mth.m_14107_((double)(this.m_20189_() + (double)z)));
                    Block blockToPlant = this.m_9236_().m_8055_(pos1).m_60734_();
                    if (this.f_19796_.m_188503_(plantChance) != 0 || blockToPlant != Blocks.f_50016_) continue;
                    this.m_9236_().m_7731_(pos1, iblockstate, 3);
                }
            }
        }
    }

    private BlockState getBlockStateToBePlanted() {
        switch (this.f_19796_.m_188503_(20)) {
            case 0: 
            case 1: 
            case 2: 
            case 3: 
            case 4: 
            case 5: {
                return red_flower[this.f_19796_.m_188503_(red_flower.length)].m_49966_();
            }
            case 6: {
                return Blocks.f_50072_.m_49966_();
            }
            case 7: {
                return Blocks.f_50073_.m_49966_();
            }
            case 8: 
            case 9: 
            case 10: 
            case 11: {
                return tallgrass[this.f_19796_.m_188503_(tallgrass.length)].m_49966_();
            }
            case 12: 
            case 13: 
            case 14: 
            case 15: {
                return Blocks.f_50746_.m_49966_();
            }
            case 16: {
                return Blocks.f_50748_.m_49966_();
            }
            case 17: {
                return Blocks.f_50747_.m_49966_();
            }
            case 18: {
                return Blocks.f_50749_.m_49966_();
            }
            case 19: {
                return Blocks.f_50750_.m_49966_();
            }
        }
        return Blocks.f_50034_.m_49966_();
    }

    public boolean m_6094_() {
        return false;
    }

    public void m_7334_(Entity entityIn) {
        if (entityIn.m_20205_() < 1.5f) {
            super.m_7334_(entityIn);
        }
    }

    public void m_19970_(LivingEntity entityLivingBaseIn, Entity entityIn) {
        super.m_19970_(entityLivingBaseIn, entityIn);
    }

    @Override
    public boolean isNotScared() {
        return true;
    }

    protected boolean m_6107_() {
        return false;
    }

    protected float m_6431_(Pose poseIn, EntityDimensions sizeIn) {
        return this.m_20206_() * 0.9f;
    }
}

