/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.entity.monster;

import drzhark.mocreatures.entity.MoCEntityMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

public class MoCEntityWerewolf
extends MoCEntityMob {
    public MoCEntityWerewolf(EntityType<? extends MoCEntityWerewolf> type, Level world) {
        super(type, world);
    }
}

