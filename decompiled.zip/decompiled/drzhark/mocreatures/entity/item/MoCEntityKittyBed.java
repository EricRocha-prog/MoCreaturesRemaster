/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.network.syncher.EntityDataAccessor
 *  net.minecraft.network.syncher.EntityDataSerializer
 *  net.minecraft.network.syncher.EntityDataSerializers
 *  net.minecraft.network.syncher.SynchedEntityData
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.sounds.SoundEvents
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.InteractionResult
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.Entity$RemovalReason
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.Mob
 *  net.minecraft.world.entity.MoverType
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.Items
 *  net.minecraft.world.level.ClipContext
 *  net.minecraft.world.level.ClipContext$Block
 *  net.minecraft.world.level.ClipContext$Fluid
 *  net.minecraft.world.level.ItemLike
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.phys.HitResult$Type
 *  net.minecraft.world.phys.Vec3
 */
package drzhark.mocreatures.entity.item;

import drzhark.mocreatures.MoCTools;
import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.entity.neutral.MoCEntityKitty;
import drzhark.mocreatures.init.MoCItems;
import drzhark.mocreatures.init.MoCSoundEvents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializer;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class MoCEntityKittyBed
extends Mob {
    private static final EntityDataAccessor<Boolean> HAS_MILK = SynchedEntityData.m_135353_(MoCEntityKittyBed.class, (EntityDataSerializer)EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Boolean> HAS_FOOD = SynchedEntityData.m_135353_(MoCEntityKittyBed.class, (EntityDataSerializer)EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Boolean> PICKED_UP = SynchedEntityData.m_135353_(MoCEntityKittyBed.class, (EntityDataSerializer)EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Integer> SHEET_COLOR = SynchedEntityData.m_135353_(MoCEntityKittyBed.class, (EntityDataSerializer)EntityDataSerializers.f_135028_);
    public float milkLevel;

    public MoCEntityKittyBed(EntityType<? extends MoCEntityKittyBed> type, Level world) {
        super(type, world);
        this.m_21557_(true);
        this.milkLevel = 0.0f;
    }

    public ResourceLocation getTexture() {
        return MoCreatures.proxy.getModelTexture("kitty_bed.png");
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.m_21552_().m_22268_(Attributes.f_22276_, 20.0);
    }

    protected void m_8097_() {
        super.m_8097_();
        this.f_19804_.m_135372_(HAS_MILK, (Object)false);
        this.f_19804_.m_135372_(HAS_FOOD, (Object)false);
        this.f_19804_.m_135372_(PICKED_UP, (Object)false);
        this.f_19804_.m_135372_(SHEET_COLOR, (Object)0);
    }

    public boolean getHasFood() {
        return (Boolean)this.f_19804_.m_135370_(HAS_FOOD);
    }

    public void setHasFood(boolean flag) {
        this.f_19804_.m_135381_(HAS_FOOD, (Object)flag);
    }

    public boolean getHasMilk() {
        return (Boolean)this.f_19804_.m_135370_(HAS_MILK);
    }

    public void setHasMilk(boolean flag) {
        this.f_19804_.m_135381_(HAS_MILK, (Object)flag);
    }

    public boolean getPickedUp() {
        return (Boolean)this.f_19804_.m_135370_(PICKED_UP);
    }

    public void setPickedUp(boolean flag) {
        this.f_19804_.m_135381_(PICKED_UP, (Object)flag);
    }

    public int getSheetColor() {
        return (Integer)this.f_19804_.m_135370_(SHEET_COLOR);
    }

    public void setSheetColor(int i) {
        this.f_19804_.m_135381_(SHEET_COLOR, (Object)i);
    }

    public boolean m_6094_() {
        return !this.m_213877_();
    }

    public boolean m_6040_() {
        return true;
    }

    public boolean m_6785_(double distanceToClosestPlayer) {
        return false;
    }

    public boolean m_142582_(Entity entity) {
        return this.m_9236_().m_45547_(new ClipContext(new Vec3(this.m_20185_(), this.m_20186_() + (double)this.m_20192_(), this.m_20189_()), new Vec3(entity.m_20185_(), entity.m_20186_() + (double)entity.m_20192_(), entity.m_20189_()), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, (Entity)this)).m_6662_() == HitResult.Type.MISS;
    }

    public boolean m_142535_(float distance, float damageMultiplier, DamageSource source) {
        return false;
    }

    protected float m_6121_() {
        return 0.0f;
    }

    public double m_6048_() {
        return 0.0;
    }

    public void m_7822_(byte byte0) {
    }

    public InteractionResult m_6071_(Player player, InteractionHand hand) {
        ItemStack stack = player.m_21120_(hand);
        if (!(stack.m_41619_() || this.getHasFood() || this.getHasMilk())) {
            if (stack.m_150930_((Item)MoCItems.PET_FOOD.get())) {
                if (!player.m_7500_()) {
                    stack.m_41774_(1);
                }
                MoCTools.playCustomSound((Entity)this, (SoundEvent)MoCSoundEvents.ENTITY_KITTYBED_POURINGFOOD.get());
                this.setHasMilk(false);
                this.setHasFood(true);
            } else if (stack.m_150930_(Items.f_42455_)) {
                player.m_21008_(hand, new ItemStack((ItemLike)Items.f_42446_, 1));
                MoCTools.playCustomSound((Entity)this, (SoundEvent)MoCSoundEvents.ENTITY_KITTYBED_POURINGMILK.get());
                this.setHasMilk(true);
                this.setHasFood(false);
            }
            return InteractionResult.SUCCESS;
        }
        if (this.m_20202_() == null) {
            if (player.m_6047_()) {
                int color = this.getSheetColor();
                player.m_150109_().m_36054_(new ItemStack((ItemLike)MoCItems.KITTYBED[color].get(), 1));
                if (this.getHasFood()) {
                    player.m_150109_().m_36054_(new ItemStack((ItemLike)MoCItems.PET_FOOD.get(), 1));
                } else if (this.getHasMilk()) {
                    player.m_150109_().m_36054_(new ItemStack((ItemLike)Items.f_42455_, 1));
                }
                MoCTools.playCustomSound((Entity)this, SoundEvents.f_12019_, 0.2f);
                this.m_142687_(Entity.RemovalReason.DISCARDED);
            } else {
                this.m_5616_((float)MoCTools.roundToNearest90Degrees(this.m_6080_()) + 90.0f);
                MoCTools.playCustomSound((Entity)this, SoundEvents.f_12017_);
            }
            return InteractionResult.SUCCESS;
        }
        return InteractionResult.SUCCESS;
    }

    public void m_6478_(MoverType type, Vec3 pos) {
        if (!(this.m_9236_().m_5776_() || this.m_20202_() == null && this.m_20096_() && MoCreatures.proxy.staticBed)) {
            super.m_6478_(type, pos);
        }
    }

    public void m_8119_() {
        MoCEntityKitty kitty;
        super.m_8119_();
        if (this.m_20096_()) {
            this.setPickedUp(false);
        }
        if (!this.m_9236_().m_5776_() && (this.getHasMilk() || this.getHasFood()) && this.m_20160_() && this.m_146895_() instanceof MoCEntityKitty && (kitty = (MoCEntityKitty)this.m_146895_()).getKittyState() != 12) {
            this.milkLevel += 0.003f;
            if (this.milkLevel > 2.0f) {
                this.milkLevel = 0.0f;
                this.setHasMilk(false);
                this.setHasFood(false);
            }
        }
        if (this.m_20159_()) {
            MoCTools.dismountSneakingPlayer(this);
        }
    }

    public void m_7378_(CompoundTag compound) {
        this.setHasMilk(compound.m_128471_("HasMilk"));
        this.setSheetColor(compound.m_128451_("SheetColour"));
        this.setHasFood(compound.m_128471_("HasFood"));
        this.milkLevel = compound.m_128457_("MilkLevel");
    }

    public void m_7380_(CompoundTag compound) {
        compound.m_128379_("HasMilk", this.getHasMilk());
        compound.m_128405_("SheetColour", this.getSheetColor());
        compound.m_128379_("HasFood", this.getHasFood());
        compound.m_128350_("MilkLevel", this.milkLevel);
    }

    public boolean m_6469_(DamageSource damagesource, float i) {
        return false;
    }
}

