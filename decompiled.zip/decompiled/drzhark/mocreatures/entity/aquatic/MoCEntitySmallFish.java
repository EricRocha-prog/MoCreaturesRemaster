/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.EntityDimensions
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.Mob
 *  net.minecraft.world.entity.PathfinderMob
 *  net.minecraft.world.entity.Pose
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.entity.ai.goal.Goal
 *  net.minecraft.world.level.Level
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.entity.aquatic;

import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.entity.ai.EntityAIFleeFromEntityMoC;
import drzhark.mocreatures.entity.ai.EntityAIPanicMoC;
import drzhark.mocreatures.entity.ai.EntityAIWanderMoC2;
import drzhark.mocreatures.entity.tameable.MoCEntityTameableAquatic;
import drzhark.mocreatures.init.MoCEntities;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class MoCEntitySmallFish
extends MoCEntityTameableAquatic {
    public static final String[] fishNames = new String[]{"Anchovy", "Angelfish", "Angler", "Clownfish", "Goldfish", "Hippo Tang", "Mandarinfish"};

    public MoCEntitySmallFish(EntityType<? extends MoCEntitySmallFish> type, Level world) {
        super((EntityType<? extends MoCEntityTameableAquatic>)type, world);
        this.setMoCAge(100);
    }

    public static MoCEntitySmallFish createEntity(Level world, int type) {
        if (type == 1) {
            return (MoCEntitySmallFish)((EntityType)MoCEntities.ANCHOVY.get()).m_20615_(world);
        }
        if (type == 2) {
            return (MoCEntitySmallFish)((EntityType)MoCEntities.ANGELFISH.get()).m_20615_(world);
        }
        if (type == 3) {
            return (MoCEntitySmallFish)((EntityType)MoCEntities.ANGLER.get()).m_20615_(world);
        }
        if (type == 4) {
            return (MoCEntitySmallFish)((EntityType)MoCEntities.CLOWNFISH.get()).m_20615_(world);
        }
        if (type == 5) {
            return (MoCEntitySmallFish)((EntityType)MoCEntities.GOLDFISH.get()).m_20615_(world);
        }
        if (type == 6) {
            return (MoCEntitySmallFish)((EntityType)MoCEntities.HIPPOTANG.get()).m_20615_(world);
        }
        if (type == 7) {
            return (MoCEntitySmallFish)((EntityType)MoCEntities.MANDERIN.get()).m_20615_(world);
        }
        return (MoCEntitySmallFish)((EntityType)MoCEntities.CLOWNFISH.get()).m_20615_(world);
    }

    protected void m_8099_() {
        this.f_21345_.m_25352_(1, (Goal)new EntityAIPanicMoC((PathfinderMob)this, 1.3));
        this.f_21345_.m_25352_(2, (Goal)new EntityAIFleeFromEntityMoC((Mob)this, entity -> entity.m_20206_() > 0.3f || entity.m_20205_() > 0.3f, 2.0f, 0.6, 1.5));
        this.f_21345_.m_25352_(5, (Goal)new EntityAIWanderMoC2((PathfinderMob)this, 1.0, 80));
    }

    public static AttributeSupplier.Builder createAttributes() {
        return MoCEntityTameableAquatic.m_21552_().m_22268_(Attributes.f_22276_, 4.0).m_22268_(Attributes.f_22279_, 0.5);
    }

    @Override
    public void selectType() {
        if (this.getTypeMoC() == 0) {
            this.setTypeMoC(this.f_19796_.m_188503_(fishNames.length) + 1);
        }
    }

    @Override
    public ResourceLocation getTexture() {
        switch (this.getTypeMoC()) {
            case 1: {
                return MoCreatures.proxy.getModelTexture("smallfish_anchovy.png");
            }
            case 2: {
                return MoCreatures.proxy.getModelTexture("smallfish_angelfish.png");
            }
            case 3: {
                return MoCreatures.proxy.getModelTexture("smallfish_angler.png");
            }
            case 5: {
                return MoCreatures.proxy.getModelTexture("smallfish_goldfish.png");
            }
            case 6: {
                return MoCreatures.proxy.getModelTexture("smallfish_hippotang.png");
            }
            case 7: {
                return MoCreatures.proxy.getModelTexture("smallfish_manderin.png");
            }
        }
        return MoCreatures.proxy.getModelTexture("smallfish_clownfish.png");
    }

    @Override
    protected boolean canBeTrappedInNet() {
        return true;
    }

    public void m_8107_() {
        super.m_8107_();
        if (!this.m_9236_().m_5776_() && this.getIsTamed() && this.f_19796_.m_188503_(100) == 0 && this.m_21223_() < this.m_21233_()) {
            this.m_21153_(this.m_21233_());
        }
        if (!this.m_20069_()) {
            this.f_20883_ = this.m_146908_();
            this.m_146926_(this.m_146909_());
        }
    }

    @Override
    public float getSizeFactor() {
        return (float)this.getMoCAge() * 0.01f;
    }

    @Override
    public float getAdjustedYOffset() {
        if (!this.m_20069_()) {
            return 0.5f;
        }
        return 0.3f;
    }

    @Override
    protected boolean isFisheable() {
        return !this.getIsTamed();
    }

    @Override
    @OnlyIn(value=Dist.CLIENT)
    public float yawRotationOffset() {
        if (!this.m_20069_()) {
            return 90.0f;
        }
        return 90.0f + super.yawRotationOffset();
    }

    @Override
    public float rollRotationOffset() {
        if (!this.m_20069_()) {
            return -90.0f;
        }
        return 0.0f;
    }

    @Override
    public int nameYOffset() {
        return -25;
    }

    @Override
    protected boolean usesNewAI() {
        return true;
    }

    public float m_6113_() {
        return 0.1f;
    }

    @Override
    public boolean isMovementCeased() {
        return !this.m_20069_();
    }

    @Override
    protected double maxDivingDepth() {
        return 2.0;
    }

    @Override
    public int getMaxAge() {
        return 120;
    }

    @Override
    public boolean isNotScared() {
        return this.getIsTamed();
    }

    @Override
    public float getAdjustedZOffset() {
        if (!this.m_20069_()) {
            return 0.1f;
        }
        return 0.0f;
    }

    protected float m_6431_(Pose poseIn, EntityDimensions sizeIn) {
        return this.m_20206_() * 0.45f;
    }
}

