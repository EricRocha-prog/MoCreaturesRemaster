/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.Entity$RemovalReason
 *  net.minecraft.world.entity.EntityDimensions
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.PathfinderMob
 *  net.minecraft.world.entity.Pose
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.entity.ai.goal.Goal
 *  net.minecraft.world.entity.ai.goal.MeleeAttackGoal
 *  net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal
 *  net.minecraft.world.entity.animal.Wolf
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.entity.aquatic;

import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.entity.MoCEntityAquatic;
import drzhark.mocreatures.entity.ai.EntityAITargetNonTamedMoC;
import drzhark.mocreatures.entity.ai.EntityAIWanderMoC2;
import drzhark.mocreatures.entity.aquatic.MoCEntityDolphin;
import drzhark.mocreatures.entity.item.MoCEntityEgg;
import drzhark.mocreatures.entity.passive.MoCEntityHorse;
import drzhark.mocreatures.entity.tameable.MoCEntityTameableAquatic;
import drzhark.mocreatures.init.MoCLootTables;
import java.util.List;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

public class MoCEntityShark
extends MoCEntityTameableAquatic {
    public MoCEntityShark(EntityType<? extends MoCEntityShark> type, Level world) {
        super((EntityType<? extends MoCEntityTameableAquatic>)type, world);
        this.texture = "shark.png";
        this.setAdult(true);
        this.setMoCAge(160);
    }

    protected void m_8099_() {
        this.f_21345_.m_25352_(2, (Goal)new MeleeAttackGoal((PathfinderMob)this, 1.0, false));
        this.f_21345_.m_25352_(5, (Goal)new EntityAIWanderMoC2((PathfinderMob)this, 1.0, 30));
        this.f_21346_.m_25352_(1, (Goal)new HurtByTargetGoal((PathfinderMob)this, new Class[0]));
        this.f_21346_.m_25352_(2, new EntityAITargetNonTamedMoC<Player>((PathfinderMob)this, Player.class, false));
    }

    public static AttributeSupplier.Builder createAttributes() {
        return MoCEntityTameableAquatic.m_21552_().m_22268_(Attributes.f_22276_, 30.0).m_22268_(Attributes.f_22279_, 0.55).m_22268_(Attributes.f_22281_, 5.0).m_22268_(Attributes.f_22277_, 32.0);
    }

    @Override
    protected void m_8097_() {
        super.m_8097_();
    }

    public int m_213860_() {
        return 5;
    }

    @Override
    public boolean m_6469_(DamageSource damagesource, float i) {
        if (super.m_6469_(damagesource, i) && this.m_9236_().m_46791_().m_19028_() > 0) {
            Entity entity = damagesource.m_7639_();
            if (entity != null && this.m_20160_() && entity == this.m_20197_().get(0)) {
                return true;
            }
            if (entity != this && entity instanceof LivingEntity) {
                this.m_6710_((LivingEntity)entity);
                return true;
            }
            return false;
        }
        return false;
    }

    protected ResourceLocation m_7582_() {
        return MoCLootTables.SHARK;
    }

    protected Entity findPlayerToAttack() {
        Player entityplayer;
        if (this.m_9236_().m_46791_().m_19028_() > 0 && this.getMoCAge() >= 100 && (entityplayer = this.m_9236_().m_45930_((Entity)this, 16.0)) != null && entityplayer.m_20069_() && !this.getIsTamed()) {
            return entityplayer;
        }
        return null;
    }

    public LivingEntity FindTarget(Entity entity, double d) {
        double d1 = -1.0;
        LivingEntity entityliving = null;
        List list = this.m_9236_().m_6443_(Entity.class, this.m_20191_().m_82400_(d), ent -> ent != this);
        for (Entity o : list) {
            if (!(o instanceof LivingEntity) || o instanceof MoCEntityAquatic || o instanceof MoCEntityEgg || o instanceof Player || o instanceof Wolf && !MoCreatures.proxy.attackWolves || o instanceof MoCEntityHorse && !MoCreatures.proxy.attackHorses) continue;
            if (o instanceof MoCEntityDolphin) {
                this.getIsTamed();
            }
            double d2 = o.m_20275_(entity.m_20185_(), entity.m_20186_(), entity.m_20189_());
            if (!(d < 0.0) && !(d2 < d * d) || d1 != -1.0 && !(d2 < d1) || !((LivingEntity)o).m_142582_(entity)) continue;
            d1 = d2;
            entityliving = (LivingEntity)o;
        }
        return entityliving;
    }

    public void m_8107_() {
        super.m_8107_();
        if (!this.m_9236_().m_5776_() && !this.getIsAdult() && this.f_19796_.m_188503_(50) == 0) {
            this.setMoCAge(this.getMoCAge() + 1);
            if (this.getMoCAge() >= 200) {
                this.setAdult(true);
            }
        }
    }

    @Override
    public void m_142687_(Entity.RemovalReason reason) {
        if (this.m_9236_().m_5776_() || !this.getIsTamed() || !(this.m_21223_() > 0.0f)) {
            super.m_142687_(reason);
        }
    }

    public boolean isMyHealFood(Item item1) {
        return false;
    }

    @Override
    protected boolean usesNewAI() {
        return true;
    }

    public float m_6113_() {
        return 0.12f;
    }

    @Override
    public boolean isMovementCeased() {
        return !this.m_20069_();
    }

    @Override
    protected double minDivingDepth() {
        return 1.0;
    }

    @Override
    protected double maxDivingDepth() {
        return 6.0;
    }

    @Override
    public int getMaxAge() {
        return 200;
    }

    @Override
    public boolean isNotScared() {
        return true;
    }

    protected float m_6431_(Pose poseIn, EntityDimensions sizeIn) {
        return this.m_20206_() * 0.61f;
    }
}

