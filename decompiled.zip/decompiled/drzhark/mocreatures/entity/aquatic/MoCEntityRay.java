/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.InteractionResult
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.PathfinderMob
 *  net.minecraft.world.entity.ai.goal.Goal
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.entity.aquatic;

import drzhark.mocreatures.entity.ai.EntityAIWanderMoC2;
import drzhark.mocreatures.entity.tameable.MoCEntityTameableAquatic;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class MoCEntityRay
extends MoCEntityTameableAquatic {
    public MoCEntityRay(EntityType<? extends MoCEntityRay> type, Level world) {
        super((EntityType<? extends MoCEntityTameableAquatic>)type, world);
    }

    protected void m_8099_() {
        this.f_21345_.m_25352_(2, (Goal)new EntityAIWanderMoC2((PathfinderMob)this, 1.0, 80));
    }

    public boolean isPoisoning() {
        return false;
    }

    @Override
    public InteractionResult m_6071_(Player player, InteractionHand hand) {
        InteractionResult tameResult = this.processTameInteract(player, hand);
        if (tameResult != null) {
            return tameResult;
        }
        if (!this.m_20160_() && this.getTypeMoC() == 1) {
            if (!this.m_9236_().m_5776_() && player.m_20329_((Entity)this)) {
                player.m_146922_(this.m_146908_());
                player.m_146926_(this.m_146909_());
                player.m_6034_(player.m_20185_(), this.m_20186_(), player.m_20189_());
            }
            return InteractionResult.SUCCESS;
        }
        return super.m_6071_(player, hand);
    }

    @Override
    public float getAdjustedYOffset() {
        if (!this.m_20069_()) {
            return 0.09f;
        }
        return 0.15f;
    }

    @Override
    public int nameYOffset() {
        return -25;
    }

    @Override
    public boolean canBeTrappedInNet() {
        return true;
    }

    public double m_6048_() {
        return (double)this.m_20206_() * 0.15 * (double)this.getSizeFactor();
    }

    @Override
    public float getSizeFactor() {
        float f = (float)this.getMoCAge() * 0.01f;
        if (f > 1.5f) {
            f = 1.5f;
        }
        return f;
    }

    @Override
    protected boolean usesNewAI() {
        return true;
    }

    public float m_6113_() {
        return 0.06f;
    }

    @Override
    public boolean isMovementCeased() {
        return !this.m_20069_();
    }

    @Override
    protected double minDivingDepth() {
        return 3.0;
    }

    @Override
    protected double maxDivingDepth() {
        return 6.0;
    }

    @Override
    public int getMaxAge() {
        return 90;
    }

    public boolean isMantaRay() {
        return false;
    }
}

