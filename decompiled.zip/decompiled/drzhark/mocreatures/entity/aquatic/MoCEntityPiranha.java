/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.Mob
 *  net.minecraft.world.entity.PathfinderMob
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.entity.ai.goal.Goal
 *  net.minecraft.world.entity.ai.goal.MeleeAttackGoal
 *  net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal
 *  net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.entity.aquatic;

import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.entity.ai.EntityAIFollowHerd;
import drzhark.mocreatures.entity.aquatic.MoCEntitySmallFish;
import drzhark.mocreatures.init.MoCLootTables;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class MoCEntityPiranha
extends MoCEntitySmallFish {
    public MoCEntityPiranha(EntityType<? extends MoCEntityPiranha> type, Level world) {
        super((EntityType<? extends MoCEntitySmallFish>)type, world);
    }

    @Override
    protected void m_8099_() {
        this.f_21345_.m_25352_(3, (Goal)new MeleeAttackGoal((PathfinderMob)this, 1.0, false));
        this.f_21345_.m_25352_(4, (Goal)new EntityAIFollowHerd((Mob)this, 0.6, 4.0, 20.0, 1));
        this.f_21346_.m_25352_(1, (Goal)new HurtByTargetGoal((PathfinderMob)this, new Class[0]));
        this.f_21346_.m_25352_(2, (Goal)new NearestAttackableTargetGoal((Mob)this, Player.class, true));
    }

    public static AttributeSupplier.Builder createAttributes() {
        return MoCEntitySmallFish.createAttributes().m_22268_(Attributes.f_22276_, 5.0).m_22268_(Attributes.f_22281_, 3.5);
    }

    @Override
    public void selectType() {
        this.setTypeMoC(1);
    }

    @Override
    public ResourceLocation getTexture() {
        return MoCreatures.proxy.getModelTexture("smallfish_piranha.png");
    }

    protected Entity findPlayerToAttack() {
        Player entityplayer;
        if (this.m_9236_().m_46791_().m_19028_() > 0 && (entityplayer = this.m_9236_().m_45930_((Entity)this, 12.0)) != null && entityplayer.m_20069_() && !this.getIsTamed()) {
            return entityplayer;
        }
        return null;
    }

    public int m_213860_() {
        return 3;
    }

    @Override
    public boolean m_6469_(DamageSource damagesource, float i) {
        Entity entity;
        if (super.m_6469_(damagesource, i) && this.m_9236_().m_46791_().m_19028_() > 0 && (entity = damagesource.m_7639_()) instanceof LivingEntity) {
            if (this.m_20160_() && entity == this.m_20197_().get(0)) {
                return true;
            }
            if (entity != this) {
                this.m_6710_((LivingEntity)entity);
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean isNotScared() {
        return true;
    }

    protected ResourceLocation m_7582_() {
        return MoCLootTables.PIRANHA;
    }
}

