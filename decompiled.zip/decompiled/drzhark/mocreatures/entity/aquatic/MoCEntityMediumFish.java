/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.tags.FluidTags
 *  net.minecraft.world.entity.EntityDimensions
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.Mob
 *  net.minecraft.world.entity.PathfinderMob
 *  net.minecraft.world.entity.Pose
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.entity.ai.goal.Goal
 *  net.minecraft.world.level.Level
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.entity.aquatic;

import drzhark.mocreatures.entity.ai.EntityAIFleeFromEntityMoC;
import drzhark.mocreatures.entity.ai.EntityAIWanderMoC2;
import drzhark.mocreatures.entity.tameable.MoCEntityTameableAquatic;
import drzhark.mocreatures.init.MoCEntities;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class MoCEntityMediumFish
extends MoCEntityTameableAquatic {
    public static final String[] fishNames = new String[]{"Salmon", "Cod", "Bass"};

    public MoCEntityMediumFish(EntityType<? extends MoCEntityMediumFish> type, Level world) {
        super((EntityType<? extends MoCEntityTameableAquatic>)type, world);
        this.setMoCAge(100);
    }

    public static MoCEntityMediumFish createEntity(Level world, int type) {
        if (type == 1) {
            return (MoCEntityMediumFish)((EntityType)MoCEntities.SALMON.get()).m_20615_(world);
        }
        if (type == 2) {
            return (MoCEntityMediumFish)((EntityType)MoCEntities.COD.get()).m_20615_(world);
        }
        if (type == 3) {
            return (MoCEntityMediumFish)((EntityType)MoCEntities.BASS.get()).m_20615_(world);
        }
        return (MoCEntityMediumFish)((EntityType)MoCEntities.SALMON.get()).m_20615_(world);
    }

    protected void m_8099_() {
        this.f_21345_.m_25352_(3, (Goal)new EntityAIFleeFromEntityMoC((Mob)this, entity -> entity.m_20206_() > 0.6f && entity.m_20205_() > 0.3f, 2.0f, 0.6, 1.5));
        this.f_21345_.m_25352_(5, (Goal)new EntityAIWanderMoC2((PathfinderMob)this, 1.0, 50));
    }

    public static AttributeSupplier.Builder createAttributes() {
        return MoCEntityTameableAquatic.m_21552_().m_22268_(Attributes.f_22276_, 7.0).m_22268_(Attributes.f_22279_, 0.5);
    }

    @Override
    public void selectType() {
        if (this.getTypeMoC() == 0) {
            this.setTypeMoC(this.f_19796_.m_188503_(fishNames.length) + 1);
        }
    }

    public void m_8107_() {
        super.m_8107_();
        if (!this.m_9236_().m_5776_() && this.getIsTamed() && this.f_19796_.m_188503_(100) == 0 && this.m_21223_() < this.m_21233_()) {
            this.m_21153_(this.m_21233_());
        }
        if (!this.m_204029_(FluidTags.f_13131_)) {
            this.f_20883_ = this.m_146908_();
            this.m_146926_(this.m_146909_());
        }
    }

    @Override
    public float getSizeFactor() {
        return (float)this.getMoCAge() * 0.0081f;
    }

    @Override
    public float getAdjustedYOffset() {
        if (!this.m_204029_(FluidTags.f_13131_)) {
            return 1.0f;
        }
        return 0.5f;
    }

    @Override
    protected boolean isFisheable() {
        return !this.getIsTamed();
    }

    @Override
    @OnlyIn(value=Dist.CLIENT)
    public float yawRotationOffset() {
        if (!this.m_204029_(FluidTags.f_13131_)) {
            return 90.0f;
        }
        return 90.0f + super.yawRotationOffset();
    }

    @Override
    public float rollRotationOffset() {
        if (!this.m_20069_() && this.m_20096_()) {
            return -90.0f;
        }
        return 0.0f;
    }

    @Override
    public int nameYOffset() {
        return -30;
    }

    @Override
    public float getAdjustedZOffset() {
        if (!this.m_20069_()) {
            return 0.2f;
        }
        return 0.0f;
    }

    @Override
    protected boolean canBeTrappedInNet() {
        return true;
    }

    @Override
    protected boolean usesNewAI() {
        return true;
    }

    public float m_6113_() {
        return 0.15f;
    }

    @Override
    public boolean isMovementCeased() {
        return !this.m_20069_();
    }

    @Override
    protected double minDivingDepth() {
        return 0.5;
    }

    @Override
    protected double maxDivingDepth() {
        return 4.0;
    }

    @Override
    public int getMaxAge() {
        return 120;
    }

    @Override
    public boolean isNotScared() {
        return this.getIsTamed();
    }

    protected float m_6431_(Pose poseIn, EntityDimensions sizeIn) {
        return this.m_20206_() * 0.775f;
    }
}

