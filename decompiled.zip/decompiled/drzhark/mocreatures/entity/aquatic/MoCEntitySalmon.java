/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.entity.aquatic;

import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.entity.aquatic.MoCEntityMediumFish;
import drzhark.mocreatures.init.MoCLootTables;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

public class MoCEntitySalmon
extends MoCEntityMediumFish {
    public MoCEntitySalmon(EntityType<? extends MoCEntitySalmon> type, Level world) {
        super((EntityType<? extends MoCEntityMediumFish>)type, world);
        this.setTypeMoC(1);
    }

    @Override
    public ResourceLocation getTexture() {
        return MoCreatures.proxy.getModelTexture("mediumfish_salmon.png");
    }

    protected ResourceLocation m_7582_() {
        return MoCLootTables.SALMON;
    }
}

