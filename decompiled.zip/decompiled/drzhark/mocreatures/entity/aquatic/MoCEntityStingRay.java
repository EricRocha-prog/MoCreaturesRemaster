/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityDimensions
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.Pose
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.level.Level
 *  net.minecraftforge.network.PacketDistributor
 *  net.minecraftforge.network.PacketDistributor$TargetPoint
 */
package drzhark.mocreatures.entity.aquatic;

import drzhark.mocreatures.MoCTools;
import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.entity.aquatic.MoCEntityRay;
import drzhark.mocreatures.init.MoCLootTables;
import drzhark.mocreatures.network.MoCMessageHandler;
import drzhark.mocreatures.network.message.MoCMessageAnimation;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.PacketDistributor;

public class MoCEntityStingRay
extends MoCEntityRay {
    private int poisoncounter;
    private int tailCounter;

    public MoCEntityStingRay(EntityType<? extends MoCEntityStingRay> type, Level world) {
        super((EntityType<? extends MoCEntityRay>)type, world);
        this.setMoCAge(90);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return MoCEntityRay.createAttributes().m_22268_(Attributes.f_22276_, 8.0);
    }

    @Override
    public ResourceLocation getTexture() {
        return MoCreatures.proxy.getModelTexture("ray_sting.png");
    }

    protected ResourceLocation m_7582_() {
        return MoCLootTables.STINGRAY;
    }

    @Override
    public boolean isPoisoning() {
        return this.tailCounter != 0;
    }

    public void m_8107_() {
        super.m_8107_();
        if (!this.m_9236_().m_5776_()) {
            if (!this.getIsTamed() && ++this.poisoncounter > 250 && this.m_9236_().m_46791_().m_19028_() > 0 && this.f_19796_.m_188503_(30) == 0 && MoCTools.findNearPlayerAndPoison((Entity)this, true)) {
                MoCMessageHandler.INSTANCE.send(PacketDistributor.NEAR.with(() -> new PacketDistributor.TargetPoint(this.m_20185_(), this.m_20186_(), this.m_20189_(), 64.0, this.m_9236_().m_46472_())), (Object)new MoCMessageAnimation(this.m_19879_(), 1));
                this.poisoncounter = 0;
            }
        } else if (this.tailCounter > 0 && ++this.tailCounter > 50) {
            this.tailCounter = 0;
        }
    }

    @Override
    public void performAnimation(int animationType) {
        if (animationType == 1) {
            this.tailCounter = 1;
        }
    }

    @Override
    public boolean m_6469_(DamageSource damagesource, float i) {
        if (super.m_6469_(damagesource, i)) {
            if (this.m_9236_().m_46791_().m_19028_() == 0) {
                return true;
            }
            Entity entity = damagesource.m_7639_();
            if (entity instanceof LivingEntity) {
                if (entity != this) {
                    this.m_6710_((LivingEntity)entity);
                }
                return true;
            }
        }
        return false;
    }

    protected float m_6431_(Pose poseIn, EntityDimensions sizeIn) {
        return this.m_20206_() * 0.86f;
    }
}

