/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.sounds.SoundEvent
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityDimensions
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.Mob
 *  net.minecraft.world.entity.PathfinderMob
 *  net.minecraft.world.entity.Pose
 *  net.minecraft.world.entity.ai.attributes.AttributeSupplier$Builder
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.entity.ai.goal.FloatGoal
 *  net.minecraft.world.entity.ai.goal.Goal
 *  net.minecraft.world.entity.ai.goal.LookAtPlayerGoal
 *  net.minecraft.world.entity.ai.goal.PanicGoal
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.phys.Vec3
 */
package drzhark.mocreatures.entity.passive;

import drzhark.mocreatures.MoCTools;
import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.entity.ai.EntityAIFleeFromEntityMoC;
import drzhark.mocreatures.entity.ai.EntityAIFollowAdult;
import drzhark.mocreatures.entity.ai.EntityAIWanderMoC2;
import drzhark.mocreatures.entity.tameable.MoCEntityTameableAnimal;
import drzhark.mocreatures.init.MoCLootTables;
import drzhark.mocreatures.init.MoCSoundEvents;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class MoCEntityDeer
extends MoCEntityTameableAnimal {
    private int readyToJumpTimer;

    public MoCEntityDeer(EntityType<? extends MoCEntityDeer> type, Level world) {
        super((EntityType<? extends MoCEntityTameableAnimal>)type, world);
        this.setMoCAge(75);
        this.setAdult(true);
        this.setTamed(false);
    }

    protected void m_8099_() {
        this.f_21345_.m_25352_(0, (Goal)new FloatGoal((Mob)this));
        this.f_21345_.m_25352_(1, (Goal)new EntityAIFleeFromEntityMoC((Mob)this, entity -> !(entity instanceof MoCEntityDeer) && (entity.m_20206_() > 0.8f || entity.m_20205_() > 0.8f), 6.0f, this.getMyAISpeed(), this.getMyAISpeed() * 1.2));
        this.f_21345_.m_25352_(2, (Goal)new PanicGoal((PathfinderMob)this, this.getMyAISpeed() * 1.2));
        this.f_21345_.m_25352_(4, (Goal)new EntityAIFollowAdult((Mob)this, this.getMyAISpeed()));
        this.f_21345_.m_25352_(5, (Goal)new EntityAIWanderMoC2((PathfinderMob)this, this.getMyAISpeed()));
        this.f_21345_.m_25352_(6, (Goal)new LookAtPlayerGoal((Mob)this, Player.class, 6.0f));
    }

    public static AttributeSupplier.Builder registerAttributes() {
        return MoCEntityTameableAnimal.createAttributes().m_22268_(Attributes.f_22277_, 12.0).m_22268_(Attributes.f_22276_, 10.0).m_22268_(Attributes.f_22279_, 0.35);
    }

    @Override
    public void selectType() {
        if (this.getTypeMoC() == 0) {
            int i = this.f_19796_.m_188503_(100);
            if (i <= 20) {
                this.setTypeMoC(1);
            } else if (i <= 70) {
                this.setTypeMoC(2);
            } else {
                this.setAdult(false);
                this.setTypeMoC(3);
            }
        }
    }

    @Override
    public ResourceLocation getTexture() {
        switch (this.getTypeMoC()) {
            case 2: {
                return MoCreatures.proxy.getModelTexture("deer_doe.png");
            }
            case 3: {
                this.setAdult(false);
                return MoCreatures.proxy.getModelTexture("deer_fawn.png");
            }
        }
        return MoCreatures.proxy.getModelTexture("deer_stag.png");
    }

    public boolean m_142535_(float distance, float damageMultiplier, DamageSource source) {
        return false;
    }

    @Override
    public boolean entitiesToInclude(Entity entity) {
        return !(entity instanceof MoCEntityDeer) && super.entitiesToInclude(entity);
    }

    protected SoundEvent m_5592_() {
        return (SoundEvent)MoCSoundEvents.ENTITY_DEER_DEATH.get();
    }

    protected SoundEvent m_7975_(DamageSource source) {
        return (SoundEvent)MoCSoundEvents.ENTITY_DEER_HURT.get();
    }

    protected SoundEvent m_7515_() {
        if (!this.getIsAdult()) {
            return (SoundEvent)MoCSoundEvents.ENTITY_DEER_AMBIENT_BABY.get();
        }
        return (SoundEvent)MoCSoundEvents.ENTITY_DEER_AMBIENT.get();
    }

    protected ResourceLocation m_7582_() {
        return MoCLootTables.DEER;
    }

    public double getMyAISpeed() {
        return 1.1;
    }

    public int m_8100_() {
        return 400;
    }

    @Override
    public int getMoCMaxAge() {
        return 130;
    }

    @Override
    public void setAdult(boolean flag) {
        if (!this.m_9236_().f_46443_) {
            this.setTypeMoC(this.f_19796_.m_188503_(1));
        }
        super.setAdult(flag);
    }

    @Override
    public boolean getIsAdult() {
        return this.getTypeMoC() != 3 && super.getIsAdult();
    }

    @Override
    public void m_8119_() {
        super.m_8119_();
        if (!this.m_9236_().f_46443_ && this.m_20096_() && --this.readyToJumpTimer <= 0 && MoCTools.getMyMovementSpeed((Entity)this) > 0.17f) {
            float velX = (float)(0.5 * Math.cos(MoCTools.realAngle(this.m_146908_() - 90.0f) / 57.29578f));
            float velZ = (float)(0.5 * Math.sin(MoCTools.realAngle(this.m_146908_() - 90.0f) / 57.29578f));
            this.m_20256_(new Vec3(this.m_20184_().f_82479_, 0.5, this.m_20184_().f_82481_).m_82492_((double)velX, 0.0, (double)velZ));
            this.readyToJumpTimer = this.f_19796_.m_188503_(10) + 20;
        }
    }

    @Override
    public float pitchRotationOffset() {
        if (!this.m_20096_() && MoCTools.getMyMovementSpeed((Entity)this) > 0.08f) {
            if (this.m_20184_().f_82480_ > 0.5) {
                return 25.0f;
            }
            if (this.m_20184_().f_82480_ < -0.5) {
                return -25.0f;
            }
            return (float)(this.m_20184_().f_82480_ * 70.0);
        }
        return 0.0f;
    }

    @Override
    public float getSizeFactor() {
        if (this.getTypeMoC() == 1) {
            return 1.6f;
        }
        if (this.getTypeMoC() == 2) {
            return 1.3f;
        }
        return (float)this.getMoCAge() * 0.01f;
    }

    protected float m_6431_(Pose poseIn, EntityDimensions sizeIn) {
        return sizeIn.f_20378_ * 0.945f;
    }
}

