/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.entity.passive;

import drzhark.mocreatures.entity.tameable.MoCEntityTameableAnimal;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

public class MoCEntitySnake
extends MoCEntityTameableAnimal {
    public MoCEntitySnake(EntityType<? extends MoCEntitySnake> type, Level world) {
        super((EntityType<? extends MoCEntityTameableAnimal>)type, world);
    }
}

