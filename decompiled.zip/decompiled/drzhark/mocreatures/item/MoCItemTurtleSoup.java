/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.Items
 *  net.minecraft.world.level.ItemLike
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.item;

import drzhark.mocreatures.item.MoCItemFood;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;

public class MoCItemTurtleSoup
extends MoCItemFood {
    protected MoCItemTurtleSoup(MoCItemFood.Builder builder) {
        super(builder);
    }

    public ItemStack m_5922_(ItemStack stack, Level level, LivingEntity entity) {
        ItemStack resultStack = super.m_5922_(stack, level, entity);
        return entity instanceof Player && ((Player)entity).m_7500_() ? resultStack : new ItemStack((ItemLike)Items.f_42399_);
    }

    public static class Builder
    extends MoCItemFood.Builder {
        public Builder(Item.Properties properties, int nutrition) {
            this(properties, nutrition, 0.6f, false);
        }

        public Builder(Item.Properties properties, int nutrition, float saturation, boolean isWolfFood) {
            this(properties, nutrition, saturation, isWolfFood, 32);
        }

        public Builder(Item.Properties properties, int nutrition, float saturation, boolean isWolfFood, int eatingSpeed) {
            super(properties, nutrition, saturation, isWolfFood, eatingSpeed);
        }

        @Override
        public MoCItemTurtleSoup build() {
            return new MoCItemTurtleSoup(this);
        }
    }
}

