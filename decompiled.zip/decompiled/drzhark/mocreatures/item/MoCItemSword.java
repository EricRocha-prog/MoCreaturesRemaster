/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.ChatFormatting
 *  net.minecraft.network.chat.Component
 *  net.minecraft.world.effect.MobEffectInstance
 *  net.minecraft.world.effect.MobEffects
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.SwordItem
 *  net.minecraft.world.item.Tier
 *  net.minecraft.world.item.TooltipFlag
 *  net.minecraft.world.level.Level
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.item;

import drzhark.mocreatures.MoCreatures;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class MoCItemSword
extends SwordItem {
    private final int specialWeaponType;

    public MoCItemSword(Item.Properties properties, Tier material) {
        super(material, 3, -2.4f, properties);
        this.specialWeaponType = 0;
    }

    public MoCItemSword(Item.Properties properties, Tier material, int damageType) {
        super(material, 3, -2.4f, properties);
        this.specialWeaponType = damageType;
    }

    public boolean m_7579_(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (MoCreatures.proxy.weaponEffects) {
            int timer = 200;
            switch (this.specialWeaponType) {
                case 1: {
                    target.m_7292_(new MobEffectInstance(MobEffects.f_19614_, timer, 1));
                    break;
                }
                case 2: {
                    target.m_7292_(new MobEffectInstance(MobEffects.f_19597_, timer, 0));
                    break;
                }
                case 3: {
                    target.m_20254_(10);
                    break;
                }
                case 4: {
                    target.m_7292_(new MobEffectInstance(target instanceof Player ? MobEffects.f_19604_ : MobEffects.f_19613_, timer, 0));
                    break;
                }
                case 5: {
                    target.m_7292_(new MobEffectInstance(target instanceof Player ? MobEffects.f_19610_ : MobEffects.f_19615_, timer, 0));
                }
            }
        }
        return super.m_7579_(stack, target, attacker);
    }

    @OnlyIn(value=Dist.CLIENT)
    public void m_7373_(ItemStack stack, @Nullable Level worldIn, List<Component> tooltip, TooltipFlag flagIn) {
        if (MoCreatures.proxy.weaponEffects) {
            String translationKey = null;
            switch (this.specialWeaponType) {
                case 1: {
                    translationKey = "info.mocreatures.stingdefault1";
                    break;
                }
                case 2: {
                    translationKey = "info.mocreatures.stingdefault2";
                    break;
                }
                case 3: {
                    translationKey = "info.mocreatures.stingdefault3";
                    break;
                }
                case 4: {
                    translationKey = "info.mocreatures.stingdefault4";
                    break;
                }
                case 5: {
                    translationKey = "info.mocreatures.stingdefault5";
                }
            }
            if (translationKey != null) {
                tooltip.add((Component)Component.m_237115_((String)translationKey).m_130940_(ChatFormatting.BLUE));
            }
        }
    }
}

