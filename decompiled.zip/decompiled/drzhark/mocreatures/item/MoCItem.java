/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.Item$Properties
 */
package drzhark.mocreatures.item;

import net.minecraft.world.item.Item;

public class MoCItem
extends Item {
    public MoCItem(Item.Properties properties) {
        super(properties);
    }
}

