/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.sounds.SoundEvents
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.InteractionResultHolder
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.item;

import drzhark.mocreatures.MoCTools;
import drzhark.mocreatures.entity.item.MoCEntityLitterBox;
import drzhark.mocreatures.init.MoCEntities;
import drzhark.mocreatures.item.MoCItem;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class MoCItemLitterBox
extends MoCItem {
    public MoCItemLitterBox(Item.Properties properties) {
        super(properties.m_41487_(16));
    }

    public InteractionResultHolder<ItemStack> m_7203_(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.m_21120_(hand);
        if (!level.f_46443_) {
            MoCEntityLitterBox litterBox;
            if (!player.m_7500_()) {
                stack.m_41774_(1);
            }
            if ((litterBox = (MoCEntityLitterBox)((EntityType)MoCEntities.LITTERBOX.get()).m_20615_(level)) != null) {
                litterBox.m_6034_(player.m_20185_(), player.m_20186_(), player.m_20189_());
                level.m_7967_((Entity)litterBox);
                MoCTools.playCustomSound((Entity)litterBox, SoundEvents.f_12635_);
            }
        }
        return InteractionResultHolder.m_19090_((Object)stack);
    }
}

