/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.InteractionResultHolder
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.CreativeModeTab$Output
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.ItemLike
 *  net.minecraft.world.level.Level
 */
package drzhark.mocreatures.item;

import drzhark.mocreatures.entity.item.MoCEntityEgg;
import drzhark.mocreatures.init.MoCEntities;
import drzhark.mocreatures.item.MoCItem;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;

public class MoCItemEgg
extends MoCItem {
    public MoCItemEgg(Item.Properties properties) {
        super(properties.m_41487_(16));
    }

    public InteractionResultHolder<ItemStack> m_7203_(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.m_21120_(hand);
        if (!player.m_7500_()) {
            stack.m_41774_(1);
        }
        if (!level.f_46443_ && player.m_20096_()) {
            MoCEntityEgg entityEgg;
            CompoundTag tag = stack.m_41784_();
            int eggType = tag.m_128451_("EggType");
            if (eggType == 30) {
                eggType = 31;
            }
            if ((entityEgg = (MoCEntityEgg)((EntityType)MoCEntities.EGG.get()).m_20615_(level)) != null) {
                entityEgg.setEggType(eggType);
                entityEgg.m_6034_(player.m_20185_(), player.m_20186_(), player.m_20189_());
                entityEgg.m_20334_((level.f_46441_.m_188501_() - level.f_46441_.m_188501_()) * 0.3f, level.f_46441_.m_188501_() * 0.05f, (level.f_46441_.m_188501_() - level.f_46441_.m_188501_()) * 0.3f);
                level.m_7967_((Entity)entityEgg);
                System.out.println("[DEBUG] Placing egg with type: " + eggType);
            }
        }
        return InteractionResultHolder.m_19090_((Object)stack);
    }

    public void fillItemCategory(CreativeModeTab.Output output) {
        this.addRange(output, 0, 10);
        this.addSingle(output, 11);
        this.addRange(output, 21, 28);
        this.addList(output, 30, 31);
        this.addSingle(output, 33);
        this.addRange(output, 41, 45);
        this.addRange(output, 50, 61);
        this.addRange(output, 62, 66);
        this.addRange(output, 70, 72);
        this.addRange(output, 80, 86);
        this.addSingle(output, 90);
    }

    private void addSingle(CreativeModeTab.Output list, int type) {
        ItemStack stack = new ItemStack((ItemLike)this);
        stack.m_41784_().m_128405_("EggType", type);
        list.m_246342_(stack);
    }

    private void addRange(CreativeModeTab.Output list, int start, int end) {
        for (int i = start; i <= end; ++i) {
            this.addSingle(list, i);
        }
    }

    private void addList(CreativeModeTab.Output list, int ... values) {
        for (int value : values) {
            this.addSingle(list, value);
        }
    }

    public String m_5671_(ItemStack stack) {
        int eggType = stack.m_41784_().m_128451_("EggType");
        return super.m_5671_(stack) + "." + eggType;
    }
}

