/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.screens.Screen
 *  net.minecraft.client.gui.screens.inventory.BookViewScreen
 *  net.minecraft.client.gui.screens.inventory.BookViewScreen$BookAccess
 *  net.minecraft.client.gui.screens.inventory.BookViewScreen$WrittenBookAccess
 *  net.minecraft.core.NonNullList
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.nbt.ListTag
 *  net.minecraft.nbt.StringTag
 *  net.minecraft.nbt.Tag
 *  net.minecraft.network.chat.Component
 *  net.minecraft.network.chat.Component$Serializer
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.InteractionResultHolder
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.ItemLike
 *  net.minecraft.world.level.Level
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.item;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.BookViewScreen;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class ItemHorseGuide
extends Item {
    public ItemHorseGuide(Item.Properties properties) {
        super(properties);
    }

    public InteractionResultHolder<ItemStack> m_7203_(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.m_21120_(hand);
        if (level.f_46443_) {
            this.openClientBookScreen(stack);
        }
        return InteractionResultHolder.m_19090_((Object)stack);
    }

    @OnlyIn(value=Dist.CLIENT)
    private void openClientBookScreen(ItemStack stack) {
        Minecraft.m_91087_().m_91152_((Screen)new BookViewScreen((BookViewScreen.BookAccess)new BookViewScreen.WrittenBookAccess(stack)));
    }

    public static void addBookToCreativeTab(NonNullList<ItemStack> items, Item item) {
        ItemStack book = new ItemStack((ItemLike)item);
        CompoundTag tag = new CompoundTag();
        tag.m_128359_("title", "Mo' Creatures Horse Guide");
        tag.m_128359_("author", "forgoted");
        tag.m_128379_("resolved", true);
        CompoundTag display = new CompoundTag();
        display.m_128359_("Name", "{\"text\":\"Mo' Creatures Horse Guide\",\"italic\":false}");
        ListTag lore = new ListTag();
        lore.add((Object)StringTag.m_129297_((String)"{\"text\":\"by forgoted\",\"italic\":false,\"color\":\"gray\"}"));
        lore.add((Object)StringTag.m_129297_((String)"{\"text\":\"Original\",\"italic\":false,\"color\":\"gray\"}"));
        display.m_128365_("Lore", (Tag)lore);
        tag.m_128365_("display", (Tag)display);
        ListTag pages = new ListTag();
        pages.add((Object)StringTag.m_129297_((String)Component.Serializer.m_130703_((Component)Component.m_237113_((String)"Welcome to the Mo' Creatures Horse Guide!\n\nLearn detailed methods to breed and raise all horses, special breeds, and mythical creatures."))));
        pages.add((Object)StringTag.m_129297_((String)Component.Serializer.m_130703_((Component)Component.m_237113_((String)"Tier 1 Horses (Breed Only)\n\n- Vanilla: Natural spawn\n- White/Light Grey: White + Pegasus/Fairy/Unicorn/Nightmare\n- Buckskin: Palomino Snowflake + Bay/Brown"))));
        pages.add((Object)StringTag.m_129297_((String)Component.Serializer.m_130703_((Component)Component.m_237113_((String)"Tier 1 (continued)\n\n- Blood Bay: Dark Brown/Bay + Buckskin\n- Mahogany/Dark Bay: Grulla Overo + Black Horse\n- Black: Nightmare/Fairy/Unicorn/Pegasus + Black Horse"))));
        pages.add((Object)StringTag.m_129297_((String)Component.Serializer.m_130703_((Component)Component.m_237113_((String)"Tier 2 Horses\n\n- Palomino Snowflake (wild)\n- Grulla Overo/Grullo (wild)\n- Bay (wild)\n- Dappled Grey: Grey Spotted + Pegasus/Unicorn/Nightmare/Fairy"))));
        pages.add((Object)StringTag.m_129297_((String)Component.Serializer.m_130703_((Component)Component.m_237113_((String)"Tier 3 Horses\n\n- Bay Tovero: Grulla Overo + Brown Spotted/Blood Bay\n- Palomino Tovero: Grulla Overo + White/Light Grey\n- Grulla/Grullo Tovero: Dappled Grey + White/Light Grey"))));
        pages.add((Object)StringTag.m_129297_((String)Component.Serializer.m_130703_((Component)Component.m_237113_((String)"Tier 4 Horses (Zebra Taming)\n\n- Black Leopard: Grulla Tovero + Black\n- Black Tovero: Bay Tovero + Black\n\nThese horses tame zebras."))));
        pages.add((Object)StringTag.m_129297_((String)Component.Serializer.m_130703_((Component)Component.m_237113_((String)"Unique Horses\n\n- Zebra (Chest Carrier)\n- Zorse (Sterile)\n- Zonkey (Sterile, Chest Carrier)\n- Mule (Sterile, Chest Carrier)"))));
        pages.add((Object)StringTag.m_129297_((String)Component.Serializer.m_130703_((Component)Component.m_237113_((String)"Mythical Horses\n\n- Nightmare (No Armor)\n- Unicorn (Armor)\n- Pegasus (Armor)\n- Bat Horse (No Armor)"))));
        pages.add((Object)StringTag.m_129297_((String)Component.Serializer.m_130703_((Component)Component.m_237113_((String)"Advanced Mythicals\n\n- Dark Pegasus (Chest Carrier)\n- Fairy Horse (Chest Carrier, Armor)"))));
        pages.add((Object)StringTag.m_129297_((String)Component.Serializer.m_130703_((Component)Component.m_237113_((String)"Undead & Skeleton\n\n- Created: Essence of Undead\n- Decays to Skeleton\n- Heal/Restore: Essence of Light/Undead\n- No Armor"))));
        pages.add((Object)StringTag.m_129297_((String)Component.Serializer.m_130703_((Component)Component.m_237113_((String)"Breeding & Care Tips\n\n- Enclose horses\n- Feed Bread/Sugar to grow foals\n- Keep chunks loaded\n- Only breed tamed horses"))));
        tag.m_128365_("pages", (Tag)pages);
        book.m_41751_(tag);
        items.add((Object)book);
    }

    public boolean m_5812_(ItemStack stack) {
        return true;
    }
}

