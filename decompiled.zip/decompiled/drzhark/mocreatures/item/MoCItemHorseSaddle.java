/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.item.Item$Properties
 */
package drzhark.mocreatures.item;

import drzhark.mocreatures.item.MoCItem;
import net.minecraft.world.item.Item;

public class MoCItemHorseSaddle
extends MoCItem {
    public MoCItemHorseSaddle(Item.Properties properties) {
        super(properties.m_41487_(32));
    }
}

