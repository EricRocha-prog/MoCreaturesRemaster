/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.ChatFormatting
 *  net.minecraft.network.chat.Component
 *  net.minecraft.world.effect.MobEffectInstance
 *  net.minecraft.world.effect.MobEffects
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.AxeItem
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.Tier
 *  net.minecraft.world.item.TooltipFlag
 *  net.minecraft.world.level.Level
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.item;

import drzhark.mocreatures.MoCreatures;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class MoCItemAxe
extends AxeItem {
    private final int specialWeaponType;

    public MoCItemAxe(Item.Properties properties, Tier material, float damage, float speed) {
        super(material, damage - 1.0f, speed - 4.0f, properties);
        this.specialWeaponType = 0;
    }

    public MoCItemAxe(Item.Properties properties, Tier material, float damage, float speed, int damageType) {
        super(material, damage - 1.0f, speed - 4.0f, properties);
        this.specialWeaponType = damageType;
    }

    public boolean m_7579_(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (MoCreatures.proxy.weaponEffects) {
            int timer = 15;
            switch (this.specialWeaponType) {
                case 1: {
                    target.m_7292_(new MobEffectInstance(MobEffects.f_19614_, timer * 20, 1));
                    break;
                }
                case 2: {
                    target.m_7292_(new MobEffectInstance(MobEffects.f_19597_, timer * 20, 0));
                    break;
                }
                case 3: {
                    target.m_20254_(timer);
                    break;
                }
                case 4: {
                    if (target instanceof Player) {
                        target.m_7292_(new MobEffectInstance(MobEffects.f_19604_, timer * 20, 0));
                        break;
                    }
                    target.m_7292_(new MobEffectInstance(MobEffects.f_19613_, timer * 20, 0));
                    break;
                }
                case 5: {
                    if (target instanceof Player) {
                        target.m_7292_(new MobEffectInstance(MobEffects.f_19610_, timer * 20, 0));
                        break;
                    }
                    target.m_7292_(new MobEffectInstance(MobEffects.f_19615_, timer * 20, 0));
                    break;
                }
            }
        }
        return super.m_7579_(stack, target, attacker);
    }

    @OnlyIn(value=Dist.CLIENT)
    public void m_7373_(ItemStack stack, @Nullable Level world, List<Component> tooltip, TooltipFlag flag) {
        if (MoCreatures.proxy.weaponEffects) {
            String key;
            switch (this.specialWeaponType) {
                case 1: {
                    String string = "info.mocreatures.stingaxe1";
                    break;
                }
                case 2: {
                    String string = "info.mocreatures.stingaxe2";
                    break;
                }
                case 3: {
                    String string = "info.mocreatures.stingaxe3";
                    break;
                }
                case 4: {
                    String string = "info.mocreatures.stingaxe4";
                    break;
                }
                case 5: {
                    String string = "info.mocreatures.stingaxe5";
                    break;
                }
                default: {
                    String string = key = null;
                }
            }
            if (key != null) {
                tooltip.add((Component)Component.m_237115_((String)key).m_130940_(ChatFormatting.BLUE));
            }
        }
    }
}

