/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.ChatFormatting
 *  net.minecraft.network.chat.Component
 *  net.minecraft.world.entity.EquipmentSlot
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.ArmorItem
 *  net.minecraft.world.item.ArmorItem$Type
 *  net.minecraft.world.item.ArmorMaterial
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.TooltipFlag
 *  net.minecraft.world.level.Level
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package drzhark.mocreatures.item;

import drzhark.mocreatures.MoCTools;
import drzhark.mocreatures.init.MoCItems;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class MoCItemArmor
extends ArmorItem {
    public MoCItemArmor(Item.Properties properties, ArmorMaterial materialIn, ArmorItem.Type type) {
        super(materialIn, type, properties);
    }

    public void onArmorTick(ItemStack itemStack, Level world, Player player) {
        ItemStack stack;
        if (player.f_19797_ % 40 == 0 && !(stack = player.m_6844_(EquipmentSlot.FEET)).m_41619_() && stack.m_41720_() instanceof MoCItemArmor) {
            MoCTools.updatePlayerArmorEffects(player);
        }
    }

    @OnlyIn(value=Dist.CLIENT)
    public void m_7373_(ItemStack stack, @Nullable Level world, List<Component> tooltip, TooltipFlag flag) {
        if (this == MoCItems.HELMET_SCORP_D.get() || this == MoCItems.PLATE_SCORP_D.get() || this == MoCItems.LEGS_SCORP_D.get() || this == MoCItems.BOOTS_SCORP_D.get()) {
            tooltip.add((Component)Component.m_237115_((String)"info.mocreatures.setbonus").m_130940_(ChatFormatting.GRAY));
            tooltip.add((Component)Component.m_237115_((String)"info.mocreatures.setbonusscorp1").m_130940_(ChatFormatting.BLUE));
        }
        if (this == MoCItems.HELMET_SCORP_F.get() || this == MoCItems.PLATE_SCORP_F.get() || this == MoCItems.LEGS_SCORP_F.get() || this == MoCItems.BOOTS_SCORP_F.get()) {
            tooltip.add((Component)Component.m_237115_((String)"info.mocreatures.setbonus").m_130940_(ChatFormatting.GRAY));
            tooltip.add((Component)Component.m_237115_((String)"info.mocreatures.setbonusscorp2").m_130940_(ChatFormatting.BLUE));
        }
        if (this == MoCItems.HELMET_SCORP_N.get() || this == MoCItems.PLATE_SCORP_N.get() || this == MoCItems.LEGS_SCORP_N.get() || this == MoCItems.BOOTS_SCORP_N.get()) {
            tooltip.add((Component)Component.m_237115_((String)"info.mocreatures.setbonus").m_130940_(ChatFormatting.GRAY));
            tooltip.add((Component)Component.m_237115_((String)"info.mocreatures.setbonusscorp3").m_130940_(ChatFormatting.BLUE));
        }
        if (this == MoCItems.HELMET_SCORP_C.get() || this == MoCItems.PLATE_SCORP_C.get() || this == MoCItems.LEGS_SCORP_C.get() || this == MoCItems.BOOTS_SCORP_C.get()) {
            tooltip.add((Component)Component.m_237115_((String)"info.mocreatures.setbonus").m_130940_(ChatFormatting.GRAY));
            tooltip.add((Component)Component.m_237115_((String)"info.mocreatures.setbonusscorp4").m_130940_(ChatFormatting.BLUE));
        }
        if (this == MoCItems.HELMET_SCORP_U.get() || this == MoCItems.PLATE_SCORP_U.get() || this == MoCItems.LEGS_SCORP_U.get() || this == MoCItems.BOOTS_SCORP_U.get()) {
            tooltip.add((Component)Component.m_237115_((String)"info.mocreatures.setbonus").m_130940_(ChatFormatting.GRAY));
            tooltip.add((Component)Component.m_237115_((String)"info.mocreatures.setbonusscorp5").m_130940_(ChatFormatting.BLUE));
        }
    }
}

