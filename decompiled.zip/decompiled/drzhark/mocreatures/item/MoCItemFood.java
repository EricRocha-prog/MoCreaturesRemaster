/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.effect.MobEffectInstance
 *  net.minecraft.world.food.FoodProperties$Builder
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.item.ItemStack
 */
package drzhark.mocreatures.item;

import drzhark.mocreatures.item.MoCItem;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class MoCItemFood
extends MoCItem {
    public int itemUseDuration;

    protected MoCItemFood(Builder builder) {
        super(builder.properties.m_41489_(builder.foodBuilder.m_38767_()));
        this.itemUseDuration = builder.itemUseDuration;
    }

    public int m_8105_(ItemStack stack) {
        return this.itemUseDuration == 0 ? 32 : this.itemUseDuration;
    }

    public static class Builder {
        private final FoodProperties.Builder foodBuilder;
        private int itemUseDuration;
        private final Item.Properties properties;
        private final String name = "PLACEHOLDER";

        public Builder(Item.Properties properties, int amount) {
            this(properties, amount, 0.6f, false);
        }

        public Builder(Item.Properties properties, int amount, float saturation, boolean isWolfFood) {
            this(properties, amount, saturation, isWolfFood, 32);
        }

        public Builder(Item.Properties properties, int amount, float saturation, boolean isWolfFood, int eatingSpeed) {
            this.properties = properties;
            this.foodBuilder = new FoodProperties.Builder().m_38760_(amount).m_38758_(saturation);
            if (isWolfFood) {
                this.foodBuilder.m_38757_();
            }
            this.itemUseDuration = eatingSpeed;
        }

        public Builder setAlwaysEdible() {
            this.foodBuilder.m_38765_();
            return this;
        }

        public Builder setPotionEffect(MobEffectInstance effectIn, float probability) {
            this.foodBuilder.effect(() -> effectIn, probability);
            return this;
        }

        public MoCItemFood build() {
            return new MoCItemFood(this);
        }
    }
}

