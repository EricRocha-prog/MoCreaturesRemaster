/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.Holder
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.tags.TagKey
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.MobCategory
 *  net.minecraft.world.level.biome.Biome
 *  net.minecraft.world.level.biome.MobSpawnSettings$SpawnerData
 */
package drzhark.mocreatures.world;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.MobSpawnSettings;

public class MoCSpawnData {
    public static final TagKey<Biome> STEEP = TagKey.m_203882_((ResourceKey)Registries.f_256952_, (ResourceLocation)new ResourceLocation("forge", "is_steep"));
    public static final TagKey<Biome> WYVERN_LAIR = TagKey.m_203882_((ResourceKey)Registries.f_256952_, (ResourceLocation)new ResourceLocation("mocreatures", "is_wyvern_lair"));
    private final String entityName;
    private final int frequency;
    private final MobCategory category;
    private final EntityType<?> entityType;
    private final int weight;
    private final int minCount;
    private final int maxCount;
    private final List<TagKey<Biome>> includeBiomeTags = new ArrayList<TagKey<Biome>>();
    private final List<TagKey<Biome>> excludeBiomeTags = new ArrayList<TagKey<Biome>>();

    public MoCSpawnData(String entityName, int frequency, MobCategory category, EntityType<?> entityType, int weight, int minCount, int maxCount) {
        this.entityName = entityName;
        this.frequency = frequency;
        this.category = category;
        this.entityType = entityType;
        this.weight = weight;
        this.minCount = minCount;
        this.maxCount = maxCount;
    }

    public MoCSpawnData addBiomeTags(TagKey<Biome> ... tags) {
        this.includeBiomeTags.addAll(Arrays.asList(tags));
        return this;
    }

    public MoCSpawnData excludeBiomeTags(TagKey<Biome> ... tags) {
        this.excludeBiomeTags.addAll(Arrays.asList(tags));
        return this;
    }

    public boolean canSpawnIn(Holder<Biome> biome) {
        if (this.frequency <= 0) {
            return false;
        }
        for (TagKey<Biome> tag : this.excludeBiomeTags) {
            if (!biome.m_203656_(tag)) continue;
            return false;
        }
        for (TagKey<Biome> tag : this.includeBiomeTags) {
            if (!biome.m_203656_(tag)) continue;
            return true;
        }
        return this.includeBiomeTags.isEmpty();
    }

    public MobSpawnSettings.SpawnerData toSpawnerData() {
        return new MobSpawnSettings.SpawnerData(this.entityType, this.calculateWeight(), this.minCount, this.maxCount);
    }

    private int calculateWeight() {
        return Math.max(1, (int)((double)this.weight * ((double)this.frequency / 10.0)));
    }

    public String getEntityName() {
        return this.entityName;
    }

    public int getFrequency() {
        return this.frequency;
    }

    public MobCategory getCategory() {
        return this.category;
    }

    public EntityType<?> getEntityType() {
        return this.entityType;
    }

    public int getWeight() {
        return this.weight;
    }

    public int getMinCount() {
        return this.minCount;
    }

    public int getMaxCount() {
        return this.maxCount;
    }

    public List<TagKey<Biome>> getIncludeBiomeTags() {
        return this.includeBiomeTags;
    }

    public List<TagKey<Biome>> getExcludeBiomeTags() {
        return this.excludeBiomeTags;
    }
}

