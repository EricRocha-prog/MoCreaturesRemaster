/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.tags.FluidTags
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.Mob
 *  net.minecraft.world.entity.MobSpawnType
 *  net.minecraft.world.entity.SpawnPlacements$Type
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.ServerLevelAccessor
 *  net.minecraft.world.level.levelgen.Heightmap$Types
 *  net.minecraftforge.event.entity.EntityAttributeCreationEvent
 *  net.minecraftforge.event.entity.SpawnPlacementRegisterEvent
 *  net.minecraftforge.event.entity.SpawnPlacementRegisterEvent$Operation
 *  net.minecraftforge.event.server.ServerAboutToStartEvent
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent
 */
package drzhark.mocreatures.world;

import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.init.MoCEntities;
import drzhark.mocreatures.world.MoCBiomeTags;
import java.util.Random;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.event.server.ServerAboutToStartEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;

@Mod.EventBusSubscriber(modid="mocreatures")
public class MoCSpawnRegistry {
    @SubscribeEvent
    public static void registerSpawnPlacements(SpawnPlacementRegisterEvent event) {
        MoCreatures.proxy.readMocConfigValues();
        MoCSpawnRegistry.registerLandAnimalPlacements(event);
        MoCSpawnRegistry.registerAquaticPlacements(event);
        MoCSpawnRegistry.registerMonsterPlacements(event);
        MoCSpawnRegistry.registerAmbientPlacements(event);
    }

    private static void registerLandAnimalPlacements(SpawnPlacementRegisterEvent event) {
        event.register((EntityType)MoCEntities.BLACK_BEAR.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_FOREST) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_CONIFEROUS), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.KITTY.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_PLAINS) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_DESERT) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SAVANNA) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_TAIGA) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SNOWY), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.GRIZZLY_BEAR.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_FOREST), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.POLAR_BEAR.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SNOWY), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.PANDA_BEAR.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_JUNGLE), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.BIRD.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_FOREST) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_JUNGLE) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_PLAINS), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.BOAR.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_FOREST) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_PLAINS), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.BUNNY.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> {
            if (spawnType == MobSpawnType.SPAWN_EGG) {
                return true;
            }
            if (world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_WYVERN_LAIR)) {
                return true;
            }
            return world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_PLAINS) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_FOREST) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_LUSH);
        }, SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.DEER.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_FOREST) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_PLAINS), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.DUCK.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_RIVER) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_LUSH), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.ELEPHANT.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SAVANNA) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SANDY) && !world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_BADLANDS), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.SNAKE.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> {
            if (spawnType == MobSpawnType.SPAWN_EGG) {
                return true;
            }
            if (world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_WYVERN_LAIR)) {
                return true;
            }
            return world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SANDY) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_BADLANDS) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_PLAINS) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_FOREST) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SWAMP) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_LUSH) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_JUNGLE) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_STEEP);
        }, SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.LION.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SAVANNA) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SANDY) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_BADLANDS), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.TIGER.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_JUNGLE), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.TURKEY.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_FOREST) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_PLAINS), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.WILDHORSE.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_PLAINS) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SAVANNA), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.LIGER.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_JUNGLE) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SAVANNA), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.LITHER.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_JUNGLE), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.PANTHGER.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_JUNGLE), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.PANTHARD.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_JUNGLE), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.LEOGER.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_JUNGLE) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SAVANNA), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.LEOPARD.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_JUNGLE) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SNOWY) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SAVANNA), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.PANTHER.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_JUNGLE), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.KOMODO_DRAGON.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SWAMP) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SAVANNA), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.FILCH_LIZARD.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> {
            if (spawnType == MobSpawnType.SPAWN_EGG) {
                return true;
            }
            if (world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_WYVERN_LAIR)) {
                return true;
            }
            return world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SAVANNA) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SANDY) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_BADLANDS);
        }, SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.MOLE.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_FOREST) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_LUSH) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_PLAINS), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.ENT.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_FOREST), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.WYVERN.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> {
            if (spawnType == MobSpawnType.SPAWN_EGG) {
                return true;
            }
            return world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_WYVERN_LAIR);
        }, SpawnPlacementRegisterEvent.Operation.AND);
    }

    private static void registerAquaticPlacements(SpawnPlacementRegisterEvent event) {
        event.register((EntityType)MoCEntities.DOLPHIN.get(), SpawnPlacements.Type.IN_WATER, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_6425_(pos).m_205070_(FluidTags.f_13131_) && world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_OCEAN), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.SHARK.get(), SpawnPlacements.Type.IN_WATER, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_6425_(pos).m_205070_(FluidTags.f_13131_) && world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_OCEAN), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.MANTA_RAY.get(), SpawnPlacements.Type.IN_WATER, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_6425_(pos).m_205070_(FluidTags.f_13131_) && world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_OCEAN), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.STING_RAY.get(), SpawnPlacements.Type.IN_WATER, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_6425_(pos).m_205070_(FluidTags.f_13131_) && (world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SWAMP) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_RIVER)), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.PIRANHA.get(), SpawnPlacements.Type.IN_WATER, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_6425_(pos).m_205070_(FluidTags.f_13131_) && (world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_JUNGLE) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SWAMP)), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.BASS.get(), SpawnPlacements.Type.IN_WATER, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_6425_(pos).m_205070_(FluidTags.f_13131_) && (world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_RIVER) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_FOREST) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_PLAINS)), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.FISHY.get(), SpawnPlacements.Type.IN_WATER, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_6425_(pos).m_205070_(FluidTags.f_13131_) && (world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_OCEAN) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_RIVER)), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.JELLYFISH.get(), SpawnPlacements.Type.IN_WATER, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_6425_(pos).m_205070_(FluidTags.f_13131_) && world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_OCEAN), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.ANCHOVY.get(), SpawnPlacements.Type.IN_WATER, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_6425_(pos).m_205070_(FluidTags.f_13131_) && (world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_BEACH) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_OCEAN) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_RIVER)), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.ANGELFISH.get(), SpawnPlacements.Type.IN_WATER, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_6425_(pos).m_205070_(FluidTags.f_13131_) && (world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SWAMP) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_RIVER) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_JUNGLE)), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.ANGLER.get(), SpawnPlacements.Type.IN_WATER, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_6425_(pos).m_205070_(FluidTags.f_13131_) && (world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_BEACH) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_OCEAN)), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.CLOWNFISH.get(), SpawnPlacements.Type.IN_WATER, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_6425_(pos).m_205070_(FluidTags.f_13131_) && (world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_BEACH) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_OCEAN)), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.COD.get(), SpawnPlacements.Type.IN_WATER, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_6425_(pos).m_205070_(FluidTags.f_13131_) && (world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_BEACH) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_OCEAN)), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.GOLDFISH.get(), SpawnPlacements.Type.IN_WATER, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_6425_(pos).m_205070_(FluidTags.f_13131_) && world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_RIVER), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.HIPPOTANG.get(), SpawnPlacements.Type.IN_WATER, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_6425_(pos).m_205070_(FluidTags.f_13131_) && (world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_BEACH) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_OCEAN)), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.MANDERIN.get(), SpawnPlacements.Type.IN_WATER, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_6425_(pos).m_205070_(FluidTags.f_13131_) && (world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_BEACH) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_OCEAN)), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.SALMON.get(), SpawnPlacements.Type.IN_WATER, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_6425_(pos).m_205070_(FluidTags.f_13131_) && (world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_BEACH) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_WATER) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_OCEAN) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_RIVER) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_FOREST) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_PLAINS)), SpawnPlacementRegisterEvent.Operation.AND);
    }

    private static void registerMonsterPlacements(SpawnPlacementRegisterEvent event) {
        event.register((EntityType)MoCEntities.GREEN_OGRE.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_PLAINS) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SWAMP), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.FIRE_OGRE.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_NETHER), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.CAVE_OGRE.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_MOUNTAIN), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.BIG_GOLEM.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SANDY) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_HILL) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_BADLANDS) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_MOUNTAIN) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_PLAINS) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_DEAD), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.MINI_GOLEM.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SANDY) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_BADLANDS) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_MOUNTAIN) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_PLAINS) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_DEAD), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.HORSE_MOB.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_NETHER) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_PLAINS) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SAVANNA) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_DEAD) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SPOOKY), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.HELL_RAT.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_NETHER), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.CAVE_SCORPION.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_MOUNTAIN), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.DIRT_SCORPION.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SANDY) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_DRY), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.FROST_SCORPION.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SNOWY), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.FIRE_SCORPION.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_NETHER), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.UNDEAD_SCORPION.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_DEAD) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SPOOKY), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.DARK_MANTICORE.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SANDY) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_MOUNTAIN) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_PLAINS) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SNOWY) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_DEAD) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SPOOKY), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.FIRE_MANTICORE.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_NETHER), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.FROST_MANTICORE.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SNOWY), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.PLAIN_MANTICORE.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SANDY) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_MOUNTAIN) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_PLAINS), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.TOXIC_MANTICORE.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_DEAD) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SPOOKY), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.SILVER_SKELETON.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SANDY) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SNOWY) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_BADLANDS) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_PLAINS) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_DEAD) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SPOOKY), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.WEREWOLF.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_FOREST) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_CONIFEROUS), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.WRAITH.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SPOOKY) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_FOREST), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.FLAME_WRAITH.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_NETHER), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.RAT.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_FOREST) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_PLAINS) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_STEEP), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.HELL_RAT.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_NETHER), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.WWOLF.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_FOREST) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SNOWY) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_DEAD), SpawnPlacementRegisterEvent.Operation.AND);
    }

    private static void registerAmbientPlacements(SpawnPlacementRegisterEvent event) {
        event.register((EntityType)MoCEntities.ANT.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_FOREST) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_JUNGLE) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_PLAINS), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.BEE.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_FOREST) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_PLAINS) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_JUNGLE), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.BUTTERFLY.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_FOREST) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_PLAINS) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_JUNGLE) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_LUSH), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.DRAGONFLY.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> {
            if (spawnType == MobSpawnType.SPAWN_EGG) {
                return true;
            }
            if (world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_WYVERN_LAIR)) {
                return true;
            }
            return world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SWAMP) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_LUSH) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_JUNGLE);
        }, SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.FIREFLY.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> {
            if (spawnType == MobSpawnType.SPAWN_EGG) {
                return true;
            }
            if (world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_WYVERN_LAIR)) {
                return true;
            }
            return world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SWAMP) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_CONIFEROUS) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_PLAINS);
        }, SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.FLY.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SWAMP) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_PLAINS), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.CRAB.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_BEACH), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.SNAIL.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SWAMP) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_JUNGLE) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_LUSH), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.MAGGOT.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SWAMP) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_DEAD) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SPOOKY), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.ROACH.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_DEAD) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SPOOKY), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.CRICKET.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> spawnType == MobSpawnType.SPAWN_EGG || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_FOREST) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_JUNGLE) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_PLAINS) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_SWAMP), SpawnPlacementRegisterEvent.Operation.AND);
        event.register((EntityType)MoCEntities.GRASSHOPPER.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, spawnType, pos, random) -> {
            if (spawnType == MobSpawnType.SPAWN_EGG) {
                return true;
            }
            if (world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_WYVERN_LAIR)) {
                return true;
            }
            return world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_FOREST) || world.m_204166_(pos).m_203656_(MoCBiomeTags.IS_PLAINS);
        }, SpawnPlacementRegisterEvent.Operation.AND);
    }

    public static void register() {
        MoCreatures.proxy.readMocConfigValues();
        MoCreatures.LOGGER.info("Registering Mo' Creatures spawn system");
    }

    @SubscribeEvent
    public static void onServerAboutToStart(ServerAboutToStartEvent event) {
        MoCSpawnRegistry.init();
    }

    @SubscribeEvent
    public static void onCommonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(MoCSpawnRegistry::init);
    }

    public static boolean debugSpawn(EntityType<? extends Mob> entityType, ServerLevelAccessor level, BlockPos pos, Random random) {
        try {
            Mob entity = (Mob)entityType.m_20615_((Level)level.m_6018_());
            if (entity == null) {
                return false;
            }
            entity.m_6034_((double)pos.m_123341_() + 0.5, (double)pos.m_123342_(), (double)pos.m_123343_() + 0.5);
            return level.m_7967_((Entity)entity);
        }
        catch (Exception e) {
            MoCreatures.LOGGER.error("Failed to debug spawn entity", (Throwable)e);
            return false;
        }
    }

    public static void init() {
        MoCreatures.LOGGER.info("Initializing Mo' Creatures spawn registry");
    }

    @SubscribeEvent
    public static void registerAttributes(EntityAttributeCreationEvent event) {
        MoCSpawnRegistry.init();
    }
}

