/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.tags.BiomeTags
 *  net.minecraft.tags.TagKey
 *  net.minecraft.world.level.biome.Biome
 */
package drzhark.mocreatures.world;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BiomeTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.biome.Biome;

public class MoCBiomeTags {
    public static final TagKey<Biome> IS_OVERWORLD = BiomeTags.f_215817_;
    public static final TagKey<Biome> IS_NETHER = BiomeTags.f_207612_;
    public static final TagKey<Biome> IS_END = BiomeTags.f_215818_;
    public static final TagKey<Biome> IS_JUNGLE = BiomeTags.f_207610_;
    public static final TagKey<Biome> IS_FOREST = BiomeTags.f_207611_;
    public static final TagKey<Biome> IS_TAIGA = BiomeTags.f_207609_;
    public static final TagKey<Biome> IS_DESERT = TagKey.m_203882_((ResourceKey)Registries.f_256952_, (ResourceLocation)new ResourceLocation("minecraft", "is_desert"));
    public static final TagKey<Biome> IS_OCEAN = BiomeTags.f_207603_;
    public static final TagKey<Biome> IS_RIVER = BiomeTags.f_207605_;
    public static final TagKey<Biome> IS_BEACH = BiomeTags.f_207604_;
    public static final TagKey<Biome> IS_MOUNTAIN = BiomeTags.f_207606_;
    public static final TagKey<Biome> IS_BADLANDS = BiomeTags.f_207607_;
    public static final TagKey<Biome> IS_HILL = BiomeTags.f_207608_;
    public static final TagKey<Biome> IS_SAVANNA = BiomeTags.f_215816_;
    public static final TagKey<Biome> IS_PLAINS = TagKey.m_203882_((ResourceKey)Registries.f_256952_, (ResourceLocation)new ResourceLocation("minecraft", "is_plains"));
    public static final TagKey<Biome> IS_SNOWY = TagKey.m_203882_((ResourceKey)Registries.f_256952_, (ResourceLocation)new ResourceLocation("minecraft", "is_snowy"));
    public static final TagKey<Biome> IS_SWAMP = TagKey.m_203882_((ResourceKey)Registries.f_256952_, (ResourceLocation)new ResourceLocation("minecraft", "is_swamp"));
    public static final TagKey<Biome> IS_WATER = TagKey.m_203882_((ResourceKey)Registries.f_256952_, (ResourceLocation)new ResourceLocation("forge", "is_water"));
    public static final TagKey<Biome> IS_HOT = MoCBiomeTags.createForgeTag("is_hot");
    public static final TagKey<Biome> IS_COLD = MoCBiomeTags.createForgeTag("is_cold");
    public static final TagKey<Biome> IS_WET = MoCBiomeTags.createForgeTag("is_wet");
    public static final TagKey<Biome> IS_DRY = MoCBiomeTags.createForgeTag("is_dry");
    public static final TagKey<Biome> IS_SPARSE = MoCBiomeTags.createForgeTag("is_sparse");
    public static final TagKey<Biome> IS_DENSE = MoCBiomeTags.createForgeTag("is_dense");
    public static final TagKey<Biome> IS_LUSH = MoCBiomeTags.createForgeTag("is_lush");
    public static final TagKey<Biome> IS_DEAD = MoCBiomeTags.createForgeTag("is_dead");
    public static final TagKey<Biome> IS_SPOOKY = MoCBiomeTags.createForgeTag("is_spooky");
    public static final TagKey<Biome> IS_STEEP = MoCBiomeTags.createForgeTag("is_steep");
    public static final TagKey<Biome> IS_PLATEAU = MoCBiomeTags.createForgeTag("is_plateau");
    public static final TagKey<Biome> IS_SANDY = MoCBiomeTags.createForgeTag("is_sandy");
    public static final TagKey<Biome> IS_CONIFEROUS = MoCBiomeTags.createForgeTag("is_coniferous");
    public static final TagKey<Biome> IS_MESA = BiomeTags.f_207607_;
    public static final TagKey<Biome> IS_WYVERN_LAIR = MoCBiomeTags.createMoCTag("is_wyvern_lair");
    public static final TagKey<Biome> IS_VILLAGE = TagKey.m_203882_((ResourceKey)Registries.f_256952_, (ResourceLocation)new ResourceLocation("mocreatures", "is_village"));

    private static TagKey<Biome> createForgeTag(String name) {
        return TagKey.m_203882_((ResourceKey)Registries.f_256952_, (ResourceLocation)new ResourceLocation("forge", name));
    }

    private static TagKey<Biome> createMoCTag(String name) {
        return TagKey.m_203882_((ResourceKey)Registries.f_256952_, (ResourceLocation)new ResourceLocation("mocreatures", name));
    }
}

