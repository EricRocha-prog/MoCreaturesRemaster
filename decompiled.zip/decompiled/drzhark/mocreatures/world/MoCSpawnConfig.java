/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.MobCategory
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 */
package drzhark.mocreatures.world;

import drzhark.mocreatures.MoCreatures;
import drzhark.mocreatures.init.MoCEntities;
import drzhark.mocreatures.world.MoCBiomeTags;
import drzhark.mocreatures.world.MoCSpawnData;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid="mocreatures")
public class MoCSpawnConfig {
    private static final List<MoCSpawnData> SPAWN_DATA = new ArrayList<MoCSpawnData>();

    public static void init() {
        MoCreatures.LOGGER.info("Initializing Mo' Creatures spawn configurations");
        SPAWN_DATA.clear();
        MoCSpawnConfig.registerAnimalSpawns();
        MoCSpawnConfig.registerMonsterSpawns();
        MoCSpawnConfig.registerAquaticSpawns();
        MoCSpawnConfig.registerAmbientSpawns();
    }

    private static void registerAnimalSpawns() {
        MoCSpawnConfig.addSpawn("BlackBear", 4, (EntityType)MoCEntities.BLACK_BEAR.get(), 8, 1, 3).addBiomeTags(MoCBiomeTags.IS_FOREST, MoCBiomeTags.IS_CONIFEROUS);
        MoCSpawnConfig.addSpawn("GrizzlyBear", 4, (EntityType)MoCEntities.GRIZZLY_BEAR.get(), 7, 1, 2).addBiomeTags(MoCBiomeTags.IS_FOREST);
        MoCSpawnConfig.addSpawn("PolarBear", 4, (EntityType)MoCEntities.POLAR_BEAR.get(), 8, 1, 2).addBiomeTags(MoCBiomeTags.IS_SNOWY);
        MoCSpawnConfig.addSpawn("PandaBear", 4, (EntityType)MoCEntities.PANDA_BEAR.get(), 7, 1, 3).addBiomeTags(MoCBiomeTags.IS_JUNGLE);
        MoCSpawnConfig.addSpawn("Bird", 4, (EntityType)MoCEntities.BIRD.get(), 16, 2, 3).addBiomeTags(MoCBiomeTags.IS_FOREST, MoCBiomeTags.IS_JUNGLE, MoCBiomeTags.IS_PLAINS, MoCBiomeTags.IS_BADLANDS, MoCBiomeTags.IS_LUSH, MoCBiomeTags.IS_STEEP);
        MoCSpawnConfig.addSpawn("Boar", 3, (EntityType)MoCEntities.BOAR.get(), 12, 2, 2).addBiomeTags(MoCBiomeTags.IS_FOREST, MoCBiomeTags.IS_PLAINS);
        MoCSpawnConfig.addSpawn("Bunny", 4, (EntityType)MoCEntities.BUNNY.get(), 12, 2, 3).addBiomeTags(MoCBiomeTags.IS_FOREST, MoCBiomeTags.IS_PLAINS, MoCBiomeTags.IS_SNOWY, MoCBiomeTags.IS_CONIFEROUS, MoCBiomeTags.IS_STEEP, MoCBiomeTags.IS_WYVERN_LAIR);
        MoCSpawnConfig.addSpawn("Deer", 2, (EntityType)MoCEntities.DEER.get(), 10, 1, 2).addBiomeTags(MoCBiomeTags.IS_FOREST, MoCBiomeTags.IS_PLAINS, MoCBiomeTags.IS_CONIFEROUS);
        MoCSpawnConfig.addSpawn("Duck", 3, (EntityType)MoCEntities.DUCK.get(), 12, 2, 4).addBiomeTags(MoCBiomeTags.IS_RIVER, MoCBiomeTags.IS_LUSH);
        MoCSpawnConfig.addSpawn("Crocodile", 2, (EntityType)MoCEntities.CROCODILE.get(), 10, 1, 2).addBiomeTags(MoCBiomeTags.IS_SWAMP);
        MoCSpawnConfig.addSpawn("Turtle", 3, (EntityType)MoCEntities.TURTLE.get(), 12, 1, 3).addBiomeTags(MoCBiomeTags.IS_SWAMP, MoCBiomeTags.IS_RIVER);
        MoCSpawnConfig.addSpawn("Elephant", 3, (EntityType)MoCEntities.ELEPHANT.get(), 6, 1, 2).addBiomeTags(MoCBiomeTags.IS_SANDY, MoCBiomeTags.IS_JUNGLE, MoCBiomeTags.IS_SAVANNA, MoCBiomeTags.IS_SNOWY).excludeBiomeTags(MoCBiomeTags.IS_BADLANDS);
        MoCSpawnConfig.addSpawn("FilchLizard", 2, (EntityType)MoCEntities.FILCH_LIZARD.get(), 6, 1, 2).addBiomeTags(MoCBiomeTags.IS_SAVANNA, MoCBiomeTags.IS_SANDY, MoCBiomeTags.IS_BADLANDS, MoCBiomeTags.IS_WYVERN_LAIR);
        MoCSpawnConfig.addSpawn("Ostrich", 3, (EntityType)MoCEntities.OSTRICH.get(), 7, 1, 1).addBiomeTags(MoCBiomeTags.IS_SAVANNA, MoCBiomeTags.IS_SANDY).excludeBiomeTags(MoCBiomeTags.IS_BADLANDS);
        MoCSpawnConfig.addSpawn("Fox", 2, (EntityType)MoCEntities.FOX.get(), 10, 1, 1).addBiomeTags(MoCBiomeTags.IS_FOREST, MoCBiomeTags.IS_SNOWY, MoCBiomeTags.IS_CONIFEROUS);
        MoCSpawnConfig.addSpawn("Goat", 2, (EntityType)MoCEntities.GOAT.get(), 12, 1, 3).addBiomeTags(MoCBiomeTags.IS_PLAINS, MoCBiomeTags.IS_STEEP);
        MoCSpawnConfig.addSpawn("Kitty", 3, (EntityType)MoCEntities.KITTY.get(), 8, 1, 2).addBiomeTags(MoCBiomeTags.IS_PLAINS, MoCBiomeTags.IS_FOREST);
        MoCSpawnConfig.addSpawn("KomodoDragon", 2, (EntityType)MoCEntities.KOMODO_DRAGON.get(), 12, 1, 2).addBiomeTags(MoCBiomeTags.IS_SWAMP, MoCBiomeTags.IS_SAVANNA);
        MoCSpawnConfig.addSpawn("Leopard", 4, (EntityType)MoCEntities.LEOPARD.get(), 7, 1, 2).addBiomeTags(MoCBiomeTags.IS_JUNGLE, MoCBiomeTags.IS_SNOWY, MoCBiomeTags.IS_SAVANNA);
        MoCSpawnConfig.addSpawn("Lion", 4, (EntityType)MoCEntities.LION.get(), 8, 1, 3).addBiomeTags(MoCBiomeTags.IS_SAVANNA, MoCBiomeTags.IS_SANDY, MoCBiomeTags.IS_BADLANDS);
        MoCSpawnConfig.addSpawn("Panther", 4, (EntityType)MoCEntities.PANTHER.get(), 6, 1, 2).addBiomeTags(MoCBiomeTags.IS_JUNGLE);
        MoCSpawnConfig.addSpawn("Tiger", 4, (EntityType)MoCEntities.TIGER.get(), 7, 1, 2).addBiomeTags(MoCBiomeTags.IS_JUNGLE);
        MoCSpawnConfig.addSpawn("Liger", 4, (EntityType)MoCEntities.LIGER.get(), 8, 1, 2).addBiomeTags(MoCBiomeTags.IS_JUNGLE, MoCBiomeTags.IS_SAVANNA);
        MoCSpawnConfig.addSpawn("Lither", 4, (EntityType)MoCEntities.LITHER.get(), 7, 1, 2).addBiomeTags(MoCBiomeTags.IS_JUNGLE);
        MoCSpawnConfig.addSpawn("Panthger", 4, (EntityType)MoCEntities.PANTHGER.get(), 7, 1, 2).addBiomeTags(MoCBiomeTags.IS_JUNGLE);
        MoCSpawnConfig.addSpawn("Panthard", 4, (EntityType)MoCEntities.PANTHARD.get(), 7, 1, 2).addBiomeTags(MoCBiomeTags.IS_JUNGLE);
        MoCSpawnConfig.addSpawn("Leoger", 4, (EntityType)MoCEntities.LEOGER.get(), 7, 1, 2).addBiomeTags(MoCBiomeTags.IS_JUNGLE, MoCBiomeTags.IS_SAVANNA);
        MoCSpawnConfig.addSpawn("Mouse", 2, (EntityType)MoCEntities.MOUSE.get(), 10, 1, 2).addBiomeTags(MoCBiomeTags.IS_FOREST, MoCBiomeTags.IS_PLAINS, MoCBiomeTags.IS_BADLANDS, MoCBiomeTags.IS_STEEP);
        MoCSpawnConfig.addSpawn("Mole", 3, (EntityType)MoCEntities.MOLE.get(), 10, 1, 2).addBiomeTags(MoCBiomeTags.IS_FOREST, MoCBiomeTags.IS_LUSH, MoCBiomeTags.IS_PLAINS);
        MoCSpawnConfig.addSpawn("Raccoon", 2, (EntityType)MoCEntities.RACCOON.get(), 12, 1, 2).addBiomeTags(MoCBiomeTags.IS_FOREST);
        MoCSpawnConfig.addSpawn("Snake", 3, (EntityType)MoCEntities.SNAKE.get(), 14, 1, 2).addBiomeTags(MoCBiomeTags.IS_SANDY, MoCBiomeTags.IS_BADLANDS, MoCBiomeTags.IS_PLAINS, MoCBiomeTags.IS_FOREST, MoCBiomeTags.IS_SWAMP, MoCBiomeTags.IS_LUSH, MoCBiomeTags.IS_JUNGLE, MoCBiomeTags.IS_STEEP, MoCBiomeTags.IS_WYVERN_LAIR);
        MoCSpawnConfig.addSpawn("Turkey", 2, (EntityType)MoCEntities.TURKEY.get(), 12, 1, 2).addBiomeTags(MoCBiomeTags.IS_FOREST, MoCBiomeTags.IS_PLAINS);
        MoCSpawnConfig.addSpawn("WildHorse", 4, (EntityType)MoCEntities.WILDHORSE.get(), 12, 1, 4).addBiomeTags(MoCBiomeTags.IS_PLAINS, MoCBiomeTags.IS_SAVANNA);
        MoCSpawnConfig.addSpawn("Ent", 3, (EntityType)MoCEntities.ENT.get(), 5, 1, 2).addBiomeTags(MoCBiomeTags.IS_FOREST);
        MoCSpawnConfig.addSpawn("Wyvern", 3, (EntityType)MoCEntities.WYVERN.get(), 12, 1, 3).addBiomeTags(MoCBiomeTags.IS_WYVERN_LAIR);
    }

    private static void registerMonsterSpawns() {
        MoCSpawnConfig.addSpawn("GreenOgre", 3, MoCCategory.MONSTER, (EntityType)MoCEntities.GREEN_OGRE.get(), 8, 1, 2).addBiomeTags(MoCBiomeTags.IS_PLAINS, MoCBiomeTags.IS_SWAMP, MoCBiomeTags.IS_LUSH, MoCBiomeTags.IS_DEAD, MoCBiomeTags.IS_SPOOKY);
        MoCSpawnConfig.addSpawn("CaveOgre", 3, MoCCategory.MONSTER, (EntityType)MoCEntities.CAVE_OGRE.get(), 5, 1, 2).addBiomeTags(MoCBiomeTags.IS_MOUNTAIN);
        MoCSpawnConfig.addSpawn("FireOgre", 3, MoCCategory.MONSTER, (EntityType)MoCEntities.FIRE_OGRE.get(), 6, 1, 2).addBiomeTags(MoCBiomeTags.IS_NETHER);
        MoCSpawnConfig.addSpawn("CaveScorpion", 3, MoCCategory.MONSTER, (EntityType)MoCEntities.CAVE_SCORPION.get(), 4, 1, 3).addBiomeTags(MoCBiomeTags.IS_MOUNTAIN, MoCBiomeTags.IS_SANDY, MoCBiomeTags.IS_SNOWY, MoCBiomeTags.IS_BADLANDS, MoCBiomeTags.IS_DRY, MoCBiomeTags.IS_HOT, MoCBiomeTags.IS_DEAD, MoCBiomeTags.IS_SPOOKY);
        MoCSpawnConfig.addSpawn("DirtScorpion", 3, MoCCategory.MONSTER, (EntityType)MoCEntities.DIRT_SCORPION.get(), 6, 1, 3).addBiomeTags(MoCBiomeTags.IS_SANDY, MoCBiomeTags.IS_BADLANDS, MoCBiomeTags.IS_DRY, MoCBiomeTags.IS_HOT);
        MoCSpawnConfig.addSpawn("FireScorpion", 3, MoCCategory.MONSTER, (EntityType)MoCEntities.FIRE_SCORPION.get(), 6, 1, 3).addBiomeTags(MoCBiomeTags.IS_NETHER);
        MoCSpawnConfig.addSpawn("FrostScorpion", 3, MoCCategory.MONSTER, (EntityType)MoCEntities.FROST_SCORPION.get(), 6, 1, 3).addBiomeTags(MoCBiomeTags.IS_SNOWY);
        MoCSpawnConfig.addSpawn("UndeadScorpion", 3, MoCCategory.MONSTER, (EntityType)MoCEntities.UNDEAD_SCORPION.get(), 6, 1, 3).addBiomeTags(MoCBiomeTags.IS_DEAD, MoCBiomeTags.IS_SPOOKY);
        MoCSpawnConfig.addSpawn("BigGolem", 1, MoCCategory.MONSTER, (EntityType)MoCEntities.BIG_GOLEM.get(), 3, 1, 1).addBiomeTags(MoCBiomeTags.IS_SANDY, MoCBiomeTags.IS_HILL, MoCBiomeTags.IS_BADLANDS, MoCBiomeTags.IS_MOUNTAIN, MoCBiomeTags.IS_PLAINS, MoCBiomeTags.IS_DEAD);
        MoCSpawnConfig.addSpawn("MiniGolem", 2, MoCCategory.MONSTER, (EntityType)MoCEntities.MINI_GOLEM.get(), 6, 1, 3).addBiomeTags(MoCBiomeTags.IS_SANDY, MoCBiomeTags.IS_BADLANDS, MoCBiomeTags.IS_MOUNTAIN, MoCBiomeTags.IS_PLAINS, MoCBiomeTags.IS_DEAD);
        MoCSpawnConfig.addSpawn("DarkManticore", 3, MoCCategory.MONSTER, (EntityType)MoCEntities.DARK_MANTICORE.get(), 5, 1, 3).addBiomeTags(MoCBiomeTags.IS_SANDY, MoCBiomeTags.IS_MOUNTAIN, MoCBiomeTags.IS_PLAINS, MoCBiomeTags.IS_SNOWY, MoCBiomeTags.IS_DEAD, MoCBiomeTags.IS_SPOOKY);
        MoCSpawnConfig.addSpawn("FireManticore", 3, MoCCategory.MONSTER, (EntityType)MoCEntities.FIRE_MANTICORE.get(), 8, 1, 3).addBiomeTags(MoCBiomeTags.IS_NETHER);
        MoCSpawnConfig.addSpawn("FrostManticore", 3, MoCCategory.MONSTER, (EntityType)MoCEntities.FROST_MANTICORE.get(), 8, 1, 3).addBiomeTags(MoCBiomeTags.IS_SNOWY);
        MoCSpawnConfig.addSpawn("PlainManticore", 3, MoCCategory.MONSTER, (EntityType)MoCEntities.PLAIN_MANTICORE.get(), 8, 1, 3).addBiomeTags(MoCBiomeTags.IS_SANDY, MoCBiomeTags.IS_MOUNTAIN, MoCBiomeTags.IS_PLAINS);
        MoCSpawnConfig.addSpawn("ToxicManticore", 3, MoCCategory.MONSTER, (EntityType)MoCEntities.TOXIC_MANTICORE.get(), 8, 1, 3).addBiomeTags(MoCBiomeTags.IS_DEAD, MoCBiomeTags.IS_SPOOKY);
        MoCSpawnConfig.addSpawn("Werewolf", 3, MoCCategory.MONSTER, (EntityType)MoCEntities.WEREWOLF.get(), 8, 1, 4).addBiomeTags(MoCBiomeTags.IS_CONIFEROUS, MoCBiomeTags.IS_FOREST);
        MoCSpawnConfig.addSpawn("WWolf", 3, MoCCategory.MONSTER, (EntityType)MoCEntities.WWOLF.get(), 8, 1, 3).addBiomeTags(MoCBiomeTags.IS_FOREST, MoCBiomeTags.IS_SNOWY, MoCBiomeTags.IS_DEAD);
        MoCSpawnConfig.addSpawn("Rat", 2, MoCCategory.MONSTER, (EntityType)MoCEntities.RAT.get(), 7, 1, 2).addBiomeTags(MoCBiomeTags.IS_FOREST, MoCBiomeTags.IS_PLAINS, MoCBiomeTags.IS_BADLANDS, MoCBiomeTags.IS_STEEP);
        MoCSpawnConfig.addSpawn("HellRat", 4, MoCCategory.MONSTER, (EntityType)MoCEntities.HELL_RAT.get(), 6, 1, 4).addBiomeTags(MoCBiomeTags.IS_NETHER);
        MoCSpawnConfig.addSpawn("SilverSkeleton", 4, MoCCategory.MONSTER, (EntityType)MoCEntities.SILVER_SKELETON.get(), 6, 1, 4).addBiomeTags(MoCBiomeTags.IS_SANDY, MoCBiomeTags.IS_SNOWY, MoCBiomeTags.IS_BADLANDS, MoCBiomeTags.IS_PLAINS, MoCBiomeTags.IS_DEAD, MoCBiomeTags.IS_SPOOKY);
        MoCSpawnConfig.addSpawn("Wraith", 3, MoCCategory.MONSTER, (EntityType)MoCEntities.WRAITH.get(), 6, 1, 4).addBiomeTags(MoCBiomeTags.IS_FOREST, MoCBiomeTags.IS_CONIFEROUS, MoCBiomeTags.IS_DEAD, MoCBiomeTags.IS_DENSE, MoCBiomeTags.IS_SPOOKY);
        MoCSpawnConfig.addSpawn("FlameWraith", 3, MoCCategory.MONSTER, (EntityType)MoCEntities.FLAME_WRAITH.get(), 5, 1, 2).addBiomeTags(MoCBiomeTags.IS_NETHER);
        MoCSpawnConfig.addSpawn("HorseMob", 3, MoCCategory.MONSTER, (EntityType)MoCEntities.HORSE_MOB.get(), 8, 1, 3).addBiomeTags(MoCBiomeTags.IS_NETHER, MoCBiomeTags.IS_PLAINS, MoCBiomeTags.IS_SAVANNA, MoCBiomeTags.IS_DEAD, MoCBiomeTags.IS_SPOOKY);
    }

    private static void registerAquaticSpawns() {
        MoCSpawnConfig.addSpawn("Dolphin", 3, MoCCategory.WATER_CREATURE, (EntityType)MoCEntities.DOLPHIN.get(), 6, 2, 4).addBiomeTags(MoCBiomeTags.IS_OCEAN);
        MoCSpawnConfig.addSpawn("Shark", 3, MoCCategory.WATER_CREATURE, (EntityType)MoCEntities.SHARK.get(), 6, 1, 2).addBiomeTags(MoCBiomeTags.IS_OCEAN);
        MoCSpawnConfig.addSpawn("MantaRay", 3, MoCCategory.WATER_CREATURE, (EntityType)MoCEntities.MANTA_RAY.get(), 10, 1, 2).addBiomeTags(MoCBiomeTags.IS_OCEAN);
        MoCSpawnConfig.addSpawn("Bass", 4, MoCCategory.WATER_CREATURE, (EntityType)MoCEntities.BASS.get(), 10, 1, 4).addBiomeTags(MoCBiomeTags.IS_SWAMP, MoCBiomeTags.IS_RIVER, MoCBiomeTags.IS_FOREST, MoCBiomeTags.IS_PLAINS);
        MoCSpawnConfig.addSpawn("StingRay", 3, MoCCategory.WATER_CREATURE, (EntityType)MoCEntities.STING_RAY.get(), 10, 1, 2).addBiomeTags(MoCBiomeTags.IS_SWAMP, MoCBiomeTags.IS_RIVER);
        MoCSpawnConfig.addSpawn("Anchovy", 6, MoCCategory.WATER_CREATURE, (EntityType)MoCEntities.ANCHOVY.get(), 12, 1, 6).addBiomeTags(MoCBiomeTags.IS_BEACH, MoCBiomeTags.IS_OCEAN, MoCBiomeTags.IS_RIVER);
        MoCSpawnConfig.addSpawn("AngelFish", 6, MoCCategory.WATER_CREATURE, (EntityType)MoCEntities.ANGELFISH.get(), 12, 1, 6).addBiomeTags(MoCBiomeTags.IS_SWAMP, MoCBiomeTags.IS_RIVER, MoCBiomeTags.IS_JUNGLE);
        MoCSpawnConfig.addSpawn("Angler", 6, MoCCategory.WATER_CREATURE, (EntityType)MoCEntities.ANGLER.get(), 12, 1, 6).addBiomeTags(MoCBiomeTags.IS_BEACH, MoCBiomeTags.IS_OCEAN);
        MoCSpawnConfig.addSpawn("ClownFish", 6, MoCCategory.WATER_CREATURE, (EntityType)MoCEntities.CLOWNFISH.get(), 12, 1, 6).addBiomeTags(MoCBiomeTags.IS_BEACH, MoCBiomeTags.IS_OCEAN);
        MoCSpawnConfig.addSpawn("GoldFish", 6, MoCCategory.WATER_CREATURE, (EntityType)MoCEntities.GOLDFISH.get(), 12, 1, 6).addBiomeTags(MoCBiomeTags.IS_RIVER);
        MoCSpawnConfig.addSpawn("HippoTang", 6, MoCCategory.WATER_CREATURE, (EntityType)MoCEntities.HIPPOTANG.get(), 12, 1, 6).addBiomeTags(MoCBiomeTags.IS_BEACH, MoCBiomeTags.IS_OCEAN);
        MoCSpawnConfig.addSpawn("Manderin", 6, MoCCategory.WATER_CREATURE, (EntityType)MoCEntities.MANDERIN.get(), 12, 1, 6).addBiomeTags(MoCBiomeTags.IS_BEACH, MoCBiomeTags.IS_OCEAN);
        MoCSpawnConfig.addSpawn("Cod", 4, MoCCategory.WATER_CREATURE, (EntityType)MoCEntities.COD.get(), 10, 1, 4).addBiomeTags(MoCBiomeTags.IS_BEACH, MoCBiomeTags.IS_OCEAN);
        MoCSpawnConfig.addSpawn("Salmon", 4, MoCCategory.WATER_CREATURE, (EntityType)MoCEntities.SALMON.get(), 10, 1, 4).addBiomeTags(MoCBiomeTags.IS_BEACH, MoCBiomeTags.IS_WATER, MoCBiomeTags.IS_OCEAN, MoCBiomeTags.IS_RIVER, MoCBiomeTags.IS_FOREST, MoCBiomeTags.IS_PLAINS);
        MoCSpawnConfig.addSpawn("Piranha", 4, MoCCategory.WATER_CREATURE, (EntityType)MoCEntities.PIRANHA.get(), 4, 1, 3).addBiomeTags(MoCBiomeTags.IS_SWAMP, MoCBiomeTags.IS_JUNGLE, MoCBiomeTags.IS_LUSH);
        MoCSpawnConfig.addSpawn("JellyFish", 4, MoCCategory.WATER_CREATURE, (EntityType)MoCEntities.JELLYFISH.get(), 8, 1, 4).addBiomeTags(MoCBiomeTags.IS_OCEAN);
        MoCSpawnConfig.addSpawn("Fishy", 6, MoCCategory.WATER_CREATURE, (EntityType)MoCEntities.FISHY.get(), 12, 1, 6).addBiomeTags(MoCBiomeTags.IS_BEACH, MoCBiomeTags.IS_WATER, MoCBiomeTags.IS_OCEAN, MoCBiomeTags.IS_RIVER, MoCBiomeTags.IS_FOREST, MoCBiomeTags.IS_PLAINS);
    }

    private static void registerAmbientSpawns() {
        MoCSpawnConfig.addSpawn("Ant", 4, MoCCategory.AMBIENT, (EntityType)MoCEntities.ANT.get(), 12, 1, 4).addBiomeTags(MoCBiomeTags.IS_FOREST, MoCBiomeTags.IS_JUNGLE, MoCBiomeTags.IS_BADLANDS, MoCBiomeTags.IS_PLAINS, MoCBiomeTags.IS_SWAMP, MoCBiomeTags.IS_HOT, MoCBiomeTags.IS_DRY, MoCBiomeTags.IS_LUSH, MoCBiomeTags.IS_SPARSE, MoCBiomeTags.IS_STEEP);
        MoCSpawnConfig.addSpawn("Firefly", 3, MoCCategory.AMBIENT, (EntityType)MoCEntities.FIREFLY.get(), 6, 1, 3).addBiomeTags(MoCBiomeTags.IS_SWAMP, MoCBiomeTags.IS_FOREST, MoCBiomeTags.IS_JUNGLE, MoCBiomeTags.IS_LUSH, MoCBiomeTags.IS_WYVERN_LAIR);
        MoCSpawnConfig.addSpawn("Crab", 3, MoCCategory.AMBIENT, (EntityType)MoCEntities.CRAB.get(), 6, 1, 2).addBiomeTags(MoCBiomeTags.IS_BEACH);
        MoCSpawnConfig.addSpawn("Snail", 2, MoCCategory.AMBIENT, (EntityType)MoCEntities.SNAIL.get(), 8, 1, 3).addBiomeTags(MoCBiomeTags.IS_SWAMP, MoCBiomeTags.IS_JUNGLE, MoCBiomeTags.IS_LUSH);
        MoCSpawnConfig.addSpawn("Dragonfly", 3, MoCCategory.AMBIENT, (EntityType)MoCEntities.DRAGONFLY.get(), 6, 1, 3).addBiomeTags(MoCBiomeTags.IS_SWAMP, MoCBiomeTags.IS_FOREST, MoCBiomeTags.IS_JUNGLE, MoCBiomeTags.IS_LUSH, MoCBiomeTags.IS_WYVERN_LAIR);
        MoCSpawnConfig.addSpawn("Butterfly", 3, MoCCategory.AMBIENT, (EntityType)MoCEntities.BUTTERFLY.get(), 6, 1, 3).addBiomeTags(MoCBiomeTags.IS_FOREST, MoCBiomeTags.IS_JUNGLE, MoCBiomeTags.IS_PLAINS, MoCBiomeTags.IS_LUSH, MoCBiomeTags.IS_SAVANNA);
        MoCSpawnConfig.addSpawn("Bee", 3, MoCCategory.AMBIENT, (EntityType)MoCEntities.BEE.get(), 6, 1, 3).addBiomeTags(MoCBiomeTags.IS_FOREST, MoCBiomeTags.IS_JUNGLE, MoCBiomeTags.IS_PLAINS, MoCBiomeTags.IS_LUSH, MoCBiomeTags.IS_SAVANNA);
        MoCSpawnConfig.addSpawn("Fly", 3, MoCCategory.AMBIENT, (EntityType)MoCEntities.FLY.get(), 6, 1, 3).addBiomeTags(MoCBiomeTags.IS_SWAMP, MoCBiomeTags.IS_PLAINS, MoCBiomeTags.IS_FOREST);
        MoCSpawnConfig.addSpawn("Cricket", 2, MoCCategory.AMBIENT, (EntityType)MoCEntities.CRICKET.get(), 10, 1, 2).addBiomeTags(MoCBiomeTags.IS_FOREST, MoCBiomeTags.IS_JUNGLE, MoCBiomeTags.IS_PLAINS, MoCBiomeTags.IS_SWAMP);
        MoCSpawnConfig.addSpawn("Grasshopper", 2, MoCCategory.AMBIENT, (EntityType)MoCEntities.GRASSHOPPER.get(), 10, 1, 2).addBiomeTags(MoCBiomeTags.IS_FOREST, MoCBiomeTags.IS_JUNGLE, MoCBiomeTags.IS_PLAINS, MoCBiomeTags.IS_SAVANNA, MoCBiomeTags.IS_WYVERN_LAIR);
        MoCSpawnConfig.addSpawn("Maggot", 2, MoCCategory.AMBIENT, (EntityType)MoCEntities.MAGGOT.get(), 6, 1, 3).addBiomeTags(MoCBiomeTags.IS_SWAMP, MoCBiomeTags.IS_DEAD, MoCBiomeTags.IS_SPOOKY);
        MoCSpawnConfig.addSpawn("Roach", 2, MoCCategory.AMBIENT, (EntityType)MoCEntities.ROACH.get(), 6, 1, 3).addBiomeTags(MoCBiomeTags.IS_DEAD, MoCBiomeTags.IS_SPOOKY, MoCBiomeTags.IS_HOT);
    }

    private static MoCSpawnData addSpawn(String name, int frequency, MobCategory category, EntityType<?> entityType, int weight, int minCount, int maxCount) {
        MoCSpawnData data = new MoCSpawnData(name, frequency, category, entityType, weight, minCount, maxCount);
        SPAWN_DATA.add(data);
        return data;
    }

    private static MoCSpawnData addSpawn(String name, int frequency, EntityType<?> entityType, int weight, int minCount, int maxCount) {
        return MoCSpawnConfig.addSpawn(name, frequency, MobCategory.CREATURE, entityType, weight, minCount, maxCount);
    }

    public static List<MoCSpawnData> getSpawnData() {
        if (SPAWN_DATA.isEmpty()) {
            MoCSpawnConfig.init();
        }
        return SPAWN_DATA;
    }

    public static void register() {
        MoCSpawnConfig.registerAmbientSpawns();
        MoCSpawnConfig.registerAquaticSpawns();
        MoCSpawnConfig.registerMonsterSpawns();
        MoCSpawnConfig.registerAnimalSpawns();
    }

    private static class MoCCategory {
        public static final MobCategory CREATURE = MobCategory.CREATURE;
        public static final MobCategory MONSTER = MobCategory.MONSTER;
        public static final MobCategory AMBIENT = MobCategory.AMBIENT;
        public static final MobCategory WATER_CREATURE = MobCategory.WATER_CREATURE;
        public static final MobCategory UNDERGROUND_WATER_CREATURE = MobCategory.UNDERGROUND_WATER_CREATURE;

        private MoCCategory() {
        }
    }
}

